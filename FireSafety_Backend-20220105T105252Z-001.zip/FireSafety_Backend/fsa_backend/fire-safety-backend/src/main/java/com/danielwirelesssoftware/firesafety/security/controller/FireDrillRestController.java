package com.danielwirelesssoftware.firesafety.security.controller;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.quartz.*;
//import org.quartz.JobBuilder;
//import org.quartz.JobDataMap;
//import org.quartz.JobDetail;
//import org.quartz.Scheduler;
//import org.quartz.SchedulerException;
//import org.quartz.SimpleScheduleBuilder;
//import org.quartz.Trigger;
//import org.quartz.TriggerBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mobile.device.Device;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.danielwirelesssoftware.firesafety.common.utils.TimeProvider;
import com.danielwirelesssoftware.firesafety.model.ConfigurationsDetail;
import com.danielwirelesssoftware.firesafety.model.FireDrillAttendanceDetail;
import com.danielwirelesssoftware.firesafety.model.FireDrillDetail;
import com.danielwirelesssoftware.firesafety.model.FireDrillEndDetail;
import com.danielwirelesssoftware.firesafety.model.FireDrillScheduleDetail;
import com.danielwirelesssoftware.firesafety.model.FireDrillTypeDetail;
import com.danielwirelesssoftware.firesafety.model.FireDrillWardenAttendanceDetail;
import com.danielwirelesssoftware.firesafety.model.TenantEmployeeDetail;
import com.danielwirelesssoftware.firesafety.model.requestModel.RequestForAttendanceAccess;
import com.danielwirelesssoftware.firesafety.model.requestModel.RequestForAttendanceRemove;
import com.danielwirelesssoftware.firesafety.model.requestModel.RequestForFDAUpdate;
import com.danielwirelesssoftware.firesafety.model.requestModel.RequestForFireDrillCreate;
import com.danielwirelesssoftware.firesafety.model.requestModel.RequestWithFireDrillId;
import com.danielwirelesssoftware.firesafety.model.requestModel.RequestForFireDrillEnd;
import com.danielwirelesssoftware.firesafety.model.requestModel.RequestWithBuildingRoleId;
import com.danielwirelesssoftware.firesafety.model.responseModel.ResponseForFireDrillAccess;
import com.danielwirelesssoftware.firesafety.model.responseModel.ResponseForGeneral;
import com.danielwirelesssoftware.firesafety.model.PastFireDrillAccessDetail;
import com.danielwirelesssoftware.firesafety.model.responseModel.ResponseForAttendanceAccess;
import com.danielwirelesssoftware.firesafety.model.responseModel.ResponseForNewFireDrillGenerate;
import com.danielwirelesssoftware.firesafety.model.responseModel.ResponseForPastFireDrillDetailsAccess;
import com.danielwirelesssoftware.firesafety.model.responseModel.ResponseForPastFireDrillAccess;
import com.danielwirelesssoftware.firesafety.model.security.Building;
import com.danielwirelesssoftware.firesafety.model.security.BuildingRole;
import com.danielwirelesssoftware.firesafety.model.security.Configurations;
import com.danielwirelesssoftware.firesafety.model.security.FireDrillAttendance;
import com.danielwirelesssoftware.firesafety.model.security.FireDrillSchedule;
import com.danielwirelesssoftware.firesafety.model.security.FireDrillType;
import com.danielwirelesssoftware.firesafety.model.security.MessageType;
import com.danielwirelesssoftware.firesafety.model.security.Role;
import com.danielwirelesssoftware.firesafety.model.security.Tenant;
import com.danielwirelesssoftware.firesafety.model.security.TenantEmployee;
import com.danielwirelesssoftware.firesafety.model.security.User;
import com.danielwirelesssoftware.firesafety.security.JwtUser;
import com.danielwirelesssoftware.firesafety.security.repository.BuildingRoleRepository;
import com.danielwirelesssoftware.firesafety.security.repository.ConfigurationsRepository;
import com.danielwirelesssoftware.firesafety.security.repository.FireDrillAttendanceRepository;
import com.danielwirelesssoftware.firesafety.security.repository.FireDrillScheduleRepository;
import com.danielwirelesssoftware.firesafety.security.repository.FireDrillTypeRepository;
import com.danielwirelesssoftware.firesafety.security.repository.MessageTypeRepository;
import com.danielwirelesssoftware.firesafety.security.repository.RoleRepository;
import com.danielwirelesssoftware.firesafety.security.repository.TenantEmployeeRepository;
import com.danielwirelesssoftware.firesafety.security.repository.TenantRepository;
import com.danielwirelesssoftware.firesafety.security.repository.UserRepository;
import com.danielwirelesssoftware.firesafety.security.service.FCMService;
import com.danielwirelesssoftware.firesafety.security.service.JobBuilderService;
import com.danielwirelesssoftware.firesafety.security.service.MessageService;
import com.danielwirelesssoftware.firesafety.security.service.EmailService;
import com.danielwirelesssoftware.firesafety.security.service.ScheduleFireDrillService;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.SUCCESS;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.DELETE_FALSE;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.DELETE_TRUE;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.STATUS_ABSENT;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.STATUS_PRESENT;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.STATUS_OPEN;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.STATUS_CLOSE;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.STATUS_NOT_PARTICIPATING;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.FIREDRILL_TYPEID_DRY_RUN;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.FIREDRILL_TYPEID_FIREDRILL;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.FIREDRILL_TYPEID_REAL_FIRE;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.MESSAGE_TYPE_FIREDRILL_SCHEDULE;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.MESSAGE_TYPE_FIREDRILL_DRY_RUN;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.MESSAGE_TYPE_FIRE_ACTIVATION;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.MESSAGE_TYPE_FIREDRILL_DELETE;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.MESSAGE_TYPE_FIREDRILL_END;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.ACTION_FIREDRILL_SCHEDULED;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.ACTION_FIREDRILL_START;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.ACTION_FIREDRILL_END;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.ACTION_FIREDRILL_DELETE;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.ROLEID_FIRE_WARDEN;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.ROLE_FIRE_SAFETY_MANAGER;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.ROLE_BUILDING_MANAGER;


@RestController
public class FireDrillRestController {

    private final Log logger = LogFactory.getLog(this.getClass());
    
    @Autowired
    private BuildingRoleRepository buildingRoleRepository;
    
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private RoleRepository roleRepository;
    
    @Autowired
    private FireDrillTypeRepository fireDrillTypeRepository;
    
    @Autowired
    private FireDrillAttendanceRepository fireDrillAttendanceRepository;
    
    @Autowired
    private FireDrillScheduleRepository fireDrillScheduleRepository;
    
    @Autowired
    private TenantRepository tenantRepository;
    
    @Autowired
    private TenantEmployeeRepository tenantEmployeeRepository;
    
    @Autowired
    private ConfigurationsRepository configurationsRepository;
    
    @Autowired
    private MessageTypeRepository messageTypeRepository;
    
    @Autowired
    private Scheduler scheduler;
    
    @Autowired
    private TimeProvider timeProvider;
    
    @Autowired
    private FCMService fcmService;
    
    @Autowired
    private MessageService messageService;
    
    @Autowired
    private EmailService emailService;
    
    @Autowired
    private ScheduleFireDrillService scheduleFireDrillService;
  
    @Autowired
	private JobBuilderService jobBuilderService;
    
    @RequestMapping(value = "/accessFireDrill", method = RequestMethod.POST)
    public ResponseEntity<?> fireDrillAccess(@RequestBody RequestWithBuildingRoleId request, Device device){
    	
    	BuildingRole buildingRole = null;
    	buildingRole = buildingRoleRepository.findByBuildingRoleIdAndDeleted(request.getBuildingRoleId(),DELETE_FALSE);

    	if(buildingRole == null){
    		logger.error("/accessFireDrill, buildingRoleId : "+ request.getBuildingRoleId() +" is invalid");
    		return new ResponseEntity<>("buildingRole not found", HttpStatus.BAD_REQUEST);
    	}
    	
    	if(buildingRole.getBuilding().isDeleted()){
    		logger.error("/accessFireDrill, building : "+ buildingRole.getBuilding().getBuildingId() +" is deleted");
    		return new ResponseEntity<>("building not found", HttpStatus.BAD_REQUEST);
    	}
    	
    	//get all fireDrillSchedule base on buildingRole's building
    	List<FireDrillSchedule> fdsList = buildingRole.getBuilding().getFdsList();    	
    	List<FireDrillScheduleDetail> fireDrillDetailList = new ArrayList<FireDrillScheduleDetail>();
    	
    	//remove if fireDrill is completed or deleted
    	for(FireDrillSchedule f:fdsList){ 
    		if(!f.isDeleted() && f.getCompleteDateTime() == null){
    			logger.debug("id: "+f.getFireDrillId() +", dateTime: "+ f.getScheduleDateTime());
    			
    			FireDrillScheduleDetail fdd = new FireDrillScheduleDetail(f.getFireDrillId(),
    														f.getScheduleDateTime(),
    														f.getStartDateTime(),
    														f.getDescription(),
    														null);
    			fireDrillDetailList.add(fdd);   			
    		}    		
    	}
    	
    	Collections.sort(fireDrillDetailList);
    	
    	logger.debug("firedrill group: "+buildingRole.getRole().getFireDrillAuthorityGroup());
    	logger.debug("getrole roleName: "+buildingRole.getRole().getRoleName());
    	logger.debug("building getname: "+buildingRole.getBuilding().getName());
    	
        //set response
    	ResponseForFireDrillAccess response = new ResponseForFireDrillAccess(
    												buildingRole.getRole().getFireDrillAuthorityGroup(),
    												buildingRole.getRole().getFireDrillAttendanceGroup(),
    												buildingRole.getRole().getFireDrillStartGroup(),
    												buildingRole.getBuilding().getName(),
    												fireDrillDetailList);
        
        return new ResponseEntity<ResponseForFireDrillAccess>(response, HttpStatus.OK);
    }
    
    
    @RequestMapping(value = "/generateNewFireDrill", method = RequestMethod.POST)
    public ResponseEntity<?> newFireDrillGenerate(){

    	List<FireDrillType> fireDrillScheduleList = fireDrillTypeRepository.findAll();
    	
    	List<FireDrillTypeDetail> fireDrillScheduleDetailList = new ArrayList<FireDrillTypeDetail>();
    	
    	
    	for(FireDrillType f : fireDrillScheduleList){
    		fireDrillScheduleDetailList.add(new FireDrillTypeDetail(f.getFireDrillTypeId(),
    																f.getFireDrillTypeName()));
    	}
    	
        return new ResponseEntity<List<FireDrillTypeDetail>>(fireDrillScheduleDetailList, HttpStatus.OK);
    }
    

    @RequestMapping(value = "/createFireDrill", method = RequestMethod.POST)
    @Transactional
    public ResponseEntity<?> fireDrillCreate(@RequestBody RequestForFireDrillCreate request,
    											@AuthenticationPrincipal final JwtUser principle, Device device){
    	BuildingRole buildingRole = null;
    	FireDrillType fireDrillType = null;
		long now = timeProvider.timestampToLong(timeProvider.timestampNow());
		try{
			if(request.getBuildingRoleId() <= 0L){
				logger.error("//createFireDrill, invalid input for buildingRole");
				return new ResponseEntity<>("invalid buildingRole", HttpStatus.BAD_REQUEST);
			}
			if(request.getFireDrillTypeId() <= 0L){
				logger.error("//createFireDrill, invalid input for fireDrillTypeId");
				return new ResponseEntity<>("invalid fireDrillTypeId", HttpStatus.BAD_REQUEST);
			}
			
			if(request.getScheduleDateTime() <= 0L){
				logger.error("//createFireDrill, invalid input for scheduleDateTime");
				return new ResponseEntity<>("invalid scheduleDateTime", HttpStatus.BAD_REQUEST);
			}

		}catch(Exception e){
			logger.error("//createFireDrill, invalid data input");
			return new ResponseEntity<>("invalid data input", HttpStatus.BAD_REQUEST);
		}
		
		
		
    	if((now > request.getScheduleDateTime()) && request.getFireDrillTypeId() != FIREDRILL_TYPEID_REAL_FIRE) {
    		logger.error("//now:"+now);
    		logger.error("//ScheduleDateTime:"+request.getScheduleDateTime());
        	logger.error("//dateTime must be after current time");
        	ResponseForGeneral response = new ResponseForGeneral("dateTime must be after current time");
            return ResponseEntity.badRequest().body(response);
        }
    	
    	if(request.getFireDrillTypeId() == FIREDRILL_TYPEID_REAL_FIRE) {
        	
    		//in case of real fire, give some buffertime to check 
    		if(request.getScheduleDateTime()-TimeUnit.MINUTES.toMillis(5) > now){
        		//overriding request time as its out of sync
        		logger.debug("/createFireDrill, overriding request time as its out of sync"
        					+", current server time:"+timeProvider.timestampNow()
        					+",  mobile time:"+timeProvider.longToTimestamp(request.getScheduleDateTime()));
        		request.setScheduleDateTime(now);
        	}
        }

        logger.info("//dateTime is after current time");
    	
    	buildingRole = buildingRoleRepository.findByBuildingRoleIdAndDeleted(request.getBuildingRoleId(),DELETE_FALSE);
    	fireDrillType = fireDrillTypeRepository.findByFireDrillTypeId(request.getFireDrillTypeId());
    	
    	if(fireDrillType == null){
    		logger.error("//createFireDrill, fireDrillTypeId:"+request.getFireDrillTypeId()+" is invalid");
    		return new ResponseEntity<>("invalid fire drill type", HttpStatus.BAD_REQUEST);
    	}
    	
    	if(buildingRole == null){
    		logger.error("//createFireDrill, buildingRoleId:"+request.getBuildingRoleId()+" is invalid");
    		return new ResponseEntity<>("invalid buildingRole", HttpStatus.BAD_REQUEST);
    	}
    	
    	
    	//get current user
    	User user = userRepository.findByUserIdAndDeleted(principle.getUserId(),DELETE_FALSE);
    	logger.debug("//userID:"+principle.getUserId());
    	logger.debug("ori time"+timeProvider.longToTimestamp(request.getScheduleDateTime()));
    	logger.debug("edited time"+timeProvider.longToTimestamp2(request.getScheduleDateTime()));
    	
    	//create and add new fireDrillSchedule
    	FireDrillSchedule f = new FireDrillSchedule(buildingRole.getBuilding(), request.getDescription(),
    												fireDrillType, STATUS_OPEN, user,
    												timeProvider.longToTimestamp(request.getScheduleDateTime()),
    												timeProvider.timestampNow());
    	fireDrillScheduleRepository.saveAndFlush(f);
    	logger.info("//added fireDrillSchedule");
    	logger.debug("//f:"+f.getBuildingFDS());

    	List<Tenant> tenantList = tenantRepository.findByBuilding(buildingRole.getBuilding());
    	
    	
    	Role fireWardenRole = roleRepository.findByRoleIdAndDeleted(ROLEID_FIRE_WARDEN, DELETE_FALSE);
    	
    	// get firewarden from this building
    	List<BuildingRole> buildingRoleList = buildingRoleRepository.findByBuildingAndRoleAndDeleted(buildingRole.getBuilding(), fireWardenRole, DELETE_FALSE);
    	
    	List<FireDrillAttendance> tobeRemoveList = new ArrayList<FireDrillAttendance>();
    	
    	
    	
    	
    	List<FireDrillAttendance> fireDrillAttendanceList = new ArrayList<FireDrillAttendance>();
    	
    	//loop tenant
    	for(Tenant t:tenantList){
    		//check exist
    		if(!t.isDeleted()){
    			
	    		//loop tenantEmployee
	    		for(TenantEmployee te: t.getTenantEmployeeList()){
	        		
	    			//check exist
	    			if(!te.isDeleted()){
	    				fireDrillAttendanceList.add(new FireDrillAttendance(te, f, STATUS_ABSENT));
	    			}	    			
	        	}
    		}
    	}
    	//2019/8/2 have no idea what is this for
    	//TODO:  find out what is this
//    	for(BuildingRole br: buildingRoleList){
//    		FireDrillAttendance a = new FireDrillAttendance(br.getUser().getTenantEmployee(), f, STATUS_ABSENT);
//    		fireDrillAttendanceList.remove(a);
//    		
//   		 //tobeRemoveList.add();
//   		 //logger.debug("//tobeRemove "+br.getUser().getTenantEmployee().getTenantEmployeeId());
//    	}
//    	
    	
    	
    	
    	logger.debug("//fireDrillAttendanceList length after "+fireDrillAttendanceList.size());
    	//add fireDrillAttendance
    	fireDrillAttendanceRepository.save(fireDrillAttendanceList);
    	logger.debug("//added fireDrillAttandance");
    	logger.debug("//fireDrillAttandanceList length"+fireDrillAttendanceList.size());
    	
    	MessageType messageType = null;
    	
    	if(request.getFireDrillTypeId() == FIREDRILL_TYPEID_FIREDRILL || request.getFireDrillTypeId() == FIREDRILL_TYPEID_DRY_RUN){
    		messageType = messageTypeRepository.findByMessageTypeId(MESSAGE_TYPE_FIREDRILL_SCHEDULE);
    	}
    	
    	if(request.getFireDrillTypeId()==FIREDRILL_TYPEID_REAL_FIRE){
    		messageType = messageTypeRepository.findByMessageTypeId(MESSAGE_TYPE_FIRE_ACTIVATION);
    	}
    	
    	//scheduling fireDrillSchedule
    	try {
    		//initialize counter
    		final AtomicInteger counter = new AtomicInteger();
    		
            if(request.getFireDrillTypeId() == FIREDRILL_TYPEID_REAL_FIRE){
            	
        		//start sending start realFire pushNotification to everyone
        		Thread startRealFire = new Thread(scheduleFireDrillService.fireDrillThread(counter,
        																					buildingRole.getBuilding(),
        																					f,
        																					buildingRole.getBuildingRoleId(),
        																					ACTION_FIREDRILL_START,
        																					messageType,
        																					fireDrillAttendanceList));
        		startRealFire.start();
            }else{
                
            	//schdule fireDrill and send notification/ message
            	Thread scheduleFireDrill = new Thread(scheduleFireDrillService.fireDrillThread(counter,
																								buildingRole.getBuilding(),
																								f,
																								buildingRole.getBuildingRoleId(),
																								ACTION_FIREDRILL_SCHEDULED,
																								messageType,
																								fireDrillAttendanceList));
            	scheduleFireDrill.start();
            	
            	long scheduleTime ;
            	if(request.getScheduleDateTime()+TimeUnit.MINUTES.toMillis(15) > timeProvider.longNow()){
            		
            		scheduleTime= request.getScheduleDateTime()-TimeUnit.MINUTES.toMillis(15);
            		logger.debug("//logging scheduleTime: (-15)"+scheduleTime);
            	}else{
            		scheduleTime = request.getScheduleDateTime();
            		logger.debug("//logging scheduleTime: (ori)"+scheduleTime);
            	}
            	
            	//schedule the date to send notification
            	//set it to 15 minute earlier than the schedule time
            	JobDetail jobDetail = jobBuilderService.buildJobDetail(f);
                Trigger trigger = jobBuilderService.buildJobTrigger(jobDetail, timeProvider.longToDate(scheduleTime));
                scheduler.scheduleJob(jobDetail, trigger);
            }
            
        } catch (SchedulerException e) {
            logger.error("Error scheduling fireDrill for buildingRoleId: "+request.getBuildingRoleId()+", error:", e);

            ResponseForGeneral response = new ResponseForGeneral("Error scheduling fireDrill. Please try later!");
            
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    	logger.info("//scheduled on createFireDrill ");
    	
    	ResponseForGeneral response = new ResponseForGeneral(SUCCESS);
	
    	return new ResponseEntity<ResponseForGeneral>(response, HttpStatus.OK);
    }
    
    
    @RequestMapping(value = "/deleteFireDrill", method = RequestMethod.POST)
    public ResponseEntity<?> fireDrillDelete(@RequestBody RequestWithFireDrillId request,
	  											@AuthenticationPrincipal final JwtUser principle, Device device){
    	logger.debug("FireDrillId: "+request.getFireDrillId());
		logger.debug("getUserId: "+principle.getUserId());
		
		MessageType messageType = null;
		FireDrillSchedule fireDrillSchedule = null;
		fireDrillSchedule = fireDrillScheduleRepository.findByFireDrillId(request.getFireDrillId());
		
		if(fireDrillSchedule == null){
    		logger.error("/deleteFireDrill, fireDrillId : "+ request.getFireDrillId() +" is invalid");
    		return new ResponseEntity<>("fireDrill not found", HttpStatus.BAD_REQUEST);
    	}
		
		
		try{
			fireDrillScheduleRepository.setFixedDeletedAndEditedByAndLastUpdateFor(true, principle.getUserId(), 
	  											timeProvider.timestampNow(),request.getFireDrillId());
			fireDrillSchedule.setDeleted(DELETE_TRUE);
		}catch(Exception e){
			  logger.error("error in deleteFireDrill API : "+e);
			  ResponseForGeneral response = new ResponseForGeneral("fail");
			  return new ResponseEntity<ResponseForGeneral>(response, HttpStatus.BAD_REQUEST);
		}
		
    	messageType = messageTypeRepository.findTopByMessageTypeAndDeletedOrderByMessageTypeIdDesc("Fire Drill Delete",DELETE_FALSE);
    	if(messageType == null){
    		messageType = messageTypeRepository.findByMessageTypeId(MESSAGE_TYPE_FIREDRILL_DELETE);
    	}
		
		//initialize counter
		final AtomicInteger counter = new AtomicInteger();
				
		//TODO: fix null
		Thread deleteFireDrill = new Thread(scheduleFireDrillService.fireDrillThread(counter,
																					fireDrillSchedule.getBuildingFDS(),
																					fireDrillSchedule,
																					fireDrillSchedule.getBuildingFDS().getBuildingId(),
																					ACTION_FIREDRILL_DELETE,
																					messageType,
																					null));
		deleteFireDrill.start();
		
		ResponseForGeneral response = new ResponseForGeneral(SUCCESS);
		  
		return new ResponseEntity<ResponseForGeneral>(response, HttpStatus.OK);
	}
	
    
    @RequestMapping(value = "/accessFireWardenAttendance", method = RequestMethod.POST)
    public ResponseEntity<?> fireWarrentAttendanceAccess(@RequestBody RequestForAttendanceAccess request,
	  											@AuthenticationPrincipal final JwtUser principle, Device device){
    	
    	BuildingRole buildingRole = null;
    	FireDrillSchedule fireDrillSchedule = null;
    	
    	buildingRole = buildingRoleRepository.findByBuildingRoleIdAndDeleted(request.getBuildingRoleId(),DELETE_FALSE);
    	
    	if(buildingRole == null){
    		logger.error("/accessFireWardenAttendance, buildingId : "+ request.getBuildingRoleId() +" is invalid");
    		return new ResponseEntity<>("buildingRole not found", HttpStatus.BAD_REQUEST);
    	}
    	
    	//get fireDrillSchedule
    	fireDrillSchedule = fireDrillScheduleRepository.findByFireDrillId(request.getFireDrillId());
    	
    	if(fireDrillSchedule == null){
    		logger.error("/accessFireWardenAttendance, fireDrillId : "+ request.getFireDrillId() +" is invalid");
    		return new ResponseEntity<>("fireDrill not found", HttpStatus.BAD_REQUEST);
    	}
    	
    	if(!buildingRole.getRole().getFireDrillAttendanceGroup()) {
    		logger.error("/accessFireWardenAttendance, buildingRole role : "+ buildingRole.getRole().getRoleId() +" is not a fire warden");
    		return new ResponseEntity<>("buildingRole not fireWarden", HttpStatus.BAD_REQUEST);
    	}
    	
    	//get the list of attendance
    	List<FireDrillAttendance> fireDrillAttendanceList = fireDrillSchedule.getFireDrillAttendanceList();
        
    	//2019/8/2 updated to remove search by tenantemployee
//    	TenantEmployee tenantEmployee = null;
//    	tenantEmployee = buildingRole.getUser().getTenantEmployee();
//    	
//    	if(tenantEmployee == null){
//    		logger.error("/accessFireWardenAttendance, tenantEmployee is invalid for user: "+buildingRole.getUser().getTenantEmployee());
//    		return new ResponseEntity<>("tenantEmployee not found", HttpStatus.BAD_REQUEST);
//    	}
//    	long tenantId = tenantEmployee.getTenant().getTenantId();
//        String tenantName = tenantEmployee.getTenant().getTenantName();
        
    	//FireDrillAttendance fda = null;
    	List<TenantEmployee> teList= tenantEmployeeRepository.findByUserAndDeleted(buildingRole.getUser(),DELETE_FALSE);
    	TenantEmployee te = null;
    	for(TenantEmployee tes : teList){
    		if(tes.getTenant().getBuilding() == buildingRole.getBuilding())
    			te = tes;
    	}
    	if(te == null){
    		logger.error("/accessFireWardenAttendance, user is not linked to any tenant employee");
    		return new ResponseEntity<>("tenantEmployee not linked", HttpStatus.BAD_REQUEST);
    	}
    	
    	long tenantId = te.getTenant().getTenantId();
    	String tenantName = te.getTenant().getTenantName();
    		
    	List<TenantEmployeeDetail> tenantEmployeeDetailList = new ArrayList<TenantEmployeeDetail>();
    	FireDrillWardenAttendanceDetail fireDrillWardenAttendance = new FireDrillWardenAttendanceDetail(tenantId,tenantName,tenantEmployeeDetailList);
    	
    	for(FireDrillAttendance f:fireDrillAttendanceList){
    		if(f.getTenantEmployee().getTenant().getTenantId() == tenantId 
    				&& !(f.getTenantEmployee().isDeleted()) 
    				&& !f.getStatus().equalsIgnoreCase(STATUS_NOT_PARTICIPATING)){
    			TenantEmployeeDetail t = new TenantEmployeeDetail(f.getTenantEmployee().getTenantEmployeeId(), 
    																f.getTenantEmployee().getTenantEmployeeName(),
    																f.getTenantEmployee().getTitle(),
    																f.getStatus());
    			tenantEmployeeDetailList.add(t);    				
    		}
    		fireDrillWardenAttendance = new FireDrillWardenAttendanceDetail(tenantId,tenantName,tenantEmployeeDetailList);
        }
    	return new ResponseEntity<FireDrillWardenAttendanceDetail>(fireDrillWardenAttendance, HttpStatus.OK);
	}
    
    
    @RequestMapping(value = "/accessAttendance", method = RequestMethod.POST)
    public ResponseEntity<?> attendanceAccess(@RequestBody RequestWithFireDrillId request,
											@AuthenticationPrincipal final JwtUser principle, Device device){
    	
    	//get fireDrillSchedule
    	FireDrillSchedule fireDrillSchedule = fireDrillScheduleRepository.findByFireDrillId(request.getFireDrillId());
    	
    	if(fireDrillSchedule == null){
    		logger.error("/accessAttendance,fireDrillId: "+request.getFireDrillId() +"is invalid");
            return new ResponseEntity<>("fireDrill invalid",HttpStatus.BAD_REQUEST);
    	}
    	
    	//get the list of attendance
    	List<FireDrillAttendance> fireDrillAttendanceList = fireDrillSchedule.getFireDrillAttendanceList();
    	
    	List<FireDrillAttendanceDetail> fireDrillAttendance = new ArrayList<FireDrillAttendanceDetail>();
    	
    		//loop retrieved FireDrillAttendance
    		for(FireDrillAttendance fda:fireDrillAttendanceList){
    			
    			//check tenant and tenantEmployee existence in the list
    			if(fda.getTenantEmployee().isDeleted() || fda.getTenantEmployee().getTenant().isDeleted()){
    				continue;
    			}
    			
    			long tenantId = fda.getTenantEmployee().getTenant().getTenantId();
    			logger.debug("tenantId: "+tenantId);
    			//to check if its added
    			boolean added = false;
    			
    			//loop the tenant list
    			for(FireDrillAttendanceDetail fdad:fireDrillAttendance){
    				
    				//check if tenant exist
    				if (fdad.getTenantId() == tenantId){
    					if(!fda.getStatus().equalsIgnoreCase(STATUS_NOT_PARTICIPATING)){
    						
    						logger.debug("id: "+fda.getFireDrillAttendanceId() +",fdad tenantId: "+ fdad.getTenantId());
        					fdad.setTenantTotalStrength(fdad.getTenantTotalStrength()+1);
        					
        					logger.debug("current total str: "+fdad.getTenantTotalStrength());
        					
        					if(fda.getStatus().equalsIgnoreCase(STATUS_PRESENT)){
        						
        						fdad.setTenantPresentStrength(fdad.getTenantPresentStrength()+1);
        						logger.debug("current present str:"+fdad.getTenantPresentStrength());
        					}
    					}
    					
    					added = true;
    					break;
    					
    				}    				
    			}
    			
    			// not added in the list yet
    			// create tenantEmployee list, create tenantEmployee, add tenantEmployee into list
    			// create a new attendance, add attendance into attendanceList 
    			if(!added){

    				//check the status if not participating, if it is do not add it list

    				if(fda.getStatus().equalsIgnoreCase(STATUS_NOT_PARTICIPATING)){
    					continue;
    				}
    				
    				long presentStrength = 0;
    				long totalStrength = 0;
    				totalStrength+=1;
    				
    				if(fda.getStatus().equalsIgnoreCase(STATUS_PRESENT)){
    					
    					presentStrength+=1;
    					logger.debug("current present str:"+presentStrength + "initialize");
					}
    				
    				FireDrillAttendanceDetail f = new FireDrillAttendanceDetail(fda.getTenantEmployee().getTenant().getTenantId(),
																				fda.getTenantEmployee().getTenant().getTenantName(),
															    				presentStrength,
															    				totalStrength);
    				fireDrillAttendance.add(f);
    				logger.debug("id: "+fda.getFireDrillAttendanceId());
    				logger.debug("just added for tenantId: "+fda.getTenantEmployee().getTenant().getTenantId());
    				logger.debug("total str: "+fireDrillAttendance.get(fireDrillAttendance.size()-1).getTenantTotalStrength());
				}
        	}

        return new ResponseEntity<List<FireDrillAttendanceDetail>>(fireDrillAttendance, HttpStatus.OK);
    }
    
    
    @RequestMapping(value = "/updateFireDrillAttendance", method = RequestMethod.POST)
    public ResponseEntity<?> fireDrillAttendanceUpdate(@RequestBody RequestForFDAUpdate request,
    											@AuthenticationPrincipal final JwtUser principle, Device device){
    	logger.debug("fireDrillId: "+request.getFireDrillId()+", status:"+request.getStatus());
    	
    	FireDrillAttendance fireDrillAttendance = null;
    	TenantEmployee tenantEmployee = null;
    	FireDrillSchedule fireDrillSchedule = null;
    	ResponseForGeneral response = new ResponseForGeneral(SUCCESS);
    	
    	
    	//check valid request status
    	if(!request.getStatus().equalsIgnoreCase(STATUS_PRESENT) 
        	&& !request.getStatus().equalsIgnoreCase(STATUS_ABSENT)
        	&& !request.getStatus().equalsIgnoreCase(STATUS_NOT_PARTICIPATING)){
        	logger.error("/updateFireDrillAttendance, status invalid for status: "+request.getStatus());
            return new ResponseEntity<>("status invalid",HttpStatus.BAD_REQUEST);
       }
    	
    	tenantEmployee = tenantEmployeeRepository.findByTenantEmployeeId(request.getTenantEmployeeId());
    	fireDrillSchedule = fireDrillScheduleRepository.findByFireDrillId(request.getFireDrillId());
    	
    	//check valid tenantEmployee/ fireDrill Schedule status
    	if(tenantEmployee == null || fireDrillSchedule == null 
    		|| tenantEmployee.isDeleted() || fireDrillSchedule.isDeleted()){
    		logger.error("/updateFireDrillAttendance, request tenantEmployeeId or fireDrillScheduleId is invalid");
    		return new ResponseEntity<>("request id invalid",HttpStatus.BAD_REQUEST);
    	}
    	
    	fireDrillAttendance = fireDrillAttendanceRepository.findByTenantEmployeeAndFireDrillSchedule(tenantEmployee, fireDrillSchedule);
    	
    	//check valid fireDrillAttendance
    	if(fireDrillAttendance == null){
        	logger.error("/updateFireDrillAttendance, fireDrillAttendance is invalid");
        	return new ResponseEntity<>("fireDrillAttendance invalid",HttpStatus.BAD_REQUEST);
        }
    	
    	//check if its completed
    	if(fireDrillAttendance.getFireDrillSchedule().getCompleteDateTime() != null){
    		logger.error("/updateFireDrillAttendance, fireDrillSchedule for fireDrillScheduleId: "
    						+ fireDrillAttendance.getFireDrillSchedule().getFireDrillId() + " is completed, no updating allow");
        	return new ResponseEntity<ResponseForGeneral>(response, HttpStatus.OK);
    	}
    	
    	//do checking for status, if current status is not participating, do not update
    	if(request.getStatus().equalsIgnoreCase(STATUS_PRESENT) || request.getStatus().equalsIgnoreCase(STATUS_ABSENT)){
    		if(fireDrillAttendance.getStatus().equalsIgnoreCase(STATUS_NOT_PARTICIPATING)){
    			return new ResponseEntity<ResponseForGeneral>(response, HttpStatus.OK);
    		}
    	}

    	try{
    		fireDrillAttendanceRepository.setStatusFor(request.getStatus(),fireDrillAttendance.getFireDrillAttendanceId());
    		fireDrillScheduleRepository.setLastAttendanceUpdateFor(fireDrillAttendance.getFireDrillSchedule().getFireDrillId());
    	}catch(Exception e){
    		logger.error("/updateFireDrillAttendance, error updating status: " + e);
    		return new ResponseEntity<>("error updating",HttpStatus.BAD_REQUEST);
    	}
    	
//    	List<Role> roleList = roleRepository.findByFireDrillAttendanceGroupAndDeletedOrFireDrillAuthorityGroupAndDeletedOrFireDrillStartGroupAndDeleted(true,
//    																																					DELETE_FALSE,
//    																																					true,
//    																																					DELETE_FALSE,
//    																																					true,
//    																																					DELETE_FALSE);
//		
//		for(Role r : roleList){
//			buildingRoleList.addAll(buildingRoleRepository.findByBuildingAndRoleAndDeleted(fireDrillSchedule.getBuildingFDS(),r,DELETE_FALSE));
//		}
//
//		Thread sendUpdateNotification = new Thread(messageService.updateFireDrillThread(buildingRoleList,fireDrillSchedule.getFireDrillId()));
//		sendUpdateNotification.start();
    	
    	
    	return new ResponseEntity<ResponseForGeneral>(response, HttpStatus.OK);
    }
    
    
    @RequestMapping(value = "/removeAttendance", method = RequestMethod.POST)
    public ResponseEntity<?> attendanceRemove(@RequestBody RequestForAttendanceRemove request,
    											@AuthenticationPrincipal final JwtUser principle, Device device){
    	//get fireDrillSchedule
    	FireDrillSchedule fireDrillSchedule = null;
    	List<BuildingRole> buildingRoleList = new ArrayList<BuildingRole>();
    	int i = 0;
    	//List<FireDrillAttendance> newFireDrillAttendanceList = new ArrayList<FireDrillAttendance>();
    	fireDrillSchedule = fireDrillScheduleRepository.findByFireDrillIdAndDeletedAndCompleteDateTimeIsNull(request.getFireDrillId(),DELETE_FALSE);
    	
    	if(fireDrillSchedule == null){
    		logger.error("/removeAttendance,schedule invalid for fireDrillId: "+request.getFireDrillId());
            return new ResponseEntity<>("fireDrill invalid",HttpStatus.BAD_REQUEST);
    	}

    	//update the tenantEmployee to not pariticating
    	for(FireDrillAttendance fda : fireDrillSchedule.getFireDrillAttendanceList()){
    		if (fda.getTenantEmployee().getTenant().getTenantId() == request.getTenantId()){
    			fireDrillAttendanceRepository.setStatusFor(STATUS_NOT_PARTICIPATING, fda.getFireDrillAttendanceId());
    			i++;
    		}
    	}
    	
    	logger.info("/removeAttendance, total attendance updated: " + i + " for ScheduleId: " + fireDrillSchedule.getFireDrillId());
    	
    	
    	List<Role> roleList = roleRepository.findByFireDrillAttendanceGroupAndDeletedOrFireDrillAuthorityGroupAndDeletedOrFireDrillStartGroupAndDeleted(true,
    																																					DELETE_FALSE,
    																																					true,
    																																					DELETE_FALSE,
    																																					true,
    																																					DELETE_FALSE);
		
		for(Role r : roleList){
			buildingRoleList.addAll(buildingRoleRepository.findByBuildingAndRoleAndDeleted(fireDrillSchedule.getBuildingFDS(),r,DELETE_FALSE));
		}

		Thread sendUpdateNotification = new Thread(messageService.updateFireDrillThread(buildingRoleList,fireDrillSchedule.getFireDrillId()));
		sendUpdateNotification.start();
		
    	return new ResponseEntity<ResponseForGeneral>(new ResponseForGeneral(SUCCESS),HttpStatus.OK);
    }
    
    
    
    @RequestMapping(value = "/endFireDrill", method = RequestMethod.POST)
    public ResponseEntity<?> fireDrillEnd(@RequestBody RequestForFireDrillEnd request,
    											@AuthenticationPrincipal final JwtUser principle, Device device){
    	
    	logger.info("/endFireDrill, fireDrillId: "+request.getFireDrillId()+", completeDateTime: "+request.getCompleteDateTime());
    	
    	FireDrillSchedule fireDrillSchedule = null;
    	MessageType messageType = null;
    	BuildingRole buildingRole = null;
    	Thread endFireDrill = new Thread();
    	Timestamp completeDateTime = null;
    	
    	//initialize counter
		final AtomicInteger counter = new AtomicInteger();
    	
		buildingRole = buildingRoleRepository.findByBuildingRoleIdAndDeleted(request.getBuildingRoleId(), DELETE_FALSE);
		
		if(buildingRole == null){
    		logger.error("/endFireDrill, buildingId : "+ request.getBuildingRoleId() +" is invalid");
    		return new ResponseEntity<>("buildingRole not found", HttpStatus.BAD_REQUEST);
    	}
		
		if(!buildingRole.getRole().getFireDrillStartGroup()){
			logger.error("/endFireDrill, buildingRoleId: "+request.getBuildingRoleId()+" have no authority to start fireDrill");
			return new ResponseEntity<>("no authority to end fireDrill",HttpStatus.FORBIDDEN);
		}
		
		//get fireDrillSchedule
		fireDrillSchedule = fireDrillScheduleRepository.findByFireDrillId(request.getFireDrillId());
		
		if(fireDrillSchedule == null){
			logger.error("/endFireDrill, fireDrillId: "+request.getFireDrillId()+" is invalid");
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
		
		if(request.isNeedToDoPushNotification()){
			logger.info("timeProvider :"+timeProvider.longToTimestamp(request.getCompleteDateTime()));
			
			//fireDrill have not end yet
			if(fireDrillSchedule.getCompleteDateTime() == null){
				
				//create a temp completeDateTime
				completeDateTime = timeProvider.timestampNow();
				fireDrillScheduleRepository.setStatusAndEditedBy(STATUS_CLOSE, principle.getUserId(), request.getFireDrillId());
			}
			
			if(messageType == null){
				messageType = messageTypeRepository.findByMessageTypeId(MESSAGE_TYPE_FIREDRILL_END);
			}
			
	    	
			//TODO: fix null
			//start sending end fireDrill pushNotification to everyone
			endFireDrill = new Thread(scheduleFireDrillService.fireDrillThread(counter, 
																						fireDrillSchedule.getBuildingFDS(),
																						fireDrillSchedule, 
																						request.getBuildingRoleId(),
																						ACTION_FIREDRILL_END,
																						messageType,
																						null));
	    	endFireDrill.start();
		}
    	
    	
		//get the list of attendance
		List<FireDrillAttendance> fireDrillAttendanceList = fireDrillSchedule.getFireDrillAttendanceList();
		
		List<FireDrillAttendanceDetail> fireDrillAttendance = new ArrayList<FireDrillAttendanceDetail>();

		HashMap<String, String> attendanceList = new HashMap<String, String>();
		long presentStrength = 0;
		//loop retrieved FireDrillAttendance
		for(FireDrillAttendance fda:fireDrillAttendanceList){
			
			//check tenant and tenantEmployee existence in the list
			//check if the participant is not participating
			if(fda.getTenantEmployee().isDeleted() 
				|| fda.getTenantEmployee().getTenant().isDeleted() 
				|| fda.getStatus().equals(STATUS_NOT_PARTICIPATING)){
				continue;
			}
				
			long tenantId = fda.getTenantEmployee().getTenant().getTenantId();    			
			
			//to check if its added
			boolean added = false;
				
			//loop the tenant list
			for(FireDrillAttendanceDetail fdad:fireDrillAttendance){
				
				//check if tenant exist
				if (fdad.getTenantId() == tenantId){
					fdad.setTenantTotalStrength(fdad.getTenantTotalStrength()+1);
					attendanceList.put(fda.getTenantEmployee().getTenantEmployeeName(), fda.getStatus());
					if(fda.getStatus().equalsIgnoreCase(STATUS_PRESENT)){
						fdad.setTenantPresentStrength(fdad.getTenantPresentStrength()+1);
					}
					added = true;
					break;
				}    				
			}
			
			// not added in the list yet
			// create tenantEmployee list, create tenantEmployee, add tenantEmployee into list
			// create a new attendance, add attendance into attendanceList 
			if(!added){
				
				attendanceList.put(fda.getTenantEmployee().getTenantEmployeeName(), fda.getStatus());
				
				
				if(fda.getStatus().equalsIgnoreCase(STATUS_PRESENT)){
					presentStrength+=1;
				}
				
				FireDrillAttendanceDetail f = new FireDrillAttendanceDetail(fda.getTenantEmployee().getTenant().getTenantId(),
																			fda.getTenantEmployee().getTenant().getTenantName(),
														    				presentStrength,
														    				1);
				fireDrillAttendance.add(f);
			}
	    }
		
		//overwrite the temp completeDateTime with the database completeDateTime
		if ( fireDrillSchedule.getCompleteDateTime() != null ){
			completeDateTime = fireDrillSchedule.getCompleteDateTime();
		}
		
		FireDrillEndDetail fireDrillEnd = new FireDrillEndDetail(fireDrillAttendance, completeDateTime);
		
		if(request.isNeedToDoPushNotification()){
			try {
				endFireDrill.join();
			} catch (InterruptedException e) {
				e.printStackTrace();
				logger.info("/endFireDrill, error getting push notif count:"+e);
			}
			logger.info("//endFireDrill: total Push notification sent: "+counter.intValue());
		}
		
		logger.info("/endFireDrill for user:"+buildingRole.getUser().getDisplayName()+", "+fireDrillEnd.toString());
		//send email report to relevant user
		Thread sendAttendanceEmail = new Thread();
		sendAttendanceEmail = new Thread(emailService.sendAttendanceReportEmailThread(buildingRole.getBuilding(), presentStrength, fireDrillSchedule.getFireDrillType().getFireDrillTypeName(), fireDrillSchedule.getStartDateTime().toString(), completeDateTime.toString(), attendanceList));
		sendAttendanceEmail.start();
		
//		List<BuildingRole> brList = buildingRoleRepository.findByBuildingAndDeleted(buildingRole.getBuilding(), DELETE_FALSE);
//		for(BuildingRole br: brList){
//			if(br.getRole().getRoleName().equalsIgnoreCase(ROLE_FIRE_SAFETY_MANAGER) 
//					|| br.getRole().getRoleName().equalsIgnoreCase(ROLE_BUILDING_MANAGER))
//				if(!br.getUser().getEmail().isEmpty()){
//					emailService.sendAttendanceReportEmail (br.getUser(), presentStrength, fireDrillSchedule.getBuildingFDS().getName(), fireDrillSchedule.getFireDrillType().getFireDrillTypeName(), completeDateTime.toString(), attendanceList);	
//				}
//			}
			
	    return new ResponseEntity<FireDrillEndDetail>(fireDrillEnd, HttpStatus.OK);
    }
    
    
    @RequestMapping(value = "/accessTrainingVideo", method = RequestMethod.POST)
    public ResponseEntity<?> trainingVideoAccess(){
    	
    	Configurations c = configurationsRepository.findTopByOrderByLastUpdateDesc();
        ConfigurationsDetail trainingVideo = new ConfigurationsDetail(c.getConfigurationId(),
        																c.getTrainingName(),
        																c.getTrainingURL());
    	
        return new ResponseEntity<ConfigurationsDetail>(trainingVideo, HttpStatus.OK);
    }
    
    
    @RequestMapping(value = "/accessPastFireDrill", method = RequestMethod.POST)
    public ResponseEntity<?> accessPastFireDrill(@RequestBody RequestWithBuildingRoleId request){
    	
    	BuildingRole buildingRole = null;
    	buildingRole = buildingRoleRepository.findByBuildingRoleIdAndDeleted(request.getBuildingRoleId(),DELETE_FALSE);
    	
    	if(buildingRole == null){
    		logger.error("/accessPastFireDrill, BuildingRoleId : "+ request.getBuildingRoleId() +" is invalid");
    		return new ResponseEntity<>("buildingRole not found", HttpStatus.BAD_REQUEST);
    	}
    	
    	List<FireDrillSchedule> fdsList = buildingRole.getBuilding().getFdsList();    	
    	List<FireDrillScheduleDetail> fireDrillDetailList = new ArrayList<FireDrillScheduleDetail>();
    	
    	for(FireDrillSchedule f:fdsList){ 
    		if(!f.isDeleted() && f.getCompleteDateTime() != null){
    			FireDrillScheduleDetail fdd = new FireDrillScheduleDetail(f.getFireDrillId(),
    																		f.getScheduleDateTime(),
    																		f.getStartDateTime(),
    																		f.getDescription(),
    																		f.getCompleteDateTime());
    			fireDrillDetailList.add(fdd);   			
    		}    		
    	}
    	
    	Collections.sort(fireDrillDetailList, Collections.reverseOrder());
    	
    	
        //set response
    	ResponseForFireDrillAccess response = new ResponseForFireDrillAccess(buildingRole.getRole().getFireDrillAuthorityGroup(),
    																		buildingRole.getRole().getFireDrillAttendanceGroup(),
    																		buildingRole.getRole().getFireDrillAuthorityGroup(),
    																		buildingRole.getBuilding().getName(),
    																		fireDrillDetailList);
    	return new ResponseEntity<ResponseForFireDrillAccess>(response, HttpStatus.OK);
        //return new ResponseEntity<ResponseForPastFireDrillAccess>(response, HttpStatus.OK);
    	
    }
    
    @RequestMapping(value = "/accessPastFireDrillDetails", method = RequestMethod.POST)
    public ResponseEntity<?> passFireDrillAccessDetailsAccess(@RequestBody long fireDrillId){
    	
    	
	    //get fireDrillSchedule
		FireDrillSchedule fireDrillSchedule = null;
		fireDrillSchedule = fireDrillScheduleRepository.findByFireDrillId(fireDrillId);
		
		if(fireDrillSchedule == null){
    		logger.error("/accessPastFireDrillDetails, fireDrillId: " + fireDrillId +" is invalid");
    		return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
    	}
		
		//get the list of attendance
		List<FireDrillAttendance> fireDrillAttendanceList = fireDrillSchedule.getFireDrillAttendanceList();
		
		List<FireDrillAttendanceDetail> fireDrillAttendance = new ArrayList<FireDrillAttendanceDetail>();
		
			//loop retrieved FireDrillAttendance
			for(FireDrillAttendance fda:fireDrillAttendanceList){
				
				//check tenant and tenantEmployee existence in the list
				//check if the participant is not participating
				if(fda.getTenantEmployee().isDeleted() 
					|| fda.getTenantEmployee().getTenant().isDeleted()
					|| fda.getStatus().equals(STATUS_NOT_PARTICIPATING)){
					continue;
				}
				
				long tenantId = fda.getTenantEmployee().getTenant().getTenantId();    			
				
				//to check if its added
				boolean added = false;
				
				//loop the tenant list
				for(FireDrillAttendanceDetail fdad:fireDrillAttendance){
					
					//check if tenant exist
					if (fdad.getTenantId() == tenantId){
						fdad.setTenantTotalStrength(fdad.getTenantTotalStrength()+1);
						
						if(fda.getStatus().equalsIgnoreCase(STATUS_PRESENT)){
							fdad.setTenantPresentStrength(fdad.getTenantPresentStrength()+1);
						}
						added = true;
					}    				
				}
				
				// not added in the list yet
				// create tenantEmployee list, create tenantEmployee, add tenantEmployee into list
				// create a new attendance, add attendance into attendanceList 
				if(!added){
	
					List<TenantEmployeeDetail> tList = new ArrayList<TenantEmployeeDetail>();
					
					TenantEmployeeDetail t = new TenantEmployeeDetail(fda.getStatus());
					
					tList.add(t);
					
					long presentStrength = 0;
					if(fda.getStatus().equalsIgnoreCase(STATUS_PRESENT)){
						presentStrength+=1;
					}
					
					FireDrillAttendanceDetail f = new FireDrillAttendanceDetail(fda.getTenantEmployee().getTenant().getTenantId(),
																				fda.getTenantEmployee().getTenant().getTenantName(),
															    				presentStrength,
															    				1);
					fireDrillAttendance.add(f);
				}
	    	}
	
	    return new ResponseEntity<List<FireDrillAttendanceDetail>>(fireDrillAttendance, HttpStatus.OK);
   	
    }
    

    @RequestMapping(value = "/startFireDrill", method = RequestMethod.POST)
    public ResponseEntity<?> fireDrillStart(@RequestBody RequestForAttendanceAccess request, @AuthenticationPrincipal final JwtUser principle){
    	
    	FireDrillSchedule fireDrillSchedule = null;
    	fireDrillSchedule = fireDrillScheduleRepository.findByFireDrillIdAndDeletedAndCompleteDateTimeIsNull(
    																										request.getFireDrillId(),
										    																DELETE_FALSE);
    	if(fireDrillSchedule == null){
    		logger.error("/startFireDrill, fireDrillId: " + request.getFireDrillId() 
    						+ " is either completed, deleted or not found");
    		return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
    	}
    	
    	//get buildingId
    	Building building = fireDrillSchedule.getBuildingFDS();
    	
    	// building is deleted
    	if(building.isDeleted()){
    		logger.error("/startFireDrill, buildingId: " + building.getBuildingId() +" is deleted");
    		return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
    	}
    	
    	//check if its started
    	if(fireDrillSchedule.getStartDateTime() != null){
    		logger.info("/startFireDrill, fireDrillSchedule "+fireDrillSchedule.getStartDateTime() + "is started");
    		FireDrillScheduleDetail response = new FireDrillScheduleDetail(fireDrillSchedule.getFireDrillId(),
																			fireDrillSchedule.getScheduleDateTime(),
																			fireDrillSchedule.getStartDateTime(),
																			fireDrillSchedule.getDescription(),
																			fireDrillSchedule.getCompleteDateTime());
    		return new ResponseEntity<FireDrillScheduleDetail>(response,HttpStatus.OK);
    	}
    	
    	//check ongoing fireDrill
    	//check by building, start date time before now, not deleted, complete date time null
    	List<FireDrillSchedule> existedFireDrillSchedule = fireDrillScheduleRepository
    														.findByBuildingFDSAndStartDateTimeBeforeAndDeletedAndCompleteDateTimeIsNull(building, 
    																																timeProvider.timestampNow(), 
    																																DELETE_FALSE);
    	if(existedFireDrillSchedule.size()>0){
    		logger.error("onGoing fireDrill for buildingId: " + building.getBuildingId());
    		return new ResponseEntity<>(HttpStatus.CONFLICT);
    	}
    	
    	MessageType messageType = null;

		if(fireDrillSchedule.getFireDrillType().getFireDrillTypeId() == FIREDRILL_TYPEID_DRY_RUN
				|| fireDrillSchedule.getFireDrillType().getFireDrillTypeId() == FIREDRILL_TYPEID_FIREDRILL){
				messageType = messageTypeRepository.findByMessageTypeId(MESSAGE_TYPE_FIREDRILL_DRY_RUN);
		}
			
		if(fireDrillSchedule.getFireDrillType().getFireDrillTypeId() == FIREDRILL_TYPEID_REAL_FIRE){
			messageType = messageTypeRepository.findByMessageTypeId(MESSAGE_TYPE_FIRE_ACTIVATION);
		}
		
		BuildingRole buildingRole = null;
		buildingRole = buildingRoleRepository.findByBuildingRoleIdAndDeleted(request.getBuildingRoleId(), DELETE_FALSE);
		
		if(!buildingRole.getRole().getFireDrillStartGroup()){
			logger.error("/startFireDrill, buildingRoleId: "+request.getBuildingRoleId()+" have no authority to start fireDrill");
    		return new ResponseEntity<>("no authority to start fireDrill",HttpStatus.FORBIDDEN);
		}
		
		
    	//initialize counter
		final AtomicInteger counter = new AtomicInteger();
		
		
		//TODO: fix 2nd null
    	Thread startFireDrill = new Thread(scheduleFireDrillService.fireDrillThread(counter,
																					building,
																					fireDrillSchedule,
																					request.getBuildingRoleId(),
																					ACTION_FIREDRILL_START,
																					messageType,
																					null));
    	startFireDrill.start();
    	
    	Timestamp now = timeProvider.timestampNow(); 
    	
    	//update fireDrillSchedule
//    	fireDrillScheduleRepository.setStartDateTimeAndEditedFor(now,
//																	principle.getUserId(), 
//																	request.getFireDrillId());
    	fireDrillScheduleRepository.setStartDateTimeAndEditedFor(principle.getUserId(), request.getFireDrillId());
    	
    	
    	//set scheduler to call it 20second later and see if there is any update.
    	 try {
         	JobDetail jobDetail = jobBuilderService.buildJobDetail2(fireDrillSchedule);
         	Trigger trigger = jobBuilderService.buildJobTrigger2(jobDetail, timeProvider.millisecondsLater(20000L));
 			scheduler.scheduleJob(jobDetail, trigger);
 		} catch (SchedulerException e1) {
 			logger.info("err in scheduling: "+e1);
 			e1.printStackTrace();
 		}
    	 
    	//create response
    	FireDrillScheduleDetail response = new FireDrillScheduleDetail(
    																fireDrillSchedule.getFireDrillId(),
    																fireDrillSchedule.getScheduleDateTime(),
    																now,
    																fireDrillSchedule.getDescription(),
    																fireDrillSchedule.getCompleteDateTime());
    	// log the total notification send
    	try {
    		startFireDrill.join();
		} catch (InterruptedException e) {
			logger.info("/startFireDrill, error getting push notif count:"+e);
			e.printStackTrace();
		}
		
    	logger.info("//startFireDrill, total Push notification sent: "+counter.intValue());
        
		return new ResponseEntity<FireDrillScheduleDetail>(response, HttpStatus.OK);
   	
    }
    

}