package com.danielwirelesssoftware.firesafety.model;

public class AttachImageDetail {

    private String attachImages;
    private String attachImageName;

    public AttachImageDetail() {
    }

	public AttachImageDetail(String attachImages, String attachImageName) {
		this.attachImages = attachImages;
		this.attachImageName = attachImageName;
	}

	public String getAttachImages() {
		return attachImages;
	}

	public void setAttachImages(String attachImages) {
		this.attachImages = attachImages;
	}

	public String getAttachImageName() {
		return attachImageName;
	}

	public void setAttachImageName(String attachImageName) {
		this.attachImageName = attachImageName;
	}

	

	
}
