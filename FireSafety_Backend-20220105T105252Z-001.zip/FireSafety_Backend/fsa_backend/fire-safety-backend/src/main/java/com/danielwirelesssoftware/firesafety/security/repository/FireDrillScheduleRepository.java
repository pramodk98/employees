package com.danielwirelesssoftware.firesafety.security.repository;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.danielwirelesssoftware.firesafety.model.security.Building;
import com.danielwirelesssoftware.firesafety.model.security.FireDrillSchedule;

public interface FireDrillScheduleRepository extends JpaRepository<FireDrillSchedule, Long> {

	FireDrillSchedule findByFireDrillId(long fireDrillId);
	
	List<FireDrillSchedule> findByScheduleDateTimeAfterAndStatusAndDeleted(Timestamp dateTime, String status, boolean deleted);
	
	List<FireDrillSchedule> findByBuildingFDSAndStartDateTimeBeforeAndDeletedAndCompleteDateTimeIsNull(Building buildingFDS, Timestamp dateTime, boolean deleted);
	
	FireDrillSchedule findByFireDrillIdAndDeletedAndCompleteDateTimeIsNull(long fireDrillId, boolean deleted);
	
	FireDrillSchedule findByFireDrillIdAndBuildingFDSAndCompleteDateTimeIsNullAndDeleted(long fireDrillId, Building buildingFDS, boolean deleted);
	
	
	@Modifying
	@Transactional
	@Query(value = "update FireDrillSchedule f set f.LastAttendanceUpdate = NOW(3) where f.fireDrillId = ?1", nativeQuery = true)
	int setLastAttendanceUpdateFor(long fireDrillId);
	
//	@Modifying
//	@Transactional
//	@Query(value = "update FireDrillSchedule f set f.startDateTime = ?1, f.editedBy = ?2 where f.fireDrillId = ?3", nativeQuery = true)
//	int setStartDateTimeAndEditedFor( Timestamp startDateTime, long editedBy, long fireDrillId);
	
	@Modifying
	@Transactional
	@Query(value = "update FireDrillSchedule f set f.startDateTime = NOW(3), f.editedBy = ?1 where f.fireDrillId = ?2", nativeQuery = true)
	int setStartDateTimeAndEditedFor( long editedBy, long fireDrillId);
	
	
	@Modifying
	@Transactional
	@Query(value = "update FireDrillSchedule f set f.deleted = ?1, f.editedBy = ?2, f.lastUpdate = ?3 where f.fireDrillId = ?4", nativeQuery = true)
	int setFixedDeletedAndEditedByAndLastUpdateFor(boolean deleted, long editedBy, Timestamp lastUpdate, long fireDrillId);

	
//	@Modifying
//	@Transactional
//	@Query(value = "update FireDrillSchedule f set f.status = ?1, f.completeDateTime = ?2, f.editedBy = ?3 where f.fireDrillId = ?4", nativeQuery = true)
//	int setStatusAndCompleteDateTimeAndEditedBy(String status, Timestamp completeDateTime, Long editedBy, long fireDrillId);
	
	@Modifying
	@Transactional
	@Query(value = "update FireDrillSchedule f set f.status = ?1, f.completeDateTime = NOW(3), f.editedBy = ?2 where f.fireDrillId = ?3", nativeQuery = true)
	int setStatusAndEditedBy(String status, Long editedBy, long fireDrillId);
	


}
