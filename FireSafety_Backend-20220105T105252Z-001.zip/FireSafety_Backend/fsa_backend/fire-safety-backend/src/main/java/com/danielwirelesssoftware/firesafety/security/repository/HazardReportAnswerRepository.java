package com.danielwirelesssoftware.firesafety.security.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import com.danielwirelesssoftware.firesafety.model.security.HazardReportAnswer;

public interface HazardReportAnswerRepository extends JpaRepository<HazardReportAnswer, Long> {
	
	HazardReportAnswer findByHazardReportAnswerId(long hazardReportAnswerId); 
	
	List<HazardReportAnswer> findByDeleted(boolean deleted); 
}
