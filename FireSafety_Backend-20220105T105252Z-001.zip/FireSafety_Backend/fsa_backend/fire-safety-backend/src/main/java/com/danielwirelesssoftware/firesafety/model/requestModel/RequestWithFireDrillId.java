
package com.danielwirelesssoftware.firesafety.model.requestModel;

public class RequestWithFireDrillId {

	private long fireDrillId;
	
	public RequestWithFireDrillId() {
	}
	
	public RequestWithFireDrillId(RequestWithFireDrillId requestForFireDrillDelete) {
		this.fireDrillId = requestForFireDrillDelete.fireDrillId;
	}
	
	public RequestWithFireDrillId(long fireDrillId) {
		this.fireDrillId = fireDrillId;
	}

	public long getFireDrillId() {
		return fireDrillId;
	}

	public void setFireDrillId(long fireDrillId) {
		this.fireDrillId = fireDrillId;
	}

}
