package com.danielwirelesssoftware.firesafety.model.security;

import javax.persistence.*;

@Entity
@Table(name = "ERP")
public class ERP {
    
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "erpId")
    private long erpId;
    
    @Column(name = "documentName")
    private String documentName;
    
    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "buildingId")
    private Building buildingERP;
    
    @Column(name = "documentKey")
    private String documentKey;
    
    @Column(name = "deleted")
    private Boolean deleted;

    public ERP() {
    }

    public ERP(ERP erp) {
    	this.erpId = erp.erpId;
    	this.documentName = erp.documentName;   
    	this.buildingERP = erp.buildingERP;
    	this.documentKey = erp.documentKey;
    	this.deleted = erp.deleted;
    }
    
    public ERP(String documentName,Building building,
    					String documentKey,boolean deleted){
    	this.documentName = documentName;   
    	this.buildingERP = building;
    	this.documentKey = documentKey;
    	this.deleted = deleted;
    }
    
	public long getErpId() {
		return erpId;
	}

	public void setErpId(long erpId) {
		this.erpId = erpId;
	}

	public String getDocumentName() {
		return documentName;
	}

	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}

	public Building getBuildingERP() {
		return buildingERP;
	}

	public void setBuildingERP(Building buildingERP) {
		this.buildingERP = buildingERP;
	}

	public String getDocumentKey() {
		return documentKey;
	}

	public void setDocumentKey(String documentKey) {
		this.documentKey = documentKey;
	}

	public boolean isDeleted() {
		return deleted;
	}

	public void setDeleted(boolean deleted) {
		this.deleted = deleted;
	}

	@Override
	public String toString() {
		return "ERP [erpId=" + erpId + ", documentName=" + documentName + ", buildingERP=" + buildingERP
				+ ", documentKey=" + documentKey + ", deleted=" + deleted + "]";
	}

    
}
