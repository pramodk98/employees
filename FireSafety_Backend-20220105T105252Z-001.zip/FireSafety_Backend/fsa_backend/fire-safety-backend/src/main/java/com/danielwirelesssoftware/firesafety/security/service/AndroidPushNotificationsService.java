package com.danielwirelesssoftware.firesafety.security.service;

import java.util.ArrayList;
import java.util.concurrent.CompletableFuture;

import org.springframework.http.HttpEntity;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.danielwirelesssoftware.firesafety.security.service.HeaderRequestInterceptor;

@Service
public class AndroidPushNotificationsService {
 
	private static final String FIREBASE_SERVER_KEY = "AAAAYzcGPG0:APA91bFZ0hKlS5dA7UarHI3-QEG0fuMv3csm54W5JbkybHxPEwuBJ645ZOXa-yS0fhysYkABmDHOw8HpkQ0d3k_0X3ev6H0weoUT6XJtsuRx36BkChIl_drG3WfgRNiWzjveReEic8K2";
	private static final String FIREBASE_API_URL = "https://fcm.googleapis.com/fcm/send";
	
	@Async
	public CompletableFuture<String> send(HttpEntity<String> entity) {
 
		RestTemplate restTemplate = new RestTemplate();
 
		/**
		https://fcm.googleapis.com/fcm/send
		Content-Type:application/json
		Authorization:key=FIREBASE_SERVER_KEY*/
 
		ArrayList<ClientHttpRequestInterceptor> interceptors = new ArrayList<>();
		interceptors.add(new HeaderRequestInterceptor("Authorization", "key=" + FIREBASE_SERVER_KEY));
		interceptors.add(new HeaderRequestInterceptor("Content-Type", "application/json"));
		restTemplate.setInterceptors(interceptors);
 
		String firebaseResponse = restTemplate.postForObject(FIREBASE_API_URL, entity, String.class);
 
		return CompletableFuture.completedFuture(firebaseResponse);
	}
}