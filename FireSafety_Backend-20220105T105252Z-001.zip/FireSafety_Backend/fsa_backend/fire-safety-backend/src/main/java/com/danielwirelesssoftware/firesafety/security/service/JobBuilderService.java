package com.danielwirelesssoftware.firesafety.security.service;

import java.util.Date;
import java.util.UUID;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.quartz.JobBuilder;
import org.quartz.JobDataMap;
import org.quartz.JobDetail;
import org.quartz.SimpleScheduleBuilder;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.springframework.stereotype.Service;

import com.danielwirelesssoftware.firesafety.model.security.Certification;
import com.danielwirelesssoftware.firesafety.model.security.FireDrillSchedule;

@Service
public class JobBuilderService {
	 
	private final Log logger = LogFactory.getLog(this.getClass());
	
    //for scheduling usage (fireDrill)
    public JobDetail buildJobDetail(FireDrillSchedule fireDrillSchedule) {
        
    	logger.info("coming into buildingJobDetail(1)");
    	JobDataMap jobDataMap = new JobDataMap();
        jobDataMap.put("fireDrillSchedule", fireDrillSchedule);

        return JobBuilder.newJob(ScheduleFireDrillService.class)
                .withIdentity(UUID.randomUUID().toString(), "schedule-jobs")
                .withDescription("Schedule Fire Drill")
                .usingJobData(jobDataMap)
                .storeDurably()
                .build();
    }

    //for scheduling usage (fireDrill)
    public Trigger buildJobTrigger(JobDetail jobDetail, Date startAt) {
    	logger.info("coming into buildingJobTrigger(2)");
        return TriggerBuilder.newTrigger()
                .forJob(jobDetail)
                .withIdentity(jobDetail.getKey().getName(), "schedule-triggers")
                .withDescription("Schedule Fire Drill Trigger")
                .startAt(Date.from(startAt.toInstant()))
                .withSchedule(SimpleScheduleBuilder.simpleSchedule().withMisfireHandlingInstructionFireNow())
                .build();
    }
    
	//for scheduling usage (send silent notification for user to refresh)
    public JobDetail buildJobDetail2(FireDrillSchedule fireDrillSchedule) {
        
    	logger.info("coming into buildingJobDetail2 (1)");
    	JobDataMap jobDataMap = new JobDataMap();
        jobDataMap.put("fireDrillSchedule", fireDrillSchedule);

        return JobBuilder.newJob(MessageService.class)
                .withIdentity(UUID.randomUUID().toString(), "schedule-jobs")
                .withDescription("Schedule Fire Drill")
                .usingJobData(jobDataMap)
                .storeDurably()
                .build();
    }

    //for scheduling usage (send silent notification for user to refresh)
    public Trigger buildJobTrigger2(JobDetail jobDetail, Date startAt) {
    	logger.info("coming into buildingJobTrigger2 (2)");
        return TriggerBuilder.newTrigger()
                .forJob(jobDetail)
                .withIdentity(jobDetail.getKey().getName(), "schedule-triggers")
                .withDescription("Schedule Fire Drill Update Notification Trigger")
                .startAt(Date.from(startAt.toInstant()))
                .withSchedule(SimpleScheduleBuilder.simpleSchedule().withMisfireHandlingInstructionFireNow())
                .build();
    }
    
//for scheduling certification on create/on update    
    
  //for scheduling usage (certification)
    public JobDetail buildJobDetail(Certification certification) {
        
    	logger.info("coming into buildingJobDetail(certification 1)");
    	JobDataMap jobDataMap = new JobDataMap();
        jobDataMap.put("certification", certification);

        return JobBuilder.newJob(ScheduleCertificationService.class)
                .withIdentity(UUID.randomUUID().toString(), "schedule-jobs")
                .withDescription("Schedule Certification")
                .usingJobData(jobDataMap)
                .storeDurably()
                .build();
    }

    //for scheduling usage (certification)
    public Trigger buildJobTriggerCertification(JobDetail jobDetail, Date startAt) {
    	logger.info("coming into buildingJobTrigger(certification 2)");
        return TriggerBuilder.newTrigger()
                .forJob(jobDetail)
                .withIdentity(jobDetail.getKey().getName(), "schedule-triggers")
                .withDescription("Schedule Certification")
                .startAt(Date.from(startAt.toInstant()))
                .withSchedule(SimpleScheduleBuilder.simpleSchedule().withMisfireHandlingInstructionFireNow())
                .build();
    }
    
//for scheduling certification on 3month, on 2 month, on 1 month, on date.
    
}