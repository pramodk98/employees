package com.danielwirelesssoftware.firesafety.model.responseModel;

import java.util.List;
import com.danielwirelesssoftware.firesafety.model.FireDrillDetail;
import com.danielwirelesssoftware.firesafety.model.FireDrillScheduleDetail;

public class ResponseForFireDrillAccess {
		
	private Boolean fireDrillScheduleAccess;
	private Boolean enableUpdateAttendance;
	private Boolean enableStartFireDrill;
	private String buildingName;
	private List <FireDrillScheduleDetail> fireDrillSchedule;
	
	public ResponseForFireDrillAccess() {
	}
	
	public ResponseForFireDrillAccess(ResponseForFireDrillAccess responseForFireDrillAccess) {
		this.fireDrillScheduleAccess = responseForFireDrillAccess.fireDrillScheduleAccess;
		this.enableUpdateAttendance = responseForFireDrillAccess.enableUpdateAttendance;
		this.enableStartFireDrill = responseForFireDrillAccess.enableStartFireDrill; 
		this.buildingName = responseForFireDrillAccess.buildingName;
		this.fireDrillSchedule = responseForFireDrillAccess.fireDrillSchedule;
		
	}
	
	public ResponseForFireDrillAccess(Boolean fireDrillScheduleAccess, Boolean enableUpdateAttendance, Boolean fireDrillStartGroup, String buildingName,
			List<FireDrillScheduleDetail> fireDrillDetailList) {
		this.fireDrillScheduleAccess = fireDrillScheduleAccess;
		this.enableUpdateAttendance = enableUpdateAttendance;
		this.enableStartFireDrill = fireDrillStartGroup;
		this.buildingName = buildingName;
		this.fireDrillSchedule = fireDrillDetailList;
		
	}

	public Boolean isFireDrillScheduleAccess() {
		return fireDrillScheduleAccess;
	}

	public void setFireDrillScheduleAccess(Boolean fireDrillScheduleAccess) {
		this.fireDrillScheduleAccess = fireDrillScheduleAccess;
	}

	public List<FireDrillScheduleDetail> getFireDrillSchedule() {
		return fireDrillSchedule;
	}

	public Boolean getFireDrillScheduleAccess() {
		return fireDrillScheduleAccess;
	}
	
	public void setFireDrillSchedule(List<FireDrillScheduleDetail> fireDrillSchedule) {
		this.fireDrillSchedule = fireDrillSchedule;
	}

	public Boolean getEnableUpdateAttendance() {
		return enableUpdateAttendance;
	}

	public void setEnableUpdateAttendance(Boolean enableUpdateAttendance) {
		this.enableUpdateAttendance = enableUpdateAttendance;
	}

	public String getBuildingName() {
		return buildingName;
	}

	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}

	public Boolean getEnableStartFireDrill() {
		return enableStartFireDrill;
	}

	public void setEnableStartFireDrill(Boolean enableStartFireDrill) {
		this.enableStartFireDrill = enableStartFireDrill;
	}

	
	
	
		
}

