package com.danielwirelesssoftware.firesafety.security.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.danielwirelesssoftware.firesafety.model.security.ERP;

public interface ERPRepository extends JpaRepository<ERP, Long> {
	
	ERP findByErpId(Long erpId);
	
	@Modifying
	@Transactional
	@Query(value = "update ERP e set e.deleted = ?1 where e.erpId = ?2", nativeQuery = true)
	int setFixedDeletedFor(boolean deleted, long erpId); 
}
