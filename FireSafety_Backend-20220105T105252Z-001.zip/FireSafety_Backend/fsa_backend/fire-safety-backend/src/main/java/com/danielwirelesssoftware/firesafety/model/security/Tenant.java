package com.danielwirelesssoftware.firesafety.model.security;

import javax.persistence.*;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import java.sql.Timestamp;
import java.util.List;

@Entity
@Table(name = "Tenant")
public class Tenant {
	@Id
    @Column(name = "tenantId")
    private long tenantId;
    
    @Column(name = "tenantName")
    private String tenantName;
    
    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "buildingId")
    private Building building;    
    
    @Column(name = "dateTime")
    private Timestamp dateTime;
    
    @OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "editedBy")
    private User editedBy;
    
    @Column(name = "deleted")
    private Boolean deleted;

    
    @OneToMany(mappedBy = "tenant", fetch = FetchType.LAZY
    		, cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.DETACH, CascadeType.REFRESH })
    @Fetch(value = FetchMode.SUBSELECT)
	private List<TenantEmployee> tenantEmployeeList;
    
    public Tenant() {
    }
    
    
	public Tenant(Tenant tenant) {
		this.tenantId = tenant.tenantId;
		this.tenantName = tenant.tenantName;
		this.building = tenant.building;
		this.dateTime = tenant.dateTime;
		this.editedBy = tenant.editedBy;
		this.deleted = tenant.deleted;
	}
    
	public Tenant(Long tenantId, String tenantName, Building building,
					Timestamp dateTime, User editedBy, boolean deleted) {
		this.tenantId = tenantId;
		this.tenantName = tenantName;
		this.building = building;
		this.dateTime = dateTime;
		this.editedBy = editedBy;
		this.deleted = deleted;
	}
	
	public long getTenantId() {
		return tenantId;
	}

	public void setTenantId(long tenantId) {
		this.tenantId = tenantId;
	}

	public String getTenantName() {
		return tenantName;
	}

	public void setTenantName(String tenantName) {
		this.tenantName = tenantName;
	}

	public Building getBuilding() {
		return building;
	}

	public void setBuilding(Building building) {
		this.building = building;
	}

	public Timestamp getDateTime() {
		return dateTime;
	}

	public void setDateTime(Timestamp dateTime) {
		this.dateTime = dateTime;
	}

	public User getEditedBy() {
		return editedBy;
	}

	public void setEditedBy(User editedBy) {
		this.editedBy = editedBy;
	}

	public boolean isDeleted() {
		return deleted;
	}

	public void setDeleted(boolean deleted) {
		this.deleted = deleted;
	}

	@Override
	public String toString() {
		return "Tenant [tenantId=" + tenantId + ", tenantName=" + tenantName + ", building=" + building + ", dateTime="
				+ dateTime + ", editedBy=" + editedBy + ", delete=" + deleted + "]";
	}


	public List<TenantEmployee> getTenantEmployeeList() {
		return tenantEmployeeList;
	}


	public void setTenantEmployeeList(List<TenantEmployee> tenantEmployeeList) {
		this.tenantEmployeeList = tenantEmployeeList;
	}
	
	


}
