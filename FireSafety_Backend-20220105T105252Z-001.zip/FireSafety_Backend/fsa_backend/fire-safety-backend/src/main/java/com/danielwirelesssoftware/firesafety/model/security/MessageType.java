package com.danielwirelesssoftware.firesafety.model.security;

import javax.persistence.*;

@Entity
@Table(name = "MessageType")
public class MessageType {
    
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name="messageTypeId")
    private Long messageTypeId; 
    
    @Column(name = "messageType")
    private String messageType;
    
    @Column(name = "deleted")
    private boolean deleted;

    public MessageType(){
	}
    
	public MessageType(Long messageTypeId, String messageType, boolean deleted) {
		this.messageTypeId = messageTypeId;
		this.messageType = messageType;
		this.deleted = deleted;
	}
	
	public MessageType(String messageType, boolean deleted) {

		this.messageType = messageType;
		this.deleted = deleted;
	}

	public Long getMessageTypeId() {
		return messageTypeId;
	}

	public void setMessageTypeId(Long messageTypeId) {
		this.messageTypeId = messageTypeId;
	}

	public String getMessageType() {
		return messageType;
	}

	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}

	public boolean isDeleted() {
		return deleted;
	}

	public void setDeleted(boolean deleted) {
		this.deleted = deleted;
	}
	
    
}
