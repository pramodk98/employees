package com.danielwirelesssoftware.firesafety.model.security;

import java.sql.Timestamp;

import javax.persistence.*;

@Entity
@Table(name = "Certification")
public class Certification {
    
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "certificationId")
    private long certificationId;
	
	@Column(name = "certificationName")
    private String certificationName;
    
    @Column(name = "description")
    private String description;
    
    @Column(name = "expiryDate")
    private Timestamp expiryDate;
    
    @Column(name = "lastExpiryDate")
    private Timestamp lastExpiryDate;
    
    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "buildingId")
    private Building building;
    
    @Column(name = "deleted")
    private boolean deleted;

    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "createdBy")
    private User createdBy;
    
    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "editedBy")
    private User editedBy;
    
    @Column(name = "documentName")
    private String documentName;
    
    @Column(name = "documentKey")
    private String documentKey;
    
    @Column(name = "pastCertificationId")
    private long pastCertificationId;
    
    public Certification(){
    	
	}
    
    public Certification(Certification certification) {
    	this.certificationId = certification.certificationId;
		this.certificationName = certification.certificationName;
		this.description = certification.description;
		this.expiryDate = certification.expiryDate;
		this.lastExpiryDate = certification.lastExpiryDate;
		this.building = certification.building;
		this.deleted = certification.deleted;
		this.createdBy = certification.createdBy;
		this.editedBy = certification.editedBy;
		this.documentName = certification.documentName;
		this.documentKey = certification.documentKey;
	}

    //on create
    public Certification(String certificationName, String description, Timestamp expiryDate,
			Timestamp lastExpiryDate, Building building, boolean deleted, User createdBy, User editedBy,
			String documentName, String documentKey) {
		this.certificationName = certificationName;
		this.description = description;
		this.expiryDate = expiryDate;
		this.lastExpiryDate = lastExpiryDate;
		this.building = building;
		this.deleted = deleted;
		this.createdBy = createdBy;
		this.editedBy = editedBy;
		this.documentKey = documentKey;
		this.documentName = documentName;
	}
    
    //on update
    public Certification(String certificationName, String description, Timestamp expiryDate,
			Timestamp lastExpiryDate, Building building, boolean deleted, User createdBy, User editedBy,
			String documentName, String documentKey, long pastCertificationId) {
		this.certificationName = certificationName;
		this.description = description;
		this.expiryDate = expiryDate;
		this.lastExpiryDate = lastExpiryDate;
		this.building = building;
		this.deleted = deleted;
		this.createdBy = createdBy;
		this.editedBy = editedBy;
		this.documentKey = documentKey;
		this.documentName = documentName;
		this.pastCertificationId = pastCertificationId;
	}
    
    public Certification(long certificationId, String certificationName, String description, Timestamp expiryDate,
			Timestamp lastExpiryDate, Building building, boolean deleted, User createdBy, User editedBy,
			String documentName, String documentKey) {
		this.certificationId = certificationId;
		this.certificationName = certificationName;
		this.description = description;
		this.expiryDate = expiryDate;
		this.lastExpiryDate = lastExpiryDate;
		this.building = building;
		this.deleted = deleted;
		this.createdBy = createdBy;
		this.editedBy = editedBy;
		this.documentKey = documentKey;
		this.documentName = documentName;
	}
    
    public Certification(long certificationId, String certificationName, String description, Timestamp expiryDate,
			Building building, boolean deleted, User createdBy, User editedBy, String documentName, 
			String documentKey, long pastCertificationId) {
		this.certificationId = certificationId;
		this.certificationName = certificationName;
		this.description = description;
		this.expiryDate = expiryDate;
		this.lastExpiryDate = null;
		this.building = building;
		this.deleted = deleted;
		this.createdBy = createdBy;
		this.editedBy = editedBy;
		this.documentKey = documentKey;
		this.documentName = documentName;
		this.pastCertificationId = pastCertificationId;
	}

	public long getCertificationId() {
		return certificationId;
	}

	public void setCertificationId(long certificationId) {
		this.certificationId = certificationId;
	}

	public String getCertificationName() {
		return certificationName;
	}

	public void setCertificationName(String certificationName) {
		this.certificationName = certificationName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Timestamp getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(Timestamp expiryDate) {
		this.expiryDate = expiryDate;
	}

	public Timestamp getLastExpiryDate() {
		return lastExpiryDate;
	}

	public void setLastExpiryDate(Timestamp lastExpiryDate) {
		this.lastExpiryDate = lastExpiryDate;
	}

	public Building getBuilding() {
		return building;
	}

	public void setBuilding(Building building) {
		this.building = building;
	}

	public boolean isDeleted() {
		return deleted;
	}

	public void setDeleted(boolean deleted) {
		this.deleted = deleted;
	}

	public User getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(User createdBy) {
		this.createdBy = createdBy;
	}

	public User getEditedBy() {
		return editedBy;
	}

	public void setEditedBy(User editedBy) {
		this.editedBy = editedBy;
	}

	public String getDocumentName() {
		return documentName;
	}

	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}

	public String getDocumentKey() {
		return documentKey;
	}

	public void setDocumentKey(String documentKey) {
		this.documentKey = documentKey;
	}

	public long getPastCertificationId() {
		return pastCertificationId;
	}

	public void setPastCertificationId(long pastCertificationId) {
		this.pastCertificationId = pastCertificationId;
	}
    
    
}
