package com.danielwirelesssoftware.firesafety.model.requestModel;

import java.util.List;


import com.danielwirelesssoftware.firesafety.model.DrawingsDetail;

public class RequestForDrawingUpdate {
   
    private long levelId;
    private List<DrawingsDetail> drawingList;

    public RequestForDrawingUpdate() {
    }

	public RequestForDrawingUpdate(long levelId, List<DrawingsDetail> drawingList) {
		this.levelId = levelId;
		this.drawingList = drawingList;
	}

	public long getLevelId() {
		return levelId;
	}

	public void setLevelId(long levelId) {
		this.levelId = levelId;
	}
	
	public List<DrawingsDetail> getDrawingList() {
		return drawingList;
	}

	public void setDrawingList(List<DrawingsDetail> drawingList) {
		this.drawingList = drawingList;
	}	

}
