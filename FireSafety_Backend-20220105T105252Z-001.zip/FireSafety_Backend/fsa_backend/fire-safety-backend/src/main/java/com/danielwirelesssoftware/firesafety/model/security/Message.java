package com.danielwirelesssoftware.firesafety.model.security;

import java.sql.Timestamp;

import javax.persistence.*;


@Entity
@Table(name = "Message")
public class Message {
   
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name="messageId")
    private Long messageId; 
    
    @ManyToOne
    @JoinColumn(name = "messageTypeId")
    private MessageType messageType;

    @Column(name = "dateTime")
    private Timestamp dateTime;
    
    @Column(name = "messageTitle")
    private String messageTitle;
    
    @Column(name = "messageDetails")
    private String messageDetails;
    
    @Column(name = "buildingId")
    private Long buildingId;
    
    @Column(name = "contentId")
    private Long contentId;

   
	public Message(){
	}
    
	public Message(MessageType messageType, Timestamp dateTime, String messageTitle,
			String messageDetails, Long buildingId, Long contentId) {
		this.messageType = messageType;
		this.dateTime = dateTime;
		this.messageTitle = messageTitle;
		this.messageDetails = messageDetails;
		this.buildingId = buildingId;
		this.contentId = contentId;
	}
	
	public Message(Long messageId, MessageType messageType, Timestamp dateTime, String messageTitle,
			String messageDetails, Long buildingId, Long contentId) {
		this.messageId = messageId;
		this.messageType = messageType;
		this.dateTime = dateTime;
		this.messageTitle = messageTitle;
		this.messageDetails = messageDetails;
		this.buildingId = buildingId;
		this.contentId = contentId;
	}

	public Long getMessageId() {
		return messageId;
	}

	public void setMessageId(Long messageId) {
		this.messageId = messageId;
	}

	public MessageType getMessageType() {
		return messageType;
	}

	public void setMessageType(MessageType messageType) {
		this.messageType = messageType;
	}

	public Timestamp getDateTime() {
		return dateTime;
	}

	public void setDateTime(Timestamp dateTime) {
		this.dateTime = dateTime;
	}

	public String getMessageTitle() {
		return messageTitle;
	}

	public void setMessageTitle(String messageTitle) {
		this.messageTitle = messageTitle;
	}

	public String getMessageDetails() {
		return messageDetails;
	}

	public void setMessageDetails(String messageDetails) {
		this.messageDetails = messageDetails;
	}

	public Long getBuildingId() {
		return buildingId;
	}

	public void setBuildingId(Long buildingId) {
		this.buildingId = buildingId;
	}
	
	public Long getContentId() {
		return contentId;
	}

	public void setContentId(Long contentId) {
		this.contentId = contentId;
	}

}
