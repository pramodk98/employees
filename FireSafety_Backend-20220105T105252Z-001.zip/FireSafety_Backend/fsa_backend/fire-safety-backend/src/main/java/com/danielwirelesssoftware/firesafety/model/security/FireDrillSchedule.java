package com.danielwirelesssoftware.firesafety.model.security;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.*;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.hibernate.annotations.Type;
import org.springframework.transaction.annotation.Transactional;

@Entity
@Transactional
@Table(name = "FireDrillSchedule")
public class FireDrillSchedule {
    
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "fireDrillId")
    private long fireDrillId;
    
    @ManyToOne( fetch = FetchType.LAZY)
    @JoinColumn(name = "buildingId")
    private Building buildingFDS;
    
    @Column(name = "description")
    private String description;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "fireDrillTypeId")
    private FireDrillType fireDrillType;
    
    @Column(name = "status")
    private String status;
    
    @ManyToOne( fetch = FetchType.LAZY)
    @JoinColumn(name = "scheduledBy")
    private User scheduledBy;
    
    @Column(name = "scheduleDateTime", columnDefinition = "TIMESTAMP(3) NOT NULL")
    private Timestamp scheduleDateTime;
    
    @Column(name = "startDateTime", columnDefinition = "DATETIME(3) NOT NULL")
    @Temporal(TemporalType.TIMESTAMP)
    @Type(type="timestamp")
    private Timestamp startDateTime;
    
    @Column(name = "lastUpdate")
    private Timestamp lastUpdate;
    
    @Column(name = "completeDateTime", columnDefinition = "TIMESTAMP(3) NOT NULL")
    private Timestamp completeDateTime;
    
    @Column(name = "deleted")
    private boolean deleted;
    
    @Column(name = "editedBy")
    private long editedBy;
    
    @Column(name = "lastAttendanceUpdate", columnDefinition = "TIMESTAMP(3)")
    private Timestamp lastAttendanceUpdate;
    
    @OneToMany(mappedBy = "fireDrillSchedule", fetch = FetchType.LAZY
    		, cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.DETACH, CascadeType.REFRESH })
    @Fetch(value = FetchMode.SUBSELECT)
	private List<FireDrillAttendance> fireDrillAttendanceList;
    
    
    public FireDrillSchedule() {
    }

	public FireDrillSchedule(long fireDrillId, Building buildingFDS, String description, FireDrillType fireDrillType,
			String status, User scheduledBy, Timestamp startDateTime, Timestamp scheduleDateTime, Timestamp lastUpdate, Timestamp completeDateTime,
			boolean deleted) {
		this.fireDrillId = fireDrillId;
		this.buildingFDS = buildingFDS;
		this.description = description;
		this.fireDrillType = fireDrillType;
		this.status = status;
		this.scheduledBy = scheduledBy;
		this.scheduleDateTime = scheduleDateTime;
		this.startDateTime = startDateTime;
		this.lastUpdate = lastUpdate;
		this.completeDateTime = completeDateTime;
		this.deleted = deleted;
	}

	public FireDrillSchedule(Building buildingFDS, String description, FireDrillType fireDrillType,
			String status, User scheduledBy, Timestamp scheduleDateTime, Timestamp lastUpdate) {
		this.buildingFDS = buildingFDS;
		this.description = description;
		this.fireDrillType = fireDrillType;
		this.status = status;
		this.scheduledBy = scheduledBy;
		this.scheduleDateTime = scheduleDateTime;
		this.lastUpdate = lastUpdate;
	}


	public long getFireDrillId() {
		return fireDrillId;
	}

	public void setFireDrillId(long fireDrillId) {
		this.fireDrillId = fireDrillId;
	}

	public Timestamp getScheduleDateTime() {
		return scheduleDateTime;
	}

	public void setScheduleDateTime(Timestamp scheduleDateTime) {
		this.scheduleDateTime = scheduleDateTime;
	}

	public Timestamp getLastUpdate() {
		return lastUpdate;
	}
	
	public void setLastUpdate(Timestamp lastUpdate) {
		this.lastUpdate = lastUpdate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Building getBuildingFDS() {
		return buildingFDS;
	}

	public void setBuildingFDS(Building buildingFDS) {
		this.buildingFDS = buildingFDS;
	}

	public FireDrillType getFireDrillType() {
		return fireDrillType;
	}

	public void setFireDrillType(FireDrillType fireDrillType) {
		this.fireDrillType = fireDrillType;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public boolean isDeleted() {
		return deleted;
	}
	
	public void setDeleted(boolean deleted) {
		this.deleted = deleted;
	}

	public User getScheduledBy() {
		return scheduledBy;
	}

	public void setScheduledBy(User scheduledBy) {
		this.scheduledBy = scheduledBy;
	}

	public Timestamp getCompleteDateTime() {
		return completeDateTime;
	}

	public void setCompleteDateTime(Timestamp completeDateTime) {
		this.completeDateTime = completeDateTime;
	}

	public long getEditedBy() {
		return editedBy;
	}

	public void setEditedBy(long editedBy) {
		this.editedBy = editedBy;
	}

	public List<FireDrillAttendance> getFireDrillAttendanceList() {
		return fireDrillAttendanceList;
	}

	public void setFireDrillAttendanceList(List<FireDrillAttendance> fireDrillAttendanceList) {
		this.fireDrillAttendanceList = fireDrillAttendanceList;
	}

	public Timestamp getStartDateTime() {
		return startDateTime;
	}

	public void setStartDateTime(Timestamp startDateTime) {
		this.startDateTime = startDateTime;
	}

	public Timestamp getLastAttendanceUpdate() {
		return lastAttendanceUpdate;
	}

	public void setLastAttendanceUpdate(Timestamp lastAttendanceUpdate) {
		this.lastAttendanceUpdate = lastAttendanceUpdate;
	}

	@Override
	public String toString() {
		return "FireDrillSchedule [fireDrillId=" + fireDrillId + ", description="
				+ description + ", fireDrillType=" + fireDrillType + ", status=" + status + ", scheduledBy="
				+ scheduledBy + ", scheduleDateTime=" + scheduleDateTime + ", startDateTime=" + startDateTime
				+ ", lastUpdate=" + lastUpdate + ", completeDateTime=" + completeDateTime + ", deleted=" + deleted
				+ ", editedBy=" + editedBy + "]";
	}

    
}
