package com.danielwirelesssoftware.firesafety.model.security;

import javax.persistence.*;

import org.springframework.transaction.annotation.Transactional;

@Entity
@Transactional
@Table(name = "FireDrillAttendance")
public class FireDrillAttendance {
    
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "fireDrillAttendanceId")
    private long fireDrillAttendanceId;
    
    @OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "tenantEmployeeId")
    private TenantEmployee tenantEmployee;
    
    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "fireDrillId")
    private FireDrillSchedule fireDrillSchedule;
    
    @Column(name = "status")
    private String status;

    public FireDrillAttendance(){
    	
    }
    
    public FireDrillAttendance(TenantEmployee tenantEmployee, FireDrillSchedule fireDrillSchedule, String status) {
		this.tenantEmployee = tenantEmployee;
		this.fireDrillSchedule = fireDrillSchedule;
		this.status = status;
	}
    
	public FireDrillAttendance(long fireDrillAttendanceId, TenantEmployee tenantEmployee, FireDrillSchedule fireDrillSchedule,
			String status) {
		this.fireDrillAttendanceId = fireDrillAttendanceId;
		this.tenantEmployee = tenantEmployee;
		this.fireDrillSchedule = fireDrillSchedule;
		this.status = status;
	}

	public long getFireDrillAttendanceId() {
		return fireDrillAttendanceId;
	}

	public void setFireDrillAttendanceId(long fireDrillAttendanceId) {
		this.fireDrillAttendanceId = fireDrillAttendanceId;
	}

	public TenantEmployee getTenantEmployee() {
		return tenantEmployee;
	}

	public void setTenantEmployee(TenantEmployee tenantEmployee) {
		this.tenantEmployee = tenantEmployee;
	}

	public FireDrillSchedule getFireDrillSchedule() {
		return fireDrillSchedule;
	}

	public void setFireDrillSchedule(FireDrillSchedule fireDrillSchedule) {
		this.fireDrillSchedule = fireDrillSchedule;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "FireDrillAttendance [fireDrillAttendanceId=" + fireDrillAttendanceId + ", tenantEmployee="
				+ tenantEmployee + ", fireDrillSchedule=" + fireDrillSchedule + ", status=" + status + "]";
	}
    
}
