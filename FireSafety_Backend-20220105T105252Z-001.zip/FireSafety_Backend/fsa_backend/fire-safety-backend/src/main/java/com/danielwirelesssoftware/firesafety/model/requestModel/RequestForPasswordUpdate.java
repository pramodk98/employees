package com.danielwirelesssoftware.firesafety.model.requestModel;

public class RequestForPasswordUpdate {

    private String password;
    private String newPassword;
    
    public RequestForPasswordUpdate() {
	}
    
    public RequestForPasswordUpdate( RequestForPasswordUpdate requestForPasswordUpdate) {
		this.password = requestForPasswordUpdate.password;
		this.newPassword = requestForPasswordUpdate.newPassword;
	}
    
    public RequestForPasswordUpdate(String password, String newPassword) {
		this.password = password;
		this.newPassword = newPassword;
	}
    
	public String getPassword() {
		return password;
	}
	
	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getNewPassword() {
		return newPassword;
	}
	
	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}
    
    
    
}
