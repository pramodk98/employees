package com.danielwirelesssoftware.firesafety.model.requestModel;

public class RequestWithEmail {

	private String email;
	
	public RequestWithEmail() {
	}
	
	public RequestWithEmail(RequestWithEmail requestWithEmail) {
		this.email = requestWithEmail.email;
	}
	
	public RequestWithEmail(String email) {
		super();
		this.email = email;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	
	

}
