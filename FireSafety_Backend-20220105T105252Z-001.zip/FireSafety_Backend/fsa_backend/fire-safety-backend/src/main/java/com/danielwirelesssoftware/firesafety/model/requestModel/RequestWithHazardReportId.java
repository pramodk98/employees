
package com.danielwirelesssoftware.firesafety.model.requestModel;

public class RequestWithHazardReportId {

	private long hazardReportId;
	
	public RequestWithHazardReportId() {
	}
	
	public RequestWithHazardReportId(RequestWithHazardReportId requestWithHazardReportId) {
		this.hazardReportId = requestWithHazardReportId.hazardReportId;
	}
	
	public RequestWithHazardReportId(long hazardReportId) {
		this.hazardReportId = hazardReportId;
	}

	public long getHazardReportId() {
		return hazardReportId;
	}

	public void setHazardReportId(long hazardReportId) {
		this.hazardReportId = hazardReportId;
	}

}
