//package com.danielwirelesssoftware.firesafety.security.service;
//
//import java.util.ArrayList;
//import java.util.List;
//import java.util.concurrent.atomic.AtomicInteger;
//
//import org.apache.commons.logging.Log;
//import org.apache.commons.logging.LogFactory;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Component;
//
//import com.danielwirelesssoftware.firesafety.common.utils.TimeProvider;
//import com.danielwirelesssoftware.firesafety.model.EscalationAttendanceDetail;
//import com.danielwirelesssoftware.firesafety.model.security.Building;
//import com.danielwirelesssoftware.firesafety.model.security.BuildingRole;
//import com.danielwirelesssoftware.firesafety.model.security.Message;
//import com.danielwirelesssoftware.firesafety.model.security.MessageType;
//import com.danielwirelesssoftware.firesafety.model.security.Notification;
//import com.danielwirelesssoftware.firesafety.security.repository.BuildingRepository;
//import com.danielwirelesssoftware.firesafety.security.repository.BuildingRoleRepository;
//import com.danielwirelesssoftware.firesafety.security.repository.MessageRepository;
//import com.danielwirelesssoftware.firesafety.security.repository.NotificationRepository;
//
//import static com.danielwirelesssoftware.firesafety.common.utils.Constant.STATUS_FALSE;
//import static com.danielwirelesssoftware.firesafety.common.utils.Constant.DELETE_FALSE;
//import static com.danielwirelesssoftware.firesafety.common.utils.Constant.ACTION_HAZARD_REPORT;
//import static com.danielwirelesssoftware.firesafety.common.utils.Constant.ACTION_HAZARD_REPORT_COMPLETE;
//import static com.danielwirelesssoftware.firesafety.common.utils.Constant.MESSAGE_TITLE_HAZARD_REPORT;
//import static com.danielwirelesssoftware.firesafety.common.utils.Constant.MESSAGE_TITLE_HAZARD_REPORT_COMPLETE;
//import static com.danielwirelesssoftware.firesafety.common.utils.Constant.MESSAGE_TYPE_HAZARD_REPORT;
//import static com.danielwirelesssoftware.firesafety.common.utils.Constant.MESSAGE_TYPE_HAZARD_REPORT_COMPLETE;
//import static com.danielwirelesssoftware.firesafety.common.utils.Constant.MESSAGE_DEFAULT;
//
//@Component
//public class HazardReportService{
//	
//	private final Log logger = LogFactory.getLog(this.getClass());
//	
//	@Autowired
//	private BuildingRoleRepository buildingRoleRepository;
//	
//	@Autowired
//	private BuildingRepository buildingRepository;
//	
//	@Autowired
//    private MessageRepository messageRepository;
//	
//	@Autowired
//    private NotificationRepository notificationRepository;
//	
//	@Autowired
//    private FCMService fcmService;
//
//	@Autowired
//    private TimeProvider timeProvider;
//
//    
//    //counter to count how many push notification sent, 
//    //building to get each user buildingRoleId ,
//    //fireDrillSchedule to loop the attendance
//    //fireDrillStatus to set the status for notification
//    public Thread hazardReportThread(AtomicInteger counter, Long buildingId, Long userId, MessageType messageType, String detail){
//
//    	return new Thread() {
//    		
//    		@Override
//    		public void run() {
//    			
//    			String title = MESSAGE_TITLE_HAZARD_REPORT;
//    	    	int action = 0;
//    	    	
//    	    	if(messageType.getMessageTypeId() == MESSAGE_TYPE_HAZARD_REPORT){
//    	    		action = ACTION_HAZARD_REPORT;
//    	    	}else if(messageType.getMessageTypeId() == MESSAGE_TYPE_HAZARD_REPORT_COMPLETE){
//    	    		action = ACTION_HAZARD_REPORT_COMPLETE;
//
//    	    	}
//    	    	
//    			logger.debug("//0.1");
//    			Building building = null;
//    			building = buildingRepository.findByBuildingId(buildingId);
//    			if(building==null){
//    				logger.debug("//empty 1");
//    			}
//    			List<BuildingRole> brList = new ArrayList<BuildingRole>();
//    			brList = buildingRoleRepository.findByBuilding(building);
//    			if(brList.isEmpty()){
//    				logger.debug("//empty 2");
//    			}
//    			for(BuildingRole br: brList){
//    				
//    				logger.debug("//01");
//    				
//    				if(br.isDeleted()){
//    					continue;
//    				}
//    				
//    				if(br.getUser().isDeleted()){
//    					continue;
//    				}
//    				
//    				if(br.getUser().getUserId() ==userId){
//    					continue;
//    				}
//    				
//    				logger.debug("//02");
//    				
//    				//TODO:  fix hardcode 0L
//    				Message message = new Message(messageType,timeProvider.timestampNow(),
//													title, detail,
//													br.getBuilding().getBuildingId(), 0L);
//    				messageRepository.saveAndFlush(message);
//    				
//    				logger.debug("//03:"+message.getMessageId());
//					Notification notification = new Notification(br.getUser(),
//																	STATUS_FALSE,
//																	message);												
//					notificationRepository.save(notification);
//					
//    				logger.debug("//04");
//    				
//    				if(br.getUser().getPushNotificationToken() != null && br.getUser().getNotification()){
//		    			logger.debug("//05");
//
//		    			//send notification
//		    			fcmService.sendNotification(br.getUser().getPushNotificationToken(),
//													br.getBuildingRoleId(),
//													action,
//													"",
//													"",
//													"");
//		    			logger.debug("//06");
//		    				
//		    			//add sent counter
//		    			counter.getAndIncrement();
//
//						logger.debug("//07");
//		    		}
//    			}
//    		}
//    	};
//    }}
