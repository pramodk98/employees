package com.danielwirelesssoftware.firesafety.model.requestModel;

public class RequestForUpdateEscalation {

	private long escalationAttendanceId;
	private String status;
	
	public RequestForUpdateEscalation(){
	}
	
	public RequestForUpdateEscalation(long buildingRoleId, String status) {
		this.escalationAttendanceId = buildingRoleId;
		this.status = status;
	}

	public long getEscalationAttendanceId() {
		return escalationAttendanceId;
	}

	public void setEscalationAttendanceId(long escalationAttendanceId) {
		this.escalationAttendanceId = escalationAttendanceId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
		
}

