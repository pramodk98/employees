
package com.danielwirelesssoftware.firesafety.model.requestModel;

public class RequestForFireDrillEnd {

	private long buildingRoleId;
	private long fireDrillId;
	private long completeDateTime;
	private boolean needToDoPushNotification;
	
	public RequestForFireDrillEnd(){	
	}
	
	public RequestForFireDrillEnd(long buildingRoleId, long fireDrillId, long completeDateTime, boolean needToDoPushNotification) {
		this.buildingRoleId = buildingRoleId;
		this.fireDrillId = fireDrillId;
		this.completeDateTime = completeDateTime;
		this.needToDoPushNotification = needToDoPushNotification;
	}

	public long getFireDrillId() {
		return fireDrillId;
	}

	public void setFireDrillId(long fireDrillId) {
		this.fireDrillId = fireDrillId;
	}

	public long getCompleteDateTime() {
		return completeDateTime;
	}

	public void setCompleteDateTime(long completeDateTime) {
		this.completeDateTime = completeDateTime;
	}

	public long getBuildingRoleId() {
		return buildingRoleId;
	}

	public void setBuildingRoleId(long buildingRoleId) {
		this.buildingRoleId = buildingRoleId;
	}

	public boolean isNeedToDoPushNotification() {
		return needToDoPushNotification;
	}

	public void setNeedToDoPushNotification(boolean needToDoPushNotification) {
		this.needToDoPushNotification = needToDoPushNotification;
	}
	
	
}
