package com.danielwirelesssoftware.firesafety.model.security;

import javax.persistence.*;

@Entity
@Table(name = "Role")
public class Role {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "roleId")
    private long roleId;
    
    @Column(name = "roleName")
    private String roleName;
    
    @Column(name = "editHazardReportGroup")
    private Boolean editHazardReportGroup;
    
    @Column(name = "hazardReportGroup")
    private Boolean hazardReportGroup;
    
    @Column(name = "authorityToEscalateGroup")
    private Boolean authorityToEscalateGroup;
    
    @Column(name = "escalationGroup")
    private Boolean escalationGroup;
    
    @Column(name = "fireDrillAuthorityGroup")
    private Boolean fireDrillAuthorityGroup;
    
    @Column(name = "fireDrillNotificationGroup")
    private Boolean fireDrillNotificationGroup;
    
    @Column(name = "fireDrillStartGroup")
    private Boolean fireDrillStartGroup;
    
    @Column(name = "fireDrillAttendanceGroup")
    private Boolean fireDrillAttendanceGroup;
    
    @Column(name = "documentManagementGroup")
    private Boolean documentManagementGroup;
    
    @Column(name = "documentViewingGroup")
    private Boolean documentViewingGroup;
    
    @Column(name = "certificateManagementGroup")
    private Boolean certificateManagementGroup;
    
    @Column(name = "certificateViewingGroup")
    private Boolean certificateViewingGroup;
    
    @Column(name = "deleted")
    private Boolean deleted;

    public Role() {
    }

    public Role(Role role) {
    	this.roleId = role.roleId;
    	this.roleName = role.roleName;
    	this.editHazardReportGroup = role.editHazardReportGroup;
    	this.hazardReportGroup = role.hazardReportGroup;
    	this.authorityToEscalateGroup = role.authorityToEscalateGroup;
    	this.escalationGroup = role.escalationGroup;
    	this.fireDrillAuthorityGroup = role.fireDrillAuthorityGroup;
    	this.fireDrillStartGroup = role.fireDrillStartGroup;
    	this.fireDrillAttendanceGroup = role.fireDrillAttendanceGroup;
    	this.fireDrillNotificationGroup = role.fireDrillNotificationGroup;
    	this.documentManagementGroup = role.documentManagementGroup;
    	this.documentViewingGroup = role.documentViewingGroup;
    	this.deleted = role.deleted;
    	this.certificateManagementGroup = role.certificateManagementGroup;
    	this.certificateViewingGroup = role.certificateViewingGroup;
    }
    
    public Role(long roleId, String roleName, boolean editHazardReportGroup, boolean hazardReportGroup, 
    			boolean authorityToEscalateGroup, boolean escalationGroup, boolean fireDrillAuthorityGroup, 
    			boolean fireDrillAttendanceGroup, boolean fireDrillStartGroup, boolean fireDrillNotificationGroup,
    			boolean documentManagementGroup, boolean documentViewingGroup,
    			boolean certificateManagementGroup, boolean certificateViewingGroup){
    	this.roleId =roleId;
    	this.roleName = roleName;
    	this.editHazardReportGroup = editHazardReportGroup;
    	this.hazardReportGroup = hazardReportGroup;
    	this.fireDrillAuthorityGroup = fireDrillAuthorityGroup;
    	this.fireDrillAttendanceGroup = fireDrillAttendanceGroup;
    	this.fireDrillStartGroup = fireDrillStartGroup;
    	this.fireDrillNotificationGroup = fireDrillNotificationGroup;
    	this.escalationGroup = escalationGroup;
    	this.fireDrillAuthorityGroup = fireDrillAuthorityGroup;
    	this.documentManagementGroup = documentManagementGroup;
    	this.documentViewingGroup = documentViewingGroup;
    	this.certificateManagementGroup = certificateManagementGroup;
    	this.certificateViewingGroup = certificateViewingGroup;
    	
    }
    
    public Role(long roleId, String roleName, boolean editHazardReportGroup, boolean hazardReportGroup, 
			boolean authorityToEscalateGroup, boolean escalationGroup, boolean fireDrillAuthorityGroup, 
			boolean fireDrillAttendanceGroup, boolean fireDrillStartGroup, boolean fireDrillNotificationGroup,
			boolean documentManagementGroup, boolean documentViewingGroup, boolean deleted, 
			boolean certificateManagementGroup, boolean certificateViewingGroup){
	this.roleId =roleId;
	this.roleName = roleName;
	this.editHazardReportGroup = editHazardReportGroup;
	this.hazardReportGroup = hazardReportGroup;
	this.authorityToEscalateGroup = authorityToEscalateGroup;
	this.escalationGroup = escalationGroup;
	this.fireDrillAuthorityGroup = fireDrillAuthorityGroup;
	this.fireDrillAttendanceGroup = fireDrillAttendanceGroup;
	this.fireDrillStartGroup = fireDrillStartGroup;
	this.fireDrillNotificationGroup = fireDrillNotificationGroup;
	this.documentManagementGroup = documentManagementGroup;
	this.documentViewingGroup = documentViewingGroup;
	this.deleted = deleted;
	this.certificateManagementGroup = certificateManagementGroup;
	this.certificateViewingGroup = certificateViewingGroup;
}

	public long getRoleId() {
		return roleId;
	}

	public void setRoleId(long roleId) {
		this.roleId = roleId;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public Boolean getEditHazardReportGroup() {
		return editHazardReportGroup;
	}

	public void setEditHazardReportGroup(Boolean editHazardReportGroup) {
		this.editHazardReportGroup = editHazardReportGroup;
	}

	public Boolean getHazardReportGroup() {
		return hazardReportGroup;
	}

	public void setHazardReportGroup(Boolean hazardReportGroup) {
		this.hazardReportGroup = hazardReportGroup;
	}

	public Boolean getAuthorityToEscalateGroup() {
		return authorityToEscalateGroup;
	}

	public void setAuthorityToEscalateGroup(Boolean authorityToEscalateGroup) {
		this.authorityToEscalateGroup = authorityToEscalateGroup;
	}

	public Boolean getEscalationGroup() {
		return escalationGroup;
	}

	public void setEscalationGroup(Boolean escalationGroup) {
		this.escalationGroup = escalationGroup;
	}

	public Boolean getFireDrillAuthorityGroup() {
		return fireDrillAuthorityGroup;
	}

	public void setFireDrillAuthorityGroup(Boolean fireDrillAuthorityGroup) {
		this.fireDrillAuthorityGroup = fireDrillAuthorityGroup;
	}

	public Boolean getDocumentManagementGroup() {
		return documentManagementGroup;
	}

	public void setDocumentManagementGroup(Boolean documentManagementGroup) {
		this.documentManagementGroup = documentManagementGroup;
	}

	public Boolean getFireDrillNotificationGroup() {
		return fireDrillNotificationGroup;
	}

	public void setFireDrillNotificationGroup(Boolean fireDrillNotificationGroup) {
		this.fireDrillNotificationGroup = fireDrillNotificationGroup;
	}

	public Boolean getFireDrillAttendanceGroup() {
		return fireDrillAttendanceGroup;
	}

	public void setFireDrillAttendanceGroup(Boolean fireDrillAttendanceGroup) {
		this.fireDrillAttendanceGroup = fireDrillAttendanceGroup;
	}

	public Boolean getDocumentViewingGroup() {
		return documentViewingGroup;
	}

	public void setDocumentViewingGroup(Boolean documentViewingGroup) {
		this.documentViewingGroup = documentViewingGroup;
	}

	public Boolean isDeleted() {
		return deleted;
	}

	public void setDeleted(Boolean deleted) {
		this.deleted = deleted;
	}

	public Boolean getFireDrillStartGroup() {
		return fireDrillStartGroup;
	}

	public void setFireDrillStartGroup(Boolean fireDrillStartGroup) {
		this.fireDrillStartGroup = fireDrillStartGroup;
	}

	public Boolean getCertificateManagementGroup() {
		return certificateManagementGroup;
	}

	public void setCertificateManagementGroup(Boolean certificateManagementGroup) {
		this.certificateManagementGroup = certificateManagementGroup;
	}

	public Boolean getCertificateViewingGroup() {
		return certificateViewingGroup;
	}

	public void setCertificateViewingGroup(Boolean certificateViewingGroup) {
		this.certificateViewingGroup = certificateViewingGroup;
	}

	@Override
	public String toString() {
		return "Role [roleId=" + roleId + ", roleName=" + roleName + ", editHazardReportGroup=" + editHazardReportGroup
				+ ", hazardReportGroup=" + hazardReportGroup + ", authorityToEscalateGroup=" + authorityToEscalateGroup
				+ ", escalationGroup=" + escalationGroup + ", fireDrillAuthorityGroup=" + fireDrillAuthorityGroup
				+ ", fireDrillNotificationGroup=" + fireDrillNotificationGroup + ", fireDrillStartGroup="
				+ fireDrillStartGroup + ", fireDrillAttendanceGroup=" + fireDrillAttendanceGroup
				+ ", documentManagementGroup=" + documentManagementGroup + ", documentViewingGroup="
				+ documentViewingGroup + ", certificateManagementGroup=" + certificateManagementGroup
				+ ", certificateViewingGroup=" + certificateViewingGroup + ", deleted=" + deleted + "]";
	}

	

	
    
}
