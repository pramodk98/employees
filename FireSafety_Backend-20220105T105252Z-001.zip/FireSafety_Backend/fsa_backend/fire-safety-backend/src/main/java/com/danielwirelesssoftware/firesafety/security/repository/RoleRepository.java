package com.danielwirelesssoftware.firesafety.security.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import com.danielwirelesssoftware.firesafety.model.security.Role;

public interface RoleRepository extends JpaRepository<Role, Long> {
	
	Role findByRoleIdAndDeleted(long roleId, boolean deleted);
	
	List<Role> findByFireDrillAttendanceGroupAndDeleted(boolean fireDrillAttendanceGroup, boolean deleted);
	
	List<Role> findByFireDrillAttendanceGroupAndDeletedOrFireDrillAuthorityGroupAndDeletedOrFireDrillStartGroupAndDeleted(boolean fireDrillAttendanceGroup, 
																															boolean deleted, 
																															boolean fireDrillAuthorityGroup, 
																															boolean deleted2,
																															boolean fireDrillStartGroup,
																															boolean deleted3);
}
