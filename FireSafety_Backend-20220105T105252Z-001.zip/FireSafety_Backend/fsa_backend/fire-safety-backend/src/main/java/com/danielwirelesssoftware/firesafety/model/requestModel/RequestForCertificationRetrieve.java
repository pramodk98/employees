package com.danielwirelesssoftware.firesafety.model.requestModel;

public class RequestForCertificationRetrieve {
	
	private long buildingRoleId;
	private long certificationId;
	
	public RequestForCertificationRetrieve() {
	}

	public RequestForCertificationRetrieve(RequestForCertificationRetrieve requestForCertificationRetrieve) {
		this.buildingRoleId = requestForCertificationRetrieve.buildingRoleId;
		this.certificationId = requestForCertificationRetrieve.certificationId;
	}
	
	public RequestForCertificationRetrieve(long buildingRoleId, long certificationId) {
		this.buildingRoleId = buildingRoleId;
		this.certificationId = certificationId;
	}

	public long getBuildingRoleId() {
		return buildingRoleId;
	}

	public void setBuildingRoleId(long buildingRoleId) {
		this.buildingRoleId = buildingRoleId;
	}

	public long getCertificationId() {
		return certificationId;
	}

	public void setCertificationId(long certificationId) {
		this.certificationId = certificationId;
	}
	
	
}

