package com.danielwirelesssoftware.firesafety.model.security;



import javax.persistence.*;

@Entity
@Table(name = "FireDrillType")
public class FireDrillType {
    
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "fireDrillTypeId")
    private long fireDrillTypeId;
    
    @Column(name = "fireDrillTypeName")
    private String fireDrillTypeName;

    @Column(name = "deleted")
    private Boolean deleted;
    
    public FireDrillType(){
	}
    
	public FireDrillType(long fireDrillTypeId, String fireDrillTypeName) {
		this.fireDrillTypeId = fireDrillTypeId;
		this.fireDrillTypeName = fireDrillTypeName;
	}
	
	public FireDrillType(long fireDrillTypeId, String fireDrillTypeName, boolean deleted) {
		this.fireDrillTypeId = fireDrillTypeId;
		this.fireDrillTypeName = fireDrillTypeName;
		this.deleted = deleted;
	}

	public long getFireDrillTypeId() {
		return fireDrillTypeId;
	}

	public void setFireDrillTypeId(long fireDrillTypeId) {
		this.fireDrillTypeId = fireDrillTypeId;
	}

	public String getFireDrillTypeName() {
		return fireDrillTypeName;
	}

	public void setFireDrillTypeName(String fireDrillTypeName) {
		this.fireDrillTypeName = fireDrillTypeName;
	}

	public Boolean isDeleted() {
		return deleted;
	}

	public void setDeleted(Boolean deleted) {
		this.deleted = deleted;
	}
    
}