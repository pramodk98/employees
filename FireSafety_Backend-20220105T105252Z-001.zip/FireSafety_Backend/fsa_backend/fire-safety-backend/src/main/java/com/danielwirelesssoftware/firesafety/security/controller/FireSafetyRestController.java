package com.danielwirelesssoftware.firesafety.security.controller;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mobile.device.Device;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.danielwirelesssoftware.firesafety.model.AttachDocument;
import com.danielwirelesssoftware.firesafety.model.requestModel.RequestForFSCUpdate;
import com.danielwirelesssoftware.firesafety.model.requestModel.RequestWithBuildingRoleId;
import com.danielwirelesssoftware.firesafety.model.responseModel.ResponseForFSC;
import com.danielwirelesssoftware.firesafety.model.security.BuildingRole;
import com.danielwirelesssoftware.firesafety.model.security.FSC;
import com.danielwirelesssoftware.firesafety.security.repository.BuildingRoleRepository;
import com.danielwirelesssoftware.firesafety.security.repository.FSCRepository;

import static com.danielwirelesssoftware.firesafety.common.utils.Constant.DELETE_FALSE;
@RestController
public class FireSafetyRestController {

    private final Log logger = LogFactory.getLog(this.getClass());
    
    @Autowired
    private BuildingRoleRepository buildingRoleRepository;
    
    @Autowired
    private FSCRepository fscRepository;
    
  
    @RequestMapping(value = "/accessFireSafetyCommittee", method = RequestMethod.POST)
    public ResponseEntity<?> fireSafetyCommitteeAccess(@RequestBody RequestWithBuildingRoleId request, Device device){
    	
    	BuildingRole buildingRole;
    	long buildingId;
    	
    	//check buildingRole exist
    	try{
    		buildingRole = buildingRoleRepository.findByBuildingRoleIdAndDeleted(request.getBuildingRoleId(),DELETE_FALSE);  	
	    	buildingId = buildingRole.getBuilding().getBuildingId();
    	}catch(Exception e){
    		logger.error("/accessFireSafetyCommittee API : buildingRole not found for buildingRoleId "+request.getBuildingRoleId());
    		return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
    	}
    	
    	//check building exist
    	if(buildingRole.getBuilding().isDeleted()){
    		logger.error("/accessFireSafetyCommittee API : building not found for buildingRoleId "+request.getBuildingRoleId());
    		return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
    	}
    	
    	
    	FSC fsc = fscRepository.findTopByBuildingIdOrderByFscIdDesc(buildingId);
    	
    	AttachDocument attachDocument = new AttachDocument();
    	
    	//add data if its not null
    	if(fsc!=null){
    		attachDocument = new AttachDocument(fsc.getDocumentName(),fsc.getDocumentKey());
    	}else{
    		logger.info("/accessFireSafetyCommittee API : no data in FSC for buildingId "+buildingId);
    	}
    	
        //set response
    	ResponseForFSC response = new ResponseForFSC(buildingRole.getBuildingRoleId(), buildingId, 
    												attachDocument, buildingRole.getRole().getDocumentManagementGroup());
        
        return new ResponseEntity<ResponseForFSC>(response, HttpStatus.OK);
    }
    
    
    @RequestMapping(value = "/updateFireSafetyCommittee", method = RequestMethod.POST)
    public ResponseEntity<?> fireSafetyCommitteeUpdate(@RequestBody RequestForFSCUpdate request, Device device){
    	
    	BuildingRole buildingRole;
    	long buildingId;
    	
    	try{
    		buildingRole = buildingRoleRepository.findByBuildingRoleIdAndDeleted(request.getBuildingRoleId(),DELETE_FALSE);  	
	    	buildingId = buildingRole.getBuilding().getBuildingId();
    	}catch(Exception e){
    		logger.error("/updateFireSafetyCommittee API : buildingRole not found for buildingRoleId "+request.getBuildingRoleId());
    		logger.error(e);
    		return new ResponseEntity<>("buildingRole not found",HttpStatus.BAD_REQUEST);
    	}
    	
    	
    	if(request.getAttachDocument().getDocumentName() != null 
    		&& request.getAttachDocument().getKey() != null
    		&& !request.getAttachDocument().getDocumentName().isEmpty() 
    		&& !request.getAttachDocument().getKey().isEmpty()){
    		
    		//add new FSC
    		FSC newFSC = new FSC(buildingId,
					request.getAttachDocument().getDocumentName(),
					request.getAttachDocument().getKey());
        	fscRepository.saveAndFlush(newFSC);
        	
    	}else{
    		logger.info("/updateFireSafetyCommittee API : attachDocument data error in request ");
    	}
    	
    	//get latest fsc
    	FSC fsc = fscRepository.findTopByBuildingIdOrderByFscIdDesc(buildingId);
    	
    	AttachDocument attachDocument = new AttachDocument();

    	//add into attachDocument list if fsc exist
    	if(fsc!= null){
    		attachDocument = new AttachDocument(fsc.getDocumentName(),fsc.getDocumentKey());
    	}else{
    		logger.info("/updateFireSafetyCommittee API : no data in FSC for buildingId "+buildingId);
    	}
    	
         //set response
    	ResponseForFSC response = new ResponseForFSC(buildingRole.getBuildingRoleId(), buildingId, 
        											attachDocument, buildingRole.getRole().getDocumentManagementGroup());
        
        return new ResponseEntity<ResponseForFSC>(response, HttpStatus.OK);
    }
    

 
    

}