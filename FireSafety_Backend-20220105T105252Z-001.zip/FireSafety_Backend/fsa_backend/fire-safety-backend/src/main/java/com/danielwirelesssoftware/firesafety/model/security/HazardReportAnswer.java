package com.danielwirelesssoftware.firesafety.model.security;

import java.util.List;

import javax.persistence.*;

@Entity
@Table(name = "HazardReportAnswer")
public class HazardReportAnswer {
    
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "hazardReportAnswerId")
    private long hazardReportAnswerId;
	
    @Column(name = "answerText")
    private String answerText;
    
    @Column(name = "deleted")
    private boolean deleted;
    
    @OneToMany(mappedBy = "answer", fetch = FetchType.LAZY
    		, cascade = {CascadeType.MERGE, CascadeType.DETACH, CascadeType.REFRESH })
    private List<HazardReportQuestionData> hazardReportQuestionDataList;
    
    public HazardReportAnswer(){
	}
    
	public HazardReportAnswer(long hazardReportAnswerId, String answerText) {
		this.hazardReportAnswerId = hazardReportAnswerId;
		this.answerText = answerText;
	}
	
	public HazardReportAnswer(long hazardReportAnswerId, String answerText, boolean deleted) {
		this.hazardReportAnswerId = hazardReportAnswerId;
		this.answerText = answerText;
		this.deleted = deleted;
	}

	public long getHazardReportAnswerId() {
		return hazardReportAnswerId;
	}

	public void setHazardReportAnswerId(long hazardReportAnswerId) {
		this.hazardReportAnswerId = hazardReportAnswerId;
	}

	public String getAnswerText() {
		return answerText;
	}

	public void setAnswerText(String answerText) {
		this.answerText = answerText;
	}

	public List<HazardReportQuestionData> getHazardReportQuestionDataList() {
		return hazardReportQuestionDataList;
	}

	public void setHazardReportQuestionDataList(List<HazardReportQuestionData> hazardReportQuestionDataList) {
		this.hazardReportQuestionDataList = hazardReportQuestionDataList;
	}

	public boolean isDeleted() {
		return deleted;
	}

	public void setDeleted(boolean deleted) {
		this.deleted = deleted;
	}
	
    
}