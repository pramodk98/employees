package com.danielwirelesssoftware.firesafety.model;

public class EmergencyResponsePlanDetail {
    
    private long emergencyPlanId;
    AttachDocument attachDocument;
    
    public EmergencyResponsePlanDetail() {
    }

    public EmergencyResponsePlanDetail(EmergencyResponsePlanDetail emergencyResponsePlanDetail) {
    	this.emergencyPlanId = emergencyResponsePlanDetail.emergencyPlanId;
    	this.attachDocument = emergencyResponsePlanDetail.attachDocument;
    }
    
    public EmergencyResponsePlanDetail(long emergencyPlanId, AttachDocument attachDocument){
    	this.emergencyPlanId = emergencyPlanId;   
    	this.attachDocument = attachDocument;
    }

	public long getEmergencyPlanId() {
		return emergencyPlanId;
	}

	public void setEmergencyPlanIdd(long emergencyPlanId) {
		this.emergencyPlanId = emergencyPlanId;
	}

	public AttachDocument getAttachDocument() {
		return attachDocument;
	}

	public void setAttachDocument(AttachDocument attachDocument) {
		this.attachDocument = attachDocument;
	}

	public void setEmergencyPlanId(long emergencyPlanId) {
		this.emergencyPlanId = emergencyPlanId;
	}

	@Override
	public String toString() {
		return "EmergencyResponsePlanDetail [emergencyPlanId=" + emergencyPlanId + ", attachDocument=" + attachDocument
				+ "]";
	}

	
	
    
}
