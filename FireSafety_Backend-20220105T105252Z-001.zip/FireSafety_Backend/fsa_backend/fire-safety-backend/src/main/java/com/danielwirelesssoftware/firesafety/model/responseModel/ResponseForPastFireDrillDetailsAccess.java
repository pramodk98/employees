package com.danielwirelesssoftware.firesafety.model.responseModel;

import java.util.List;
import com.danielwirelesssoftware.firesafety.model.PastFireDrillAccessDetail;

public class ResponseForPastFireDrillDetailsAccess {
	
	private List<PastFireDrillAccessDetail> fireDrillAttendanceDetail;

	public ResponseForPastFireDrillDetailsAccess(List<PastFireDrillAccessDetail> fireDrillAttendanceDetail) {
		this.fireDrillAttendanceDetail = fireDrillAttendanceDetail;
	}

	public List<PastFireDrillAccessDetail> getFireDrillAttendanceDetail() {
		return fireDrillAttendanceDetail;
	}

	public void setFireDrillAttendanceDetail(List<PastFireDrillAccessDetail> fireDrillAttendanceDetail) {
		this.fireDrillAttendanceDetail = fireDrillAttendanceDetail;
	}

	
	
		
}

