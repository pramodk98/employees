package com.danielwirelesssoftware.firesafety.model;

public class ConfigurationsDetail {
    
    private long configurationId; 
    private String trainingName;
    private String trainingURL;   

    public ConfigurationsDetail(){

	}
    
	public ConfigurationsDetail(long configurationId, String trainingName, String trainingURL) {
		this.configurationId = configurationId;
		this.trainingName = trainingName;
		this.trainingURL = trainingURL;
	}

	public long getConfigurationId() {
		return configurationId;
	}

	public void setConfigurationId(long configurationId) {
		this.configurationId = configurationId;
	}

	public String getTrainingName() {
		return trainingName;
	}

	public void setTrainingName(String trainingName) {
		this.trainingName = trainingName;
	}

	public String getTrainingURL() {
		return trainingURL;
	}

	public void setTrainingURL(String trainingURL) {
		this.trainingURL = trainingURL;
	}

    
    
    
}