package com.danielwirelesssoftware.firesafety.security.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.danielwirelesssoftware.firesafety.model.requestModel.RequestForRegistration;
import com.danielwirelesssoftware.firesafety.model.security.User;
import com.danielwirelesssoftware.firesafety.security.JwtTokenUtil;
import com.danielwirelesssoftware.firesafety.security.JwtUser;
import com.danielwirelesssoftware.firesafety.security.repository.UserRepository;

import javax.servlet.http.HttpServletRequest;


//TODO: remove this class on production, for testing purpose only
@RestController
public class UserRestController {

    @Value("${jwt.header}")
    private String tokenHeader;

    @Autowired
    private JwtTokenUtil jwtTokenUtil;

    @Autowired
    private UserDetailsService userDetailsService;
    
    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;
        
	public PasswordEncoder passwordEncoder(){
		PasswordEncoder encoder = new BCryptPasswordEncoder();
		return encoder;
	}
    
    
    @RequestMapping(value = "user", method = RequestMethod.GET)
    public JwtUser getAuthenticatedUser(HttpServletRequest request) {
        String token = request.getHeader(tokenHeader).substring(7);
        String username = jwtTokenUtil.getUsernameFromToken(token);
        JwtUser user = (JwtUser) userDetailsService.loadUserByUsername(username);
        return user;
    }
    
    
    @GetMapping("/registration")
    public ResponseEntity<?> getRequestsList() {
    	
    	//tester1, qwer1234
    	//tester2, asdf1234
    	//tester3, qwer1234
    	
    	//encrpt pass
    	String pass =new BCryptPasswordEncoder().encode("qwer1234");
    	String pass2 =new BCryptPasswordEncoder().encode("asdf1234");
    	String pass3 =new BCryptPasswordEncoder().encode("qwer1234");
    	String pass4 =new BCryptPasswordEncoder().encode("qwer1234");
    	
    	User u = new User("tester1","tester1", pass, "title1",
    						"tester1@gmail.com", 
    						"+6588881111");
    	User u2 = new User("tester2","tester2", pass2, "title2",
				"tester43@gmail.com",
				"+6588882222");
    	User u3 = new User("tester3","tester3", pass3, "title3",
				"tester3@gmail.com",
				"+6588883333");
    	User u4 = new User("tester4","tester4", pass4, "title4",
				"tester4gmail.com", 
				"+6588884444");
    	userRepository.save(u);
    	userRepository.save(u2);
    	userRepository.save(u3);
    	userRepository.save(u4);
    	
		return new ResponseEntity<>(HttpStatus.OK);
	}
    
    
    @PostMapping("/addSingleUser")
    public ResponseEntity<?> getRequestsList(@RequestBody RequestForRegistration newUser) {

    	User exist = userRepository.findByEmail(newUser.getEmail());
    	
    	//check user exist
    	try{
    		if(exist.getDisplayName() != null || !exist.getDisplayName().isEmpty()){
    			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
    		}
    	}catch(Exception e){
    		
    	}
    	//check for empty field
    	if(newUser.anyUnset()){
    		return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
    	}

    	//encrypt pass
    	String pass = passwordEncoder.encode(newUser.getPassword());
    	
    	//TODO: fix hardcoded name
    	User u = new User("name", newUser.getDiplayName(), pass,
    						newUser.getEmail(), newUser.getTitle(),
    						newUser.getPhoneNumber());
    	userRepository.save(u);
    	
		return new ResponseEntity<>(HttpStatus.OK);
	}

    
   
}
