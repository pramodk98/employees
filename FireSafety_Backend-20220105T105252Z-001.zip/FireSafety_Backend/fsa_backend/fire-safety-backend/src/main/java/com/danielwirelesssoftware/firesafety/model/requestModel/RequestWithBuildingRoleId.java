package com.danielwirelesssoftware.firesafety.model.requestModel;

public class RequestWithBuildingRoleId {
	
	private long buildingRoleId;
	
	public RequestWithBuildingRoleId () {
	}
	
	public RequestWithBuildingRoleId(long buildingRoleId) {
		this.buildingRoleId = buildingRoleId;
	}	
			
	public long getBuildingRoleId() {
		return buildingRoleId;
	}
		
}
