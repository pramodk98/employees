package com.danielwirelesssoftware.firesafety;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.quartz.JobBuilder;
import org.quartz.JobDataMap;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.SimpleScheduleBuilder;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.danielwirelesssoftware.firesafety.common.utils.TimeProvider;
import com.danielwirelesssoftware.firesafety.model.security.Certification;
import com.danielwirelesssoftware.firesafety.model.security.FireDrillSchedule;
import com.danielwirelesssoftware.firesafety.security.repository.CertificationRepository;
import com.danielwirelesssoftware.firesafety.security.repository.FireDrillScheduleRepository;
import com.danielwirelesssoftware.firesafety.security.service.JobBuilderService;
import com.danielwirelesssoftware.firesafety.security.service.ScheduleFireDrillService;

import static com.danielwirelesssoftware.firesafety.common.utils.Constant.DELETE_FALSE;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.STATUS_OPEN;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

@Component
public class ApplicationStartup 
implements ApplicationListener<ApplicationReadyEvent> {

	@Autowired
    private FireDrillScheduleRepository fireDrillScheduleRespository;
	
	@Autowired
    private CertificationRepository certificationRespository;
	
	@Autowired
    private TimeProvider timeProvider;
	
	@Autowired
    private Scheduler scheduler;
	
	@Autowired
	private JobBuilderService jobBuilderService;
	
	private final Log logger = LogFactory.getLog(this.getClass());
  /**
   * This event is executed as late as conceivably possible to indicate that 
   * the application is ready to service requests.
   */
  @Override
  public void onApplicationEvent(final ApplicationReadyEvent event) {
 
	  
   	//TODO: loop FireDrillSchedule and check whichever is still open and not delete and is after current Time
	
	  //get the list of upcoming schedule
	  List<FireDrillSchedule> fireDrillScheduleList = new ArrayList<FireDrillSchedule>();
	  fireDrillScheduleList= fireDrillScheduleRespository.findByScheduleDateTimeAfterAndStatusAndDeleted(timeProvider.timestampNow(),
			  																						STATUS_OPEN, 
			  																						DELETE_FALSE);
	  //loop the fireDrillScheduleList
	  for(FireDrillSchedule fds: fireDrillScheduleList){
		  logger.info("//fireDrillId"+fds.getFireDrillId());
		  
		  //get the original scheduled time, check if its starting within 15 from now. 
		  //if no. send the notification 15 minute before the schedule time. 
		  //else send notification on scheduled time.
		  
		  long scheduleTime;
		  long oriScheduleTime = timeProvider.timestampToLong(fds.getScheduleDateTime());
		  if(oriScheduleTime+TimeUnit.MINUTES.toMillis(15) > timeProvider.longNow()){
			  scheduleTime= oriScheduleTime-TimeUnit.MINUTES.toMillis(15);
			  logger.info("//logging scheduleTime: (-15)"+scheduleTime);
		  }else{
			  scheduleTime = oriScheduleTime;
			  logger.info("//logging scheduleTime: (ori)"+scheduleTime);
		  }
		  
		  //run the scheduler for each fireDrillSchedule
		  try {
			  
			  JobDetail jobDetail =  jobBuilderService.buildJobDetail(fds);
			  Trigger trigger =  jobBuilderService.buildJobTrigger(jobDetail,timeProvider.longToDate(scheduleTime));
			  scheduler.scheduleJob(jobDetail, trigger);
			  
			  logger.info("scheduled fireDrillSchedule for id: "+fds.getFireDrillId() 
	  						+ ", scheduled at dateTime: " +fds.getScheduleDateTime());

	      } catch (SchedulerException e) {
	          logger.error("Error scheduling fireDrill for fireDrillId: "+fds.getFireDrillId()+", error:", e);
	            
	      }
	  }
	  
	  
	  //reschedule all certification 
	  List<Certification> certificationList = new ArrayList<Certification>();
	  certificationList = certificationRespository.findByDeletedAndExpiryDateAfter(DELETE_FALSE, timeProvider.timestampNow());
	  
	  for(Certification certification : certificationList) {
		  try{
	    		//get localTime
	    		LocalDate expiryDate = timeProvider.timestampToLocalDate(certification.getExpiryDate());
	        	LocalDate now = LocalDate.now(); 
	        	for(int i = 3;i>=0; i--){
	        		LocalDate noticeDate = expiryDate.minusMonths(i);
	        		//if notice date > now, schedule the closest date.
	        		if(noticeDate.compareTo(now) >= 0){
	        			JobDetail jobDetail = jobBuilderService.buildJobDetail(certification);
	                    Trigger trigger = jobBuilderService.buildJobTriggerCertification(jobDetail, timeProvider.localDateToDate(noticeDate));
	                    scheduler.scheduleJob(jobDetail, trigger);
	                    
	                    logger.info("scheduled certification for id: "+certification.getCertificationId() 
  						+ ", scheduled at dateTime: " +noticeDate);
	        			break;
	        		}
	        	}
	    	}catch(Exception e){
	    		//send email to system admin
	    	}
	  }
 
    return;
  }
  
}
  
  