package com.danielwirelesssoftware.firesafety.model;

public class EscalationAttendanceDetail {

    private long escalationAttendanceId;
    private long buildingRoleId;
    private String displayName;
    private String role;
    private String status;
   
    public EscalationAttendanceDetail() {
    }

	public EscalationAttendanceDetail(long escalationAttendanceId, long buildingRoleId,
										String displayName, String role,String status) {
		this.escalationAttendanceId = escalationAttendanceId;
		this.buildingRoleId = buildingRoleId;
		this.displayName = displayName;
		this.role = role;
		this.status = status;
	}

	public long getEscalationAttendanceId() {
		return escalationAttendanceId;
	}

	public void setEscalationAttendanceId(long escalationAttendanceId) {
		this.escalationAttendanceId = escalationAttendanceId;
	}

	public long getBuildingRoleId() {
		return buildingRoleId;
	}

	public void setBuildingRoleId(long buildingRoleId) {
		this.buildingRoleId = buildingRoleId;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "EscalationAttendanceDetail [escalationAttendanceId=" + escalationAttendanceId + ", buildingRoleId="
				+ buildingRoleId + ", displayName=" + displayName + ", role=" + role + ", status=" + status + "]";
	}

	
}
