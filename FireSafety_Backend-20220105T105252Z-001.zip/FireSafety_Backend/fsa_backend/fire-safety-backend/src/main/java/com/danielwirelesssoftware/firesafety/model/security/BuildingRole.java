package com.danielwirelesssoftware.firesafety.model.security;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "BuildingRole")
public class BuildingRole {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name="buildingRoleId")
    private Long buildingRoleId;

    @NotNull
    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "userId")
    private User buildingUser;
    
    @NotNull
    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "buildingId")
    private Building building;
    
    @NotNull
    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "roleId")
    private Role role;
    
    @Column(name = "deleted")
    private boolean deleted;
    
    public BuildingRole() {
    }

    public BuildingRole(BuildingRole buildingRole) {
    	this.buildingRoleId = buildingRole.buildingRoleId;
    	this.buildingUser = buildingRole.buildingUser;
    	this.building = buildingRole.building;
    	this.role = buildingRole.role;
    	this.deleted = buildingRole.deleted;
    }

	public BuildingRole(long buildingRoleId, User buildingUser, Building building, Role role /*String userId, String buildingId, String roleId*/) {
		this.buildingRoleId = buildingRoleId;
		this.buildingUser = buildingUser;
		this.building = building;
		this.role = role;
	}
	
	public BuildingRole(long buildingRoleId, User buildingUser, Building building, Role role, boolean deleted) {
		this.buildingRoleId = buildingRoleId;
		this.buildingUser = buildingUser;
		this.building = building;
		this.role = role;
		this.deleted = deleted;

	}

	public long getBuildingRoleId() {
		return buildingRoleId;
	}

	public void setBuildingRoleId(long buildingRoleId) {
		this.buildingRoleId = buildingRoleId;
	}

	public User getUser() {
		return buildingUser;
	}

	public void setUser(User buildingUser) {
		this.buildingUser = buildingUser;
	}

	public Building getBuilding() {
		return building;
	}

	public void setBuilding(Building building) {
		this.building = building;
	}

	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

	public boolean isDeleted() {
		return deleted;
	}

	public void setDeleted(boolean deleted) {
		this.deleted = deleted;
	}

	@Override
	public String toString() {
		return "BuildingRole [buildingRoleId=" + buildingRoleId + ", user=" + buildingUser + ", building=" + building
				+ ", role=" + role + "]";
	}
	
//	public String getUserId() {
//	return userId;
//}
//
//public void setUserId(String userId) {
//	this.userId = userId;
//}
//
//public String getBuildingId() {
//	return buildingId;
//}
//
//public void setBuildingId(String buildingId) {
//	this.buildingId = buildingId;
//}
//
//public String getRoleId() {
//	return roleId;
//}
//
//public void setRoleId(String roleId) {
//	this.roleId = roleId;
//}

//	@Override
//	public String toString() {
//		return "BuildingRole [buildingRoleId=" + buildingRoleId + ", userId=" + userId + ", buildingId=" + buildingId
//				+ ", roleId=" + roleId + "]";
//	}
    
    
}
