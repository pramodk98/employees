package com.danielwirelesssoftware.firesafety.security.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.danielwirelesssoftware.firesafety.model.security.HazardReportQuestion;

public interface HazardReportQuestionRepository extends JpaRepository<HazardReportQuestion, Long> {
	
	HazardReportQuestion findByHazardReportQuestionId(long hazardReportQuestionId); 
	
	List<HazardReportQuestion> findByDeleted(boolean deleted);
	
	List<HazardReportQuestion> findByDeletedOrderBySectionId(boolean deleted);
}
