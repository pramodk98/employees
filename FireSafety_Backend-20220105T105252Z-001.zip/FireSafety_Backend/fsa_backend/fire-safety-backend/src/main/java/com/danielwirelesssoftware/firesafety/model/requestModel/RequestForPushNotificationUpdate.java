package com.danielwirelesssoftware.firesafety.model.requestModel;

import com.danielwirelesssoftware.firesafety.model.UserProfileDetail;

public class RequestForPushNotificationUpdate extends UserProfileDetail {

    private Long userId;
    private boolean pushNotification;
	private String pushNotificationToken;
    
    public RequestForPushNotificationUpdate(){
	}
    
    public RequestForPushNotificationUpdate(Long userId, boolean pushNotification, String pushNotificationToken) {
		this.userId = userId;
		this.pushNotification = pushNotification;
		this.pushNotificationToken = pushNotificationToken;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public boolean getPushNotification() {
		return pushNotification;
	}

	public void setPushNotification(boolean pushNotification) {
		this.pushNotification = pushNotification;
	}

	public String getPushNotificationToken() {
		return pushNotificationToken;
	}

	public void setPushNotificationToken(String pushNotificationToken) {
		this.pushNotificationToken = pushNotificationToken;
	} 
    
}
