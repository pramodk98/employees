package com.danielwirelesssoftware.firesafety.model.responseModel;

public class ResponseForRelogin {
	
	private String token;
	private String buildingName;
	private String name;
	private String tenantName;
	private Long roleId;
	private String role;
	private String key;
	private Long buildingId;
	private Boolean enableViewing;
	private Boolean fireDrillAuthorityGroup;
	private Boolean fireDrillStartGroup;
	private Boolean fireDrillAttendanceGroup;
	
	public ResponseForRelogin() {
	}
	
	public ResponseForRelogin(String token, String buildingName, String name, String tenantName, 
								Long roleId, String role, String key, Long buildingId, Boolean enableViewing, 
								Boolean fireDrillAuthorityGroup, Boolean fireDrillStartGroup, 
								Boolean fireDrillAttendanceGroup) {
		
		this.token = token;
		this.buildingName = buildingName;
		this.name = name;
		this.tenantName = tenantName;
		this.roleId = roleId;
		this.role = role;
		this.key = key;
		this.buildingId = buildingId;
		this.enableViewing = enableViewing;
		this.fireDrillAuthorityGroup = fireDrillAuthorityGroup; 
		this.fireDrillStartGroup = fireDrillStartGroup;
		this.fireDrillAttendanceGroup = fireDrillAttendanceGroup;
	}
	
	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}
	
	public String getBuildingName() {
		return buildingName;
	}

	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getTenantName() {
		return tenantName;
	}

	public void setTenantName(String tenantName) {
		this.tenantName = tenantName;
	}

	public Long getRoleId() {
		return roleId;
	}

	public void setRoleId(Long roleId) {
		this.roleId = roleId;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public Boolean getEnableViewing() {
		return enableViewing;
	}

	public void setEnableViewing(Boolean enableViewing) {
		this.enableViewing = enableViewing;
	}

	public Boolean getFireDrillAuthorityGroup() {
		return fireDrillAuthorityGroup;
	}

	public void setFireDrillAuthorityGroup(Boolean fireDrillAuthorityGroup) {
		this.fireDrillAuthorityGroup = fireDrillAuthorityGroup;
	}

	public Boolean getFireDrillStartGroup() {
		return fireDrillStartGroup;
	}

	public void setFireDrillStartGroup(Boolean fireDrillStartGroup) {
		this.fireDrillStartGroup = fireDrillStartGroup;
	}

	public Boolean getFireDrillAttendanceGroup() {
		return fireDrillAttendanceGroup;
	}

	public void setFireDrillAttendanceGroup(Boolean fireDrillAttendanceGroup) {
		this.fireDrillAttendanceGroup = fireDrillAttendanceGroup;
	}

	public Long getBuildingId() {
		return buildingId;
	}

	public void setBuildingId(Long buildingId) {
		this.buildingId = buildingId;
	}
	
	
}

