package com.danielwirelesssoftware.firesafety.model;

import java.sql.Timestamp;
import java.util.List;

public class FireDrillEndDetail {

	private List<FireDrillAttendanceDetail> fireDrillAttendanceManagerArrayList;
	private Timestamp completeDateTime;
	
	public FireDrillEndDetail(List<FireDrillAttendanceDetail> fireDrillAttendance, Timestamp completeDateTime) {
		this.fireDrillAttendanceManagerArrayList = fireDrillAttendance;
		this.completeDateTime = completeDateTime;
	}

	public List<FireDrillAttendanceDetail> getFireDrillAttendanceManagerArrayList() {
		return fireDrillAttendanceManagerArrayList;
	}

	public void setFireDrillAttendanceManagerArrayList(List<FireDrillAttendanceDetail> fireDrillAttendanceManagerArrayList) {
		this.fireDrillAttendanceManagerArrayList = fireDrillAttendanceManagerArrayList;
	}

	public Timestamp getCompleteDateTime() {
		return completeDateTime;
	}

	public void setCompleteDateTime(Timestamp completeDateTime) {
		this.completeDateTime = completeDateTime;
	}

	@Override
	public String toString() {
		return "FireDrillEndDetail [fireDrillAttendanceManagerArrayList=" + fireDrillAttendanceManagerArrayList
				+ ", completeDateTime=" + completeDateTime + "]";
	}
	
}