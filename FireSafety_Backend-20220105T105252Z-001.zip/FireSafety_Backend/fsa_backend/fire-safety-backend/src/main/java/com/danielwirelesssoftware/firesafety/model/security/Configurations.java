package com.danielwirelesssoftware.firesafety.model.security;

import java.sql.Timestamp;

import javax.persistence.*;

@Entity
@Table(name = "Configurations")
public class Configurations {
    
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name="configurationId")
    private long configurationId; 
    
    @Column(name = "trainingName")
    private String trainingName;
    
    @Column(name = "trainingURL")
    private String trainingURL;
    
    @Column(name = "document")
    private String document;
    
    @Column(name = "lastUpdate")
    private Timestamp lastUpdate;

    public Configurations(){
	}
    
	public Configurations(long configurationId, String trainingName, String trainingURL, String document, Timestamp lastUpdate) {
		this.configurationId = configurationId;
		this.trainingName = trainingName;
		this.trainingURL = trainingURL;
		this.document = document;
		this.lastUpdate = lastUpdate;
	}

	public long getConfigurationId() {
		return configurationId;
	}

	public void setConfigurationId(long configurationId) {
		this.configurationId = configurationId;
	}

	public String getTrainingName() {
		return trainingName;
	}

	public void setTrainingName(String trainingName) {
		this.trainingName = trainingName;
	}

	public String getTrainingURL() {
		return trainingURL;
	}

	public void setTrainingURL(String trainingURL) {
		this.trainingURL = trainingURL;
	}

	public String getDocument() {
		return document;
	}

	public void setDocument(String document) {
		this.document = document;
	}

	public Timestamp getLastUpdate() {
		return lastUpdate;
	}

	public void setLastUpdate(Timestamp lastUpdate) {
		this.lastUpdate = lastUpdate;
	}
    
    
}