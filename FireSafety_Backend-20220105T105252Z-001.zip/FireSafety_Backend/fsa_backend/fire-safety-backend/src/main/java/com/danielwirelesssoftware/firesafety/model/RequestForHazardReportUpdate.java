package com.danielwirelesssoftware.firesafety.model;

import java.util.List;

public class RequestForHazardReportUpdate {
	
	private long buildingRoleId;
    private List<HazardReportDetail> listOfDeletedReport ;

    public RequestForHazardReportUpdate() {
		
	}
    
	public RequestForHazardReportUpdate(long buildingRoleId, List<HazardReportDetail> listOfDeletedReport) {
		this.buildingRoleId = buildingRoleId;
		this.listOfDeletedReport = listOfDeletedReport;
	}

	public List<HazardReportDetail> getListOfDeletedReport() {
		return listOfDeletedReport;
	}

	public void setListOfDeletedReport(List<HazardReportDetail> listOfDeletedReport) {
		this.listOfDeletedReport = listOfDeletedReport;
	}

	public long getBuildingRoleId() {
		return buildingRoleId;
	}

	public void setBuildingRoleId(long buildingRoleId) {
		this.buildingRoleId = buildingRoleId;
	}
    
    
	
}
