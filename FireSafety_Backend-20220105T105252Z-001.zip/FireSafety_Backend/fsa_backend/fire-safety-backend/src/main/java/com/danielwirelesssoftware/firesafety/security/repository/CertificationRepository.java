package com.danielwirelesssoftware.firesafety.security.repository;

import java.sql.Timestamp;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.danielwirelesssoftware.firesafety.model.security.Building;
import com.danielwirelesssoftware.firesafety.model.security.Certification;


public interface CertificationRepository extends JpaRepository<Certification, Long> {

	List<Certification> findByDeletedAndExpiryDateAfter(Boolean deleted,Timestamp now);
	
	List<Certification> findByBuildingAndDeletedAndExpiryDateAfter(long Building, Boolean deleted,Timestamp now);
	
	List<Certification> findByBuildingAndDeleted(Building Building, Boolean deleted);
	
	Certification findByCertificationIdAndDeleted(long certificationId, Boolean deleted);
	
	Certification findByCertificationId(long certificationId);
	
	@Modifying
	@Transactional
	@Query(value = "update Certification c set c.deleted = ?1 where c.certificationId = ?2", nativeQuery = true)
	int setDeletedByCertificationId(Boolean deleted, long certificationId);
}