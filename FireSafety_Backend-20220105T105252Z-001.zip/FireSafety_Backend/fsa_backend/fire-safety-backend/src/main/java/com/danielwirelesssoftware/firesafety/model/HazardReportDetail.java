package com.danielwirelesssoftware.firesafety.model;

import java.sql.Timestamp;

public class HazardReportDetail implements Comparable<HazardReportDetail>{
    
    private Long hazardReportId;
    private String hazardReportName;
    private Timestamp reportTime;
    private String reportName;
    private String status;
	
    public HazardReportDetail(){
	}

    public HazardReportDetail(Long hazardReportId){
    	this.hazardReportId = hazardReportId;
   	}

    
    public HazardReportDetail(Long hazardReportId, String hazardReportName, Timestamp reportTime, String reportName,
			String status) {
    	this.hazardReportId = hazardReportId;
		this.hazardReportName = hazardReportName;
		this.reportTime = reportTime;
		this.reportName = reportName;
		this.status = status;
	}

	public Long getHazardReportId() {
		return hazardReportId;
	}

	public void setHazardReportId(Long hazardReportId) {
		this.hazardReportId = hazardReportId;
	}

	public String getHazardReportName() {
		return hazardReportName;
	}

	public void setHazardReportName(String hazardReportName) {
		this.hazardReportName = hazardReportName;
	}

	public Timestamp getReportTime() {
		return reportTime;
	}

	public void setReportTime(Timestamp reportTime) {
		this.reportTime = reportTime;
	}

	public String getReportName() {
		return reportName;
	}

	public void setReportName(String reportName) {
		this.reportName = reportName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public int compareTo(HazardReportDetail o) {
		return getHazardReportId().compareTo(o.getHazardReportId());
	    
	}
    
    
}