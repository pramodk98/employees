package com.danielwirelesssoftware.firesafety.model.requestModel;

public class RequestForAttendanceUpdate {
	
	private Long notificationId;
	private String status;
	
	public RequestForAttendanceUpdate() {
	}
	
	public RequestForAttendanceUpdate(RequestForAttendanceUpdate requestForAttendanceUpdate) {
		this.notificationId = requestForAttendanceUpdate.notificationId;
		this.status = requestForAttendanceUpdate.status;
	}

	public RequestForAttendanceUpdate(Long notificationId, String status) {
		this.notificationId = notificationId;
		this.status = status;
	}

	public Long getNotificationId() {
		return notificationId;
	}

	public void setNotificationId(Long notificationId) {
		this.notificationId = notificationId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	
}