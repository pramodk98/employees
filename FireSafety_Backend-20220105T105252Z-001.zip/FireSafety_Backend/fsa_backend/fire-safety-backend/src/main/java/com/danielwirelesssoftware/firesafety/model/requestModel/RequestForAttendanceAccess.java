package com.danielwirelesssoftware.firesafety.model.requestModel;

public class RequestForAttendanceAccess {
	
	private long buildingRoleId;
	private long fireDrillId;
	
	public RequestForAttendanceAccess() {
	}
	
	public RequestForAttendanceAccess( RequestForAttendanceAccess requestForAttendanceAccess ) {
		this.buildingRoleId = requestForAttendanceAccess.buildingRoleId;
		this.fireDrillId = requestForAttendanceAccess.fireDrillId;
	}
	
	public RequestForAttendanceAccess(long buildingRoleId, long fireDrillId) {
		this.buildingRoleId = buildingRoleId;
		this.fireDrillId = fireDrillId;
	}
	
	public long getBuildingRoleId() {
		return buildingRoleId;
	}
	
	public void setBuildingRoleId(long buildingRoleId) {
		this.buildingRoleId = buildingRoleId;
	}
	
	public long getFireDrillId() {
		return fireDrillId;
	}
	
	public void setFireDrillId(long fireDrillId) {
		this.fireDrillId = fireDrillId;
	}
	
	
}

