package com.danielwirelesssoftware.firesafety.security.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.danielwirelesssoftware.firesafety.model.security.Building;
import com.danielwirelesssoftware.firesafety.model.security.Tenant;

public interface TenantRepository extends JpaRepository<Tenant, Long> {
	
	Tenant findByTenantId(Long tenantId);
	
	List<Tenant> findByBuilding(Building building);
	
	
}
