package com.danielwirelesssoftware.firesafety.model;

import com.danielwirelesssoftware.firesafety.model.ReviewReportSectionDetail;

public class ReviewReportSectionDetail extends QuestionDetail{

    private String questionAnswer;
    private String questionRemark;
    
    public ReviewReportSectionDetail() {

	}

	public ReviewReportSectionDetail(Long questionId, String questionName, String questionAnswer, String questionRemark) {
		super.setQuestionId(questionId);
		super.setQuestionName(questionName);
		this.questionAnswer = questionAnswer;
		this.questionRemark = questionRemark;
	}

	public String getQuestionAnswer() {
		return questionAnswer;
	}

	public void setQuestionAnswer(String questionAnswer) {
		this.questionAnswer = questionAnswer;
	}

	public String getQuestionRemark() {
		return questionRemark;
	}

	public void setQuestionRemark(String questionRemark) {
		this.questionRemark = questionRemark;
	}    
    
}
