package com.danielwirelesssoftware.firesafety.model.security;

import javax.persistence.*;

@Entity
@Table(name = "Notification")
public class Notification {
    
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name="notificationId")
    private long notificationId; 
    
    @OneToOne()
    @JoinColumn(name = "messageId")
    private Message message;
    
    @ManyToOne()
    @JoinColumn(name = "reciever")
    private User reciever;

    @Column(name = "status")
    private Boolean status;
    
    
    public Notification() {
    	
    }

    public Notification(User reciever, Boolean status, Message message) {
		this.reciever = reciever;
		this.status = status;
		this.message = message;
	}
    
	public Notification(long notificationId, User reciever, Boolean status, Message message) {
		super();
		this.notificationId = notificationId;
		this.reciever = reciever;
		this.status = status;
		this.message = message;
	}

	public long getNotificationId() {
		return notificationId;
	}

	public void setNotificationId(long notificationId) {
		this.notificationId = notificationId;
	}

	public User getReciever() {
		return reciever;
	}

	public void setReciever(User reciever) {
		this.reciever = reciever;
	}

	public Boolean getStatus() {
		return status;
	}

	public void setStatus(Boolean status) {
		this.status = status;
	}

	public Message getMessage() {
		return message;
	}

	public void setMessage(Message message) {
		this.message = message;
	}
    
   
	
    
}
