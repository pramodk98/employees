package com.danielwirelesssoftware.firesafety.security.controller;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.danielwirelesssoftware.firesafety.common.utils.TimeProvider;
import com.danielwirelesssoftware.firesafety.model.UserProfileDetail;
import com.danielwirelesssoftware.firesafety.model.requestModel.RequestForPasswordUpdate;
import com.danielwirelesssoftware.firesafety.model.requestModel.RequestForProfileUpdate;
import com.danielwirelesssoftware.firesafety.model.requestModel.RequestForPushNotificationUpdate;
import com.danielwirelesssoftware.firesafety.model.requestModel.RequestWithBuildingRoleId;
import com.danielwirelesssoftware.firesafety.model.requestModel.RequestWithEmail;
import com.danielwirelesssoftware.firesafety.model.requestModel.RequestWithUserId;
import com.danielwirelesssoftware.firesafety.model.responseModel.ResponseForGeneral;
import com.danielwirelesssoftware.firesafety.model.responseModel.ResponseForPushNotificationRetrieve;
import com.danielwirelesssoftware.firesafety.model.responseModel.ResponseForSettingAccess;
import com.danielwirelesssoftware.firesafety.model.security.BuildingRole;
import com.danielwirelesssoftware.firesafety.model.security.ResetPassword;
import com.danielwirelesssoftware.firesafety.model.security.User;
import com.danielwirelesssoftware.firesafety.security.JwtUser;
import com.danielwirelesssoftware.firesafety.security.repository.BuildingRoleRepository;
import com.danielwirelesssoftware.firesafety.security.repository.ResetPasswordRepository;
import com.danielwirelesssoftware.firesafety.security.repository.UserRepository;
import com.danielwirelesssoftware.firesafety.security.service.EmailService;

import static com.danielwirelesssoftware.firesafety.common.utils.Constant.ROLE_FIRE_SAFETY_MANAGER;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.SUCCESS;

import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Timestamp;
import java.util.Base64;
import java.util.Random;

import javax.servlet.http.HttpServletRequest;

import static com.danielwirelesssoftware.firesafety.common.utils.Constant.DELETE_FALSE;

@RestController
public class ProfileRestController {

    private final Log logger = LogFactory.getLog(this.getClass());
    
    @Value("${server.port-web}")
    private String SERVER_PORT;
    
    @Value("${server.address}")
    private String SERVER_ADDRESS;
    
    @Value("${server.address.protocol}")
    private String SERVER_ADDRESS_PROTOCOL;
    
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private BuildingRoleRepository buildingRoleRepository;
    
    @Autowired
    private ResetPasswordRepository resetPasswordRepository;
    
    @Autowired
    private EmailService emailService;
    
    @Autowired
    private TimeProvider timeProvider;
    
    @Autowired
    private AuthenticationManager authenticationManager;
    
   
    @RequestMapping(value = "/accessProfile", method = RequestMethod.POST)
    public ResponseEntity<?> profileAccess(@AuthenticationPrincipal final JwtUser principle){
    	
    	User user;
    	
    	try{
    		user = userRepository.findByUserIdAndDeleted(principle.getUserId(),DELETE_FALSE);
    	}catch(Exception e){
    		logger.error("/accessProfile : user not found for userId "+principle.getUserId());
    		return new ResponseEntity<>("user not found",HttpStatus.UNAUTHORIZED);
    	}
    	
    	UserProfileDetail response = new UserProfileDetail(user.getDisplayName(),user.getEmail(),user.getPhoneNumber(),user.getProfileImage());
    	
    	return new ResponseEntity<UserProfileDetail>(response, HttpStatus.OK);
    }
    
    
    @RequestMapping(value = "/updateProfile", method = RequestMethod.POST)
    public ResponseEntity<?> profileUpdate(@RequestBody RequestForProfileUpdate request){
    	
    	User userExist = null;
    	userExist = userRepository.findByEmailAndDeleted(request.getEmail(),DELETE_FALSE);
    	
    	if(userExist != null){
    		if(userExist.getUserId() != request.getUserId()){
    			logger.error("/updateProfile : email existed "+request.getUserId());
        		return new ResponseEntity<>("email used",HttpStatus.BAD_REQUEST);
    		}	
    	}
    	
    	try{
    		userRepository.setFixedDisplayNameAndEmailAndContactNoAndProfileImageFor(request.getName(), 
																					request.getEmail(), 
																					request.getContactNo(), 
																					request.getKey(),
																					request.getUserId());
    	}catch(Exception e){
    		logger.error("error in updateProfile: "+e);
    		return new ResponseEntity<ResponseForGeneral>(new ResponseForGeneral("fail"), HttpStatus.BAD_REQUEST);
    	}
    	
    	return new ResponseEntity<ResponseForGeneral>(new ResponseForGeneral(SUCCESS), HttpStatus.OK);
    }
    
    @RequestMapping(value = "/accessSettings", method = RequestMethod.POST)
    public ResponseEntity<?> settingsAccess(@RequestBody RequestWithBuildingRoleId request){
    	
    	BuildingRole buildingRole;
    	
    	try{
    		buildingRole = buildingRoleRepository.findByBuildingRoleIdAndDeleted(request.getBuildingRoleId(),DELETE_FALSE);  	
    	}catch(Exception e){
    		logger.error("/accessSettings : buildingRole not found for buildingRoleId "+request.getBuildingRoleId());
    		return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
    	}
    	
    	ResponseForSettingAccess response = new ResponseForSettingAccess (buildingRole.getUser().getNotification(),
    																		buildingRole.getBuilding().getName(),
    																		buildingRole.getRole().getRoleName().equalsIgnoreCase(ROLE_FIRE_SAFETY_MANAGER));
 
    	return new ResponseEntity<ResponseForSettingAccess>(response, HttpStatus.OK);
    }
    
    
    @RequestMapping(value = "/updatePushNotification", method = RequestMethod.POST)
    public ResponseEntity<?> pushNotificationUpdate(@RequestBody RequestForPushNotificationUpdate request){
    	
    	try{
    		if(request.getPushNotificationToken() == null || request.getPushNotificationToken().isEmpty()){
    			userRepository.setFixedNotificationFor(request.getPushNotification(), request.getUserId());
    		}else{
    			userRepository.setPushNotificationTokenFor(request.getPushNotificationToken());
    			userRepository.setFixedNotificationAndPushNotificationTokenFor(request.getPushNotification(), request.getPushNotificationToken(), request.getUserId());
    		}
    		
    		
    	}catch(Exception e){
    		logger.error("error in updatePushNotification: "+e);
    		return new ResponseEntity<ResponseForGeneral>(new ResponseForGeneral("fail"), HttpStatus.BAD_REQUEST);
    	}
    	
    	return new ResponseEntity<ResponseForGeneral>(new ResponseForGeneral(SUCCESS), HttpStatus.OK);
    }
    
    
    @RequestMapping(value = "/forgetPassword", method = RequestMethod.POST)
    public ResponseEntity<?> passwordForget(@RequestBody RequestWithEmail request,HttpServletRequest httpServletRequest){
    	
    	User user = null;
    	user = userRepository.findByEmailAndDeleted(request.getEmail(), DELETE_FALSE);
    	
    	if(user == null){
    		logger.error("/forgetPassword, user not found for email: "+request.getEmail());
    		return new ResponseEntity<ResponseForGeneral>(HttpStatus.BAD_REQUEST);
    	}
    	
    	//generate random code
    	String encodedUserId = Base64.getUrlEncoder().encodeToString(String.valueOf(user.getUserId()).getBytes());
    	try {
			encodedUserId = URLEncoder.encode(encodedUserId, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	Timestamp now = timeProvider.timestampNow();
    	String ukey = user.getUsername() + "_" + user.getEmail() + "_" + new Random().nextInt(10000) + "_" + now;
    	
    	MessageDigest md5;
    	String newUkey=null;
		try {
			md5 = MessageDigest.getInstance("MD5");
			md5.update(StandardCharsets.UTF_8.encode(ukey));
			newUkey = String.format("%032x", new BigInteger(1, md5.digest()));
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
		if(newUkey == null){
			logger.error("/forgetPassword, something is wrong with MD5 for user: "+request.getEmail());
			return new ResponseEntity<ResponseForGeneral>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
    	String link = SERVER_ADDRESS_PROTOCOL+SERVER_ADDRESS+":"+SERVER_PORT + "/changePassword?a=recovery&token="+newUkey+"&u="+encodedUserId;
    	
    	emailService.sendForgetPasswordEmail(user,link);
    	
    	resetPasswordRepository.save(new ResetPassword(newUkey, user,timeProvider.millisecondsLater(86400000L) , DELETE_FALSE));
    	
    	ResponseForGeneral response = new ResponseForGeneral(SUCCESS);
    	
    	return new ResponseEntity<>(response, HttpStatus.OK);
    }
    
    //for Android. BCrypt implementation is done on the mobile side.
    //Android sending new password in BCrypted format.
    @RequestMapping(value = "/updatePassword", method = RequestMethod.POST)
    public ResponseEntity<?> passwordUpdate(@AuthenticationPrincipal final JwtUser principle, 
    										@RequestBody RequestForPasswordUpdate request,
    										HttpServletRequest servletRequest){
    	
    	User user = null;
    	user = userRepository.findByUserIdAndDeleted(principle.getUserId(),DELETE_FALSE);
    	
    	if(user== null){
    		logger.error("/updatePassword, user not found for userId: "+principle.getUserId());
    		return new ResponseEntity<ResponseForGeneral>(new ResponseForGeneral("user not found"),HttpStatus.UNAUTHORIZED);
    	}
    	
    	//check if its the correct current password.
    	try{
    		Authentication auth = authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(
																									          principle.getUsername(),
																									          request.getPassword()
																									        	)
	        );
    	}catch(BadCredentialsException e){
    		logger.error("/updatePassword, password & id mismatch for username: "+principle.getUsername());
    		return new ResponseEntity<ResponseForGeneral>(new ResponseForGeneral("id and password mismatch"),HttpStatus.BAD_REQUEST);
    	}
    	
    	logger.debug("/updatePassword, password:"+request.getPassword());
    	logger.debug("/updatePassword, newPassword:"+request.getNewPassword());
    	
    	//save the password directly as its already in BCrypt format.
    	userRepository.setPasswordFor(request.getNewPassword(), user.getUsername());
    	logger.debug("/updatePassword, updated Password for userId: "+principle.getUserId()
	    				+ ", at remote Address: "+servletRequest.getRemoteAddr() 
	    				+ ", local Address: "+ servletRequest.getLocalAddr() 
	    				+ ", ServerPort: "+ servletRequest.getServerPort()
	    				+ ", LocalPort: "+ servletRequest.getLocalPort()
	    				+ ", RemotePort: "+ servletRequest.getRemotePort());
    	
    	ResponseForGeneral response = new ResponseForGeneral(SUCCESS);
    	
    	return new ResponseEntity<>(response, HttpStatus.OK);
    }
    
    //for IOS, BCrypt implementation is done on the backend.
    //IOS sending in the new password without encryption.
    @RequestMapping(value = "/updatePassword2", method = RequestMethod.POST)
    public ResponseEntity<?> passwordUpdate2(@AuthenticationPrincipal final JwtUser principle, 
    										@RequestBody RequestForPasswordUpdate request,
    										HttpServletRequest servletRequest){
    	
    	User user = null;
    	user = userRepository.findByUserIdAndDeleted(principle.getUserId(),DELETE_FALSE);
    	
    	if(user== null){
    		logger.error("/updatePassword, user not found for userId: "+principle.getUserId());
    		return new ResponseEntity<ResponseForGeneral>(new ResponseForGeneral("user not found"),HttpStatus.UNAUTHORIZED);
    	}
    	
    	//check if its the correct current password.
    	try{
    		Authentication auth = authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(
																									          principle.getUsername(),
																									          request.getPassword()
																									        	)
	        );
    	}catch(BadCredentialsException e){
    		logger.error("/updatePassword, password & id mismatch for username: "+principle.getUsername());
    		return new ResponseEntity<ResponseForGeneral>(new ResponseForGeneral("id and password mismatch"),HttpStatus.BAD_REQUEST);
    	}
    	
    	logger.debug("/updatePassword, password:"+request.getPassword());
    	logger.debug("/updatePassword, newPassword:"+request.getNewPassword());
    	
    	//encode the new password in BCrypt format.
    	String encrpytedNewPassword = new BCryptPasswordEncoder().encode(request.getNewPassword());
    	
    	//save the new password.
    	userRepository.setPasswordFor(encrpytedNewPassword, user.getUsername());
    	logger.debug("/updatePassword, updated Password for userId: "+principle.getUserId()
	    				+ ", at remote Address: "+servletRequest.getRemoteAddr() 
	    				+ ", local Address: "+ servletRequest.getLocalAddr() 
	    				+ ", ServerPort: "+ servletRequest.getServerPort()
	    				+ ", LocalPort: "+ servletRequest.getLocalPort()
	    				+ ", RemotePort: "+ servletRequest.getRemotePort());
    	
    	ResponseForGeneral response = new ResponseForGeneral(SUCCESS);
    	
    	return new ResponseEntity<>(response, HttpStatus.OK);
    }
    
}