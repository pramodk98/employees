package com.danielwirelesssoftware.firesafety.model;

public class TenantEmployeeDetail {

    private long tenantEmployeeId;

    private String tenantEmployeeName;
    
    private String tenantEmployeePosition;
    
    private String status;

    public TenantEmployeeDetail() {
    }

	public TenantEmployeeDetail(long tenantEmployeeId, String tenantEmployeeName,
			String tenantEmployeePosition, String status) {
		this.tenantEmployeeId = tenantEmployeeId;
		this.tenantEmployeeName = tenantEmployeeName;
		this.tenantEmployeePosition = tenantEmployeePosition;
		this.status = status;
	}
	
	public TenantEmployeeDetail(String status) {
		this.status = status;
	}

	public long getTenantEmployeeId() {
		return tenantEmployeeId;
	}

	public void setTenantEmployeeId(long tenantEmployeeId) {
		this.tenantEmployeeId = tenantEmployeeId;
	}

	public String getTenantEmployeeName() {
		return tenantEmployeeName;
	}

	public void setTenantEmployeeName(String tenantEmployeeName) {
		this.tenantEmployeeName = tenantEmployeeName;
	}

	public String getTenantEmployeePosition() {
		return tenantEmployeePosition;
	}

	public void setTenantEmployeePosition(String tenantEmployeePosition) {
		this.tenantEmployeePosition = tenantEmployeePosition;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
    
	

    
}
