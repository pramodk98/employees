package com.danielwirelesssoftware.firesafety.security.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.danielwirelesssoftware.firesafety.model.security.FireDrillAttendance;
import com.danielwirelesssoftware.firesafety.model.security.FireDrillSchedule;
import com.danielwirelesssoftware.firesafety.model.security.TenantEmployee;
import com.danielwirelesssoftware.firesafety.model.security.User;

public interface FireDrillAttendanceRepository extends JpaRepository<FireDrillAttendance, Long> {
	
	FireDrillAttendance findByFireDrillAttendanceId(Long fireDrillAttendanceId);
	
	FireDrillAttendance findByFireDrillSchedule(FireDrillSchedule fireDrillSchedule );
	
	FireDrillAttendance findByTenantEmployeeAndFireDrillSchedule(TenantEmployee tenantEmployee, FireDrillSchedule fireDrillSchedule );
	
	
	@Modifying
	@Transactional
	@Query(value = "update FireDrillAttendance f set f.status = ?1 where f.fireDrillAttendanceId = ?2", nativeQuery = true)
	int setStatusFor(String status, long fireDrillAttendanceId);
	
	
}
