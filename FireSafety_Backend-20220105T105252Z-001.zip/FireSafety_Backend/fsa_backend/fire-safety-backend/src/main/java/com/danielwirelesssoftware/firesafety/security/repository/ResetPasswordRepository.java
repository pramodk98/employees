package com.danielwirelesssoftware.firesafety.security.repository;

import com.danielwirelesssoftware.firesafety.model.security.ResetPassword;
import org.springframework.data.jpa.repository.JpaRepository;

import java.sql.Timestamp;

public interface ResetPasswordRepository extends JpaRepository<ResetPassword, Long> {
	
	ResetPassword findByTokenAndUsedAndExpiryDateAfter(String token, Boolean used, Timestamp expiryDate);

}

