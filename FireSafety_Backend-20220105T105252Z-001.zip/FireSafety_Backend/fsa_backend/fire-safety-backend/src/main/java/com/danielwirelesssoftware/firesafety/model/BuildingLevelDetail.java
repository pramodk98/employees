package com.danielwirelesssoftware.firesafety.model;

import java.util.List;

public class BuildingLevelDetail {
   
    private long levelId;
    private String levelName;

    private List<PremiseEmergencyData> premiseEmergencyDataList;

    public BuildingLevelDetail() {
    }

	public BuildingLevelDetail(long levelId, String levelName, List<PremiseEmergencyData> premiseEmergencyDataList) {
		this.levelId = levelId;
		this.levelName = levelName;
		this.premiseEmergencyDataList = premiseEmergencyDataList;
	}

	public long getLevelId() {
		return levelId;
	}

	public void setLevelId(long levelId) {
		this.levelId = levelId;
	}

	public String getLevelName() {
		return levelName;
	}

	public void setLevelName(String levelName) {
		this.levelName = levelName;
	}

	public List<PremiseEmergencyData> getPremiseEmergencyDataList() {
		return premiseEmergencyDataList;
	}

	public void setPremiseEmergencyDataList(List<PremiseEmergencyData> premiseEmergencyDataList) {
		this.premiseEmergencyDataList = premiseEmergencyDataList;
	}


	
	

}
