package com.danielwirelesssoftware.firesafety.model.responseModel;

import com.danielwirelesssoftware.firesafety.model.AttachDocument;

public class ResponseForFSC {
	
	private Long buildingRoleId;
	private Long buildingId;
	private AttachDocument attachDocument;
	private boolean enableEditImage;
	
	public ResponseForFSC() {
	}
	
	public ResponseForFSC(ResponseForFSC responseForFSC) {
		this.buildingRoleId = responseForFSC.buildingRoleId;
		this.buildingId = responseForFSC.buildingId;
		this.attachDocument = responseForFSC.attachDocument;
		this.enableEditImage = responseForFSC.enableEditImage;
	}
	
	public ResponseForFSC(Long buildingRoleId, Long buildingId, AttachDocument attachDocument, boolean enableEditImage) {
		this.buildingRoleId = buildingRoleId;
		this.buildingId = buildingId;
		this.attachDocument = attachDocument;
		this.enableEditImage = enableEditImage;
	}

	public Long getBuildingRoleId() {
		return buildingRoleId;
	}

	public void setBuildingRoleId(Long buildingRoleId) {
		this.buildingRoleId = buildingRoleId;
	}

	public Long getBuildingId() {
		return buildingId;
	}

	public void setBuildingId(Long buildingId) {
		this.buildingId = buildingId;
	}

	public AttachDocument getAttachDocument() {
		return attachDocument;
	}

	public void setAttachDocument(AttachDocument attachDocument) {
		this.attachDocument = attachDocument;
	}

	public boolean isEnableEditImage() {
		return enableEditImage;
	}

	public void setEnableEditImage(boolean enableEditImage) {
		this.enableEditImage = enableEditImage;
	}
	
	
		
}

