package com.danielwirelesssoftware.firesafety.security;

import com.danielwirelesssoftware.firesafety.model.security.User;
import com.fasterxml.jackson.annotation.JsonIgnore;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class JwtUser extends User implements UserDetails {

	private static final long serialVersionUID = 7524591251055428902L;
	
	private final Log logger = LogFactory.getLog(this.getClass());
	
	private boolean deleted = true;
	
	  public JwtUser(final User user) {
	    	 super(user);
	    	 this.deleted = user.isDeleted();
	    }

	    @JsonIgnore
	    public Long getUserId() {
	        return super.getUserId();
	    }
	    
	    
	    public String getEmail() {
	        return super.getEmail();
	    }

		@Override
	    public String getUsername() {
	        return super.getUsername();
	    }
	    
	    @Override
	    public String getDisplayName() {
	        return super.getDisplayName();
	    }

	    @JsonIgnore
	    @Override
	    public boolean isAccountNonExpired() {
	        return true;
	    }

	    @JsonIgnore
	    @Override
	    public boolean isAccountNonLocked() {
	        return true;
	    }

	    @JsonIgnore
	    @Override
	    public boolean isCredentialsNonExpired() {
	        return true;
	    }

	    @JsonIgnore
	    @Override
	    public String getPassword() {
	    	logger.debug("inside jwtUser get password:"+super.getPassword());
	        return super.getPassword();
	    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
    	
    	// TODO fix hardcode
        List<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();
        authorities.add(new SimpleGrantedAuthority("ROLE_ADMIN"/* + getMobileRole().getRole()*/));
        return authorities;
    }

//	@Override
//	public String getUsername() {
//		// TODO Auto-generated method stub
//		return null;
//	}

	@Override
	public boolean isEnabled() {	
		return !deleted;
		
		//return true;
		//return !super.isDeleted();
	}

//    @Override
//    public boolean isEnabled() {
//        return super.isEnabled();
//    }
}
