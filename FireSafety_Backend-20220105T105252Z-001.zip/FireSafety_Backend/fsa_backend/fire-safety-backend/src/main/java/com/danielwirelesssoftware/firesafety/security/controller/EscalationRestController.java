package com.danielwirelesssoftware.firesafety.security.controller;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.danielwirelesssoftware.firesafety.common.utils.TimeProvider;
import com.danielwirelesssoftware.firesafety.model.EscalationAttendanceDetail;
import com.danielwirelesssoftware.firesafety.model.requestModel.RequestForEndEscalation;
import com.danielwirelesssoftware.firesafety.model.requestModel.RequestForStartEscalation;
import com.danielwirelesssoftware.firesafety.model.requestModel.RequestForUpdateEscalation;
import com.danielwirelesssoftware.firesafety.model.requestModel.RequestWithBuildingRoleId;
import com.danielwirelesssoftware.firesafety.model.responseModel.ResponseForEscalation;
import com.danielwirelesssoftware.firesafety.model.responseModel.ResponseForGeneral;
import com.danielwirelesssoftware.firesafety.model.security.Building;
import com.danielwirelesssoftware.firesafety.model.security.BuildingRole;
import com.danielwirelesssoftware.firesafety.model.security.Escalation;
import com.danielwirelesssoftware.firesafety.model.security.EscalationAttendance;
import com.danielwirelesssoftware.firesafety.model.security.Message;
import com.danielwirelesssoftware.firesafety.model.security.MessageType;
import com.danielwirelesssoftware.firesafety.model.security.Role;
import com.danielwirelesssoftware.firesafety.model.security.User;
import com.danielwirelesssoftware.firesafety.security.repository.BuildingRoleRepository;
import com.danielwirelesssoftware.firesafety.security.repository.EscalationAttendanceRepository;
import com.danielwirelesssoftware.firesafety.security.repository.EscalationRepository;
import com.danielwirelesssoftware.firesafety.security.repository.MessageRepository;
import com.danielwirelesssoftware.firesafety.security.repository.MessageTypeRepository;
import com.danielwirelesssoftware.firesafety.security.service.EscalationService;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import static com.danielwirelesssoftware.firesafety.common.utils.Constant.SUCCESS;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.STATUS_ABSENT;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.STATUS_OPEN;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.STATUS_CLOSE;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.STATUS_NOT_PARTICIPATING;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.DELETE_FALSE;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.MESSAGE_TYPE_ESCALATION;

@RestController
public class EscalationRestController {

    private final Log logger = LogFactory.getLog(this.getClass());
    
    @Autowired
    private BuildingRoleRepository buildingRoleRepository;
    
    @Autowired
    private EscalationRepository escalationRepository;
    
    @Autowired
    private EscalationAttendanceRepository escalationAttendanceRepository;
    
    @Autowired
    private TimeProvider timeProvider;
    
    @Autowired
    private EscalationService escalationService;
    
    @Autowired
    private MessageTypeRepository messageTypeRepository;
  
    @RequestMapping(value = "/escalation", method = RequestMethod.POST)
    public ResponseEntity<?> escalation(@RequestBody RequestWithBuildingRoleId request){
    	
    	Timestamp dateTime = null;
    	Long escalationId = 0L;
    	boolean checkAuthorityToEscalate = false;
    	List <EscalationAttendanceDetail> escalationAttendanceList = new ArrayList<>();
    	
    	BuildingRole buildingRole = null;
    	buildingRole = buildingRoleRepository.findByBuildingRoleIdAndDeleted(request.getBuildingRoleId(),DELETE_FALSE);    	
    	
    	if(buildingRole == null){
    		logger.error("//escalation : buildingRole not found for buildingRoleId "+request.getBuildingRoleId());
    		return new ResponseEntity<>("invalid buildingRoleId",HttpStatus.BAD_REQUEST);
    	}
    	
    	if(buildingRole.getBuilding().isDeleted()){
    		logger.error("//escalation : building not found for buildingRoleId "+request.getBuildingRoleId());
    		return new ResponseEntity<>("invalid building",HttpStatus.UNAUTHORIZED);
    	}
    	
    	Escalation escalation = null;
    	escalation = escalationRepository.findTopByEscalationBuildingOrderByDateTimeDesc(buildingRole.getBuilding());
    	
    	//not checking escalationAuthority, as the mobile side is checking, and required get 401 to call generatingQRCode	
    	checkAuthorityToEscalate = buildingRole.getRole().getAuthorityToEscalateGroup();
    	
    	//if there is no escalation for this building yet
    	if (escalation == null){
    		
    		List<BuildingRole> buildingRoleList = buildingRoleRepository.findByBuildingAndDeleted(buildingRole.getBuilding(), DELETE_FALSE);
    		
    		//create a list of user to be return 
    		for(BuildingRole r : buildingRoleList){
    			
    			//check if the user is in escalation group and the role's user is not deleted
    			if(r.getRole().getEscalationGroup() && !r.getUser().isDeleted() && r.getBuildingRoleId() != request.getBuildingRoleId()){
    				logger.info("escalation dont exist for user: " + r.getUser().getDisplayName());
    				
    				Long buildingRoleId = r.getBuildingRoleId();
        			String displayName = r.getUser().getDisplayName();
        			String role = r.getRole().getRoleName();
        			String Status = "";
        			
        			//add into a list of user
        			escalationAttendanceList.add(new EscalationAttendanceDetail(0, buildingRoleId, displayName, role, Status));
        			
        			logger.info("escalation dont exist: " + escalationAttendanceList.toString());
    			}	
    		}
    		
    		
    	//if there is escalation for this building
    	}else{
    		//check if escalation is completed or ongoing
    	    if(escalation.getCompleteDateTime() != null){    	    	
    	    	
    	    	List<BuildingRole> buildingRoleList = buildingRoleRepository.findByBuilding(buildingRole.getBuilding());
        		
        		//create a list of user to be return 
        		for(BuildingRole r : buildingRoleList){
        			
        			//check if the user is in escalation group and the role's user is deleted
        			if(r.getRole().getEscalationGroup() && !r.getUser().isDeleted() 
        					&& r.getBuildingRoleId() != request.getBuildingRoleId()){
        				logger.info("escalation exist for user: " + r.getUser().getDisplayName());
        				Long buildingRoleId = r.getBuildingRoleId();
        				String displayName = r.getUser().getDisplayName();
            			String role = r.getRole().getRoleName();
            			String Status = "";
            			
            			logger.info("escalation exist: " + escalationAttendanceList.toString());
            			//add into a list of user
            			escalationAttendanceList.add(new EscalationAttendanceDetail(0,buildingRoleId, displayName, role, Status));
            			
        			}	
        		}
        	
        	//escalation is ongoing	
    	    }else{
    	    	
    	    	//current user is not the user who one that started the escalation
    	    	if(buildingRole.getUser().getUserId() != escalation.getReporter().getUserId()){
    	    		
    	    		ResponseForEscalation response = new ResponseForEscalation(dateTime,escalationId,buildingRole.getBuilding().getName(),
							checkAuthorityToEscalate,escalationAttendanceList);
    	    		
    	    		return new ResponseEntity<ResponseForEscalation>(response,HttpStatus.CREATED);
    	    	}
    	    	
    	    	//set return dateTime to escalation start datetime
    	    	dateTime = escalation.getDateTime();
    	    	
    	    	//set return escaltionId
    	    	escalationId = escalation.getEscalationId();
    	    	
        	    for(EscalationAttendance e: escalationAttendanceRepository.findByEscalationId(escalationId)){
            		
            		BuildingRole br = buildingRoleRepository.findByBuildingUserAndBuilding(e.getUser(),buildingRole.getBuilding());
            		Role r = br.getRole();
            		if(r.getEscalationGroup()==true && !e.getStatus().equalsIgnoreCase(STATUS_NOT_PARTICIPATING)){
        	    		EscalationAttendanceDetail ea = new EscalationAttendanceDetail(e.getEscalationAttendanceId(),
        	    																		br.getBuildingRoleId(),
        																	    		e.getUser().getDisplayName(),
        																	    		r.getRoleName(),
        																	    		e.getStatus());
        	    		escalationAttendanceList.add(ea);
        	    		logger.info("escalation on going: " + escalationAttendanceList.toString());
            		}
        	    }
    	    }
    	}
	      	
        //set response
    	ResponseForEscalation response = new ResponseForEscalation(dateTime,escalationId,buildingRole.getBuilding().getName(),
    																checkAuthorityToEscalate,escalationAttendanceList);
        
        return new ResponseEntity<ResponseForEscalation>(response, HttpStatus.OK);
    }
    
    @RequestMapping(value = "/escalationStart", method = RequestMethod.POST)
    public ResponseEntity<?> startEscalation(@RequestBody RequestForStartEscalation request){
    	
    	BuildingRole buildingRole = null;
    	buildingRole = buildingRoleRepository.findByBuildingRoleIdAndDeleted(request.getBuildingRoleId(),DELETE_FALSE);  	
    	
    	if(buildingRole == null){
    		logger.error("/escalationStart API : buildingRole not found for buildingRoleId "+request.getBuildingRoleId());
    		return new ResponseEntity<>("invalid buildingRoleId",HttpStatus.BAD_REQUEST);
    	}
    	
    	//check permission to start escalation
    	if(!buildingRole.getRole().getAuthorityToEscalateGroup()){
    		logger.error("/escalationStart API : buildingRole:"+ buildingRole +" unauthorize to escalate");
    		return new ResponseEntity<>("unauthorize to escalate",HttpStatus.FORBIDDEN);
    	}
    	
    	User user = buildingRole.getUser();
    	Building building =buildingRole.getBuilding();
    	
    	if(building.isDeleted()){
    		logger.error("/escalationStart API : building is deleted for buildingRoleId "+request.getBuildingRoleId());
    		return new ResponseEntity<>("invalid building",HttpStatus.BAD_REQUEST);
    	}
    	
    	Timestamp now = timeProvider.timestampNow();
    	long escalationId;
    	
    	//check if there is ongoing escalation, return error if there is ,else add new escalation
    	try{
    		
	    	Escalation e = escalationRepository.findTopByCompleteDateTimeIsNullAndEscalationBuildingAndStatusOrderByEscalationIdDesc(
	    																									building,STATUS_OPEN);
	    	logger.error("/escalationStart API : on going escalation for escalationId "+e.getEscalationId());
	    	//if there is an on going escalation
	    	return new ResponseEntity<String>("ongoing escalation exist",HttpStatus.BAD_REQUEST);
    	}catch(Exception e){
    		logger.info("error"+e);
    		logger.info("/escalationStart API : adding escalation for buildingId "+building.getBuildingId());
    		escalationRepository.saveAndFlush(new Escalation(building,user,timeProvider.longToTimestamp(request.getDateTime()),
					now,STATUS_OPEN));
    	}
    	
    	
    	//get the escalation id
    	escalationId = escalationRepository.findTopByEscalationBuildingAndReporterOrderByEscalationIdDesc(building,user).getEscalationId();
    	
    	logger.info("//escalationId: "+escalationId);
    	
    	List<EscalationAttendanceDetail> escalationAttendanceList = new ArrayList<EscalationAttendanceDetail>();
    	
    	//loop request buildingRoleId
    	for(RequestWithBuildingRoleId bid :request.getEscalationAttendanceList()){
    		
    		logger.info("//bid: "+bid.getBuildingRoleId());
    		
    		// get building role base on the list of buildingRoleId
    		BuildingRole br = null;
    		br = buildingRoleRepository.findByBuildingRoleIdAndDeleted(bid.getBuildingRoleId(),DELETE_FALSE);
    		
    		if(br==null || br.getUser().isDeleted() || br.isDeleted()){
    			continue;
    		}
    		
    		EscalationAttendance ea = null;
    		ea = escalationAttendanceRepository.findByEscalationIdAndUser(escalationId,br.getUser());
    		
    		//escalationAttandance dont exist
    		//create and update escalationAttendance
    		if(ea == null){
    			EscalationAttendance eascalationAttendance = new EscalationAttendance(escalationId,br.getUser(),STATUS_ABSENT);
    			ea = escalationAttendanceRepository.saveAndFlush(eascalationAttendance);
    			logger.info("//catch EscalationAttendance: "+ea.getEscalationAttendanceId());
    		}
    		
    		EscalationAttendanceDetail ead = new EscalationAttendanceDetail(ea.getEscalationAttendanceId(),
		    		bid.getBuildingRoleId(),
		    		br.getUser().getDisplayName(),
		    		br.getRole().getRoleName(),
		    		ea.getStatus());
			
			escalationAttendanceList.add(ead);
				
    	}
    	
    	MessageType messageType = null;
		messageType = messageTypeRepository.findTopByMessageTypeAndDeletedOrderByMessageTypeIdDesc("Escalation",DELETE_FALSE);
    	
		if(messageType == null){
			messageType = messageTypeRepository.findByMessageTypeId(MESSAGE_TYPE_ESCALATION);
		}
    	//initialize counter
		final AtomicInteger counter = new AtomicInteger();
		
		//start sending start escalation pushNotification to everyone
		Thread startEscalation = new Thread(escalationService.escalationThread(counter,escalationAttendanceList,escalationId,messageType));
		startEscalation.start();
    	
    	ResponseForEscalation response = new ResponseForEscalation(timeProvider.longToTimestamp(request.getDateTime()),
															    	escalationId,
															    	building.getName(),
															    	buildingRole.getRole().getEscalationGroup(),
															    	escalationAttendanceList);	
    	   	
    	return new ResponseEntity<ResponseForEscalation>(response, HttpStatus.OK);
    }

    
    @RequestMapping(value = "/escalationUpdate", method = RequestMethod.POST)
    public ResponseEntity<?> updateEscalation(@RequestBody RequestForUpdateEscalation request){
    	
    	try{
    		escalationAttendanceRepository.setFixedStatusFor(request.getStatus(),request.getEscalationAttendanceId());
    	}catch (Exception e){
    		logger.error("/escalationUpdate, error updating status: "+e);
    		return new ResponseEntity<ResponseForGeneral>(new ResponseForGeneral("fail"), HttpStatus.BAD_REQUEST);
    	}
    	
    	return new ResponseEntity<ResponseForGeneral>(new ResponseForGeneral(SUCCESS), HttpStatus.OK);
    }
    
    
    @RequestMapping(value = "/escalationEnd", method = RequestMethod.POST)
    public ResponseEntity<?> endEscalation(@RequestBody RequestForEndEscalation request){
    	
    	Escalation escalation = escalationRepository.findByEscalationId(request.getEscalationId());
    	
//    	if(escalation.getStatus().equals(STATUS_CLOSE)){
//    		return new ResponseEntity<ResponseForGeneral>(new ResponseForGeneral("fail"), HttpStatus.BAD_REQUEST);
//    	}
    	
    	//update escalation
    	try{
    		escalationRepository.setLastUpdateAndStatusAndCompleteDateTimeByEscalationId(timeProvider.timestampNow(),
																					STATUS_CLOSE,
																					timeProvider.longToTimestamp(
																							request.getEndDateTime()),
																					request.getEscalationId());
    	}catch (Exception e){
    		logger.error("error updating escalation in escalationEnd: "+e);
    		return new ResponseEntity<ResponseForGeneral>(new ResponseForGeneral("fail"), HttpStatus.BAD_REQUEST);
    	}
    	
    	//update escalationAttendance list
    	for(RequestForUpdateEscalation ue : request.getEscalationAttendanceList()){
    		try{
        		escalationAttendanceRepository.setFixedStatusFor(ue.getStatus(),request.getBuildingRoleId());
        	}catch (Exception e){
        		logger.error("error updating escalationAttendance in escalationEnd: "+e);
        		return new ResponseEntity<ResponseForGeneral>(new ResponseForGeneral("fail"), HttpStatus.BAD_REQUEST);
        	}
    	}
    	
    	return new ResponseEntity<ResponseForGeneral>(new ResponseForGeneral(SUCCESS), HttpStatus.OK);
    }
}