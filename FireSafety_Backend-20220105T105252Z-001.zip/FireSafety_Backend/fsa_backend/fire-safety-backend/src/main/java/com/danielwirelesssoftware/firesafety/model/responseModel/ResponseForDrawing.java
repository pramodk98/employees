package com.danielwirelesssoftware.firesafety.model.responseModel;

import java.util.List;

import com.danielwirelesssoftware.firesafety.model.BuildingLevelDrawingDetail;

public class ResponseForDrawing {
	
	private Long buildingId;
	private Boolean enableEdit;
	private List<BuildingLevelDrawingDetail> listOfBuildingLevelDrawingList;
	
	public ResponseForDrawing() {
	}
	
	public ResponseForDrawing(ResponseForDrawing responseForDrawing) {
		this.buildingId = responseForDrawing.buildingId;
		this.enableEdit = responseForDrawing.enableEdit;
		this.listOfBuildingLevelDrawingList = responseForDrawing.listOfBuildingLevelDrawingList;
	}
	
	public ResponseForDrawing( Long buildingId, Boolean enableEdit, List<BuildingLevelDrawingDetail> listOfBuildingLevelDrawingList) {
		this.buildingId = buildingId;
		this.enableEdit = enableEdit;
		this.listOfBuildingLevelDrawingList = listOfBuildingLevelDrawingList;
	}

	public Long getBuildingId() {
		return buildingId;
	}

	public void setBuildingId(Long buildingId) {
		this.buildingId = buildingId;
	}

	public List<BuildingLevelDrawingDetail> getListOfBuildingLevelDrawingList() {
		return listOfBuildingLevelDrawingList;
	}

	public void setListOfBuildingLevelDrawingList(List<BuildingLevelDrawingDetail> listOfBuildingLevelDrawingList) {
		this.listOfBuildingLevelDrawingList = listOfBuildingLevelDrawingList;
	}

	public Boolean getEnableEdit() {
		return enableEdit;
	}

	public void setEnableEdit(Boolean enableEdit) {
		this.enableEdit = enableEdit;
	}
	
	
}

