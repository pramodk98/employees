package com.danielwirelesssoftware.firesafety.security.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.danielwirelesssoftware.firesafety.model.security.EscalationAttendance;
import com.danielwirelesssoftware.firesafety.model.security.User;

public interface EscalationAttendanceRepository extends JpaRepository<EscalationAttendance, Long> {
	
	EscalationAttendance findByEscalationAttendanceId(long escalationAttendanceId);
	
	List<EscalationAttendance> findByEscalationId(long escalationId);
	
	EscalationAttendance findByEscalationIdAndUser(long escalationId, User user);
	
	@Modifying
	@Transactional
	@Query("update EscalationAttendance e set e.status = ?1 where e.escalationAttendanceId = ?2")
	int setFixedStatusFor(String status, long escalationAttendanceId);
	
}
