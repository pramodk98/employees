package com.danielwirelesssoftware.firesafety.model.responseModel;

import java.util.List;
import com.danielwirelesssoftware.firesafety.model.EmergencyResponsePlanDetail;

public class ResponseForERP {
		
	private Long buildingId;
	private Boolean enableEdit;
	private List<EmergencyResponsePlanDetail>emergencyResponsePlanList;
	
	public ResponseForERP() {
	}
	
	public ResponseForERP(ResponseForERP responseForERP) {
		this.buildingId = responseForERP.buildingId;
		this.enableEdit = responseForERP.enableEdit;
		this.emergencyResponsePlanList = responseForERP.emergencyResponsePlanList;
	}
	
	public ResponseForERP(Long buildingId,Boolean enableEdit, List<EmergencyResponsePlanDetail>emergencyResponsePlanList) {		
		this.buildingId = buildingId;
		this.enableEdit = enableEdit;
		this.emergencyResponsePlanList = emergencyResponsePlanList;
	}

	public Long getBuildingId() {
		return buildingId;
	}

	public void setBuildingId(Long buildingId) {
		this.buildingId = buildingId;
	}

	public List<EmergencyResponsePlanDetail> getEmergencyResponsePlanList() {
		return emergencyResponsePlanList;
	}

	public void setEmergencyResponsePlanList(List<EmergencyResponsePlanDetail> emergencyResponsePlanList) {
		this.emergencyResponsePlanList = emergencyResponsePlanList;
	}

	public Boolean getEnableEdit() {
		return enableEdit;
	}

	public void setEnableEdit(Boolean enableEdit) {
		this.enableEdit = enableEdit;
	}
	
}

