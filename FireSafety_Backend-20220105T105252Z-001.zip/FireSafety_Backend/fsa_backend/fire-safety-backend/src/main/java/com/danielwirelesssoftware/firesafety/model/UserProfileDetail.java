package com.danielwirelesssoftware.firesafety.model;

public class UserProfileDetail {

    private String name;
    private String email;
    private String contactNo;
    private String key;
	
    public UserProfileDetail(){
	}
    
    public UserProfileDetail(UserProfileDetail userProfileDetail){
    	this.name = userProfileDetail.name;
		this.email = userProfileDetail.email;
		this.contactNo = userProfileDetail.contactNo;
		this.key = userProfileDetail.key;
	}
    
    public UserProfileDetail(String name, String email, String contactNo, String key) {
		this.name = name;
		this.email = email;
		this.contactNo = contactNo;
		this.key = key;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

    
}
