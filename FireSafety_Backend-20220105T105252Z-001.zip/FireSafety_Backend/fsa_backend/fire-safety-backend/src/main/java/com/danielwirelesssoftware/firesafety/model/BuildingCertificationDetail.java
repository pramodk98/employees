package com.danielwirelesssoftware.firesafety.model;

import java.sql.Timestamp;

import com.danielwirelesssoftware.firesafety.model.AttachDocument;
import com.danielwirelesssoftware.firesafety.model.security.Certification;
import com.danielwirelesssoftware.firesafety.model.security.User;

public class BuildingCertificationDetail implements Comparable<BuildingCertificationDetail> {
	
	private long certificationId;
	private String certificationName;
	private String description;
	private Timestamp expiryDate;
	private AttachDocument attachDocument;
	private String editedBy;
	
	public BuildingCertificationDetail() {
	}
	
//	//on retrieve
//	public BuildingCertificationDetail(Certification certification,AttachDocument certificateDocument) {
//		this.certificationId = certification.getCertificationId();
//		this.certificationName = certification.getCertificationName();
//		this.description = certification.getDescription();
//		this.expiryDate = certification.getExpiryDate();
//		this.editedBy = certification.getEditedBy().getDisplayName();
//		this.attachDocument = certificateDocument;
//	}
	
	public BuildingCertificationDetail(Certification certification) {
		this.certificationId = certification.getCertificationId();
		this.certificationName = certification.getCertificationName();
		this.description = certification.getDescription();
		this.expiryDate = certification.getExpiryDate();
		this.editedBy = certification.getEditedBy().getDisplayName();
		if(certification.getDocumentName() != null){
			this.attachDocument = new AttachDocument(certification.getDocumentName(), certification.getDocumentKey());
		}else{
			this.attachDocument = null;
		}
	}
	
	public BuildingCertificationDetail(BuildingCertificationDetail buildingCertificationDetail) {
		this.certificationName = buildingCertificationDetail.certificationName;
		this.description = buildingCertificationDetail.description;
		this.expiryDate = buildingCertificationDetail.expiryDate;
		this.attachDocument = buildingCertificationDetail.attachDocument;
	}
	
	//on create
	public BuildingCertificationDetail(String certificationName, String description, Timestamp expiryDate,
			AttachDocument certificateDocument) {
		this.certificationName = certificationName;
		this.description = description;
		this.expiryDate = expiryDate;
		this.attachDocument = certificateDocument;
	}
	
	public BuildingCertificationDetail(String certificationName, String description, Timestamp expiryDate) {
		this.certificationName = certificationName;
		this.description = description;
		this.expiryDate = expiryDate;
	}
	
	public BuildingCertificationDetail(long certificationId,String certificationName, String description, 
			Timestamp expiryDate) {
		this.certificationId = certificationId;
		this.certificationName = certificationName;
		this.description = description;
		this.expiryDate = expiryDate;
	}
	
	public BuildingCertificationDetail(String certificationName, String description, Timestamp expiryDate,
			Timestamp lastExpiryDate, AttachDocument certificateDocument) {
		this.certificationName = certificationName;
		this.description = description;
		this.expiryDate = expiryDate;
		this.attachDocument = certificateDocument;
	}
	
	public BuildingCertificationDetail(long certificationId, String certificationName, String description, Timestamp expiryDate,
			 AttachDocument certificateDocument) {
		this.certificationId = certificationId;
		this.certificationName = certificationName;
		this.description = description;
		this.expiryDate = expiryDate;
		this.attachDocument = certificateDocument;
		
	}
	
	public BuildingCertificationDetail(long certificationId, String certificationName, String description, Timestamp expiryDate,
			Timestamp lastExpiryDate, AttachDocument certificateDocument) {
		this.certificationName = certificationName;
		this.description = description;
		this.expiryDate = expiryDate;
		this.attachDocument = certificateDocument;
		this.certificationId = certificationId;
	}
	
	
	
	public String getCertificationName() {
		return certificationName;
	}
	
	public void setCertificationName(String certificationName) {
		this.certificationName = certificationName;
	}
	
	public String getDescription() {
		return description;
	}
	
	public void setDescription(String description) {
		this.description = description;
	}
	
	public Timestamp getExpiryDate() {
		return expiryDate;
	}
	
	public void setExpiryDate(Timestamp expiryDate) {
		this.expiryDate = expiryDate;
	}	
	
	public AttachDocument getCertificateDocument(){
		return attachDocument;
	}
	
	public void setCertificateDocument(AttachDocument certificateDocument) {
		this.attachDocument = certificateDocument;
	}

	public long getCertificationId() {
		return certificationId;
	}

	public void setCertificationId(long certificationId) {
		this.certificationId = certificationId;
	}

	public AttachDocument getAttachDocument() {
		return attachDocument;
	}

	public void setAttachDocument(AttachDocument attachDocument) {
		this.attachDocument = attachDocument;
	}

	public String getEditedBy() {
		return editedBy;
	}

	public void setEditedBy(String editedBy) {
		this.editedBy = editedBy;
	}
	
	public int compareTo(BuildingCertificationDetail o) {
		// sort by expired date
	    return getExpiryDate().compareTo(o.getExpiryDate());
	    
	}
	
}
