package com.danielwirelesssoftware.firesafety.model.security;

import javax.persistence.*;

@Entity
@Table(name = "FSC")
public class FSC {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "fscId")
    private long fscId;
    
    @Column(name = "buildingId")
    private long buildingId;
    
    @Column(name = "documentName")
    private String documentName;
    
    @Column(name = "documentKey")
    private String documentKey;


    public FSC() {
    }

    public FSC(FSC fsc) {
    	this.fscId = fsc.fscId;
    	this.buildingId = fsc.buildingId;
    	this.documentName = fsc.documentName;
    	this.documentKey = fsc.documentKey;
    }
    
    public FSC(long buildingId, String documentName, String documentKey){
    	this.buildingId = buildingId;
    	this.documentName = documentName;
    	this.documentKey = documentKey;
    }

	public long getFscId() {
		return fscId;
	}

	public void setFscId(long fscId) {
		this.fscId = fscId;
	}

	public long getBuildingId() {
		return buildingId;
	}

	public void setBuildingId(long buildingId) {
		this.buildingId = buildingId;
	}

	public String getDocumentName() {
		return documentName;
	}	

	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}
	
	public void setDocumentKey(String documentKey) {
		this.documentKey = documentKey;
	}
	
	public String getDocumentKey() {
		return documentKey;
	}

	@Override
	public String toString() {
		return "FSC [fscId=" + fscId + ", buildingId=" + buildingId + ", documentName=" + documentName + ", documentKey=" + documentKey+"]";
	}
    
    
    
}
