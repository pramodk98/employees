package com.danielwirelesssoftware.firesafety.security.repository;

import java.sql.Timestamp;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.danielwirelesssoftware.firesafety.model.security.Building;
import com.danielwirelesssoftware.firesafety.model.security.Escalation;
import com.danielwirelesssoftware.firesafety.model.security.User;

public interface EscalationRepository extends JpaRepository<Escalation, Long> {
	
	Escalation findByEscalationId(long escalationId);
	
	Escalation findByEscalationIdAndStatusAndCompleteDateTimeIsNull(long escalationId,String status);
	
	Escalation findTopByEscalationBuildingOrderByDateTimeDesc(Building building);
	
	Escalation findTopByEscalationBuildingAndReporterOrderByEscalationIdDesc(Building building,User reporter);

	Escalation findTopByCompleteDateTimeIsNullAndEscalationBuildingAndStatusOrderByEscalationIdDesc(Building building, String Status);
	
	@Modifying
	@Transactional
	@Query(value = "update Escalation e set e.lastUpdate = ?1, e.status = ?2, e.completeDateTime = ?3 where e.escalationId = ?4", nativeQuery = true)
	int setLastUpdateAndStatusAndCompleteDateTimeByEscalationId(Timestamp lastUpdate, String status, Timestamp completeDateTime, long escalationId);
	
}
