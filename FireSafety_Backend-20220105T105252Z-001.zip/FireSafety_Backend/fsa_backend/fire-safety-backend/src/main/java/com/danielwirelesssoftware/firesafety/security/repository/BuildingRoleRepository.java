package com.danielwirelesssoftware.firesafety.security.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.danielwirelesssoftware.firesafety.model.security.Building;
import com.danielwirelesssoftware.firesafety.model.security.BuildingRole;
import com.danielwirelesssoftware.firesafety.model.security.Role;
import com.danielwirelesssoftware.firesafety.model.security.User;

public interface BuildingRoleRepository extends JpaRepository<BuildingRole, Long> {
	
	BuildingRole findByBuildingRoleIdAndDeleted(Long buildingRoleId, boolean deleted);
	
	List<BuildingRole> findByBuilding(Building building);
	
	List<BuildingRole> findByBuildingAndDeleted(Building building, boolean deleted);
	
	List<BuildingRole> findByBuildingUserAndDeleted(User buildingUser, boolean deleted);
	
	BuildingRole findByBuildingUserAndBuilding(User buildingUser,Building building);
	
	List<BuildingRole> findByBuildingAndRoleAndDeleted(Building building, Role role, boolean deleted);
}
