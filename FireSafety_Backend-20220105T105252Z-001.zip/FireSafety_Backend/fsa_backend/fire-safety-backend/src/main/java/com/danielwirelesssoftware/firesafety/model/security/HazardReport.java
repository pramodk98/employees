package com.danielwirelesssoftware.firesafety.model.security;



import java.sql.Timestamp;

import javax.persistence.*;

@Entity
@Table(name = "HazardReport")
public class HazardReport {
    
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "hazardReportId")
    private Long hazardReportId;

    @Column(name = "hazardReportName")
    private String hazardReportName;
    
    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "buildingId")
    private Building building;

    @Column(name = "dateTime")
    private Timestamp dateTime;

    @Column(name = "lastUpdate")
    private Timestamp lastUpdate;

    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "reporterId")
    private User reporter;

    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "closeReporterId")
    private User closeReporter;

    @Column(name = "status")
    private String status;

    @Column(name = "closeComment")
    private String closeComment;

    @Column(name = "deleted")
    private boolean deleted;
    
    @Column(name = "editedBy")
    private Long editedBy;

    public HazardReport(){
	}
    
    public HazardReport( String hazardReportName, Building building, Timestamp dateTime,
			Timestamp lastUpdate, User reporter, User closeReporter, String status, String closeComment,
			boolean deleted, Long editedBy) {
		this.hazardReportName = hazardReportName;
		this.building = building;
		this.dateTime = dateTime;
		this.lastUpdate = lastUpdate;
		this.reporter = reporter;
		this.closeReporter = closeReporter;
		this.status = status;
		this.closeComment = closeComment;
		this.deleted = deleted;
		this.editedBy = editedBy;
	}
    
	public HazardReport(Long hazardReportId, String hazardReportName, Building building, Timestamp dateTime,
			Timestamp lastUpdate, User reporter, User closeReporter, String status, String closeComment,
			boolean deleted, Long editedBy) {
		this.hazardReportId = hazardReportId;
		this.hazardReportName = hazardReportName;
		this.building = building;
		this.dateTime = dateTime;
		this.lastUpdate = lastUpdate;
		this.reporter = reporter;
		this.closeReporter = closeReporter;
		this.status = status;
		this.closeComment = closeComment;
		this.deleted = deleted;
		this.editedBy = editedBy;
	}

	public Long getHazardReportId() {
		return hazardReportId;
	}

	public void setHazardReportId(Long hazardReportId) {
		this.hazardReportId = hazardReportId;
	}

	public String getHazardReportName() {
		return hazardReportName;
	}

	public void setHazardReportName(String hazardReportName) {
		this.hazardReportName = hazardReportName;
	}

	public Building getBuilding() {
		return building;
	}

	public void setBuilding(Building building) {
		this.building = building;
	}

	public Timestamp getDateTime() {
		return dateTime;
	}

	public void setDateTime(Timestamp dateTime) {
		this.dateTime = dateTime;
	}

	public Timestamp getLastUpdate() {
		return lastUpdate;
	}

	public void setLastUpdate(Timestamp lastUpdate) {
		this.lastUpdate = lastUpdate;
	}

	public User getReporter() {
		return reporter;
	}

	public void setReporter(User reporter) {
		this.reporter = reporter;
	}

	public User getCloseReporter() {
		return closeReporter;
	}

	public void setCloseReporter(User closeReporter) {
		this.closeReporter = closeReporter;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getCloseComment() {
		return closeComment;
	}

	public void setCloseComment(String closeComment) {
		this.closeComment = closeComment;
	}

	public boolean isDeleted() {
		return deleted;
	}

	public void setDeleted(boolean deleted) {
		this.deleted = deleted;
	}

	public Long getEditedBy() {
		return editedBy;
	}

	public void setEditedBy(Long editedBy) {
		this.editedBy = editedBy;
	}

	
    
}