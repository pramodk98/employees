package com.danielwirelesssoftware.firesafety.security.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.danielwirelesssoftware.firesafety.model.security.MessageType;

public interface MessageTypeRepository extends JpaRepository<MessageType, Long> {
	
	MessageType findTopByMessageTypeAndDeletedOrderByMessageTypeIdDesc(String messageType, boolean deleted);
	
	MessageType findByMessageTypeId(long messageTypeId);
}