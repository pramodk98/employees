package com.danielwirelesssoftware.firesafety.model.responseModel;

public class ResponseForPushNotificationRetrieve {
	
	private boolean notification;

	public ResponseForPushNotificationRetrieve(boolean notification) {
		this.notification = notification;
	}

	public boolean isNotification() {
		return notification;
	}

	public void setNotification(boolean notification) {
		this.notification = notification;
	}
	
	
}

