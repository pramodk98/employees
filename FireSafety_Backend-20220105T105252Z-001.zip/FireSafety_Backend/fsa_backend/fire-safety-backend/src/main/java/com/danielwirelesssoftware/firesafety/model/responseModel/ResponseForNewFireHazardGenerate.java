package com.danielwirelesssoftware.firesafety.model.responseModel;

import java.util.List;
import com.danielwirelesssoftware.firesafety.model.BuildingDetail;
import com.danielwirelesssoftware.firesafety.model.HazardReportAnswerDetail;
import com.danielwirelesssoftware.firesafety.model.SectionHazardReportDetail;
import com.danielwirelesssoftware.firesafety.model.security.HazardReportAnswer;

public class ResponseForNewFireHazardGenerate {
	
	private long buildingId;
	private boolean checkEnableEditHazardReport;
	private String displayName;
	private List<HazardReportAnswerDetail> listOfAnswers;
	private List<SectionHazardReportDetail> listOfSectionsHazardReport;
	
	public ResponseForNewFireHazardGenerate(long buildingId,
											boolean checkEnableEditHazardReport,
											String displayName,
											List<HazardReportAnswerDetail> listOfAnswers,
											List<SectionHazardReportDetail> listOfSectionsHazardReport) {
		
		this.buildingId = buildingId;
		this.checkEnableEditHazardReport = checkEnableEditHazardReport;
		this.displayName = displayName;
		this.listOfAnswers = listOfAnswers;
		this.listOfSectionsHazardReport = listOfSectionsHazardReport;
	}

	public List<HazardReportAnswerDetail> getListOfAnswers() {
		return listOfAnswers;
	}

	public void setListOfAnswers(List<HazardReportAnswerDetail> listOfAnswers) {
		this.listOfAnswers = listOfAnswers;
	}

	public List<SectionHazardReportDetail> getListOfSectionsHazardReport() {
		return listOfSectionsHazardReport;
	}

	public void setListOfSectionsHazardReport(List<SectionHazardReportDetail> listOfSectionsHazardReport) {
		this.listOfSectionsHazardReport = listOfSectionsHazardReport;
	}

	public boolean isCheckEnableEditHazardReport() {
		return checkEnableEditHazardReport;
	}

	public void setCheckEnableEditHazardReport(boolean checkEnableEditHazardReport) {
		this.checkEnableEditHazardReport = checkEnableEditHazardReport;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public long getBuildingId() {
		return buildingId;
	}

	public void setBuildingId(long buildingId) {
		this.buildingId = buildingId;
	}
	
	
	
}

