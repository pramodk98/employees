package com.danielwirelesssoftware.firesafety.model.responseModel;

import java.util.List;

import com.danielwirelesssoftware.firesafety.model.FireDrillTypeDetail;

public class ResponseForNewFireDrillGenerate{
	
	List<FireDrillTypeDetail> listOfFireDrillType;

	public ResponseForNewFireDrillGenerate(List<FireDrillTypeDetail> listOfFireDrillType) {
		this.listOfFireDrillType = listOfFireDrillType;
	}

	public List<FireDrillTypeDetail> getListOfFireDrillType() {
		return listOfFireDrillType;
	}

	public void setListOfFireDrillType(List<FireDrillTypeDetail> listOfFireDrillType) {
		this.listOfFireDrillType = listOfFireDrillType;
	}
	
}