package com.danielwirelesssoftware.firesafety.model.requestModel;

import java.util.List;

import com.danielwirelesssoftware.firesafety.model.EmergencyResponsePlanDetail;

public class RequestForERPUpdate {
	
	private long buildingId;
	private List<EmergencyResponsePlanDetail> emergencyResponsePlanList;
	
	public RequestForERPUpdate() {
	}
	
	public RequestForERPUpdate(long buildingId, List<EmergencyResponsePlanDetail> emergencyResponsePlanList) {
		this.buildingId = buildingId;
		this.emergencyResponsePlanList = emergencyResponsePlanList;
	}

	public long getBuildingId() {
		return buildingId;
	}

	public void setBuildingId(long buildingId) {
		this.buildingId = buildingId;
	}

	public List<EmergencyResponsePlanDetail> getEmergencyResponsePlanList() {
		return emergencyResponsePlanList;
	}

	public void setEmergencyResponsePlanList(List<EmergencyResponsePlanDetail> emergencyResponsePlanList) {
		this.emergencyResponsePlanList = emergencyResponsePlanList;
	}

	
	
}

