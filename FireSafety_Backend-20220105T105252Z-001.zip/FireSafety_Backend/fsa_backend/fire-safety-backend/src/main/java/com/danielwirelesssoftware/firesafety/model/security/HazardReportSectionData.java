package com.danielwirelesssoftware.firesafety.model.security;

import java.util.List;

import javax.persistence.*;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

@Entity
@Table(name = "HazardReportSectionData")
public class HazardReportSectionData {
    
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "hazardSectionDataId")
    private long hazardSectionDataId;

    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "sectionId")
    private HazardReportSection section;
    
    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "hazardReportId")
    private HazardReport hazardReport;
    
    @OneToMany(mappedBy = "dataHazardReport", fetch = FetchType.LAZY
    		, cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.DETACH, CascadeType.REFRESH })
    @Fetch(value = FetchMode.SUBSELECT)
    private List<HazardReportQuestionData> hazardReportQuestionDataList;
    
    @OneToMany(mappedBy = "imageHazardReport", fetch = FetchType.LAZY
    		, cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.DETACH, CascadeType.REFRESH })
    @Fetch(value = FetchMode.SUBSELECT)
    private List<HazardReportSectionImage> hazardReportSectionImageList;

    public HazardReportSectionData() {
	}
    
    public HazardReportSectionData(HazardReportSection section, HazardReport hazardReport) {
		this.section = section;
		this.hazardReport = hazardReport;
	}
    
	public HazardReportSectionData(long hazardSectionDataId, HazardReportSection section, HazardReport hazardReport) {
		this.hazardSectionDataId = hazardSectionDataId;
		this.section = section;
		this.hazardReport = hazardReport;
	}
    
	public long getHazardSectionDataId() {
		return hazardSectionDataId;
	}

	public void setHazardSectionDataId(long hazardSectionDataId) {
		this.hazardSectionDataId = hazardSectionDataId;
	}

	public HazardReportSection getSection() {
		return section;
	}

	public void setSection(HazardReportSection section) {
		this.section = section;
	}

	public HazardReport getHazardReport() {
		return hazardReport;
	}

	public void setHazardReport(HazardReport hazardReport) {
		this.hazardReport = hazardReport;
	}

	public List<HazardReportQuestionData> getHazardReportQuestionDataList() {
		return hazardReportQuestionDataList;
	}

	public void setHazardReportQuestionData(List<HazardReportQuestionData> hazardReportQuestionDataList) {
		this.hazardReportQuestionDataList = hazardReportQuestionDataList;
	}

	public List<HazardReportSectionImage> getHazardReportSectionImageList() {
		return hazardReportSectionImageList;
	}

	public void setHazardReportSectionImage(List<HazardReportSectionImage> hazardReportSectionImageList) {
		this.hazardReportSectionImageList = hazardReportSectionImageList;
	}
	
    
}