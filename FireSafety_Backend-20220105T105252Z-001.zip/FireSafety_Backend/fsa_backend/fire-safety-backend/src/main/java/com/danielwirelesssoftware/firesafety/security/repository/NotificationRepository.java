package com.danielwirelesssoftware.firesafety.security.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.danielwirelesssoftware.firesafety.model.security.Notification;
import com.danielwirelesssoftware.firesafety.model.security.User;

public interface NotificationRepository extends JpaRepository<Notification, Long> {
	
	List<Notification> findByReciever(User reciever);
	
	Notification findByNotificationId(long notificationId);
	
	@Modifying
	@Transactional
	@Query(value = "update Notification n set n.status = ?1 where n.notificationId = ?2", nativeQuery = true)
	int setFixStatus(boolean status, long notificationId);
	
}
