package com.danielwirelesssoftware.firesafety.model;

import com.danielwirelesssoftware.firesafety.model.security.MessageImage;

public class AttachDocument {

    private String documentName;
    private String key;

    public AttachDocument() {
    }

    public AttachDocument(MessageImage messageImage) {
		this.documentName = messageImage.getDocumentName();
		this.key = messageImage.getDocumentKey();
	}

    
	public AttachDocument(String documentName, String key) {
		this.documentName = documentName;
		this.key = key;
	}

	public String getDocumentName() {
		return documentName;
	}

	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	
	
	

	
}
