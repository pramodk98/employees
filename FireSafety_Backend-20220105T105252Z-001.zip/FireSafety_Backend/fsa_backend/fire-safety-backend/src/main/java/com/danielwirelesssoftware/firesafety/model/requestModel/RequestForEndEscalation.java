package com.danielwirelesssoftware.firesafety.model.requestModel;

import java.sql.Timestamp;
import java.util.List;

public class RequestForEndEscalation {
	
	private long buildingRoleId;
	private long escalationId;
	private long endDateTime;
	private List<RequestForUpdateEscalation> escalationAttendanceList;
	
	public RequestForEndEscalation(){
	}
	
	public RequestForEndEscalation(long buildingRoleId, long escalationId, long endDateTime,
			List<RequestForUpdateEscalation> escalationAttendanceList) {
		this.buildingRoleId = buildingRoleId;
		this.escalationId = escalationId;
		this.endDateTime = endDateTime;
		this.escalationAttendanceList = escalationAttendanceList;
	}

	public long getBuildingRoleId() {
		return buildingRoleId;
	}

	public void setBuildingRoleId(long buildingRoleId) {
		this.buildingRoleId = buildingRoleId;
	}

	public long getEscalationId() {
		return escalationId;
	}

	public void setEscalationId(long escalationId) {
		this.escalationId = escalationId;
	}

	public long getEndDateTime() {
		return endDateTime;
	}

	public void setEndDateTime(long endDateTime) {
		this.endDateTime = endDateTime;
	}

	public List<RequestForUpdateEscalation> getEscalationAttendanceList() {
		return escalationAttendanceList;
	}

	public void setEscalationAttendanceList(List<RequestForUpdateEscalation> escalationAttendanceList) {
		this.escalationAttendanceList = escalationAttendanceList;
	}

	
		
}

