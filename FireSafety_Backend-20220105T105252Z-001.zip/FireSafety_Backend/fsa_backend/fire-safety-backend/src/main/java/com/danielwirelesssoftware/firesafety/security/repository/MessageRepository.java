package com.danielwirelesssoftware.firesafety.security.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.danielwirelesssoftware.firesafety.model.security.Message;

import java.util.List;

public interface MessageRepository extends JpaRepository<Message, Long> {
	
	List<Message> findByContentId(Long contentId);
	
	
}
