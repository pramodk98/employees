package com.danielwirelesssoftware.firesafety.model;

import java.sql.Timestamp;

import javax.persistence.*;


public class NotificationDetail implements Comparable<NotificationDetail> {

    private long notificationId;
    private String messageType;
    private Timestamp dateTime;    
    private String messageTitle;
    private String messageDetails;
    private Boolean status;
	
    public NotificationDetail(){
	}
    
    public NotificationDetail(long notificationId, String messageType, Timestamp dateTime, String messageTitle,
			String messageDetails, Boolean status) {
		this.notificationId = notificationId;
		this.messageType = messageType;
		this.dateTime = dateTime;
		this.messageTitle = messageTitle;
		this.messageDetails = messageDetails;
		this.status = status;
	}

	public long getNotificationId() {
		return notificationId;
	}

	public void setNotificationId(long notificationId) {
		this.notificationId = notificationId;
	}

	public String getMessageType() {
		return messageType;
	}

	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}

	public Timestamp getDateTime() {
		return dateTime;
	}

	public void setDateTime(Timestamp dateTime) {
		this.dateTime = dateTime;
	}

	public String getMessageTitle() {
		return messageTitle;
	}

	public void setMessageTitle(String messageTitle) {
		this.messageTitle = messageTitle;
	}

	public String getMessageDetails() {
		return messageDetails;
	}

	public void setMessageDetails(String messageDetails) {
		this.messageDetails = messageDetails;
	}

	public Boolean getStatus() {
		return status;
	}

	public void setStatus(Boolean status) {
		this.status = status;
	}

	@Override
	public int compareTo(NotificationDetail o) {
	    return getDateTime().compareTo(o.getDateTime());
	}

	
}
