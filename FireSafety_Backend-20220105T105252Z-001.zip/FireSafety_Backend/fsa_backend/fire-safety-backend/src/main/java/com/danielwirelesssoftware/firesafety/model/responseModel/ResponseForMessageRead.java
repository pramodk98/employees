package com.danielwirelesssoftware.firesafety.model.responseModel;

import java.sql.Timestamp;
import java.util.List;

import com.danielwirelesssoftware.firesafety.model.AttachDocument;
import com.danielwirelesssoftware.firesafety.model.BuildingDetail;

public class ResponseForMessageRead {
	
	private Long notificationId;
	private String messageType;
	private Timestamp dateTime;
	private String messageTitle;
	private String messageDetails;
	private boolean status;
	private boolean buttonEnable;
	private String buildingName;
	private String address;
	private double latitude;
	private double longitude;
	private AttachDocument attachDocument;
	
	public ResponseForMessageRead(){
		
	}
	
	public ResponseForMessageRead(Long notificationId,String messageType, Timestamp dateTime, 
									String messageTitle, String messageDetails, boolean status, boolean buttonEnable,
									String buildingName, String address, double latitude, double longitude) {
		this.notificationId = notificationId;
		this.messageType = messageType;
		this.dateTime = dateTime;
		this.messageTitle = messageTitle;
		this.messageDetails = messageDetails;
		this.status = status;
		this.buttonEnable = buttonEnable;
		this.buildingName = buildingName;
		this.address = address;
		this.latitude = latitude;
		this.longitude = longitude;
		this.attachDocument = null;
	}
	
	public ResponseForMessageRead(Long notificationId,String messageType, Timestamp dateTime, 
				String messageTitle, String messageDetails, boolean status, boolean buttonEnable,
				String buildingName, String address, double latitude, double longitude, AttachDocument attachDocument) {
		this.notificationId = notificationId;
		this.messageType = messageType;
		this.dateTime = dateTime;
		this.messageTitle = messageTitle;
		this.messageDetails = messageDetails;
		this.status = status;
		this.buttonEnable = buttonEnable;
		this.buildingName = buildingName;
		this.address = address;
		this.latitude = latitude;
		this.longitude = longitude;
		this.attachDocument = attachDocument;
	}

	public Long getNotificationId() {
		return notificationId;
	}

	public void setNotificationId(Long notificationId) {
		this.notificationId = notificationId;
	}

	public String getMessageType() {
		return messageType;
	}

	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}

	public Timestamp getDateTime() {
		return dateTime;
	}

	public void setDateTime(Timestamp dateTime) {
		this.dateTime = dateTime;
	}

	public String getMessageTitle() {
		return messageTitle;
	}

	public void setMessageTitle(String messageTitle) {
		this.messageTitle = messageTitle;
	}

	public String getMessageDetails() {
		return messageDetails;
	}

	public void setMessageDetails(String messageDetails) {
		this.messageDetails = messageDetails;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public String getBuildingName() {
		return buildingName;
	}

	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public double getLatitude() {
		return latitude;
	}

	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}

	public double getLongitude() {
		return longitude;
	}

	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}

	public boolean isButtonEnable() {
		return buttonEnable;
	}

	public void setButtonEnable(boolean buttonEnable) {
		this.buttonEnable = buttonEnable;
	}

	public AttachDocument getAttachDocument() {
		return attachDocument;
	}

	public void setAttachDocument(AttachDocument attachDocument) {
		this.attachDocument = attachDocument;
	}
	
	
		
}

