package com.danielwirelesssoftware.firesafety.security.service;
import java.io.UnsupportedEncodingException;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.NoSuchProviderException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.danielwirelesssoftware.firesafety.common.utils.TimeProvider;
import com.danielwirelesssoftware.firesafety.model.security.Building;
import com.danielwirelesssoftware.firesafety.model.security.BuildingRole;
import com.danielwirelesssoftware.firesafety.model.security.Certification;
import com.danielwirelesssoftware.firesafety.model.security.User;
import com.danielwirelesssoftware.firesafety.security.repository.BuildingRoleRepository;

import static com.danielwirelesssoftware.firesafety.common.utils.Constant.DELETE_FALSE;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.EMAIL;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.EMAIL_NAME;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.EMAIL_CONFIG;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.SMTP_USER;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.STATUS_FALSE;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.SMTP_PASS;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.PORT_NUM;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.HOST_NAME;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.ROLE_FIRE_SAFETY_MANAGER;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.ROLE_BUILDING_MANAGER;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.ROLE_FIRE_WARDEN;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.ROLE_ACCOUNT_MANAGER;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.ROLE_ACCOUNT_DIRECTOR;
@Service
public class EmailService {

	 private final Log logger = LogFactory.getLog(this.getClass());
	 
	 @Autowired
	 private BuildingRoleRepository buildingRoleRepository;
	 
	 @Autowired
	 private TimeProvider timeProvider;
	 
	 // Replace sender@example.com with your "From" address.
    // This address must be verified.
    static final String FROM = EMAIL;
    static final String FROMNAME = EMAIL_NAME;
	
//    // Replace recipient@example.com with a "To" address. If your account 
//    // is still in the sandbox, this address must be verified.
//    static final String TO = to;
    
    // Replace smtp_username with your Amazon SES SMTP user name.
    static final String SMTP_USERNAME = SMTP_USER;
    
    // Replace smtp_password with your Amazon SES SMTP password.
    static final String SMTP_PASSWORD = SMTP_PASS;
    
    // The name of the Configuration Set to use for this message.
    // If you comment out or remove this variable, you will also need to
    // comment out or remove the header below.
   // static final String CONFIGSET = EMAIL_CONFIG; //"ConfigSet";
    
    // Amazon SES SMTP host name. This example uses the US West (Oregon) region.
    // See https://docs.aws.amazon.com/ses/latest/DeveloperGuide/regions.html#region-endpoints
    // for more information.
    static final String HOST = HOST_NAME; //"email-smtp.us-west-2.amazonaws.com";
    
    // The port you will connect to on the Amazon SES SMTP endpoint. 
    static final int PORT = PORT_NUM; //587;
	
	
	public void sendForgetPasswordEmail (User user, String resetLink){
		
		final String TO = user.getEmail();
		
		final String SUBJECT = "C&W Fire Safety Password Reset Assistance";
	    
	    final String BODY = String.join(
	    	    System.getProperty("line.separator"),
	    	    "Dear "+ user.getDisplayName()+",",
	    	    "We recieved a request to reset the password for the C&W Fire Safety Account associated with this e-mail.",
	    	    "To reset your password, click <a href='"+resetLink+"'>here</a>", 
	    	    "<p>If clicking on the link doesnt work, you could copy and paste the link below into your browser address bar.",
	    	    "<p><p>"+resetLink,
	    	    "<p>You may safely ignore this email if you did not request for password reset service.",
	    	    "<p><p>Sincerely,",
	    	    "<p>C&W Safety Team"
	    	);
	    
	    Properties props = System.getProperties();
    	props.put("mail.transport.protocol", "smtp");
    	props.put("mail.smtp.port", PORT); 
    	props.put("mail.smtp.starttls.enable", "true");
    	props.put("mail.smtp.auth", "true");

        // Create a Session object to represent a mail session with the specified properties. 
    	Session session = Session.getDefaultInstance(props);

        // Create a message with the specified information. 
        MimeMessage msg = new MimeMessage(session);
        
        // Create a transport.
        Transport transport = null;
        
        try {
			msg.setFrom(new InternetAddress(FROM,FROMNAME));
			msg.setRecipient(Message.RecipientType.TO, new InternetAddress(TO));
	        msg.setSubject(SUBJECT);
	        msg.setContent(BODY,"text/html");
	        // Add a configuration set header. Comment or delete the 
	        // next line if you are not using a configuration set
	       // msg.setHeader("X-SES-CONFIGURATION-SET", CONFIGSET);
	            
	        transport = session.getTransport();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			logger.error("UnsupportedEncodingException.");
			e.printStackTrace();
			
		} catch (NoSuchProviderException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.info("Provider not found.");
			logger.error("Error message(1): " + e.getMessage());
		
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			logger.info("MessagingException");
			logger.error("Error message(2): " + e.getMessage());
			e.printStackTrace();
		}
        
                    
        // Send the message.
        try
        {
            System.out.println("Sending...");
            
            // Connect to Amazon SES using the SMTP username and password you specified above.
            transport.connect(HOST, SMTP_USERNAME, SMTP_PASSWORD);
        	
            // Send the email.
            transport.sendMessage(msg, msg.getAllRecipients());
            logger.info("Email sent!");
        }
        catch (Exception ex) {
        	logger.info("The email was not sent.");
            logger.error("Error message(3): " + ex.getMessage());
        }
        finally
        {
            // Close and terminate the connection.
            try {
				transport.close();
			} catch (MessagingException e) {
				// TODO Auto-generated catch block
				logger.error("MessagingException: transport.close");
				e.printStackTrace();
			}
        }
        
	}
	
	public void sendAttendanceReportEmail (User user, long participants, long occupants, String percentage, String buildingName, String type, String startDateTime, String endDateTime,  HashMap<String, String> attendanceList){
		
		String attendanceTable ="";
		Set set = attendanceList.entrySet();
	      Iterator iterator = set.iterator();
	      while(iterator.hasNext()) {
	    	  Map.Entry mentry = (Map.Entry)iterator.next();
	    	  attendanceTable += "<tr><td>"+ mentry.getKey() +"</td><td>" + mentry.getValue() +"</tr>";
	      }
	      
	      attendanceTable = "<table  border=\"1\"><tr><th><b>Name</b></th><th><b>Attendance</b></th></tr>"+ attendanceTable + "</table>";
		
		final String TO = user.getEmail();
		
		final String SUBJECT = "Attendance Report For "+type+" at "+buildingName;
	    
	    final String BODY = String.join(
	    	    System.getProperty("line.separator"),
	    	    "Dear "+ user.getDisplayName()+",",
	    	    "<p>This is a generated report. Please do not reply to this email. Thank you.",
	    	    "<p> <b>Building:</b> "+buildingName,
	    	    "<p> <b>Start date time:</b> "+startDateTime,
	    	    "<p> <b>End date time:</b> "+endDateTime,
	    	    "<p> <b>Participants:</b> "+participants,
	    	    "<p> <b>Occupants:</b> "+occupants,
	    	    "<p> <b>% Achieved:</b> "+percentage,
	    	    "<p><p><b>Attendance List</b>",
	    	    "<p>"+attendanceTable,
	    	    "<p><p>Sincerely,",
	    	    "<p>C&W Safety Team"
	    	);
	    
	    Properties props = System.getProperties();
    	props.put("mail.transport.protocol", "smtp");
    	props.put("mail.smtp.port", PORT); 
    	props.put("mail.smtp.starttls.enable", "true");
    	props.put("mail.smtp.auth", "true");

        // Create a Session object to represent a mail session with the specified properties. 
    	Session session = Session.getDefaultInstance(props);

        // Create a message with the specified information. 
        MimeMessage msg = new MimeMessage(session);
        
        // Create a transport.
        Transport transport = null;
        
        try {
			msg.setFrom(new InternetAddress(FROM,FROMNAME));
			msg.setRecipient(Message.RecipientType.TO, new InternetAddress(TO));
	        msg.setSubject(SUBJECT);
	        msg.setContent(BODY,"text/html");
	        // Add a configuration set header. Comment or delete the 
	        // next line if you are not using a configuration set
	       // msg.setHeader("X-SES-CONFIGURATION-SET", CONFIGSET);
	            
	        transport = session.getTransport();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			logger.error("UnsupportedEncodingException.");
			e.printStackTrace();
			
		} catch (NoSuchProviderException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.info("Provider not found.");
			logger.error("Error message: " + e.getMessage());
		
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			logger.error("MessagingException");
			e.printStackTrace();
		}
        
                    
        // Send the message.
        try
        {
            System.out.println("Sending...");
            
            // Connect to Amazon SES using the SMTP username and password you specified above.
            transport.connect(HOST, SMTP_USERNAME, SMTP_PASSWORD);
        	
            // Send the email.
            transport.sendMessage(msg, msg.getAllRecipients());
            logger.error("Email sent!");
        }
        catch (Exception ex) {
        	logger.error("The email was not sent.");
            logger.error("Error message: " + ex.getMessage());
        }
        finally
        {
            // Close and terminate the connection.
            try {
				transport.close();
			} catch (MessagingException e) {
				// TODO Auto-generated catch block
				logger.error("MessagingException: transport.close");
				e.printStackTrace();
			}
        }
        
	}
	
	//send email report to relevant user
	
	
	 public Thread sendAttendanceReportEmailThread(Building building, long presentStrength, String FireDrillTypeName, 
				String startDateTime, String endDateTime,  HashMap<String, String> attendanceList ){
		 List<BuildingRole> brList = buildingRoleRepository.findByBuildingAndDeleted(building, DELETE_FALSE);
		 long occupants = attendanceList.size();
		 System.out.print("//occupants: "+occupants);
		 System.out.print("//presentStrength: "+presentStrength);
		 double percent = presentStrength/occupants;
		 System.out.print("//percent: "+percent);
		 String percentage = String.format("%.2f", percent);
				 
		return new Thread() {
			@Override
    		public void run() {
			for(BuildingRole br: brList){
				if(br.getRole().getRoleName().equalsIgnoreCase(ROLE_FIRE_SAFETY_MANAGER) 
						|| br.getRole().getRoleName().equalsIgnoreCase(ROLE_BUILDING_MANAGER))
					if(!br.getUser().getEmail().isEmpty()){
						sendAttendanceReportEmail (br.getUser(), presentStrength, occupants, percentage, building.getName(), FireDrillTypeName, startDateTime, endDateTime,  attendanceList);
					}
				}
			};
		};
	}
	
	 
	 
	 public void sendCertificationEmail (User user, Certification certification, int monthsToExp){
		 
			final String TO = user.getEmail();
			
			final String SUBJECT = "Certification Reminder for "+certification.getBuilding().getName();
		    
			String expiryType = "";
			switch(monthsToExp) {
				case 3:
				case 2:
				case 1:
					expiryType = "The following certificate will be expiring in "+ monthsToExp+" time";
				case 0:
					expiryType = "The following certificate will be expiring today";
			}
			
			
		    final String BODY = String.join(
		    	    System.getProperty("line.separator"),
		    	    "Dear "+ user.getDisplayName()+",",
		    	    "<p>This is a generated report. Please do not reply to this email. Thank you.",
		    	    "<p> ",
		    	    "<p> "+expiryType,
		    	    "<p> <b>Certificate: </b> "+certification.getCertificationName(),
		    	    "<p> <b>Expiry Date: </b> "+timeProvider.timestampToFormattedDate(certification.getExpiryDate()),
		    	    "<p> <b>Building: </b> "+certification.getBuilding().getName(),
		    	    "<p>",
		    	    "<p><p>Sincerely,",
		    	    "<p>C&W Safety Team"
		    	);
		    
		    Properties props = System.getProperties();
	    	props.put("mail.transport.protocol", "smtp");
	    	props.put("mail.smtp.port", PORT); 
	    	props.put("mail.smtp.starttls.enable", "true");
	    	props.put("mail.smtp.auth", "true");

	        // Create a Session object to represent a mail session with the specified properties. 
	    	Session session = Session.getDefaultInstance(props);

	        // Create a message with the specified information. 
	        MimeMessage msg = new MimeMessage(session);
	        
	        // Create a transport.
	        Transport transport = null;
	        
	        try {
				msg.setFrom(new InternetAddress(FROM,FROMNAME));
				msg.setRecipient(Message.RecipientType.TO, new InternetAddress(TO));
		        msg.setSubject(SUBJECT);
		        msg.setContent(BODY,"text/html");
		        // Add a configuration set header. Comment or delete the 
		        // next line if you are not using a configuration set
		       // msg.setHeader("X-SES-CONFIGURATION-SET", CONFIGSET);
		            
		        transport = session.getTransport();
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				logger.error("UnsupportedEncodingException.");
				e.printStackTrace();
				
			} catch (NoSuchProviderException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				logger.info("Provider not found.");
				logger.error("Error message: " + e.getMessage());
			
			} catch (MessagingException e) {
				// TODO Auto-generated catch block
				logger.error("MessagingException");
				e.printStackTrace();
			}
	        
	                    
	        // Send the message.
	        try
	        {
	            System.out.println("Sending...");
	            
	            // Connect to Amazon SES using the SMTP username and password you specified above.
	            transport.connect(HOST, SMTP_USERNAME, SMTP_PASSWORD);
	        	
	            // Send the email.
	            transport.sendMessage(msg, msg.getAllRecipients());
	            logger.error("Email sent!");
	        }
	        catch (Exception ex) {
	        	logger.error("The email was not sent.");
	            logger.error("Error message: " + ex.getMessage());
	        }
	        finally
	        {
	            // Close and terminate the connection.
	            try {
					transport.close();
				} catch (MessagingException e) {
					// TODO Auto-generated catch block
					logger.error("MessagingException: transport.close");
					e.printStackTrace();
				}
	        }
	        
		}
	 
	 
	 public Thread sendCertificationEmailThread(Building building, Certification certification){
		 
		List<BuildingRole> brList = buildingRoleRepository.findByBuildingAndDeleted(building, DELETE_FALSE);
		int monthToExp = 3;
	    	//do calculation
		LocalDate expiryDate = timeProvider.timestampToLocalDate(certification.getExpiryDate());
	    LocalDate now = LocalDate.now(); 
	    for(int i = 2;i>=0; i--){
	    	LocalDate noticeDate = expiryDate.minusMonths(i);
	    	if(noticeDate.compareTo(now) >= 0){
    			if(expiryDate.compareTo(now)==0) {
	   				monthToExp = 0;
	   				break;
	   			}
	   			monthToExp = i+1;
	    		break;
	    	}
	    }
	    int monthsToExp = monthToExp;
		return new Thread() {
				@Override
	 		public void run() {
				for(BuildingRole br: brList){
					boolean toSend = false;
					if(br.getRole().getRoleName().equalsIgnoreCase(ROLE_FIRE_SAFETY_MANAGER) 
							|| br.getRole().getRoleName().equalsIgnoreCase(ROLE_BUILDING_MANAGER)){
						toSend =true;
					
					}else if(br.getRole().getRoleName().equalsIgnoreCase(ROLE_ACCOUNT_MANAGER)){
						if(monthsToExp <=2) {
							toSend = true;
						}
					
					}else if(br.getRole().getRoleName().equalsIgnoreCase(ROLE_ACCOUNT_DIRECTOR)){
						if(monthsToExp <=1) {
							toSend = true;
						}	
					}
					if(toSend) {
						if(!br.getUser().getEmail().isEmpty() && br.getUser().getEmail() != null){
							sendCertificationEmail(br.getUser(), certification, monthsToExp);
						}
					}
				}
			};
		};
		
		
	}
	 
}