package com.danielwirelesssoftware.firesafety.model.responseModel;

import java.util.List;

import com.danielwirelesssoftware.firesafety.model.FireDrillAttendanceDetail;

public class ResponseForAttendanceAccess{
	
	List<FireDrillAttendanceDetail> fireDrillAttendance;
	
	public ResponseForAttendanceAccess(List<FireDrillAttendanceDetail> fireDrillAttendance) {
		this.fireDrillAttendance = fireDrillAttendance;
	}

	public List<FireDrillAttendanceDetail> getFireDrillAttendance() {
		return fireDrillAttendance;
	}

	public void setFireDrillAttendance(List<FireDrillAttendanceDetail> fireDrillAttendance) {
		this.fireDrillAttendance = fireDrillAttendance;
	}

	
	
	
}