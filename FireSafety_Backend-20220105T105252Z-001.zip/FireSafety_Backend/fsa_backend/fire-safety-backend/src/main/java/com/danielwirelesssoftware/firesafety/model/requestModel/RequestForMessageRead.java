package com.danielwirelesssoftware.firesafety.model.requestModel;


public class RequestForMessageRead {
	
	private long notificationId;

	public RequestForMessageRead(){
	}
	
	public RequestForMessageRead(long notificationId) {
		this.notificationId = notificationId;
	}

	public long getNotificationId() {
		return notificationId;
	}

	public void setNotificationId(long notificationId) {
		this.notificationId = notificationId;
	}

	
	
		
}

