package com.danielwirelesssoftware.firesafety.security.service;

import java.util.concurrent.CompletableFuture;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.danielwirelesssoftware.firesafety.security.service.AndroidPushNotificationsService;
@Component
public class FCMService {

	@Autowired
 	private AndroidPushNotificationsService androidPushNotificationsService;
	
	private final Log logger = LogFactory.getLog(this.getClass());
	
	public void sendPushNotification(String receiverToken, long buildingRoleId, long userId, int action, String msg, long id, String recieverId){
		
		String text, clickAction, type, title;
		title = "C&W Fire Safety";
		
		switch(action){
		case 1:		//fireDrillScheduled
			clickAction = "fireDrillScheduled";
			text = "You have a new fire drill scheduled.";
			type = "Notification";
			break;
		case 2:		//fireDrillStart
			clickAction = "fireDrillStart";
			text = "You have a new fire drill.";
			type = "data";
			break;
		case 3:		//fireDrillEnd
			clickAction = "fireDrillEnd";
			text = "Fire drill ended.";
			type = "data";
			break;
		case 4:		//escalation
			clickAction = "escalation";
			text = "You have a new escalation.";
			type = "data";
			break;
		case 5:		//hazardReport
			clickAction = "hazardReport";
			text = "You have a new hazard report.";
			type = "Notification";
			break;
		case 6:		//hazardReportComplete
			clickAction = "hazardReportComplete";
			text = "A hazard report is completed.";
			type = "Notification";
			break;
		case 7:		//message
			clickAction = "message";
			text = "You have a new message.";
			type = "Notification";
			break;
		case 8:		//message
			clickAction = "updateEscalation";
			text = "Someone is not participating.";
			type = "data";
			break;
		case 9:		//message
			clickAction = "updateFireDrill";
			text = "Someone is not participating.";
			type = "data";
			break;
		case 10:		//message
			clickAction = "deleteFireDrill";
			text = "Fire drill scheduled at ? has been cancelled.";
			type = "Notification";
			break;
		case 11:		//message
			clickAction = "fireDrillPrestart";
			text = "A scheduled fire drill is starting soon.";
			type = "Notification";
			break;
		case 13:		//message
			clickAction = "certificateExpiring";
			text = "A certificate in the building is expiring. Please renew the certificate soon";
			type = "Notification";
			break;
		case 14:		//message
			clickAction = "certificateExpired";
			text = "A certificate in the building is expired. Please renew the certificate ASAP";
			type = "Notification";
			break;
		case 15:		//message
			clickAction = "certificateRequired";
			text = "A certificate is required. Please upload the document to the respective certificate";
			type = "Notification";
			break;
		default:
			clickAction = "homepage";
			text = "You have a new notification.";
			type = "Notification";
			break;
		}
		
		logger.info("/fcmService, id: "+id+ ", sending msg type: "+type+
						", to reciever: "+recieverId+", at token: "+receiverToken);
		try{
			if(msg.isEmpty()){
				msg=text;
			}	
		}catch(NullPointerException e){
			msg=text;
		}
		JSONObject body = new JSONObject();
		JSONObject data = new JSONObject();
		JSONObject android = new JSONObject();
		JSONObject notification = new JSONObject();
		JSONObject androidData = new JSONObject();
		JSONObject iOSData = new JSONObject();
		JSONObject apns = new JSONObject();
		JSONObject headers = new JSONObject();
		JSONObject payload = new JSONObject();
		JSONObject aps = new JSONObject();
		JSONObject alert = new JSONObject();
		
		try {
			body.put("to", receiverToken);    		
			body.put("priority", "high");
			body.put("content_available", true);
			body.put("time_to_live", 10);
			
			//set title and body
			notification.put("title", title);
			notification.put("body", msg);
			alert.put("title", title);
			alert.put("body", msg);
			
			//set the buildingRoleId
			androidData.put("buildingRoleId",buildingRoleId);
			iOSData.put("buildingRoleId",buildingRoleId);
						
			//android specific
			androidData.put("Type", type);
			androidData.put("click_action",clickAction);
			androidData.put("userId", userId);

			//android.put("ttl", 30);
			android.put("priority", "high");
			android.put("data", androidData);
			
			//message specific
			
			//do not send notification if its firedrill start / end
			if (action != 2 && action != 3 && action != 8 && action != 9){
				data.put("notification", notification);
				body.put("notification", notification);
				
				aps.put("alert",alert);
				logger.info("FCM set notification");
			}else{
				body.put("content_available", true);
				aps.put("content_available", true);
			}
			
			//apns specific
			headers.put("apns-priority", "10");
			
			iOSData.put("title", title);
			iOSData.put("body", msg);
			iOSData.put("Type", type);
			iOSData.put("userId", userId);
			
			payload.put("aps", aps);
			payload.put("ttl", 60);
			payload.put("click_action", clickAction);
			payload.put("id", id);
			payload.put("data",iOSData);
			
			apns.put("headers", headers);
			apns.put("payload", payload);
			
			
			data.put("click_action", clickAction);
			data.put("id", id);
			data.put("android",android);
			data.put("apns",apns);
			
			body.put("data",data);
			
			
		} catch (JSONException e2) {
			logger.error("/fcmService JSON ERROR for sending msg: "+text+", error: " + e2.toString());
			e2.printStackTrace();
		}
//		
		
//		JSONObject body = new JSONObject();
//		try {
//			//TOKEN HERE
//			body.put("to", receiverToken);    		
//			body.put("priority", "high");
//			body.put("content_available", true);
//			JSONObject notification = new JSONObject();
//			notification.put("title", "C&W Fire Safety");
//			notification.put("body", msg);
//			
//			JSONObject data = new JSONObject();
//			data.put("Type", type);
//			data.put("click_action", clickAction);
//			
//			//data.put("Key-2", "JSA Data 2");	 
//			
//			if(action == 1 ||action == 2 || action == 3 || action == 4 ){
//				data.put("buildingRoleId",buildingRoleId);
//			}
//			
//			//do not send notification if its firedrill start / end
//			if (action != 2 && action != 3 && action != 8 && action != 9){
//				body.put("notification", notification);
//				logger.debug("set notification");
//			}
//			
//			body.put("data", data);
//			
//		} catch (JSONException e1) {
//			logger.debug("/fcmService JSON ERROR for sending msg: "+text+", error: " + e1.toString());
//			e1.printStackTrace();    			
//		}
		
		HttpEntity<String> request = new HttpEntity<>(body.toString());   	     
		CompletableFuture<String> pushNotification = androidPushNotificationsService.send(request);
		CompletableFuture.allOf(pushNotification).join();
	
		try {
			String firebaseResponse = pushNotification.get();    			
			new ResponseEntity<>(firebaseResponse, HttpStatus.OK);
			
		} catch (Exception e) {
			logger.error("/fcmService FIREBASE ERROR:"+e.toString());
			//new ResponseEntity<>("Push Notification ERROR!", HttpStatus.BAD_REQUEST);
		}        	
		logger.info("///FINISH UPDATE");
	}

}
