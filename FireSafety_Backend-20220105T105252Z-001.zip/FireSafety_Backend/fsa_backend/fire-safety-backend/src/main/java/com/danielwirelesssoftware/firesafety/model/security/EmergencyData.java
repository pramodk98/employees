package com.danielwirelesssoftware.firesafety.model.security;

import java.sql.Timestamp;

import javax.persistence.*;

@Entity
@Table(name = "EmergencyData")
public class EmergencyData {
    
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "emergencyDataId")
    private long emergencyDataId;
    
    @Column(name = "documentName")
    private String documentName;   
    
    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "levelId")
    private BuildingLevel level;
    
//    @Column(name = "levelId")
//    private String levelId;
    
    @Column(name = "documentKey")
    private String documentKey;
    
    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "editedBy")
    private User editedBy;
    
//  @Column(name = "editedBy")
//  private String editedBy;
    
    @Column(name = "dateTime")
    private Timestamp dateTime;
    
    @Column(name = "deleted")
    private Boolean deleted;

    public EmergencyData() {
    }

    public EmergencyData(EmergencyData emergencyData) {
    	this.emergencyDataId = emergencyData.emergencyDataId;
    	this.documentName = emergencyData.documentName;   
    	this.level = emergencyData.level;
    	this.documentKey = emergencyData.documentKey;
    	this.editedBy = emergencyData.editedBy;
    	this.dateTime = emergencyData.dateTime;
    	this.deleted = emergencyData.deleted;
    }
    
    public EmergencyData(String documentName,BuildingLevel level,
    					String documentKey,User editedBy,
    					Timestamp dateTime,boolean deleted){
    	this.documentName = documentName;   
    	this.level = level;
    	this.documentKey = documentKey;
    	this.editedBy = editedBy;
    	this.dateTime = dateTime;
    	this.deleted = deleted;
    }

	public long getEmergencyDataId() {
		return emergencyDataId;
	}

	public void setEmergencyDataId(long emergencyDataId) {
		this.emergencyDataId = emergencyDataId;
	}

	public String getDocumentName() {
		return documentName;
	}

	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}

//	public String getLevelId() {
//		return levelId;
//	}
//
//	public void setLevelId(String levelId) {
//		this.levelId = levelId;
//	}

	public String getDocumentKey() {
		return documentKey;
	}

	public void setDocumentKey(String documentKey) {
		this.documentKey = documentKey;
	}

//	public String getEditedBy() {
//		return editedBy;
//	}
//
//	public void setEditedBy(String editedBy) {
//		this.editedBy = editedBy;
//	}

	public Timestamp getDateTime() {
		return dateTime;
	}

	public void setDateTime(Timestamp dateTime) {
		this.dateTime = dateTime;
	}

	public boolean isDeleted() {
		return deleted;
	}

	public void setDelete(boolean deleted) {
		this.deleted = deleted;
	}

	public BuildingLevel getLevel() {
		return level;
	}

	public void setLevel(BuildingLevel level) {
		this.level = level;
	}

	public User getEditedBy() {
		return editedBy;
	}

	public void setEditedBy(User editedBy) {
		this.editedBy = editedBy;
	}


    
    
}
