package com.danielwirelesssoftware.firesafety.model.responseModel;

import java.util.List;

import com.danielwirelesssoftware.firesafety.model.HazardReportDetail;

public class ResponseForHazardReportRead {
	
	private boolean checkAllowHazardReport;
	private boolean checkAllowEditHazardReport;
	private List<HazardReportDetail> listOfHazardReport;

	public ResponseForHazardReportRead(boolean checkAllowHazardReport, boolean checkAllowEditHazardReport, List<HazardReportDetail> listOfHazardReport) {
		this.checkAllowHazardReport = checkAllowHazardReport;
		this.checkAllowEditHazardReport = checkAllowEditHazardReport;
		this.listOfHazardReport = listOfHazardReport;
	}

	public List<HazardReportDetail> getListOfHazardReport() {
		return listOfHazardReport;
	}

	public void setListOfHazardReport(List<HazardReportDetail> listOfHazardReport) {
		this.listOfHazardReport = listOfHazardReport;
	}

	public boolean isCheckAllowHazardReport() {
		return checkAllowHazardReport;
	}

	public void setCheckAllowHazardReport(boolean checkAllowHazardReport) {
		this.checkAllowHazardReport = checkAllowHazardReport;
	}

	public boolean isCheckAllowEditHazardReport() {
		return checkAllowEditHazardReport;
	}

	public void setCheckAllowEditHazardReport(boolean checkAllowEditHazardReport) {
		this.checkAllowEditHazardReport = checkAllowEditHazardReport;
	}
	
	
	
}

