package com.danielwirelesssoftware.firesafety.model.responseModel;

import java.sql.Timestamp;
import java.util.List;
import com.danielwirelesssoftware.firesafety.model.EscalationAttendanceDetail;

public class ResponseForEscalation {
	
	private Timestamp dateTime;
	private Long escalationId;
	private String buildingName;
	private boolean checkAuthorityToEscalate;
	private List<EscalationAttendanceDetail> escalationAttendanceList;
	
	public ResponseForEscalation() {
	}

	public ResponseForEscalation(Timestamp dateTime, Long escalationId, String buildingName,
					boolean checkAuthorityToEscalate, List<EscalationAttendanceDetail> escalationAttendanceList) {
		this.dateTime = dateTime;
		this.escalationId = escalationId;
		this.buildingName = buildingName;
		this.checkAuthorityToEscalate = checkAuthorityToEscalate;
		this.escalationAttendanceList = escalationAttendanceList;
	}

	public Timestamp getDateTime() {
		return dateTime;
	}

	public void setDateTime(Timestamp dateTime) {
		this.dateTime = dateTime;
	}

	public Long getEscalationId() {
		return escalationId;
	}

	public void setEscalationId(Long escalationId) {
		this.escalationId = escalationId;
	}

	public boolean getCheckAuthorityToEscalate() {
		return checkAuthorityToEscalate;
	}

	public void setCheckAuthorityToEscalate(boolean checkAuthorityToEscalate) {
		this.checkAuthorityToEscalate = checkAuthorityToEscalate;
	}

	public List<EscalationAttendanceDetail> getEscalationAttendanceList() {
		return escalationAttendanceList;
	}

	public void setEscalationAttendanceList(List<EscalationAttendanceDetail> escalationAttendanceList) {
		this.escalationAttendanceList = escalationAttendanceList;
	}
	
	public String getBuildingName() {
		return buildingName;
	}

	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}
	
	
		
}

