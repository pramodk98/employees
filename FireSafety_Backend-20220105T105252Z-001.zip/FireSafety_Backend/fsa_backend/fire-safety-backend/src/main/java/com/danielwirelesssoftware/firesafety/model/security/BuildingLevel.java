package com.danielwirelesssoftware.firesafety.model.security;

import java.util.List;

import javax.persistence.*;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

@Entity
@Table(name = "BuildingLevel")
public class BuildingLevel {
    
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name="buildingLevelId")
    private long buildingLevelId;

	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "buildingId")
	private Building building;
	
//    @Column(name = "buildingId")
//    private long buildingId;
    
    @Column(name = "levelName")
    private String levelName;
    
    @Column(name = "deleted")
    private boolean deleted;
    
    @OneToMany(mappedBy = "level", fetch = FetchType.LAZY
    		,cascade = { CascadeType.MERGE, CascadeType.DETACH, CascadeType.REFRESH })
    @Fetch(value = FetchMode.SUBSELECT)
	private List<EmergencyData> emergencyDataList;
   
    @OneToMany(mappedBy = "buildingLevel", fetch = FetchType.LAZY
    		,cascade = { CascadeType.MERGE, CascadeType.DETACH, CascadeType.REFRESH })
    @Fetch(value = FetchMode.SUBSELECT)
	private List<Drawings> DrawingsList;
    
    public BuildingLevel() {
    }
    
    public BuildingLevel(BuildingLevel buildingLevel) {
		this.buildingLevelId = buildingLevel.buildingLevelId;
		this.building = buildingLevel.building;
		this.levelName = buildingLevel.levelName;
	}
    
	public BuildingLevel(long buildingLevelId, Building building, String levelName) {
		this.buildingLevelId = buildingLevelId;
		this.building = building;
		this.levelName = levelName;
	}
	
	public BuildingLevel(long buildingLevelId, Building building, String levelName, boolean deleted) {
		this.buildingLevelId = buildingLevelId;
		this.building = building;
		this.levelName = levelName;
		this.deleted = deleted;
	}

	public long getBuildingLevelId() {
		return buildingLevelId;
	}

	public void setBuildingLevelId(long buildingLevelId) {
		this.buildingLevelId = buildingLevelId;
	}
	
//	public long getBuildingId() {
//		return buildingId;
//	}
//
//	public void setBuildingId(long buildingId) {
//		this.buildingId = buildingId;
//	}

	public Building getBuilding() {
		return building;
	}

	public void setBuilding(Building building) {
		this.building = building;
	}

	public String getLevelName() {
		return levelName;
	}

	public void setLevelName(String levelName) {
		this.levelName = levelName;
	}

	public List<EmergencyData> getEmergencyDataList() {
		return emergencyDataList;
	}

	public void setEmergencyDataList(List<EmergencyData> emergencyDataList) {
		this.emergencyDataList = emergencyDataList;
	}

	public List<Drawings> getDrawingsList() {
		return DrawingsList;
	}

	public void setDrawingsList(List<Drawings> drawingsList) {
		DrawingsList = drawingsList;
	}
	
	public boolean isDeleted() {
		return deleted;
	}

	public void setDeleted(boolean deleted) {
		this.deleted = deleted;
	}

	@Override
	public String toString() {
		return "BuildingLevel [buildingLevelId=" + buildingLevelId + ", building=" + building + ", levelName="
				+ levelName + "]";
	}	

    
}
