package com.danielwirelesssoftware.firesafety.security.repository;

import java.sql.Timestamp;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.danielwirelesssoftware.firesafety.model.security.Building;
import com.danielwirelesssoftware.firesafety.model.security.HazardReport;
import com.danielwirelesssoftware.firesafety.model.security.User;

public interface HazardReportRepository extends JpaRepository<HazardReport, Long> {
	
	List<HazardReport> findByBuildingAndDeleted(Building building, boolean deleted);

	HazardReport findByHazardReportIdAndDeleted(long HazardReportId,boolean deleted);
	
	HazardReport findByLastUpdateAndReporter(Timestamp lastUpdate, User user);
	
	@Modifying
	@Transactional
	@Query(value = "update HazardReport h set h.closeReporterId = ?1, h.status = ?2, h.lastUpdate = ?3, h.closeComment = ?4, h.editedBy = ?5 where h.hazardReportId = ?6", nativeQuery = true)
	int setCloseReporterAndStatusAndLastUpdateAndCloseCommentAndEditedByFor(User closeReporter, String status, Timestamp lastUpdate, String completeRemark, long editedBy, long hazardReportId );
	
	@Modifying
	@Transactional
	@Query(value = "update HazardReport h set h.lastUpdate = ?1, h.deleted = ?2, h.editedBy = ?3 where h.hazardReportId = ?4", nativeQuery = true)
	int setLastUpdateAndDeletedAndEditedByFor(Timestamp lastUpdate, boolean deleted, long editedBy, long hazardReportId);

}
