package com.danielwirelesssoftware.firesafety.security;

import java.io.Serializable;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.context.annotation.Bean;

public class  JwtAuthenticationRequest implements Serializable {
	private final Log logger = LogFactory.getLog(this.getClass());
    private static final long serialVersionUID = -8445943548965154778L;

    private String username;
    private String password;
    private String pushNotificationToken;
    
    public JwtAuthenticationRequest() {
        super();
    }

    public JwtAuthenticationRequest(String username, String password, String pushNotification) {
        this.setUsername(username);
        this.setPassword(password);
        this.setPushNotificationToken(pushNotification);
    }

    public String getUsername() {
    	logger.debug("inside jwtAuthentication get username");
    	try{
    		logger.debug("inside jwtAuthentication get username:"+this.username);
    	}catch(Exception e){
    		logger.debug("inside jwtAuthentication get username:"+e);
    	}
    	
    	return this.username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
    	logger.debug("inside jwtAuthentication get password");
    	try{
    		logger.debug("inside jwtAuthentication get password:"+this.password);
    	}catch(Exception e){
    		logger.debug("inside jwtAuthentication get password:"+e);
    	}
        return this.password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

	public String getPushNotificationToken() {
		return pushNotificationToken;
	}

	public void setPushNotificationToken(String pushNotificationToken) {
		this.pushNotificationToken = pushNotificationToken;
	}
    
    
}
