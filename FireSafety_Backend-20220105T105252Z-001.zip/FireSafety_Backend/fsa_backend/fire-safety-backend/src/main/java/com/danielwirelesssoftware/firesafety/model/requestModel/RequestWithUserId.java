package com.danielwirelesssoftware.firesafety.model.requestModel;

public class RequestWithUserId {

    private long userId;
    
    public RequestWithUserId(){
	}
    
    public RequestWithUserId(RequestWithUserId requestWithUserId){
    	this.userId = requestWithUserId.userId;
	}
    
    public RequestWithUserId(long userId){
    	this.userId = userId;
	}

	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}
    
    
}
