package com.danielwirelesssoftware.firesafety.model;

import java.util.List;

import com.danielwirelesssoftware.firesafety.model.AnsweredQuestionDetail;
import com.danielwirelesssoftware.firesafety.model.AttachImageDetail;

public class SectionAnswerHazardReportDetail {
	
	private long sectionId;
	private List<AttachDocument> listOfAttachImages;
	private List<AnsweredQuestionDetail> listOfAnsweredQuestions;
	
	
	public SectionAnswerHazardReportDetail(){
	}
	
	public SectionAnswerHazardReportDetail(SectionAnswerHazardReportDetail sectionAnswerHazardReportDetail){
		this.sectionId = sectionAnswerHazardReportDetail.sectionId;
		this.listOfAttachImages = sectionAnswerHazardReportDetail.listOfAttachImages;
		this.listOfAnsweredQuestions = sectionAnswerHazardReportDetail.listOfAnsweredQuestions;
	}
	
	public SectionAnswerHazardReportDetail(long sectionId, List<AttachDocument> listOfAttachImages, 
												List<AnsweredQuestionDetail> listOfAnsweredQuestions) {		
		this.sectionId = sectionId;
		this.listOfAttachImages = listOfAttachImages;
		this.listOfAnsweredQuestions = listOfAnsweredQuestions;
	}


	public long getSectionId() {
		return sectionId;
	}


	public void setSectionId(long sectionId) {
		this.sectionId = sectionId;
	}


	public List<AttachDocument> getListOfAttachImages() {
		return listOfAttachImages;
	}


	public void setListOfAttachImages(List<AttachDocument> listOfAttachImages) {
		this.listOfAttachImages = listOfAttachImages;
	}


	public List<AnsweredQuestionDetail> getListOfAnsweredQuestions() {
		return listOfAnsweredQuestions;
	}


	public void setListOfAnsweredQuestions(List<AnsweredQuestionDetail> listOfAnsweredQuestions) {
		this.listOfAnsweredQuestions = listOfAnsweredQuestions;
	}
	
	
	
	
		
}
