package com.danielwirelesssoftware.firesafety.security.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.danielwirelesssoftware.firesafety.model.security.FireDrillType;

public interface FireDrillTypeRepository extends JpaRepository<FireDrillType, Long> {

	List<FireDrillType> findAll();	
	
	FireDrillType findByFireDrillTypeId(long fireDrillTypeId);
}
