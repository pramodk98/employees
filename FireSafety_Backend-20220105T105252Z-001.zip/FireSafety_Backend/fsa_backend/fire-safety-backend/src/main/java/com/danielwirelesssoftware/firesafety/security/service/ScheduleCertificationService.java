package com.danielwirelesssoftware.firesafety.security.service;

import java.sql.Timestamp;
import java.time.Instant;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.TimeZone;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.quartz.JobDataMap;
import org.quartz.JobDetail;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.Trigger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;
import org.springframework.stereotype.Component;

import com.danielwirelesssoftware.firesafety.common.utils.TimeProvider;
import com.danielwirelesssoftware.firesafety.model.security.Building;
import com.danielwirelesssoftware.firesafety.model.security.BuildingRole;
import com.danielwirelesssoftware.firesafety.model.security.Certification;
import com.danielwirelesssoftware.firesafety.model.security.FireDrillSchedule;
import com.danielwirelesssoftware.firesafety.model.security.Message;
import com.danielwirelesssoftware.firesafety.model.security.MessageImage;
import com.danielwirelesssoftware.firesafety.model.security.MessageType;
import com.danielwirelesssoftware.firesafety.model.security.Notification;
import com.danielwirelesssoftware.firesafety.model.security.User;
import com.danielwirelesssoftware.firesafety.security.repository.BuildingRoleRepository;
import com.danielwirelesssoftware.firesafety.security.repository.CertificationRepository;
import com.danielwirelesssoftware.firesafety.security.repository.MessageImageRepository;
import com.danielwirelesssoftware.firesafety.security.repository.MessageRepository;
import com.danielwirelesssoftware.firesafety.security.repository.MessageTypeRepository;
import com.danielwirelesssoftware.firesafety.security.repository.NotificationRepository;

import static com.danielwirelesssoftware.firesafety.common.utils.Constant.DELETE_FALSE;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.ACTION_CERTIFICATION_EXPIRING;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.ACTION_CERTIFICATION_EXPIRED;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.MESSAGE_DETAIL_CERTIFICATE_EXPIRING_1;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.MESSAGE_DETAIL_CERTIFICATE_EXPIRING_2;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.MESSAGE_DETAIL_CERTIFICATE_EXPIRING_3;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.MESSAGE_DETAIL_CERTIFICATE_EXPIRING_4;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.MESSAGE_DETAIL_CERTIFICATE_EXPIRED_1;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.MESSAGE_DETAIL_CERTIFICATE_EXPIRED_2;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.MESSAGE_DETAIL_CERTIFICATE_EXPIRED_3;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.MESSAGE_TITLE_CERTIFICATE_EXPIRING;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.MESSAGE_TITLE_CERTIFICATE_EXPIRED;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.MESSAGE_TYPE_CERTIFICATE_EXPIRING;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.MESSAGE_TYPE_CERTIFICATE_EXPIRED;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.ROLE_FIRE_WARDEN;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.STATUS_FALSE;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.ROLE_FIRE_SAFETY_MANAGER;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.ROLE_BUILDING_MANAGER;
@Component
public class ScheduleCertificationService extends QuartzJobBean {
	
	private final Log logger = LogFactory.getLog(this.getClass());
	
	@Autowired
	private BuildingRoleRepository buildingRoleRepository;
	    
	@Autowired
	private CertificationRepository certificationRepository;
	
	@Autowired
    private FCMService fcmService;
	
	@Autowired
    private EmailService emailService;
	
	@Autowired
    private MessageRepository messageRepository;
	
	@Autowired
    private MessageImageRepository messageImageRepository;
	
	@Autowired
    private MessageTypeRepository messageTypeRepository;
	
	@Autowired
    private TimeProvider timeProvider;

    @Autowired
	private JobBuilderService jobBuilderService;
    
    @Autowired
    private Scheduler scheduler;
    
    @Autowired
    private NotificationRepository notificationRepository;
    
    @Override
    protected void executeInternal(JobExecutionContext jobExecutionContext) throws JobExecutionException {
       
    	logger.info("Executing Job with key {}"+ jobExecutionContext.getJobDetail().getKey());
    	
        JobDataMap jobDataMap = jobExecutionContext.getMergedJobDataMap();
        
        try
        {
        	Certification certification = (Certification) jobDataMap.get("certification");
       	 	runCertificationSchedule(certification);
        }
        catch(ClassCastException e)
        {
        	logger.error("error scheduling certificate:" + e);
        }
        
        
    }
    
    // all certificate jobBuilderService.buildJobDetail go through this
    // /createBuildingCertification, /updateBuildingCertification
    // upon restarting server this is called from ApplicationStartup
    private void runCertificationSchedule(Certification cert) {

    	logger.info("coming in runCertificationSchedule id:"+cert.getCertificationId());
    	
    	//get the certificate again because the cert param is from when its created/updated/restart,and it might have been updated
    	//on /updateBuildingCertification, it delete the certificate and add a new entry;
    	Certification certification = null;
    	certification = certificationRepository.findByCertificationIdAndDeleted(cert.getCertificationId(), DELETE_FALSE);
    	
    	//check if fireDrillSchedule 
    	if(certification == null) {
    		logger.info("Certification for certificationId: " + cert.getCertificationId() + " is deleted");
    		return;
    	}
    	
    	//get buildingId
    	Building building = certification.getBuilding();
    	
    	//check building is deleted
    	if(building.isDeleted()){
    		logger.info("buildingId: " + building.getBuildingId()+" for certificationId: " 
    					+ certification.getCertificationId() + " is deleted");
    		return;
    	}
    	
    	logger.debug("0");
    	
    	//predefine action for expired certificate
    	int action = ACTION_CERTIFICATION_EXPIRED;
    	LocalDate now = timeProvider.timestampToLocalDate(timeProvider.timestampNow());
    	LocalDate expiryDate = timeProvider.timestampToLocalDate(certification.getExpiryDate());
    	logger.info("server time now (1):"+timeProvider.timestampNow()+" , expiryDate:"+certification.getExpiryDate()+" , for cert "+certification.getCertificationId() +"instant: "+Instant.now());
    	logger.info("server time now (2):"+now+" , expiryDate:"+expiryDate+" , for cert "+certification.getCertificationId());
    	int monthsToExp = expiryDate.compareTo(now);
    	//do calculation
    	//expiryDate is before this month or is this month
    	if(monthsToExp >= 0){
    		
    		//expiryDate not this month and not today
    		if(monthsToExp != 0 && now.getDayOfMonth() != expiryDate.getDayOfMonth()) {
    			
    			boolean tobeSchedule = false;
    			LocalDate noticeDate = expiryDate;
    			
    			if(monthsToExp == 0 && now.getDayOfMonth() != expiryDate.getDayOfMonth()) {
    				logger.debug("scheduling for (1) "+certification.getCertificationId()+" on "+noticeDate );
    				tobeSchedule = true;
    				
    			}else{
    				//schedule the notification in 3,2,1,0 month time if its not today.
        			for(int i = 3;i>=0; i--){
        				noticeDate = expiryDate.minusMonths(i);
        	    		if(noticeDate.isBefore(expiryDate)){
        	    			logger.debug("scheduling for (2) "+certification.getCertificationId()+" on "+noticeDate);
        	    			tobeSchedule = true;
        	    			break;
        	    		}
        			}
    			}
    			
    			if(tobeSchedule) {
    				try {
    	    			action = ACTION_CERTIFICATION_EXPIRING;
    	    			JobDetail jobDetail = jobBuilderService.buildJobDetail(certification);
    	                Trigger trigger = jobBuilderService.buildJobTriggerCertification(jobDetail, timeProvider.localDateToDate(noticeDate));
    	                scheduler.scheduleJob(jobDetail, trigger);
	    			} catch (SchedulerException e) {
	    				// TODO send to system admin
	    				e.printStackTrace();
	    			}
    			}
    			
    			
    		}
    	}
    	
    	//within this month and up to 3 month, and the day itself
    	if(monthsToExp <= 3 && monthsToExp >= 0 && now.getDayOfMonth() == expiryDate.getDayOfMonth()) {
    		logger.debug("condition: months:"+monthsToExp+", now day:"+now.getDayOfMonth()+", exp day:"+now.getDayOfMonth());
    		
    		//for counting sent pushNotification in thread 
        	final AtomicInteger counter = new AtomicInteger();
        	
        	//treading for simultaneous sending out notification
        	Thread t = new Thread(certificationThread(counter,building,certification,action, monthsToExp));
        	t.start();
    		
        	try {
    			t.join();
    		} catch (InterruptedException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		}
        	
        	logger.debug("total Push notification sent for certification id" + certification.getCertificationId() + 
        					": "+counter.intValue());
    	}
    }
    	
    	
    	
    //@counter to count how many push notification sent, 
    //@building to get each user buildingRoleId ,
    //@certification is the certificate 
    //@action is the action number
    //@monthsToExp is the total number of months difference from the expiring date
    //authorityDetail is the list of user who should be authorize to edit the certificate.
    private Thread certificationThread(AtomicInteger counter, Building building, Certification certification, int action, int monthsToExp){
    	return new Thread() {
    		@Override
    		public void run() {
    			//logger.debug("01 certification");
    			
    			List<BuildingRole> buildingRoleList = buildingRoleRepository.findByBuilding(building);
    			for(BuildingRole br: buildingRoleList){
    				
    				//TODO: change to determine who to get certification notification.
    				if(!br.getRole().getCertificateManagementGroup()){
    				//	logger.debug("buildingRole does not have certification management authority: "+br.getBuildingRoleId());
    					continue;
    				}
    				
    				if(br.isDeleted()){
    				//	logger.debug("buildingRole is deleted for buildingRoleId: "+br.getBuildingRoleId());
    	    			continue;
    				}
    				
    				User user = br.getUser();
    				
    				if(user.isDeleted()){
    					logger.debug("user is deleted for userId: "+user.getUserId());
    					continue;
    				}

    				logger.debug("02 certification");
    				
    				if(monthsToExp >= 0 && monthsToExp <=3) {
    					
    					MessageType messageType = null;
	    				String msg = "";
	    				String msgTitle = "";
    				
    					if(monthsToExp == 0) {
        					msgTitle = MESSAGE_TITLE_CERTIFICATE_EXPIRED;
        					messageType = messageTypeRepository.findByMessageTypeId(MESSAGE_TYPE_CERTIFICATE_EXPIRED);
        					msg = MESSAGE_DETAIL_CERTIFICATE_EXPIRED_1 + certification.getCertificationName()
									+ MESSAGE_DETAIL_CERTIFICATE_EXPIRED_2 + certification.getCertificationName()
									+ MESSAGE_DETAIL_CERTIFICATE_EXPIRED_3;
        					
        				} else {
        					msgTitle = MESSAGE_TITLE_CERTIFICATE_EXPIRING;
        					messageType = messageTypeRepository.findByMessageTypeId(MESSAGE_TYPE_CERTIFICATE_EXPIRING);
        					if(monthsToExp <= 3) {
        						
        						msg = MESSAGE_DETAIL_CERTIFICATE_EXPIRING_1 + certification.getCertificationName()
        								+ MESSAGE_DETAIL_CERTIFICATE_EXPIRING_2 + certification.getCertificationName()
        								+ MESSAGE_DETAIL_CERTIFICATE_EXPIRING_3 + certification.getExpiryDate()
        								+ MESSAGE_DETAIL_CERTIFICATE_EXPIRING_4;
        					}else {
        						msg = MESSAGE_DETAIL_CERTIFICATE_EXPIRING_1 + certification.getCertificationName()
										+ MESSAGE_DETAIL_CERTIFICATE_EXPIRING_2 + certification.getCertificationName()
										+ MESSAGE_DETAIL_CERTIFICATE_EXPIRING_3 + certification.getExpiryDate()
										+ MESSAGE_DETAIL_CERTIFICATE_EXPIRING_4;
        					}
        				}
        				
        				try {
        					//logger.debug("03 certification trying message");
    	    				Message message = new Message(messageType, timeProvider.timestampNow(),
    	    						msgTitle,msg,
    								br.getBuilding().getBuildingId(),
    								certification.getCertificationId());
    	    				messageRepository.saveAndFlush(message);
    	    				if(certification.getDocumentKey() != null && certification.getDocumentName() != null) {
    	    					MessageImage messageImage = new MessageImage(message,
    	    																	certification.getDocumentName(),
    	    																	certification.getDocumentKey()
    	    																	);
    	    					messageImageRepository.save(messageImage);
    	    				}
    	    				
    	    				Notification notification = new Notification(br.getUser(), STATUS_FALSE, message);
    						notificationRepository.save(notification);
        				}catch(Exception e){
        					logger.error("04 certification error in sending message: " + e.getLocalizedMessage());
        				}
        				
	    				//check user notification status and notification token
	    				if(user.getPushNotificationToken() != null && user.getNotification()){
			    			//logger.debug("05 certification sending push notif to user:"+user.getDisplayName()+"id:"+user.getUserId());
	
			    			//send notification
			    			fcmService.sendPushNotification(user.getPushNotificationToken(),br.getBuildingRoleId(),user.getUserId(), action, "",user.getUserId(), "");
			    			//logger.debug("06 certification");
			    				
			    			//add sent counter
			    			counter.getAndIncrement();
			    		}
	    				
	    				if(user.getEmail() != null && !user.getEmail().isEmpty()) {
	    					logger.debug("07 certification sending email notif to user:"+user.getDisplayName()+"id:"+user.getUserId());
	    					emailService.sendCertificationEmail (user, certification, monthsToExp);
	    				}
	    				logger.debug("06 certification after email");
	    				
    				}else {
    					logger.info("09 certificate is out of 3 month range for certificateId:"+certification.getCertificationId());
    				}
    			}
    		}
    	};
    }

}
