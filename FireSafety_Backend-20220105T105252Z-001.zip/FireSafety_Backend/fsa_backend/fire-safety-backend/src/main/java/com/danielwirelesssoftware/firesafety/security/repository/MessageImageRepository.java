package com.danielwirelesssoftware.firesafety.security.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.danielwirelesssoftware.firesafety.model.security.Message;
import com.danielwirelesssoftware.firesafety.model.security.MessageImage;

public interface MessageImageRepository extends JpaRepository<MessageImage, Long> {

	MessageImage findTop1ByMessage(Message message);
	
}

