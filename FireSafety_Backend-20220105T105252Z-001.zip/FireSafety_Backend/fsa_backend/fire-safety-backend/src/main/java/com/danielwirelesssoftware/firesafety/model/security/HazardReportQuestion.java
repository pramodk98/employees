package com.danielwirelesssoftware.firesafety.model.security;

import java.util.List;

import javax.persistence.*;

@Entity
@Table(name = "HazardReportQuestion")
public class HazardReportQuestion {
    
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "hazardReportQuestionId")
    private long hazardReportQuestionId;
	
    @Column(name = "questionText")
    private String questionText;
    
    @Column(name = "sectionId")
    private long sectionId;
    
    @Column(name = "deleted")
    private boolean deleted;
    
    @OneToMany(mappedBy = "question", fetch = FetchType.LAZY
    		, cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.DETACH, CascadeType.REFRESH })
    private List<HazardReportQuestionData> hazardReportQuestionDataList;

    public HazardReportQuestion(){
	}
    
    public HazardReportQuestion(long hazardReportQuestionId, String questionText, long sectionId) {
		this.hazardReportQuestionId = hazardReportQuestionId;
		this.questionText = questionText;
		this.sectionId = sectionId;
	}
    
	public HazardReportQuestion(long hazardReportQuestionId, String questionText, long sectionId, boolean deleted) {
		this.hazardReportQuestionId = hazardReportQuestionId;
		this.questionText = questionText;
		this.sectionId = sectionId;
		this.deleted = deleted;
	}

	public long getHazardReportQuestionId() {
		return hazardReportQuestionId;
	}

	public void setHazardReportQuestionId(long hazardReportQuestionId) {
		this.hazardReportQuestionId = hazardReportQuestionId;
	}

	public String getQuestionText() {
		return questionText;
	}

	public void setQuestionText(String questionText) {
		this.questionText = questionText;
	}

	public long getSectionId() {
		return sectionId;
	}

	public void setSectionId(long sectionId) {
		this.sectionId = sectionId;
	}

	public List<HazardReportQuestionData> getHazardReportQuestionDataList() {
		return hazardReportQuestionDataList;
	}

	public void setHazardReportQuestionDataList(List<HazardReportQuestionData> hazardReportQuestionDataList) {
		this.hazardReportQuestionDataList = hazardReportQuestionDataList;
	}

	public boolean isDeleted() {
		return deleted;
	}

	public void setDeleted(boolean deleted) {
		this.deleted = deleted;
	}

	
	
    
}