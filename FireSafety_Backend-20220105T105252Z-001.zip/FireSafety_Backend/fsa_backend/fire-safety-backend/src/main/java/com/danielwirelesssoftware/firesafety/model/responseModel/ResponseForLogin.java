package com.danielwirelesssoftware.firesafety.model.responseModel;

import java.util.List;
import com.danielwirelesssoftware.firesafety.model.BuildingDetail;

public class ResponseForLogin {
	
	private String token;
	private Long userId;
	private List<BuildingDetail> buildingList;
	
	public ResponseForLogin() {
	}
	
	public ResponseForLogin(String token, Long userId, List<BuildingDetail> buildingList) {
		this.token = token;
		this.userId = userId;
		this.buildingList = buildingList;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public List<BuildingDetail> getBuildingList() {
		return buildingList;
	}

	public void setBuildingList(List<BuildingDetail> buildingList) {
		this.buildingList = buildingList;
	}
		
}

