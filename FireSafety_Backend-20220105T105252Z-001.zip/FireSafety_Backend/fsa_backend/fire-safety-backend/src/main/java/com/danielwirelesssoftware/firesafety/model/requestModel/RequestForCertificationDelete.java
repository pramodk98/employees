package com.danielwirelesssoftware.firesafety.model.requestModel;

import java.util.List;

public class RequestForCertificationDelete {
	
	private long buildingRoleId;
	private List<Long> listOfCertificationId;
	
	public RequestForCertificationDelete() {
	}

	public RequestForCertificationDelete(RequestForCertificationDelete requestForCertificationDelete) {
		this.buildingRoleId = requestForCertificationDelete.buildingRoleId;
		this.listOfCertificationId = requestForCertificationDelete.listOfCertificationId;
	}
	
	public RequestForCertificationDelete(long buildingRoleId, List<Long> listOfCertificationId) {
		this.buildingRoleId = buildingRoleId;
		this.listOfCertificationId = listOfCertificationId;
	}

	public long getBuildingRoleId() {
		return buildingRoleId;
	}

	public void setBuildingRoleId(long buildingRoleId) {
		this.buildingRoleId = buildingRoleId;
	}

	public List<Long> getListOfCertificationId() {
		return listOfCertificationId;
	}

	public void setListOfCertificationId(List<Long> ListOfCertificationId) {
		this.listOfCertificationId = ListOfCertificationId;
	}
	
	
}

