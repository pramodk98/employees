package com.danielwirelesssoftware.firesafety.model.requestModel;

import java.util.List;
import com.danielwirelesssoftware.firesafety.model.PremiseEmergencyData;

public class RequestForPEDUpdate {
	
	private long levelId;
	private List<PremiseEmergencyData> premiseEmergencyDataList;
	
	public RequestForPEDUpdate() {
	}
	
	public RequestForPEDUpdate(long levelId, List<PremiseEmergencyData> premiseEmergencyDataList) {
		this.levelId = levelId;
		this.premiseEmergencyDataList = premiseEmergencyDataList;
	}

	public long getLevelId() {
		return levelId;
	}

	public void setLevelId(long levelId) {
		this.levelId = levelId;
	}

	public List<PremiseEmergencyData> getPremiseEmergencyDataList() {
		return premiseEmergencyDataList;
	}

	public void setPremiseEmergencyDataList(List<PremiseEmergencyData> premiseEmergencyDataList) {
		this.premiseEmergencyDataList = premiseEmergencyDataList;
	}

	
	
}

