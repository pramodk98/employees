package com.danielwirelesssoftware.firesafety.security.controller;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.danielwirelesssoftware.firesafety.model.AttachDocument;
import com.danielwirelesssoftware.firesafety.model.NotificationDetail;
import com.danielwirelesssoftware.firesafety.model.requestModel.RequestForMessageRead;
import com.danielwirelesssoftware.firesafety.model.requestModel.RequestForAttendanceUpdate;
import com.danielwirelesssoftware.firesafety.model.requestModel.RequestWithBuildingRoleId;
import com.danielwirelesssoftware.firesafety.model.responseModel.ResponseForGeneral;
import com.danielwirelesssoftware.firesafety.model.responseModel.ResponseForInboxMessageAccess;
import com.danielwirelesssoftware.firesafety.model.responseModel.ResponseForMessageRead;
import com.danielwirelesssoftware.firesafety.model.security.Building;
import com.danielwirelesssoftware.firesafety.model.security.BuildingRole;
import com.danielwirelesssoftware.firesafety.model.security.Escalation;
import com.danielwirelesssoftware.firesafety.model.security.EscalationAttendance;
import com.danielwirelesssoftware.firesafety.model.security.FireDrillAttendance;
import com.danielwirelesssoftware.firesafety.model.security.FireDrillSchedule;
import com.danielwirelesssoftware.firesafety.model.security.MessageImage;
import com.danielwirelesssoftware.firesafety.model.security.Notification;
import com.danielwirelesssoftware.firesafety.model.security.Role;
import com.danielwirelesssoftware.firesafety.model.security.User;
import com.danielwirelesssoftware.firesafety.security.JwtUser;
import com.danielwirelesssoftware.firesafety.security.repository.BuildingRepository;
import com.danielwirelesssoftware.firesafety.security.repository.BuildingRoleRepository;
import com.danielwirelesssoftware.firesafety.security.repository.EscalationAttendanceRepository;
import com.danielwirelesssoftware.firesafety.security.repository.EscalationRepository;
import com.danielwirelesssoftware.firesafety.security.repository.FireDrillAttendanceRepository;
import com.danielwirelesssoftware.firesafety.security.repository.FireDrillScheduleRepository;
import com.danielwirelesssoftware.firesafety.security.repository.MessageImageRepository;
import com.danielwirelesssoftware.firesafety.security.repository.NotificationRepository;
import com.danielwirelesssoftware.firesafety.security.repository.RoleRepository;
import com.danielwirelesssoftware.firesafety.security.repository.UserRepository;
import com.danielwirelesssoftware.firesafety.security.service.FCMService;
import com.danielwirelesssoftware.firesafety.security.service.MessageService;

import static com.danielwirelesssoftware.firesafety.common.utils.Constant.SUCCESS;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.DELETE_FALSE;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.ROLE_BUILDING_MANAGER;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.ROLE_FIRE_SAFETY_MANAGER;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.ROLE_FIRE_WARDEN;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.STATUS_TRUE;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.STATUS_OPEN;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.ACTION_UPDATE_ESCALATION;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.ACTION_UPDATE_FIRE_DRILL;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.STATUS_NOT_PARTICIPATING;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


@RestController
public class MessageRestController {

    private final Log logger = LogFactory.getLog(this.getClass());
    
    
    @Autowired
    private BuildingRepository buildingRepository;
    
    @Autowired
    private BuildingRoleRepository buildingRoleRepository;
    
    @Autowired
    private EscalationRepository escalationRepository;
    
    @Autowired
    private EscalationAttendanceRepository escalationAttendanceRepository;
    
    @Autowired
    private FireDrillScheduleRepository fireDrillScheduleRepository;
    
    @Autowired
    private FireDrillAttendanceRepository fireDrillAttendanceRepository;
    
    @Autowired
    private MessageImageRepository messageImageRepository;
    
    @Autowired
    private NotificationRepository notificationRepository;
    
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private FCMService fcmService;
    
    @Autowired
    private RoleRepository roleRepository;
    
    @Autowired
    private MessageService messageService;
    
    
    @RequestMapping(value = "/accessInboxMessage", method = RequestMethod.POST)
    public ResponseEntity<?> inboxMessageAccess(@RequestBody RequestWithBuildingRoleId request){
    	
    	BuildingRole buildingRole = buildingRoleRepository.findByBuildingRoleIdAndDeleted(request.getBuildingRoleId(),DELETE_FALSE);  	
    	
    	List<Notification> notificationList = new ArrayList<Notification>();
    	try{
    		notificationList = notificationRepository.findByReciever(buildingRole.getUser());
    	}catch(Exception e){
    		logger.info("/accessInboxMessage API unable to find notification for user : "+buildingRole.getUser().getUsername());
    		logger.debug("/accessInboxMessage API error: "+ e);
    	}

    	List<NotificationDetail> notificationDetailList = new ArrayList<NotificationDetail>();
    	
    	for(Notification n:notificationList){
    		NotificationDetail nd = new NotificationDetail(n.getNotificationId(), 
    														n.getMessage().getMessageType().getMessageType(), 
    														n.getMessage().getDateTime(),
    														n.getMessage().getMessageTitle(),
    														n.getMessage().getMessageDetails(),
    														n.getStatus());
    		notificationDetailList.add(nd);
    	}
    	
    	Collections.sort(notificationDetailList, Collections.reverseOrder()); 
        
        return new ResponseEntity<List<NotificationDetail>>(notificationDetailList, HttpStatus.OK);
    }
    
    @RequestMapping(value = "/readMessage", method = RequestMethod.POST)
    public ResponseEntity<?> messageRead(@RequestBody RequestForMessageRead request, @AuthenticationPrincipal final JwtUser principle){
 
    	notificationRepository.setFixStatus(STATUS_TRUE, request.getNotificationId());
    	
    	Notification n = notificationRepository.findByNotificationId(request.getNotificationId());
    	
    	Building building = buildingRepository.findByBuildingId(n.getMessage().getBuildingId());  	

    	FireDrillAttendance fireDrillAttendance = null;
    	Escalation escalation = null;
    	EscalationAttendance escalationAttendance = null;
    	User user = null;
    	BuildingRole buildingRole = null;
    	boolean buttonEnable = false;
    	AttachDocument attachDocument = null;
    	ResponseForMessageRead response = new ResponseForMessageRead();
    	String messageDetail = n.getMessage().getMessageDetails();
    	String authorityDetail = "";
    	
    	user = userRepository.findByUserIdAndDeleted(principle.getUserId(), DELETE_FALSE);
    	
    	buildingRole = buildingRoleRepository.findByBuildingUserAndBuilding(user,building);
    	
    	logger.info("//01 coming in ");
    	if(n.getMessage().getMessageType().getMessageType().equalsIgnoreCase("Fire Drill Dry Run")
    		|| n.getMessage().getMessageType().getMessageType().equalsIgnoreCase("Fire Drill Schedule")
    		|| n.getMessage().getMessageType().getMessageType().equalsIgnoreCase("Fire Activation")){
    		logger.info("//02 coming in ");
//    		fireDrillSchedule = fireDrillScheduleRepository.findByFireDrillId(n.getMessage().getContentId());
//    		
//    		if(fireDrillSchedule == null){
//    			logger.debug("/readMessage, fireDrillSchedule for fireDrillId: "+ n.getMessage().getContentId() + " not found" );
//        		return new ResponseEntity<>("fireDrillSchedule not found", HttpStatus.BAD_REQUEST);
//    		}
//    		
//    		fireDrillAttendance = fireDrillAttendanceRepository.findByTenantEmployeeAndFireDrillSchedule(user.getTenantEmployee(), fireDrillSchedule);

    		if(n.getMessage().getContentId() > 0L ){
    			logger.info("//03 coming in ");
    			fireDrillAttendance = fireDrillAttendanceRepository.findByFireDrillAttendanceId(n.getMessage().getContentId());
    			logger.info("//04 coming in ");
        		if(fireDrillAttendance == null){
        			logger.error("/readMessage, fireDrillAttendance for fireDrillAttendanceId: "+ n.getMessage().getContentId() + " not found" );
            		return new ResponseEntity<>("fireDrillAttendance not found", HttpStatus.BAD_REQUEST);
        		}
        		logger.info("//05 coming in ");
        		if (buildingRole != null){
            		if( !(buildingRole.getRole().getRoleName().equalsIgnoreCase(ROLE_FIRE_SAFETY_MANAGER))  //FSM must attend
            			&& !(buildingRole.getRole().getRoleName().equalsIgnoreCase(ROLE_FIRE_WARDEN))       //FW must attend
            			&& !(buildingRole.getRole().getRoleName().equalsIgnoreCase(ROLE_BUILDING_MANAGER))  //BM must attend
            			&& fireDrillAttendance.getFireDrillSchedule().getCompleteDateTime() == null
            			&& !(fireDrillAttendance.getStatus().equalsIgnoreCase(STATUS_NOT_PARTICIPATING))){
            			buttonEnable = true;
                		logger.info("/readMessage, button enabled" );
            		}
            	}
    		}
    		
    	}else if(n.getMessage().getMessageType().getMessageType().equalsIgnoreCase("Escalation")){
    		
    		escalationAttendance = escalationAttendanceRepository.findByEscalationAttendanceId(n.getMessage().getContentId());
    		
    		if(escalationAttendance == null){
    			logger.error("/readMessage, escalationAttendance for escalationAttendanceId: "+ n.getMessage().getContentId() + " not found" );
        		return new ResponseEntity<>("escalationAttendance not found", HttpStatus.BAD_REQUEST);
    		}
    		
    		escalation = escalationRepository.findByEscalationId(escalationAttendance.getEscalationId());
    		
    		if(escalation == null){
    			logger.error("/readMessage, escalation for escalationId: "+ escalationAttendance.getEscalationId() + " not found" );
        		return new ResponseEntity<>("escalation not found", HttpStatus.BAD_REQUEST);
    		}
    		
    		if (buildingRole != null){
        		if(escalation.getCompleteDateTime() == null
        			&& !escalationAttendance.getStatus().equalsIgnoreCase(STATUS_NOT_PARTICIPATING)){
        			buttonEnable = true;
            		logger.info("/readMessage, button enabled (2)");
        		}
        	}
    	}else if(n.getMessage().getMessageType().getMessageType().equalsIgnoreCase("Certificate Expiring") 
    			|| n.getMessage().getMessageType().getMessageType().equalsIgnoreCase("Certificate Expired")){
    			MessageImage messageImage = null;
    			messageImage = messageImageRepository.findTop1ByMessage(n.getMessage());
    			if(messageImage != null) {
    				if(messageImage.getDocumentKey() != null && messageImage.getDocumentName() != null) {
    					attachDocument = new AttachDocument(messageImage);
    				}
    			}
    			List<BuildingRole> brList = buildingRoleRepository.findByBuildingAndDeleted(building,DELETE_FALSE);
    	    	
    	    	for(BuildingRole br : brList) {
    	    		if(br.getRole().getRoleName().equalsIgnoreCase(ROLE_FIRE_SAFETY_MANAGER) ||
    	    			br.getRole().getRoleName().equalsIgnoreCase(ROLE_BUILDING_MANAGER)) {
    	    			if(!br.getUser().isDeleted()) {
    	    				authorityDetail += br.getRole().getRoleName() == null ? "<br>" : "<br>"+br.getRole().getRoleName();
    	    				authorityDetail += br.getUser().getDisplayName()== null ? "<p>" : "<p>"+br.getUser().getDisplayName();
    	    				authorityDetail += br.getUser().getPhoneNumber()== null ? "<p>" : "<p>"+br.getUser().getPhoneNumber();
    	    				authorityDetail += br.getUser().getEmail() == null ? "<p>" : "<p>"+br.getUser().getEmail();
    	    			}
    	    		}
    	    	}
    	    	//template of authority detail
    	    	//authorityDetail +="<br>"+"Building Manager"+"<p>"+"Raisa Green" +"<p>"+"86645554" +"<p>"+"this@email.com";
    	    	messageDetail += authorityDetail;
    	}
    	
    	if(attachDocument == null) {
    		response = new ResponseForMessageRead(n.getNotificationId(),
					n.getMessage().getMessageType().getMessageType(),
					n.getMessage().getDateTime(),
					n.getMessage().getMessageTitle(),
					messageDetail,
					n.getStatus(),
					buttonEnable,
					building.getName(),
					building.getAddress(),
					building.getLatitude(),
					building.getLongtitude());
    	}else{
    		response = new ResponseForMessageRead(n.getNotificationId(),
					n.getMessage().getMessageType().getMessageType(),
					n.getMessage().getDateTime(),
					n.getMessage().getMessageTitle(),
					messageDetail,
					n.getStatus(),
					buttonEnable,
					building.getName(),
					building.getAddress(),
					building.getLatitude(),
					building.getLongtitude(),
					attachDocument);
    	}
        return new ResponseEntity<ResponseForMessageRead>(response, HttpStatus.OK);
    }
    
    @RequestMapping(value = "/updateAttendance", method = RequestMethod.POST)
    public ResponseEntity<?> atttdendaceUpdate(@RequestBody RequestForAttendanceUpdate request, @AuthenticationPrincipal final JwtUser principle){
    	
    	FireDrillSchedule fireDrillSchedule = null;
    	FireDrillAttendance fireDrillAttendance = null;
    	Escalation escalation = null;
    	EscalationAttendance escalationAttendance = null;
    	Notification notification = null;
    	List<BuildingRole> buildingRoleList = new ArrayList<BuildingRole>();
    	
    	notification = notificationRepository.findByNotificationId(request.getNotificationId());
    	
    	if(notification == null){
    		logger.error("/updateAttendance,notification for notificationId: "+ request.getNotificationId() + " not found" );
    		return new ResponseEntity<>("notification not found", HttpStatus.BAD_REQUEST);
    	}
    	
    	if(notification.getMessage().getMessageType().getMessageType().equalsIgnoreCase("Fire Drill Dry Run")
    		|| notification.getMessage().getMessageType().getMessageType().equalsIgnoreCase("Fire Drill Schedule")){
//    		fireDrillSchedule = fireDrillScheduleRepository.findByFireDrillIdAndDeletedAndCompleteDateTimeIsNull(notification.getMessage().getContentId(), DELETE_FALSE);
//    		
//    		if(fireDrillSchedule == null){
//    			logger.debug("/updateAttendance, fireDrillSchedule for fireDrillId: "+ notification.getMessage().getContentId() + " not found" );
//        		return new ResponseEntity<>("fireDrillSchedule not found", HttpStatus.BAD_REQUEST);
//    		}
    		
    		//get the fireDrillAttendance base on fireDrillAttendanceId
    		fireDrillAttendance = fireDrillAttendanceRepository.findByFireDrillAttendanceId(notification.getMessage().getContentId());
    		
//    		fireDrillAttendance = fireDrillAttendanceRepository.findByTenantEmployeeAndFireDrillSchedule(user.getTenantEmployee(), fireDrillSchedule);

    		//check if fireDrillAttendance exist
    		if(fireDrillAttendance == null){
    			logger.error("/updateAttendance, fireDrillAttendance for fireDrillId: "+ notification.getMessage().getContentId() + " not found" );
        		return new ResponseEntity<>("fireDrillAttendance not found", HttpStatus.BAD_REQUEST);
    		}
    		
    		//find the fireDrillSchedule
    		fireDrillSchedule = fireDrillScheduleRepository.findByFireDrillIdAndDeletedAndCompleteDateTimeIsNull(fireDrillAttendance.getFireDrillSchedule().getFireDrillId(), DELETE_FALSE);
    		
    		//check if the fireDrillSchedule exist
    		if(fireDrillSchedule == null){
    			logger.error("/updateAttendance, fireDrillSchedule for fireDrillAttendanceId: "+ notification.getMessage().getContentId() + " not found" );
        		return new ResponseEntity<>("fireDrillSchedule not found", HttpStatus.BAD_REQUEST);
    		}
    		
    		//update the attendance
    		try{
    			fireDrillAttendanceRepository.setStatusFor(request.getStatus(), fireDrillAttendance.getFireDrillAttendanceId());
    		}catch(Exception e){
    			logger.error("/updateAttendance, update fail for fireDrillAttendanceId: " + fireDrillAttendance.getFireDrillAttendanceId());
        		return new ResponseEntity<>("fireDrillAttendance update error", HttpStatus.BAD_REQUEST);
    		}
    		
    		List<Role> roleList = roleRepository.findByFireDrillAttendanceGroupAndDeletedOrFireDrillAuthorityGroupAndDeletedOrFireDrillStartGroupAndDeleted(true,
																																							DELETE_FALSE,
																																							true,
																																							DELETE_FALSE,
																																							true,
																																							DELETE_FALSE);
    		
    		for(Role r : roleList){
    			buildingRoleList.addAll(buildingRoleRepository.findByBuildingAndRoleAndDeleted(fireDrillSchedule.getBuildingFDS(),r,DELETE_FALSE));
    		}
    		
    		logger.info("buildingroleList: "+buildingRoleList.toString());
    		logger.info("/updateAttendance, sending notification for firedrill");
    		Thread sendUpdateNotification = new Thread(messageService.updateFireDrillThread(buildingRoleList, fireDrillSchedule.getFireDrillId()));
    		sendUpdateNotification.start();
    		
    	
    	}else if(notification.getMessage().getMessageType().getMessageType().equalsIgnoreCase("Escalation")){	
    		
//    		escalation = escalationRepository.findByEscalationIdAndStatusAndCompleteDateTimeIsNull(notification.getMessage().getContentId(),STATUS_OPEN);
//    		
//    		if(escalation == null){
//    			logger.debug("/updateAttendance, escalation for escalationId: "+ notification.getMessage().getContentId() + " not found" );
//        		return new ResponseEntity<>("escalation not found", HttpStatus.BAD_REQUEST);
//    		}
    		
    		escalationAttendance = escalationAttendanceRepository.findByEscalationAttendanceId(notification.getMessage().getContentId());
    		
    		//escalationAttendance = escalationAttendanceRepository.findByEscalationIdAndUser(escalation.getEscalationId(), user);

    		if(escalationAttendance == null){
    			logger.error("/updateAttendance, escalationAttendance for escalationId: "+ notification.getMessage().getContentId() + " not found" );
        		return new ResponseEntity<>("escalationAttendance not found", HttpStatus.BAD_REQUEST);
    		}
    		
    		escalation = escalationRepository.findByEscalationIdAndStatusAndCompleteDateTimeIsNull(escalationAttendance.getEscalationId(),STATUS_OPEN);
    		
    		if(escalation == null){
    			logger.error("/updateAttendance, escalation for escalationAttendanceId: "+ notification.getMessage().getContentId() + " not found" );
        		return new ResponseEntity<>("escalation not found", HttpStatus.BAD_REQUEST);
    		}
    		
    		try{
    			escalationAttendanceRepository.setFixedStatusFor(request.getStatus(), escalationAttendance.getEscalationAttendanceId());
    			
    		}catch(Exception e){
    			logger.error("/updateAttendance, update fail for escalationAttendanceId: " + escalationAttendance.getEscalationAttendanceId());
        		return new ResponseEntity<>("escalationAttendance update error", HttpStatus.BAD_REQUEST);
    		}
    		
    		if(escalation.getReporter().getPushNotificationToken() != null && !escalation.getReporter().getPushNotificationToken().isEmpty()){
    			BuildingRole br = buildingRoleRepository.findByBuildingUserAndBuilding(escalation.getReporter(), escalation.getEscalationBuilding());
    			
    			fcmService.sendPushNotification(escalation.getReporter().getPushNotificationToken(), br.getBuildingRoleId(), escalation.getReporter().getUserId(), ACTION_UPDATE_ESCALATION, "", escalation.getEscalationId(), "");
    		}
    	
    	}else{
    		logger.error("/updateAttendance, update fail for messageType: " + notification.getMessage().getMessageType().getMessageType());
    		return new ResponseEntity<>("escalationAttendance update error", HttpStatus.BAD_REQUEST);
    	}
    	
    	ResponseForGeneral response = new ResponseForGeneral(SUCCESS); 
        return new ResponseEntity<ResponseForGeneral>(response, HttpStatus.OK);
    }

}