package com.danielwirelesssoftware.firesafety.security.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.danielwirelesssoftware.firesafety.model.security.HazardReportQuestion;
import com.danielwirelesssoftware.firesafety.model.security.HazardReportQuestionData;
import com.danielwirelesssoftware.firesafety.model.security.HazardReportSectionData;

public interface HazardReportQuestionDataRepository extends JpaRepository<HazardReportQuestionData, Long> {
	
	HazardReportQuestionData findByQuestionAndDataHazardReport(HazardReportQuestion question, HazardReportSectionData hrsd);
}
