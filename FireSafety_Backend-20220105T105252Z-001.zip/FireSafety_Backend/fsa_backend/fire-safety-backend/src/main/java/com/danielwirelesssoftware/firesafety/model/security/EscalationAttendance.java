package com.danielwirelesssoftware.firesafety.model.security;

import javax.persistence.*;

@Entity
@Table(name = "EscalationAttendance")
public class EscalationAttendance {
    
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "escalationAttendanceId")
    private long escalationAttendanceId;
    
    @Column(name = "escalationId")
    private long escalationId;
    
    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "userId")
    private User user;
    
    @Column(name = "status")  
    private String status ;

    public EscalationAttendance(){
	}
    
	public EscalationAttendance(long escalationAttendanceId, long escalationId, User user, String status) {
		this.escalationAttendanceId = escalationAttendanceId;
		this.escalationId = escalationId;
		this.user = user;
		this.status = status;
	}
	
	public EscalationAttendance(long escalationId, User user, String status) {
		this.escalationId = escalationId;
		this.user = user;
		this.status = status;
	}

	public long getEscalationAttendanceId() {
		return escalationAttendanceId;
	}

	public void setEscalationAttendanceId(long escalationAttendanceId) {
		this.escalationAttendanceId = escalationAttendanceId;
	}

	public long getEscalationId() {
		return escalationId;
	}

	public void setEscalationId(long escalationId) {
		this.escalationId = escalationId;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
    
    
    
    
}
