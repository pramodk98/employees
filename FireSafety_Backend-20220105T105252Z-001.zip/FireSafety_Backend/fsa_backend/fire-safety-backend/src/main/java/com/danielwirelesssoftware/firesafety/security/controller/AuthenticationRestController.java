package com.danielwirelesssoftware.firesafety.security.controller;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mobile.device.Device;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.danielwirelesssoftware.firesafety.model.BuildingDetail;
import com.danielwirelesssoftware.firesafety.model.requestModel.RequestWithBuildingRoleId;
import com.danielwirelesssoftware.firesafety.model.requestModel.RequestWithUserId;
import com.danielwirelesssoftware.firesafety.model.responseModel.ResponseForGeneral;
import com.danielwirelesssoftware.firesafety.model.responseModel.ResponseForLogin;
import com.danielwirelesssoftware.firesafety.model.responseModel.ResponseForRelogin;
import com.danielwirelesssoftware.firesafety.model.security.BuildingRole;
import com.danielwirelesssoftware.firesafety.model.security.TenantEmployee;
import com.danielwirelesssoftware.firesafety.model.security.User;
import com.danielwirelesssoftware.firesafety.security.JwtAuthenticationRequest;
import com.danielwirelesssoftware.firesafety.security.JwtTokenUtil;
import com.danielwirelesssoftware.firesafety.security.repository.BuildingRoleRepository;
import com.danielwirelesssoftware.firesafety.security.repository.TenantEmployeeRepository;
import com.danielwirelesssoftware.firesafety.security.repository.UserRepository;

import static com.danielwirelesssoftware.firesafety.common.utils.Constant.DELETE_FALSE;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.SUCCESS;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

@RestController
public class AuthenticationRestController {

    private final Log logger = LogFactory.getLog(this.getClass());

    @Value("${jwt.header}")
    private String tokenHeader;

    @Autowired
    private AuthenticationManager authenticationManager;
   
    @Autowired
    private JwtTokenUtil jwtTokenUtil;

    @Autowired
    private UserDetailsService userDetailsService;

    @Autowired
    private PasswordEncoder passwordEncoder;
    
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private BuildingRoleRepository buildingRoleRepository;
    @Autowired
    private TenantEmployeeRepository tenantEmployeeRepository;
    
    //TODO: add check for deleteFlag
   // @RequestMapping(value = "${jwt.route.authentication.auth}", method = RequestMethod.POST)
   // public ResponseEntity<?> createAuthenticationToken(@RequestBody JwtAuthenticationRequest authenticationRequest, Device device) throws AuthenticationException {
    @RequestMapping(value = "/login", method = RequestMethod.POST)
    public ResponseEntity<?> loginUser(@RequestBody JwtAuthenticationRequest authenticationRequest, Device device) throws AuthenticationException {
    	
        logger.info("//checking authentication for user: " + authenticationRequest.getUsername() + 
        			" pwd raw: "+authenticationRequest.getPassword() + 
        			" pwd: "+passwordEncoder.encode(authenticationRequest.getPassword()));
        
        // Perform the security
        final Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        authenticationRequest.getUsername(),
                        authenticationRequest.getPassword()
                )
        );
        
        logger.info("//authentication"); 
        SecurityContextHolder.getContext().setAuthentication(authentication);
        logger.info("//postSecurity Context");
        
        // Reload password post-security so we can generate token
        final UserDetails userDetails = userDetailsService.loadUserByUsername(authenticationRequest.getUsername());
        try{
        	logger.info("//userDetails username: " + userDetails.getUsername());
        }catch(Exception e){
        	logger.info("//userDetails username error: " + e);
        }
        final String token = jwtTokenUtil.generateToken(userDetails, device);
        logger.info("//tokeN generated: "+token);
        
        // Return the token
        
        
        User u = null;
        Long userId = null;
        
        try{
	        if(authenticationRequest.getPushNotificationToken() ==null || authenticationRequest.getPushNotificationToken().isEmpty()){
	        	logger.info("//pushNotification not found for username: " + authenticationRequest.getUsername());
	        	userRepository.setPushNotificationTokenFor(null, authenticationRequest.getUsername());
	        }else{
	        	//update user push notification token
//	        	userRepository.setPushNotificationTokenNullFor(authenticationRequest.getPushNotificationToken());
	            userRepository.setPushNotificationTokenFor(authenticationRequest.getPushNotificationToken(), 
	            											authenticationRequest.getUsername());
	        }
        }catch(Exception e){
        	logger.error("//pushNotification not found for username: " + authenticationRequest.getUsername() +", error:" +e);
        	userRepository.setPushNotificationTokenFor(null, authenticationRequest.getUsername());
        }
        
        //TODO: add check for user deleted on authentication 
        //get userId
        u = userRepository.findByUsername(userDetails.getUsername());
        userId = userRepository.findByUsername(userDetails.getUsername()).getUserId();
        
        //get building detail
        List<BuildingDetail> buildingList = new ArrayList<BuildingDetail>();
        
        List<BuildingRole> buildingRoleList = buildingRoleRepository.findByBuildingUserAndDeleted(u, DELETE_FALSE);
        BuildingDetail buildingDetail;
        
        for(BuildingRole b: buildingRoleList){
          	buildingDetail = new BuildingDetail(b.getBuildingRoleId(), b.getBuilding().getName(), b.getBuilding().getAddress());
        	buildingList.add(buildingDetail);
        }
        
        
        
        Thread t = new Thread();
        
        //set response
        ResponseForLogin response = new ResponseForLogin(token,userId,buildingList);
        
        return new ResponseEntity<ResponseForLogin>(response, HttpStatus.OK);
    }
    

  //TODO:  Check this is working, add check for deleteFlag
    //@RequestMapping(value = "${jwt.route.authentication.refresh}", method = RequestMethod.GET)
    @RequestMapping(value = "reloginUser", method = RequestMethod.POST)
    public ResponseEntity<?> refreshAndGetAuthenticationToken(HttpServletRequest request,
    									@RequestBody RequestWithUserId reloginRequest, Device device) {
        
    	String token = request.getHeader(tokenHeader);
        String[] splited = token.split("\\s+");
        
        String username = jwtTokenUtil.getUsernameFromToken(splited[1]);
//      JwtUser user = (JwtUser) userDetailsService.loadUserByUsername(username);
        
        //get userId
        User u = null;
        u = userRepository.findByUsernameAndDeleted(username,DELETE_FALSE);
        if(u == null){
        	logger.error("/login : user not found for username "+username);
        	return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
        }
        
        //get new token
        String refreshedToken;
        
        //TODO: this is recreating a new token, which is wrong
        if (jwtTokenUtil.canTokenBeRefreshed(token)) {
            refreshedToken = jwtTokenUtil.regenerateToken(u,device);
            //refreshedToken = jwtTokenUtil.refreshToken(token);
            //return ResponseEntity.ok(new JwtAuthenticationResponse(refreshedToken));
        } else {
            return ResponseEntity.badRequest().body(null);
        }
        
        //get building detail
        List<BuildingDetail> buildingList = new ArrayList<BuildingDetail>();
        
        List<BuildingRole> buildingRoleList = buildingRoleRepository.findByBuildingUserAndDeleted(u, DELETE_FALSE);
        BuildingDetail buildingDetail;
        
        for(BuildingRole b: buildingRoleList){
          	buildingDetail = new BuildingDetail(b.getBuildingRoleId(), b.getBuilding().getName(), b.getBuilding().getAddress());
        	buildingList.add(buildingDetail);
        }
        
        //set response
        ResponseForLogin response = new ResponseForLogin(refreshedToken,u.getUserId(),buildingList);
        
        return new ResponseEntity<ResponseForLogin>(response, HttpStatus.OK);
        
    }
    

    //TODO:  Check this is working
    @RequestMapping(value = "reloginRoleRecordId", method = RequestMethod.POST)
    public ResponseEntity<?> refreshAndGetAuthenticationTokenAndDetail(HttpServletRequest request, 
    						@RequestBody RequestWithBuildingRoleId reloginRequest, Device device){
    	
    	User u = null;
        BuildingRole buildingRole = null;
        String refreshedToken = null;   
    	String tenantName = null;
    	String token = request.getHeader(tokenHeader);
    	String[] splited = token.split("\\s+");
    	
    	//get userId
    	String username = jwtTokenUtil.getUsernameFromToken(splited[1]);
        
        u = userRepository.findByUsernameAndDeleted(username,DELETE_FALSE);
        
        //check user exist
        if(u == null){
    		logger.error("/reloginRoleRecordId API : user not found for username "+username);
    		return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
    	}   
        
        //get new token
//        if (jwtTokenUtil.canTokenBeRefreshed(token)) {
//            refreshedToken = jwtTokenUtil.refreshToken(token);
//        } else {
//            return ResponseEntity.badRequest().body(null);
//        }
        
        //TODO: this is recreating a new token, which is wrong
        if (jwtTokenUtil.canTokenBeRefreshed(token)) {
            refreshedToken = jwtTokenUtil.regenerateToken(u,device);
        } else {
            return ResponseEntity.badRequest().body(null);
        }
        
        //check buildingRole exist
        buildingRole = buildingRoleRepository.findByBuildingRoleIdAndDeleted(reloginRequest.getBuildingRoleId(),false);  	
        if(buildingRole == null){
        	logger.error("1 /reloginRoleRecordId API : buildingRole not found for buildingRoleId "+reloginRequest.getBuildingRoleId());
    		return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
        
        //check role exist
    	if(buildingRole.getRole().isDeleted()){
    		logger.error("/reloginRoleRecordId API :role deleted for buildingRoleId "+reloginRequest.getBuildingRoleId());
    		return new ResponseEntity<String>("role not found",HttpStatus.BAD_REQUEST);
    	}
    	
    	//check building exist
    	if(buildingRole.getBuilding().isDeleted()){
    		logger.error("/reloginRoleRecordId API :building deleted for buildingRoleId "+reloginRequest.getBuildingRoleId());
    		return new ResponseEntity<String>("building not found",HttpStatus.BAD_REQUEST);
    	}
    	
        //2019/8/2 updated to replace tenantName
    	//check tenant exist, and set the tenantName
//    	try{
//    		if(buildingRole.getUser().getTenantEmployee().getTenant().isDeleted()){
//    			logger.info("/reloginRoleRecordId API :tenant:"
//    							+buildingRole.getUser().getTenantEmployee().getTenant().getTenantName()
//    							+", is deleted for buildingRole "+buildingRole.getBuildingRoleId());
//        		//return new ResponseEntity<String>("tenant not found",HttpStatus.BAD_REQUEST);
//        	}else{
//        		tenantName = buildingRole.getUser().getTenantEmployee().getTenant().getTenantName();
//        	}
//    	}catch(NullPointerException e){
//    		logger.info("/reloginRoleRecordId API : tenantEmployee not found for buildingRole "+buildingRole.getBuildingRoleId());
//    	}
    	List<TenantEmployee> teList= tenantEmployeeRepository.findByUserAndDeleted(buildingRole.getUser(),DELETE_FALSE);
    	for(TenantEmployee tes : teList){
    		if(tes.getTenant().getBuilding() == buildingRole.getBuilding())
    			tenantName = tes.getTenant().getTenantName();
    	}

    	
        //set response
        ResponseForRelogin response = new ResponseForRelogin(refreshedToken, 
        												buildingRole.getBuilding().getName(),
										                buildingRole.getUser().getDisplayName(),
										                tenantName,
										        		buildingRole.getRole().getRoleId(), 
										        		buildingRole.getRole().getRoleName(),
										        		buildingRole.getUser().getProfileImage(),
										        		buildingRole.getBuilding().getBuildingId(),
										        		buildingRole.getRole().getDocumentViewingGroup(),
										        		buildingRole.getRole().getFireDrillAuthorityGroup(),
										        		buildingRole.getRole().getFireDrillStartGroup(),
										        		buildingRole.getRole().getFireDrillAttendanceGroup());
        												
        
        return new ResponseEntity<ResponseForRelogin>(response, HttpStatus.OK);
        
    }
    
      //TODO: API 38
    @RequestMapping(value = "logoutUser", method = RequestMethod.POST)
    public ResponseEntity<?> userLogout(HttpServletRequest request,  Device device){
    	
    	String token = request.getHeader(tokenHeader);
    	String[] splited = token.split("\\s+");
    	
    	//get userId
    	String username = jwtTokenUtil.getUsernameFromToken(splited[1]);
        User u = userRepository.findByUsername(username);

        String refreshedToken;        
        
        userRepository.setPushNotificationTokenFor(null,username);
        
        //TODO: this is recreating a new token, which is wrong
//        if (jwtTokenUtil.canTokenBeRefreshed(token)) {
//            refreshedToken = jwtTokenUtil.regenerateToken(u,device);
//        } else {
//            return ResponseEntity.badRequest().body(null);
//        }
//
//        BuildingRole buildingRole = buildingRoleRepository.findByBuildingRoleId(reloginRequest.getBuildingRoleId());
        
        //set response
        ResponseForGeneral response = new ResponseForGeneral(SUCCESS);
        return new ResponseEntity<ResponseForGeneral>(response, HttpStatus.OK);
        
    }

}