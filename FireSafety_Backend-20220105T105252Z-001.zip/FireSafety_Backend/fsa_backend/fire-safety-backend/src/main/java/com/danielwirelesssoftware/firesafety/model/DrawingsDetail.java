package com.danielwirelesssoftware.firesafety.model;

public class DrawingsDetail {
    
    private long drawingId;
    private AttachDocument attachDocument;
    
    public DrawingsDetail() {
    }

    public DrawingsDetail(DrawingsDetail drawingDetail) {
    	this.drawingId = drawingDetail.drawingId;
    	this.attachDocument = drawingDetail.attachDocument;
    }
    
    public DrawingsDetail(long drawingId, AttachDocument attachDocument){
    	this.drawingId = drawingId; 
    	this.attachDocument = attachDocument;	
    }

	public long getDrawingId() {
		return drawingId;
	}

	public void setDrawingId(long drawingId) {
		this.drawingId = drawingId;
	}

	public AttachDocument getAttachDocument() {
		return attachDocument;
	}

	public void setAttachDocument(AttachDocument attachDocument) {
		this.attachDocument = attachDocument;
	}
	
    
}
