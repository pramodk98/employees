package com.danielwirelesssoftware.firesafety.model.security;

import java.sql.Timestamp;

import javax.persistence.*;
//import com.danielwirelesssoftware.firesafety.model.security.BuildingLevel;


@Entity
@Table(name = "Drawings")
public class Drawings {
    
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "drawingId")
    private long drawingId;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "levelId")
    private BuildingLevel buildingLevel;
    
    @Column(name = "documentKey")
    private String documentKey;
    
    @Column(name = "documentName")
    private String documentName;
    
    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "editedBy")
    private User editedBy;
    
    @Column(name = "dateTime")
    private Timestamp dateTime;
    
    @Column(name = "deleted")
    private Boolean deleted;

    public Drawings() {
    }

    public Drawings(Drawings drawing) {
    	this.drawingId = drawing.drawingId; 
    	this.buildingLevel = drawing.buildingLevel;
    	this.documentKey = drawing.documentKey;
    	this.documentName = drawing.documentName;
    	this.editedBy = drawing.editedBy;
    	this.dateTime = drawing.dateTime;
    	this.deleted = drawing.deleted;
    }
    
    public Drawings(BuildingLevel buildingLevel,String documentName, 
    				String documentKey,User editedBy,
    				Timestamp dateTime,boolean deleted){ 
    	this.buildingLevel = buildingLevel;
    	this.documentKey = documentKey;
    	this.documentName = documentName;
    	this.editedBy = editedBy;
    	this.dateTime = dateTime;
    	this.deleted = deleted;
    }

	public long getDrawingId() {
		return drawingId;
	}

	public void setDrawingId(long drawingId) {
		this.drawingId = drawingId;
	}

	public String getDocumentName() {
		return documentName;
	}

	public void setDocument(String documentName) {
		this.documentName = documentName;
	}
	
	public void setDocumentKey(String documentKey) {
		this.documentKey = documentKey;
	}
	
	public String getDocumentKey() {
		return documentKey;
	}
	
	public Timestamp getDateTime() {
		return dateTime;
	}

	public void setDateTime(Timestamp dateTime) {
		this.dateTime = dateTime;
	}

	public boolean isDeleted() {
		return deleted;
	}

	public void setDeleted(boolean deleted) {
		this.deleted = deleted;
	}

	public BuildingLevel getBuildingLevel() {
		return buildingLevel;
	}

	public void setLevel(BuildingLevel buildingLevel) {
		this.buildingLevel = buildingLevel;
	}

	public User getEditedBy() {
		return editedBy;
	}

	public void setEditedBy(User editedBy) {
		this.editedBy = editedBy;
	}


    
    
}
