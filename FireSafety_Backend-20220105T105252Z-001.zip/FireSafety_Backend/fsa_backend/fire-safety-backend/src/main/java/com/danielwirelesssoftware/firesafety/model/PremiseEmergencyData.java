package com.danielwirelesssoftware.firesafety.model;

public class PremiseEmergencyData {
   
    private long emergencyDataId;
    private AttachDocument attachDocument;

    public PremiseEmergencyData() {
    }
    
    public PremiseEmergencyData(PremiseEmergencyData premiseEmergencyData) {
		this.emergencyDataId = premiseEmergencyData.emergencyDataId;
		this.attachDocument = premiseEmergencyData.attachDocument;
	}

	public PremiseEmergencyData(long emergencyDataId, AttachDocument attachDocument) {
		this.emergencyDataId = emergencyDataId;
		this.attachDocument = attachDocument;
	}

	public long getEmergencyDataId() {
		return emergencyDataId;
	}

	public void setEmergencyDataId(long emergencyDataId) {
		this.emergencyDataId = emergencyDataId;
	}

	public AttachDocument getAttachDocument() {
		return attachDocument;
	}

	public void setAttachDocument(AttachDocument attachDocument) {
		this.attachDocument = attachDocument;
	}
	
	
}
