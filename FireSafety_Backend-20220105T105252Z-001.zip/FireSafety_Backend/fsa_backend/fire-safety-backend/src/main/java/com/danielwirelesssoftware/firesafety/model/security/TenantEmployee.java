package com.danielwirelesssoftware.firesafety.model.security;

import javax.persistence.*;

import java.sql.Timestamp;

@Entity
@Table(name = "TenantEmployee")
public class TenantEmployee {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "tenantEmployeeId")
    private Long tenantEmployeeId;

    @Column(name = "tenantEmployeeName")
    private String tenantEmployeeName;

    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "tenantId")
    private Tenant tenant;
    
//    @Column(name = "tenantId")
//    private long tenantId;
    
    @OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "editedBy")
    private User editedBy;
    
    //@Column(name = "editedBy")
    //private String editedBy;
    
    @Column(name = "dateTime")
    private Timestamp dateTime;
    
    @Column(name = "deleted")
    private Boolean deleted;
        
    @Column(name = "title")
    private String title;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "userId")
    private User user;

    public TenantEmployee() {
    }
    
    
	public TenantEmployee(TenantEmployee tenantEmployee) {
		this.tenantEmployeeId = tenantEmployee.tenantEmployeeId;
		this.tenantEmployeeName = tenantEmployee.tenantEmployeeName;
		this.tenant = tenantEmployee.tenant;
		this.editedBy = tenantEmployee.editedBy;
		this.dateTime = tenantEmployee.dateTime;
		this.deleted = tenantEmployee.deleted;
		this.title = tenantEmployee.title;
		this.user = tenantEmployee.user;
	}
    
	public TenantEmployee(Long tenantEmployeeId, String tenantEmployeeName, Tenant tenant, User editedBy, //long tenantId, String editedBy,
							Timestamp dateTime, String title) {
		this.tenantEmployeeId = tenantEmployeeId;
		this.tenantEmployeeName = tenantEmployeeName;
		this.tenant = tenant;
		this.editedBy = editedBy;
		this.dateTime = dateTime;
		this.title = title;
	}
	
	public TenantEmployee(Long tenantEmployeeId, String tenantEmployeeName, Tenant tenant, User editedBy, //long tenantId, String editedBy,
			Timestamp dateTime, boolean deleted, String title) {
			this.tenantEmployeeId = tenantEmployeeId;
			this.tenantEmployeeName = tenantEmployeeName;
			this.tenant = tenant;
			this.editedBy = editedBy;
			this.dateTime = dateTime;
			this.deleted = deleted;
			this.title = title;
			}
	
	public Long getTenantEmployeeId() {
		return tenantEmployeeId;
	}
	
	public void setTenantEmployeeId(Long tenantEmployeeId) {
		this.tenantEmployeeId = tenantEmployeeId;
	}
	
	public String getTenantEmployeeName() {
		return tenantEmployeeName;
	}
	
	public void setTenantEmployeeName(String tenantEmployeeName) {
		this.tenantEmployeeName = tenantEmployeeName;
	}
	
	public Tenant getTenant() {
		return tenant;
	}
	
	public void setTenant(Tenant tenant) {
		this.tenant = tenant;
	}
	
//	public long getTenantId() {
//		return tenantId;
//	}
//	
//	public void setTenantId(long tenantId) {
//		this.tenantId = tenantId;
//	}
	
	public User getEditedBy() {
		return editedBy;
	}
	
	public void setEditedBy(User editedBy) {
		this.editedBy = editedBy;
	}
//	public String getEditedBy() {
//		return editedBy;
//	}
//	public void setEditedBy(String editedBy) {
//		this.editedBy = editedBy;
//	}
	public Timestamp getDateTime() {
		return dateTime;
	}
	
	public void setDateTime(Timestamp dateTime) {
		this.dateTime = dateTime;
	}
	
	public boolean isDeleted() {
		return deleted;
	}
	
	public void setDeleted(boolean deleted) {
		this.deleted = deleted;
	}
	
	public String getTitle() {
		return title;
	}
	
	public void setTitle(String title) {
		this.title = title;
	}

	public User getUser() {
		return user;
	}


	public void setUser(User user) {
		this.user = user;
	}


	@Override
	public String toString() {
		return "TenantEmployee [tenantEmployeeId=" + tenantEmployeeId + ", tenantEmployeeName=" + tenantEmployeeName
				+ ", tenant=" + tenant + ", editedBy=" + editedBy + ", dateTime=" + dateTime + ", delete=" + deleted
				+ ", title=" + title + "]";
	}
	
}
