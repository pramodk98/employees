package com.danielwirelesssoftware.firesafety.security.controller;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mobile.device.Device;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.danielwirelesssoftware.firesafety.common.utils.TimeProvider;
import com.danielwirelesssoftware.firesafety.model.AttachDocument;
import com.danielwirelesssoftware.firesafety.model.BuildingLevelDrawingDetail;
import com.danielwirelesssoftware.firesafety.model.DrawingsDetail;
import com.danielwirelesssoftware.firesafety.model.security.Building;
import com.danielwirelesssoftware.firesafety.model.security.BuildingLevel;
import com.danielwirelesssoftware.firesafety.model.requestModel.RequestForDrawingUpdate;
import com.danielwirelesssoftware.firesafety.model.requestModel.RequestWithBuildingRoleId;
import com.danielwirelesssoftware.firesafety.model.responseModel.ResponseForDrawing;
import com.danielwirelesssoftware.firesafety.model.security.BuildingRole;
import com.danielwirelesssoftware.firesafety.model.security.Drawings;
import com.danielwirelesssoftware.firesafety.model.security.User;
import com.danielwirelesssoftware.firesafety.security.JwtUser;
import com.danielwirelesssoftware.firesafety.security.repository.BuildingLevelRepository;
import com.danielwirelesssoftware.firesafety.security.repository.BuildingRoleRepository;
import com.danielwirelesssoftware.firesafety.security.repository.DrawingsRepository;
import com.danielwirelesssoftware.firesafety.security.repository.UserRepository;

import static com.danielwirelesssoftware.firesafety.common.utils.Constant.DELETE_FALSE;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.LEVELS;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

@Transactional
@RestController
public class DrawingRestController {

    private final Log logger = LogFactory.getLog(this.getClass());
    
    @Autowired
    private BuildingRoleRepository buildingRoleRepository;
    
    @Autowired
    private BuildingLevelRepository buildingLevelRepository;
    
    @Autowired
    private DrawingsRepository drawingsRepository;
    
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private TimeProvider timeProvider;
  
    @RequestMapping(value = "/accessDrawings", method = RequestMethod.POST)
    public ResponseEntity<?> DrawingsAccess(@RequestBody RequestWithBuildingRoleId request, Device device){
    	
    	BuildingRole buildingRole = null;
    	Building building = null;
    	long buildingId = 0;
    	
    	//check buildingRole exist
    	buildingRole = buildingRoleRepository.findByBuildingRoleIdAndDeleted(request.getBuildingRoleId(),DELETE_FALSE);  	
    	if(buildingRole == null){
    		logger.error("/accessDrawings API : buildingRole not found for buildingRoleId "+request.getBuildingRoleId());
    		return new ResponseEntity<>("buildingRole not found",HttpStatus.BAD_REQUEST);
    	}
    	
    	//check building exist
    	building = buildingRole.getBuilding();
    	if(building == null){
    		logger.error("/accessDrawings API : building not found for buildingRoleId "+request.getBuildingRoleId());
    		return new ResponseEntity<>("building not found",HttpStatus.BAD_REQUEST);
    	}
    	
    	if(building.isDeleted()){
    		logger.error("/accessDrawings API : building not found for buildingRoleId "+request.getBuildingRoleId());
    		return new ResponseEntity<>("building not found (2)",HttpStatus.BAD_REQUEST);
    	}
    	
    	buildingId = building.getBuildingId();
    	
    	List<BuildingLevel> buildingLevelList = null;
    	buildingLevelList = buildingLevelRepository.findByBuildingAndDeleted(building, DELETE_FALSE);
    	
    	if(buildingLevelList != null){
    		buildingLevelList.sort((left, right) -> Integer.compare(LEVELS.indexOf(left.getLevelName().toUpperCase().replaceAll("\\s","")), LEVELS.indexOf(right.getLevelName().toUpperCase().replaceAll("s",""))));
    		
    	}
    	
    	List<BuildingLevelDrawingDetail> buildingLevelDrawingDetailList = new ArrayList<BuildingLevelDrawingDetail>();
    	
    	for(BuildingLevel b:buildingLevelList){
    		
    		List <DrawingsDetail> dList = new ArrayList<DrawingsDetail>();
    		
    		for(Drawings d : b.getDrawingsList()){
    			if(!d.isDeleted()){
	    			DrawingsDetail detail = new DrawingsDetail(d.getDrawingId(),
	    														new AttachDocument(d.getDocumentName(),
	    																			d.getDocumentKey()));
	    			dList.add(detail);
    			}
    		}
    		  		
    		BuildingLevelDrawingDetail levelName = new BuildingLevelDrawingDetail(b.getBuildingLevelId(),b.getLevelName(),dList);
    		buildingLevelDrawingDetailList.add(levelName);
    	}
    	
        //set response
    	ResponseForDrawing response = new ResponseForDrawing(buildingId,buildingRole.getRole().getDocumentManagementGroup(),buildingLevelDrawingDetailList);
        
        return new ResponseEntity<ResponseForDrawing>(response, HttpStatus.OK);
    }
    
    @RequestMapping(value = "/updateDrawings", method = RequestMethod.POST)
    public ResponseEntity<?> DrawingsUpdate(@RequestBody RequestForDrawingUpdate request, @AuthenticationPrincipal final JwtUser principle, Device device){
    	
    	BuildingLevel buildingLevel = null;
    	BuildingRole buildingRole = null;
    	User user= null;
    	
    	buildingLevel = buildingLevelRepository.findByBuildingLevelIdAndDeleted(request.getLevelId(),DELETE_FALSE);
    	if(buildingLevel == null){
    		logger.error("/updateDrawings API : buildingLevel not found for buildingLevelId "+request.getLevelId());
    		return new ResponseEntity<>("buildingLevel not found",HttpStatus.BAD_REQUEST);
    	}
    	
    	
    	//get current user
    	user = userRepository.findByUserIdAndDeleted(principle.getUserId(),DELETE_FALSE);
    	if(user == null){
    		logger.error("/updateDrawings API : user not found for userId "+principle.getUserId());
    		return new ResponseEntity<>("user not found",HttpStatus.UNAUTHORIZED);
    	}
    	
    	buildingRole = buildingRoleRepository.findByBuildingUserAndBuilding(user,buildingLevel.getBuilding());
    	
    	if(buildingRole == null){
    		logger.error("/accessDrawings API : buildingRole not found for userId: "
    						+user.getUserId() +", buildingId: "+buildingLevel.getBuilding().getBuildingId());
    		return new ResponseEntity<>("buildingRole not found",HttpStatus.BAD_REQUEST);
    	}
    	
    	//update emergency data, if title/file is null, set delete true, else create 
    	for(DrawingsDetail d:request.getDrawingList()){
    		if(d.getAttachDocument().getKey() == null 
    			|| d.getAttachDocument().getDocumentName() == null 
    			|| d.getAttachDocument().getKey().isEmpty() 
    			|| d.getAttachDocument().getDocumentName().isEmpty()){
    			try{
    				drawingsRepository.setFixedDeletedFor(true, d.getDrawingId()); 
    			}catch(Exception e){
    				logger.error("error in updating drawing in updateDrawings: "+e);
    				return new ResponseEntity<String>("data error", HttpStatus.BAD_REQUEST);
    			}
    		}else{    			
    			Drawings drawing = new Drawings(buildingLevel,
    											d.getAttachDocument().getDocumentName(),
    											d.getAttachDocument().getKey(), user,
    											timeProvider.timestampNow(),false);
    			drawingsRepository.saveAndFlush(drawing);

    		}
    	}
    	
    	//get return data
    	   	
    	//get building id
    	long buildingId = buildingLevel.getBuilding().getBuildingId();
    	
    	if(buildingLevel.getBuilding().isDeleted()){
    		logger.error("/accessDrawings API : building is deleted for buildingLevelId "+request.getLevelId());
    		return new ResponseEntity<>("buildingLevel not found (2)",HttpStatus.BAD_REQUEST);
    	}
    	
    	//get all building level 
    	List<BuildingLevel> buildingLevelList = null;
    	buildingLevelList = buildingLevelRepository.findByBuildingAndDeleted(buildingLevel.getBuilding(), DELETE_FALSE);    	
    	List<BuildingLevelDrawingDetail> buildingLevelDrawingDetailList = new ArrayList<BuildingLevelDrawingDetail>();
    	
    	if(buildingLevelList != null){
    		buildingLevelList.sort((left, right) -> Integer.compare(LEVELS.indexOf(left.getLevelName().toUpperCase().replaceAll("\\bFLOOR\\bFLOORS\\bLEVEL\\bLEVELS\\s","")), LEVELS.indexOf(right.getLevelName().toUpperCase().replaceAll("\\bFLOOR\\bFLOORS\\bLEVEL\\bLEVELS\\s",""))));
    		
    	}
    	
    	//loop and check if its deleted, if not deleted, add into list
    	for(BuildingLevel b:buildingLevelList){
    		    		
    		List <DrawingsDetail> dList = new ArrayList<DrawingsDetail>();
    		
    		for(Drawings d : b.getDrawingsList()){
    			logger.info("d.getDrawingId()"+d.getDrawingId());
    			if(!d.isDeleted()){
	    			DrawingsDetail detail = new DrawingsDetail(d.getDrawingId(),
	    														new AttachDocument(d.getDocumentName(),
	    																			d.getDocumentKey()));
	    			dList.add(detail);
    			}
    		}
    		
    		BuildingLevelDrawingDetail levelName = new BuildingLevelDrawingDetail(b.getBuildingLevelId(),b.getLevelName(),dList);
    		buildingLevelDrawingDetailList.add(levelName);
    	}
    	
        //set response
    	ResponseForDrawing response = new ResponseForDrawing(buildingId,buildingRole.getRole().getDocumentManagementGroup(),
    															buildingLevelDrawingDetailList);
        
        return new ResponseEntity<ResponseForDrawing>(response, HttpStatus.OK);
    }
    

}