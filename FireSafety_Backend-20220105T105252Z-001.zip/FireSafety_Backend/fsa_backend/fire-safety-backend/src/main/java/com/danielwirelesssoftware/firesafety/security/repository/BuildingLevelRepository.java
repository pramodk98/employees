package com.danielwirelesssoftware.firesafety.security.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.danielwirelesssoftware.firesafety.model.security.Building;
import com.danielwirelesssoftware.firesafety.model.security.BuildingLevel;

public interface BuildingLevelRepository extends JpaRepository<BuildingLevel, Long> {
	
	BuildingLevel findByBuildingLevelIdAndDeleted(Long buildingLevelId,boolean deleted);
	
	List<BuildingLevel> findByBuildingAndDeleted(Building buildingId, boolean deleted);
}