package com.danielwirelesssoftware.firesafety.security.repository;

import java.sql.Timestamp;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.danielwirelesssoftware.firesafety.model.security.BuildingLevel;
import com.danielwirelesssoftware.firesafety.model.security.Drawings;
import com.danielwirelesssoftware.firesafety.model.security.User;

@Repository
public interface DrawingsRepository extends JpaRepository<Drawings, Long> {
	
	Drawings findByDrawingId(long drawingId);
	
	@Modifying
	@Transactional
	@Query(value = "update Drawings d set d.deleted = ?1 where d.drawingId = ?2", nativeQuery = true)
	int setFixedDeletedFor(boolean deleted, long drawingId);
	
	
	@Modifying
	@Transactional
	@Query(value = "insert into Drawings (levelId, editedBy, dateTime, documentKey, documentName) values (?1, ?2, ?3, ?4, ?5)", nativeQuery = true)
	int setBuildingLevelAndEditedByAndDateTimeAndDocumentKeyAndDocumentName(BuildingLevel buildingLevel,
																			User editedBy,Timestamp dateTime,
																			String documentName, String documentKey);
}


