package com.danielwirelesssoftware.firesafety.model.responseModel;

public class ResponseForSettingAccess{
	
	private boolean pushNotification;
	private String currentBuilding;
	private boolean fireSafetyManager;
	
	public ResponseForSettingAccess() {
	}
	
	public ResponseForSettingAccess(boolean pushNotification, String currentBuilding, boolean fireSafetyManager) {
		this.pushNotification = pushNotification;
		this.currentBuilding = currentBuilding;
		this.fireSafetyManager = fireSafetyManager;
	}
	
	public boolean isPushNotification() {
		return pushNotification;
	}
	public void setPushNotification(boolean pushNotification) {
		this.pushNotification = pushNotification;
	}
	public String getCurrentBuilding() {
		return currentBuilding;
	}
	public void setCurrentBuilding(String currentBuilding) {
		this.currentBuilding = currentBuilding;
	}
	public boolean isFireSafetyManager() {
		return fireSafetyManager;
	}
	public void setFireSafetyManager(boolean fireSafetyManager) {
		this.fireSafetyManager = fireSafetyManager;
	}

	
	
}