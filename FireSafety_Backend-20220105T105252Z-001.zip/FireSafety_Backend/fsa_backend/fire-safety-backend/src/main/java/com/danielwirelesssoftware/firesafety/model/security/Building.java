package com.danielwirelesssoftware.firesafety.model.security;

import java.sql.Timestamp;
import java.util.List;

import javax.persistence.*;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

@Entity
@Table(name = "Building")
public class Building {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name="buildingId")
    private long buildingId; 
    
    @Column(name = "name")
    private String name;
    
    @Column(name = "numLevels")
    private long numLevels;
    
    @Column(name = "latitude")
    private double latitude;
    
    @Column(name = "longtitude")
    private double longtitude;

    @Column(name = "address1")
    private String address1;
    
    @Column(name = "address2")
    private String address2;
    
    @Column(name = "postalCode")
    private String postalCode;
    
    @Column(name = "country")
    private String country;
    
    @Column(name = "lastUpdate")
    private Timestamp lastUpdate;
    
    @Column(name = "deleted")
    private boolean deleted;
    
    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "editedBy")
    private User editedBy;
    
    @OneToMany(mappedBy = "buildingERP", fetch = FetchType.LAZY
    			,cascade = { CascadeType.MERGE, CascadeType.DETACH, CascadeType.REFRESH })
	private List<ERP> erpList;
    
    @OneToMany(mappedBy = "buildingFDS", fetch = FetchType.LAZY
    		,cascade = { CascadeType.MERGE, CascadeType.DETACH, CascadeType.REFRESH })
    @Fetch(value = FetchMode.SUBSELECT)
	private List<FireDrillSchedule> fdsList;
    
    public Building() {
    	
    }
    
    public Building(Building building) {
    	this.buildingId = building.buildingId;;
    	this.latitude=building.latitude;
    	this.longtitude=building.longtitude;
		this.name = building.name;
		this.numLevels = building.numLevels;
    	this.address1=building.address1;
    	this.address2=building.address2;
    	this.postalCode=building.postalCode;
    	this.country=building.country;
    	this.lastUpdate=building.lastUpdate;
    	this.editedBy=building.editedBy;
    	this.deleted=building.deleted;
    }
    
	public Building(long buildingId, long latitude, long longtitude, 
					String name, long numLevels, String address1, String address2, String postalCode,
		    		String country, Timestamp lastUpdate, User editedBy /*String editedBy*/) {
		this.buildingId = buildingId;
		this.latitude=latitude;
    	this.longtitude=longtitude;
		this.name = name;
		this.numLevels = numLevels;
		this.address1=address1;
    	this.address2=address2;
    	this.postalCode=postalCode;
    	this.country=country;
    	this.lastUpdate=lastUpdate;
    	this.editedBy=editedBy;
	}
	
	public Building(long buildingId, long latitude, long longtitude, 
			String name, long numLevels, String address1, String address2, String postalCode,
    		String country, Timestamp lastUpdate, User editedBy, boolean deleted /*String editedBy*/) {
		this.buildingId = buildingId;
		this.latitude=latitude;
		this.longtitude=longtitude;
		this.name = name;
		this.numLevels = numLevels;
		this.address1=address1;
		this.address2=address2;
		this.postalCode=postalCode;
		this.country=country;
		this.lastUpdate=lastUpdate;
		this.editedBy=editedBy;
		this.deleted=deleted;
		}

	public long getBuildingId() {
		return buildingId;
	}

	public void setBuildingId(long buildingId) {
		this.buildingId = buildingId;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getNumLevels() {
		return numLevels;
	}

	public void setNumLevels(long numLevels) {
		this.numLevels = numLevels;
	}
	
	public double getLatitude() {
		return latitude;
	}

	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}

	public double getLongtitude() {
		return longtitude;
	}

	public void setLongtitude(double longtitude) {
		this.longtitude = longtitude;
	}
	
	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public String getPostalCode() {
		return postalCode;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public Timestamp getLastUpdate() {
		return lastUpdate;
	}

	public void setLastUpdate(Timestamp lastUpdate) {
		this.lastUpdate = lastUpdate;
	}

	public User getEditedBy() {
		return editedBy;
	}

	public void setEditedBy(User editedBy) {
		this.editedBy = editedBy;
	}

	public boolean isDeleted() {
		return deleted;
	}

	public void setDeleted(boolean deleted) {
		this.deleted = deleted;
	}

	@Override
	public String toString() {
		return "Building [buildingId=" + buildingId + ", name=" + name + ", numLevels=" + numLevels + ", latitude="
				+ latitude + ", longtitude=" + longtitude + ", address1=" + address1 + ", address2=" + address2
				+ ", postalCode=" + postalCode + ", country=" + country + ", lastUpdate=" + lastUpdate + ", editedBy="
				+ editedBy + "]";
	}
	
	public String getAddress(){
		if(address2==null || address2.isEmpty()){
    		return address1 + ", " + postalCode;// + ", " + country;
    	}
    	return address1 + ", " + address2 + ", " + postalCode;// + ", " + country;
	}

	public List<ERP> getErpList() {
		return erpList;
	}

	public void setErpList(List<ERP> erpList) {
		this.erpList = erpList;
	}

	public List<FireDrillSchedule> getFdsList() {
		return fdsList;
	}

	public void setFdsList(List<FireDrillSchedule> fdsList) {
		this.fdsList = fdsList;
	}
	
    
}
