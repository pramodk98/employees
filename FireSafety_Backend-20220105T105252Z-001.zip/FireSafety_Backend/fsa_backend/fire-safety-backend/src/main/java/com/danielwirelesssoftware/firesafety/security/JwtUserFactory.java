package com.danielwirelesssoftware.firesafety.security;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import com.danielwirelesssoftware.firesafety.model.security.User;

import java.util.List;
import java.util.stream.Collectors;

public final class JwtUserFactory {
	
	private final static Log logger = LogFactory.getLog(JwtUserFactory.class);

    private JwtUserFactory() {
    }

    public static JwtUser create(User user) {
    	logger.debug("inside JwtUserFactory get user:"+user.toString());
        return new JwtUser(user);
    }
}
