package com.danielwirelesssoftware.firesafety.security.controller;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.danielwirelesssoftware.firesafety.common.utils.TimeProvider;
import com.danielwirelesssoftware.firesafety.model.AnsweredQuestionDetail;
import com.danielwirelesssoftware.firesafety.model.AttachDocument;
import com.danielwirelesssoftware.firesafety.model.AttachImageDetail;
import com.danielwirelesssoftware.firesafety.model.HazardReportAnswerDetail;
import com.danielwirelesssoftware.firesafety.model.HazardReportDetail;
import com.danielwirelesssoftware.firesafety.model.QuestionDetail;
import com.danielwirelesssoftware.firesafety.model.RequestForHazardReportUpdate;
import com.danielwirelesssoftware.firesafety.model.ReviewReportDetail;
import com.danielwirelesssoftware.firesafety.model.ReviewReportSectionDetail;
import com.danielwirelesssoftware.firesafety.model.SectionAnswerHazardReportDetail;
import com.danielwirelesssoftware.firesafety.model.SectionHazardReportDetail;
import com.danielwirelesssoftware.firesafety.model.requestModel.RequestForCompleteHazardReportUpdate;
import com.danielwirelesssoftware.firesafety.model.requestModel.RequestForNewFireHazardReportSubmit;
import com.danielwirelesssoftware.firesafety.model.requestModel.RequestWithBuildingRoleId;
import com.danielwirelesssoftware.firesafety.model.requestModel.RequestWithHazardReportId;
import com.danielwirelesssoftware.firesafety.model.responseModel.ResponseForGeneral;
import com.danielwirelesssoftware.firesafety.model.responseModel.ResponseForHazardReportDetailRead;
import com.danielwirelesssoftware.firesafety.model.responseModel.ResponseForHazardReportRead;
import com.danielwirelesssoftware.firesafety.model.responseModel.ResponseForNewFireHazardGenerate;
import com.danielwirelesssoftware.firesafety.model.security.BuildingRole;
import com.danielwirelesssoftware.firesafety.model.security.HazardReport;
import com.danielwirelesssoftware.firesafety.model.security.HazardReportAnswer;
import com.danielwirelesssoftware.firesafety.model.security.HazardReportClose;
import com.danielwirelesssoftware.firesafety.model.security.HazardReportQuestion;
import com.danielwirelesssoftware.firesafety.model.security.HazardReportQuestionData;
import com.danielwirelesssoftware.firesafety.model.security.HazardReportSection;
import com.danielwirelesssoftware.firesafety.model.security.HazardReportSectionData;
import com.danielwirelesssoftware.firesafety.model.security.HazardReportSectionImage;
import com.danielwirelesssoftware.firesafety.model.security.MessageType;
import com.danielwirelesssoftware.firesafety.model.security.User;
import com.danielwirelesssoftware.firesafety.security.JwtUser;
import com.danielwirelesssoftware.firesafety.security.repository.BuildingRoleRepository;
import com.danielwirelesssoftware.firesafety.security.repository.HazardReportAnswerRepository;
import com.danielwirelesssoftware.firesafety.security.repository.HazardReportCloseRepository;
import com.danielwirelesssoftware.firesafety.security.repository.HazardReportQuestionDataRepository;
import com.danielwirelesssoftware.firesafety.security.repository.HazardReportQuestionRepository;
import com.danielwirelesssoftware.firesafety.security.repository.HazardReportRepository;
import com.danielwirelesssoftware.firesafety.security.repository.HazardReportSectionDataRepository;
import com.danielwirelesssoftware.firesafety.security.repository.HazardReportSectionImageRepository;
import com.danielwirelesssoftware.firesafety.security.repository.HazardReportSectionRepository;
import com.danielwirelesssoftware.firesafety.security.repository.MessageTypeRepository;
import com.danielwirelesssoftware.firesafety.security.repository.UserRepository;
//import com.danielwirelesssoftware.firesafety.security.service.HazardReportService;

import ch.qos.logback.classic.Logger;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import javax.servlet.http.HttpServletRequest;

import static com.danielwirelesssoftware.firesafety.common.utils.Constant.SUCCESS;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.STATUS_OPEN;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.STATUS_CLOSE;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.DELETE_FALSE;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.DELETE_TRUE;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.MESSAGE_TYPE_HAZARD_REPORT;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.MESSAGE_TYPE_HAZARD_REPORT_COMPLETE;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.MESSAGE_DETAIL_HAZARD_REPORT_1;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.MESSAGE_DETAIL_HAZARD_REPORT_2;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.MESSAGE_DETAIL_HAZARD_REPORT_COMPLETE_1;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.MESSAGE_DETAIL_HAZARD_REPORT_COMPLETE_2;
@RestController
public class ReportRestController {

    private final Log logger = LogFactory.getLog(this.getClass());
    
    @Autowired
    private BuildingRoleRepository buildingRoleRepository;
    
    @Autowired
    private HazardReportRepository hazardReportRepository;
    
    @Autowired
    private HazardReportAnswerRepository hazardReportAnswerRepository;
    
    @Autowired
    private HazardReportSectionDataRepository hazardReportSectionDataRepository;
    
    @Autowired
    private HazardReportSectionImageRepository hazardReportSectionImageRepository;
    
    @Autowired
    private HazardReportSectionRepository hazardReportSectionRepository;
   
    @Autowired
    private HazardReportQuestionDataRepository hazardReportQuestionDataRepository;
    
    @Autowired
    private HazardReportQuestionRepository hazardReportQuestionRepository;
    
    @Autowired
    private HazardReportCloseRepository hazardReportCloseRepository;
    
    @Autowired
    private UserRepository userRepository;
    
//    @Autowired
//    private HazardReportService hazardReportService;
    
    @Autowired
    private MessageTypeRepository messageTypeRepository;
    
    @Autowired
    private TimeProvider timeProvider;
  
    @RequestMapping(value = "/readHazardReport", method = RequestMethod.POST)
    public ResponseEntity<?> hazardReportRead(@RequestBody RequestWithBuildingRoleId request){
    	
    	BuildingRole buildingRole = null;
    	buildingRole = buildingRoleRepository.findByBuildingRoleIdAndDeleted(request.getBuildingRoleId(),DELETE_FALSE);    	
    	
    	if(buildingRole == null){
    		logger.error("/readHazardReport buildingRole for buildingRoleId"+request.getBuildingRoleId()+" not found");
    		return new ResponseEntity<>("buildingRole not found", HttpStatus.BAD_REQUEST);
    	}
    	
    	List<HazardReport> hazardReportList = hazardReportRepository.findByBuildingAndDeleted(buildingRole.getBuilding(),DELETE_FALSE);

    	List<HazardReportDetail> hazardReportDetailList = new ArrayList<HazardReportDetail>();
    	
    	for(HazardReport h: hazardReportList){
        	HazardReportDetail hd = new HazardReportDetail(h.getHazardReportId(),
        													h.getHazardReportName(),
        													h.getDateTime(),
        													h.getReporter().getDisplayName(),
        													h.getStatus());
        	hazardReportDetailList.add(hd);
        }
    	
        //set response
    	ResponseForHazardReportRead response = new ResponseForHazardReportRead(buildingRole.getRole().getHazardReportGroup(),
																    			buildingRole.getRole().getEditHazardReportGroup(),
																    			hazardReportDetailList);
        
        return new ResponseEntity<ResponseForHazardReportRead>(response, HttpStatus.OK);
    }
    
    @RequestMapping(value = "/readHazardReportDetail", method = RequestMethod.POST)
    public ResponseEntity<?> hazardReportDetailRead(HttpServletRequest servletRequest,
    												@RequestBody RequestWithHazardReportId request, 
    												@AuthenticationPrincipal final JwtUser principle){
    	
    	HazardReport hazardReport = null;
    	
    	BuildingRole buildingRole = null;
    	
    	String reporterName = null, endReporterName = null, displayName = null, 
    			hazardReportName = null, status = null, completeRemark = null;
    	
    	Timestamp reportTime = null, reportCloseTime = null;
    	
    	boolean checkAllowEditHazardReport = false;
    	
    	long buildingId;
    	
    	List<AttachDocument> listOfCompletedAttachImages = new ArrayList<AttachDocument>();
    	List<ReviewReportDetail> reviewReport = new ArrayList<ReviewReportDetail>();
    	
    	User user;

    	//get userId
    	String username = principle.getUsername();
        user = userRepository.findByUsername(username);
        
        //check user exist
        if(user == null || user.isDeleted()){
    		logger.error("/readHazardReportDetail API : user not found for username "+username);
    		return new ResponseEntity<>("user not found",HttpStatus.UNAUTHORIZED);
    	}   
    	
    	//set display name of the current user
    	displayName = user.getDisplayName();
    	
    	hazardReport = hazardReportRepository.findByHazardReportIdAndDeleted(request.getHazardReportId(),DELETE_FALSE);    	
    	
    	//check hazardReport exist
    	if(hazardReport == null){
    		return new ResponseEntity<>("hazardReport not found", HttpStatus.BAD_REQUEST);
    	}
    	
    	//get edit hazard Report authority
    	buildingRole = buildingRoleRepository.findByBuildingUserAndBuilding(user, hazardReport.getBuilding());
    	if(buildingRole != null){
    		checkAllowEditHazardReport = buildingRole.getRole().getEditHazardReportGroup();
    	}
    	 
    	buildingId =hazardReport.getBuilding().getBuildingId();
    	reportTime = hazardReport.getDateTime();
    	hazardReportName = hazardReport.getHazardReportName();
    	status = hazardReport.getStatus();
    	reporterName = hazardReport.getReporter().getDisplayName();
    	
    	
    	//check if report is close by any user
    	User endReportUser = hazardReport.getCloseReporter();
    	if(endReportUser != null){
    		endReporterName = endReportUser.getDisplayName();
    		reportCloseTime = hazardReport.getLastUpdate();
    		completeRemark = hazardReport.getCloseComment();
    		
    		//loop HazardReportClose
    		for(HazardReportClose hazardReportClose:hazardReportCloseRepository.findByHazardReport(hazardReport)){
    			AttachDocument attachDocument = new AttachDocument(hazardReportClose.getDocumentName(),
    																hazardReportClose.getDocumentKey());
    			listOfCompletedAttachImages.add(attachDocument);
    		}	
    	}
    	
    	//get the list of question
    	List<HazardReportQuestion> hazardReportQuestionList = hazardReportQuestionRepository.findByDeletedOrderBySectionId(DELETE_FALSE);
    	
    	//get the list of answered question
    	List<HazardReportSectionData> hazardReportSectionDataList = hazardReportSectionDataRepository.findByHazardReport(hazardReport);
    	
    	boolean attachmentAdded = false;
    	int answeredContinueFromIndex = 0;
    	long sectionId = 0;
    	long answeredSectionId = hazardReportSectionDataList.get(answeredContinueFromIndex).getSection().getSectionId();
    	String sectionName = "";
    	
    	//initialize list of AttachImages
    	List<AttachDocument> listOfAttachImages = new ArrayList<AttachDocument>();
		List<ReviewReportSectionDetail> reviewReportSection = new ArrayList<ReviewReportSectionDetail>();
    	
		for(HazardReportQuestion hazardReportQuestion : hazardReportQuestionList){
    		
    		sectionId = hazardReportQuestion.getSectionId();
    		sectionName = hazardReportSectionRepository.findBySectionId(hazardReportQuestion.getSectionId()).getSectionName();
    		
    		if(sectionId>answeredSectionId && answeredContinueFromIndex < hazardReportSectionDataList.size()){
				answeredContinueFromIndex+=1;
				attachmentAdded = false;
				answeredSectionId = hazardReportSectionDataList.get(answeredContinueFromIndex).getSection().getSectionId();
			}
    		
    		//check if the answered question section is same as current section
    		if(answeredSectionId != hazardReportQuestion.getSectionId()){
    			
    			//check if the reviewReport is empty, if no
    			boolean isSame = false;
    			if(reviewReport.size() > 0){
    				if(sectionId == reviewReport.get(reviewReport.size()-1).getSectionId()){
    					isSame = true;
    				}
    			}
    			
    			//create new list and add it in
    			if(!isSame){
    				
    				listOfAttachImages = new ArrayList<AttachDocument>();
        			reviewReportSection = new ArrayList<ReviewReportSectionDetail>();
        			reviewReportSection.add(new ReviewReportSectionDetail(hazardReportQuestion.getHazardReportQuestionId(),
        																	hazardReportQuestion.getQuestionText(),
														    				null,
														    				null));
        			reviewReport.add(new ReviewReportDetail(sectionId,sectionName,listOfAttachImages, reviewReportSection));
        			
    			}else{
    				//update the current review Report
    				reviewReport.get(reviewReport.size()-1)
    		    								.getReviewReportSection()
    		    								.add(new ReviewReportSectionDetail(hazardReportQuestion.getHazardReportQuestionId(),
    		    																	hazardReportQuestion.getQuestionText(),
    															    				null,
    															    				null));
    			}
    			
    		}else{
    			
    			if(!attachmentAdded){
    				listOfAttachImages = new ArrayList<AttachDocument>();
    				reviewReportSection = new ArrayList<ReviewReportSectionDetail>();
    				List<HazardReportSectionImage> hazardReportSectionImageList = 
    						hazardReportSectionImageRepository.findByImageHazardReport(hazardReportSectionDataList.get(answeredContinueFromIndex));//hazardSectionDataId;
    				for(HazardReportSectionImage hazardReportSectionImage : hazardReportSectionImageList){
    					AttachDocument attachDocument = new AttachDocument(hazardReportSectionImage.getDocumentName(),
    																		hazardReportSectionImage.getDocumentKey());
    					listOfAttachImages.add(attachDocument);
    				}
    				reviewReport.add(new ReviewReportDetail(sectionId,sectionName,listOfAttachImages, reviewReportSection));
    				attachmentAdded = true;
    			}
    			
    			
    			HazardReportSectionData hrsd = hazardReportSectionDataList.get(answeredContinueFromIndex);
    			HazardReportQuestionData hrqd = null;
    			hrqd = hazardReportQuestionDataRepository.findByQuestionAndDataHazardReport(hazardReportQuestion,hrsd);
    			
    			boolean isSame = false;
    			if(reviewReport.size() > 0){
    				if(sectionId == reviewReport.get(reviewReport.size()-1).getSectionId()){
    					isSame = true;
    				}
    			}
    			
    			//this section is not created in return list yet
    			if(!isSame){
    				
    				//this question is not answered and is not created in the return list yet
    				if(hrqd == null){
    					listOfAttachImages = new ArrayList<AttachDocument>();
            			reviewReportSection = new ArrayList<ReviewReportSectionDetail>();
            			reviewReportSection.add(new ReviewReportSectionDetail(hazardReportQuestion.getHazardReportQuestionId(),
            																	hazardReportQuestion.getQuestionText(),
    														    				null,
    														    				null));
            			reviewReport.add(new ReviewReportDetail(sectionId,sectionName,listOfAttachImages, reviewReportSection));
    				
    				}else{
    					//this question is answered and is not created in the return list yet
    					listOfAttachImages = new ArrayList<AttachDocument>();
            			reviewReportSection = new ArrayList<ReviewReportSectionDetail>();
            			reviewReportSection.add(new ReviewReportSectionDetail(hazardReportQuestion.getHazardReportQuestionId(),
            																	hazardReportQuestion.getQuestionText(),
    														    				hrqd.getAnswer().getAnswerText(),
    														    				hrqd.getObservationText()));
            			reviewReport.add(new ReviewReportDetail(sectionId,sectionName,listOfAttachImages, reviewReportSection));
    				}

    			//this section created in return list
    			}else{
    				//this question is not answered and but section is created in return list
    				if(hrqd == null){
    					reviewReport.get(reviewReport.size()-1).getReviewReportSection()
    										.add(new ReviewReportSectionDetail(hazardReportQuestion.getHazardReportQuestionId(),
            																	hazardReportQuestion.getQuestionText(),
    														    				null,
    														    				null));
    				}else{
    				//update the current review Report
    				reviewReport.get(reviewReport.size()-1)
    		    								.getReviewReportSection()
    		    								.add(new ReviewReportSectionDetail(hazardReportQuestion.getHazardReportQuestionId(),
    		    																	hazardReportQuestion.getQuestionText(),
    		    																	hrqd.getAnswer().getAnswerText(),
    		    												    				hrqd.getObservationText()));
    				}
    			}
    			
    		}
    	}
   	
    	
    	//set response
    	ResponseForHazardReportDetailRead response = new ResponseForHazardReportDetailRead(buildingId,checkAllowEditHazardReport,
    																						reporterName,endReporterName,
    																						displayName, reportTime, 
    																						hazardReportName, status, 
    																						reportCloseTime, completeRemark,
    																						listOfCompletedAttachImages, 
    																						reviewReport);
        
    	return new ResponseEntity<ResponseForHazardReportDetailRead>(response, HttpStatus.OK);
    }
    
    
    @RequestMapping(value = "/generateNewFireHazardReport", method = RequestMethod.POST)
    public ResponseEntity<?> newFireHazardReportGenerate(@RequestBody RequestWithBuildingRoleId request){
    	
    	logger.info("started to generate new fire hazard report");
    	
    	BuildingRole buildingRole = null;
    	buildingRole = buildingRoleRepository.findByBuildingRoleIdAndDeleted(request.getBuildingRoleId(),DELETE_FALSE);
    	
    	if(buildingRole == null){
    		logger.error("buildingRole empty");
    		return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
    	}
    	
    	String displayName = buildingRole.getUser().getDisplayName();
    	
    	//get answer list
    	List<HazardReportAnswer> hazardReportAnswerList = hazardReportAnswerRepository.findByDeleted(DELETE_FALSE);
    	
    	logger.info("starting loop 1");
    	
    	//loop into answer detail list
    	List<HazardReportAnswerDetail> hazardReportAnswerDetailList = new ArrayList<HazardReportAnswerDetail>();
    	for(HazardReportAnswer hral: hazardReportAnswerList){
    		HazardReportAnswerDetail hrad = new HazardReportAnswerDetail(hral.getHazardReportAnswerId(), hral.getAnswerText());
    		hazardReportAnswerDetailList.add(hrad);
    	}
    	logger.info("loop 1 end");
    	//get hazardReportSection list
    	List<HazardReportSection> hazardReportSectionList = hazardReportSectionRepository.findByDeleted(DELETE_FALSE);
    	
    	logger.info("starting loop 2");
    	//loop into SectionHazardReportDetail
    	List<SectionHazardReportDetail> listOfSectionsHazardReport = new ArrayList<SectionHazardReportDetail>();
    	for(HazardReportSection hrsd : hazardReportSectionList){
        		
        	List<QuestionDetail> listOfQuestionsHazardReports = new ArrayList<QuestionDetail>();

	       		for(HazardReportQuestion hrqd : hrsd.getHazardReportQuestionList()){
	       			
	        		QuestionDetail q = new QuestionDetail(hrqd.getHazardReportQuestionId(),
	        												hrqd.getQuestionText());
	        		listOfQuestionsHazardReports.add(q);    			
	        	}	
        	
        	SectionHazardReportDetail sectionHazardReportDetail = new SectionHazardReportDetail(hrsd.getSectionId(),
        																						hrsd.getSectionName(),
        																						listOfQuestionsHazardReports);
        	listOfSectionsHazardReport.add(sectionHazardReportDetail);
        }
    	logger.info("loop 2 end");
    	
    	//set response
    	ResponseForNewFireHazardGenerate response = new ResponseForNewFireHazardGenerate(buildingRole.getBuilding().getBuildingId(),
    																						buildingRole.getRole().getEditHazardReportGroup(),
    																						displayName,hazardReportAnswerDetailList,
    																						listOfSectionsHazardReport);
    	logger.info("finish generated new fire hazard report");
    	
        return new ResponseEntity<ResponseForNewFireHazardGenerate>(response, HttpStatus.OK);
    }
    
    
    @RequestMapping(value = "/submitNewFireHazardReport", method = RequestMethod.POST)
    public ResponseEntity<?> newFireHazardReportSubmit(HttpServletRequest servletRequest,
    													@RequestBody RequestForNewFireHazardReportSubmit request,
    													@AuthenticationPrincipal final JwtUser principle){
    	
    	BuildingRole buildingRole = null;
    	buildingRole = buildingRoleRepository.findByBuildingRoleIdAndDeleted(request.getBuildingRoleId(),DELETE_FALSE);
    	
    	if(buildingRole == null){
    		logger.error("buildingRole empty");
    		return new ResponseEntity<>("buildingRole not found",HttpStatus.BAD_REQUEST);
    	}
    	
        //get user from token 
        String username = principle.getUsername();
        User user = null;
        user = userRepository.findByUsernameAndDeleted(username, DELETE_FALSE);
        
        if(user == null){
        	logger.error("user not found for username"+username);
    		return new ResponseEntity<>("user not found",HttpStatus.UNAUTHORIZED);
        }
        
    	Timestamp now = timeProvider.timestampNow();
    	
    	//create hazardReport
    	hazardReportRepository.saveAndFlush(new HazardReport(request.getHazardReportName(),
														buildingRole.getBuilding(),
														now,
														now,
														user,
														null,
														STATUS_OPEN,
														null,
														DELETE_FALSE,
														principle.getUserId()));
    	
    	HazardReport hr = hazardReportRepository.findByLastUpdateAndReporter(now, user);
    	
    	//loop listOfSectionAnswerHazardReport
    	for(SectionAnswerHazardReportDetail sahrd : request.getListOfSectionAnswerHazardReport()){
    		
    		long sectionId = sahrd.getSectionId();
    		 logger.info("/submitNewFireHazardReport, sectionId:"+sectionId);
    		HazardReportSection hazardReportSection = hazardReportSectionRepository.findBySectionId(sectionId);
    		
    		//create hazardReportSectionData
    		hazardReportSectionDataRepository.saveAndFlush(new HazardReportSectionData(hazardReportSection,hr));
    		
    		HazardReportSectionData hrsd = hazardReportSectionDataRepository.findBySectionAndHazardReport(hazardReportSection,hr);
    		
    		if(sahrd.getListOfAnsweredQuestions() != null){
    			
    			//loop ListOfAnsweredQuestion
    	    	for(AnsweredQuestionDetail aqd: sahrd.getListOfAnsweredQuestions()){
    	    		
    	    		//check if the question is answered, not answered don't save
    	    		if(aqd.getAnswerId() == 0){
    	    			continue;
    	    		}
    	    		
    	    		HazardReportQuestion hrq = hazardReportQuestionRepository.findByHazardReportQuestionId(aqd.getQuestionId());
    	    		HazardReportAnswer hra = hazardReportAnswerRepository.findByHazardReportAnswerId(aqd.getAnswerId());
    	    		
    	    		HazardReportQuestionData hazardReportQuestionData = new HazardReportQuestionData(hrq,hra,aqd.getRemarks(),hrsd);
    	    		//create HazardReportQuestionData
    	    		hazardReportQuestionDataRepository.save(hazardReportQuestionData);
    	    	}
    		}
    		
    		if(sahrd.getListOfAttachImages() != null){
    			
    			//loop ListOfAttachImages and create HazardReportSectionImage
    	    	for(AttachDocument aid: sahrd.getListOfAttachImages()){
    	    		hazardReportSectionImageRepository.save(new HazardReportSectionImage(hrsd, aid.getDocumentName(), aid.getKey()));
    	    	}
    		}	
    	}
    	
    	//set response
    	ResponseForGeneral response = new ResponseForGeneral(SUCCESS);
    	
        return new ResponseEntity<ResponseForGeneral>(response, HttpStatus.OK);
    }
    

    @RequestMapping(value = "/deleteHazardReport", method = RequestMethod.POST)
    public ResponseEntity<?> HazardReportUpdate(@RequestBody RequestForHazardReportUpdate request,
    												@AuthenticationPrincipal final JwtUser principle){
    	
    	BuildingRole buildingRole = null;
    	List<HazardReport> hazardReportList = null;
    	boolean checkAllowHazardReport = false, checkAllowEditHazardReport = false;
    	List<HazardReportDetail> listOfHazardReport = new ArrayList<HazardReportDetail>();
    	
    	
    	Timestamp now = timeProvider.timestampNow();
    	for(HazardReportDetail hrd : request.getListOfDeletedReport()){
    		hrd.getHazardReportId();
    		hazardReportRepository.setLastUpdateAndDeletedAndEditedByFor(now, DELETE_TRUE, principle.getUserId(),  hrd.getHazardReportId());
    	}
    	
    	buildingRole = buildingRoleRepository.findByBuildingRoleIdAndDeleted(request.getBuildingRoleId(), DELETE_FALSE);
    	
    	if(buildingRole == null){
    		logger.error("buildingRole empty");
    		return new ResponseEntity<>("buildingRole not found",HttpStatus.BAD_REQUEST);
    	}
    	
    	checkAllowHazardReport = buildingRole.getRole().getHazardReportGroup();
    	checkAllowEditHazardReport = buildingRole.getRole().getEditHazardReportGroup();
    	
    	hazardReportList = hazardReportRepository.findByBuildingAndDeleted(buildingRole.getBuilding(), DELETE_FALSE);
    	
    	for(HazardReportDetail hrd : request.getListOfDeletedReport()){
    		hazardReportList.removeIf(hrl -> hrl.getHazardReportId().equals(hrd.getHazardReportId()));
    	}
    	
    	for(HazardReport hr:hazardReportList){
    		listOfHazardReport.add(new HazardReportDetail(hr.getHazardReportId(),
    														hr.getHazardReportName(),
    														hr.getDateTime(),
    														hr.getReporter().getDisplayName(),
    														hr.getStatus()));
    	}
    	
    	//set response
    	ResponseForHazardReportRead response = new ResponseForHazardReportRead(checkAllowHazardReport,
    																			checkAllowEditHazardReport,
    																			listOfHazardReport);
    	
        return new ResponseEntity<ResponseForHazardReportRead>(response, HttpStatus.OK);
    }
    
    
    @RequestMapping(value = "/updateCompleteHazardReport", method = RequestMethod.POST)
    public ResponseEntity<?> completeHazardReportUpdate(@RequestBody RequestForCompleteHazardReportUpdate request,
    													@AuthenticationPrincipal final JwtUser principle){
    	
    	BuildingRole buildingRole = null;
    	buildingRole = buildingRoleRepository.findByBuildingRoleIdAndDeleted(request.getBuildingRoleId(),DELETE_FALSE);
    	
    	if(buildingRole == null){
    		logger.error("buildingRole empty");
    		return new ResponseEntity<>("buildingRole not found",HttpStatus.BAD_REQUEST);
    	}
    	
    	HazardReport hazardReport = hazardReportRepository.findByHazardReportIdAndDeleted(request.getHazardReportId(),DELETE_FALSE);
    	
    	//update hazardReport
    	hazardReportRepository.setCloseReporterAndStatusAndLastUpdateAndCloseCommentAndEditedByFor(buildingRole.getUser(),
							    																STATUS_CLOSE,
							    																request.getCloseReportTime(),
							    																request.getCompleteRemark(),
							    																principle.getUserId(),
							    																request.getHazardReportId());
    	
    	if(request.getListOfCompletedAttachImages() != null){
    		for(AttachDocument attachImageDetail: request.getListOfCompletedAttachImages()){
        		
        		//create hazardReportClose
        		hazardReportCloseRepository.save(new HazardReportClose(hazardReport,
        																attachImageDetail.getDocumentName(),
        																attachImageDetail.getKey()));
        	}
    	}
    	
    	MessageType messageType = null;
		messageType = messageTypeRepository.findTopByMessageTypeAndDeletedOrderByMessageTypeIdDesc("Hazard Report Complete",DELETE_FALSE);
    	
		if(messageType == null){
			messageType = messageTypeRepository.findByMessageTypeId(MESSAGE_TYPE_HAZARD_REPORT_COMPLETE);
		}
		
		//set up message to send
		String message = MESSAGE_DETAIL_HAZARD_REPORT_COMPLETE_1 + hazardReport.getHazardReportName() 
							+ MESSAGE_DETAIL_HAZARD_REPORT_COMPLETE_2 + principle.getDisplayName();
		
    	//initialize counter
    	final AtomicInteger counter = new AtomicInteger();
    			
//    	//start sending close report pushNotification and message to everyone
//    	Thread updateHazardReportThread = new Thread(hazardReportService.hazardReportThread(counter,
//    																				buildingRole.getBuilding().getBuildingId(),
//    																				principle.getUserId(), 
//    																				messageType, 
//    																				message));
//    	updateHazardReportThread.start();
//    	
//    	try {
//    		updateHazardReportThread.join();
//		} catch (InterruptedException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//			logger.debug("/updateCompleteHazardReport, error getting push notif count:"+e);
//		}
//		logger.debug("//updateCompleteHazardReport: total Push notification sent: "+counter.intValue());
    	
    	//set response
    	ResponseForGeneral response = new ResponseForGeneral(SUCCESS);
    	
        return new ResponseEntity<ResponseForGeneral>(response, HttpStatus.OK);
    }

}