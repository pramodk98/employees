package com.danielwirelesssoftware.firesafety.model.security;

import java.util.List;

import javax.persistence.*;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

@Entity
@Table(name = "HazardReportSection")
public class HazardReportSection {
    
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "sectionId")
    private long sectionId;

	@Column(name = "sectionName")
    private String sectionName;
	
	@Column(name ="deleted")
	private boolean deleted;
	
    @OneToMany(mappedBy = "section", fetch = FetchType.LAZY
    		, cascade = { CascadeType.MERGE, CascadeType.DETACH, CascadeType.REFRESH })
    @Fetch(value = FetchMode.SUBSELECT)
    private List<HazardReportSectionData> hazardReportSectionDataList;
    
    @OneToMany(mappedBy = "sectionId", fetch = FetchType.LAZY
    		, cascade = { CascadeType.MERGE, CascadeType.DETACH, CascadeType.REFRESH })
    @Fetch(value = FetchMode.SUBSELECT)
    private List<HazardReportQuestion> HazardReportQuestionList;

    public HazardReportSection(){
	}
    
	public HazardReportSection(long sectionId, String sectionName) {
		this.sectionId = sectionId;
		this.sectionName = sectionName;
	}
	
	public HazardReportSection(long sectionId, String sectionName, boolean deleted) {
		this.sectionId = sectionId;
		this.sectionName = sectionName;
		this.deleted = deleted;
	}

	public long getSectionId() {
		return sectionId;
	}

	public void setSectionId(long sectionId) {
		this.sectionId = sectionId;
	}

	public String getSectionName() {
		return sectionName;
	}

	public void setSectionName(String sectionName) {
		this.sectionName = sectionName;
	}

	public List<HazardReportSectionData> getHazardReportSectionDataList() {
		return hazardReportSectionDataList;
	}

	public List<HazardReportQuestion> getHazardReportQuestionList() {
		return HazardReportQuestionList;
	}

	public void setHazardReportQuestionList(List<HazardReportQuestion> hazardReportQuestionList) {
		HazardReportQuestionList = hazardReportQuestionList;
	}

	public void setHazardReportSectionDataList(List<HazardReportSectionData> hazardReportSectionDataList) {
		this.hazardReportSectionDataList = hazardReportSectionDataList;
	}

	public boolean isDeleted() {
		return deleted;
	}

	public void setDeleted(boolean deleted) {
		this.deleted = deleted;
	}
    
    
}