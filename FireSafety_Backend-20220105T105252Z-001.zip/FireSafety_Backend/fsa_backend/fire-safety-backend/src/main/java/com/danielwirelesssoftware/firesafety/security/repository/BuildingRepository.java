package com.danielwirelesssoftware.firesafety.security.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import com.danielwirelesssoftware.firesafety.model.security.Building;

public interface BuildingRepository extends JpaRepository<Building, Long> {
	
	Building findByBuildingId(Long buildingId);
	
	List<Building> findByEditedBy(Long EditedBy);
	
	Building findByBuildingIdAndDeleted(Long buildingId, boolean deleted);
}
