package com.danielwirelesssoftware.firesafety.model.responseModel;

import java.util.List;
import com.danielwirelesssoftware.firesafety.model.FireDrillScheduleDetail;

public class ResponseForPastFireDrillAccess {
	
	private String role;
	private String buildingName;
	private List<FireDrillScheduleDetail> fireDrillSchedule;

	public ResponseForPastFireDrillAccess(String role, String buildingName,
			List<FireDrillScheduleDetail> fireDrillSchedule) {
		this.role = role;
		this.buildingName = buildingName;
		this.fireDrillSchedule = fireDrillSchedule;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getBuildingName() {
		return buildingName;
	}

	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}

	public List<FireDrillScheduleDetail> getFireDrillSchedule() {
		return fireDrillSchedule;
	}

	public void setFireDrillSchedule(List<FireDrillScheduleDetail> fireDrillSchedule) {
		this.fireDrillSchedule = fireDrillSchedule;
	}
	
		
}

