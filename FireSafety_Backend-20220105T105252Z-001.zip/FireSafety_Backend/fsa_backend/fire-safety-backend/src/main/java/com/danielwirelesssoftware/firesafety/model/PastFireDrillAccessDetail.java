package com.danielwirelesssoftware.firesafety.model;

import java.sql.Timestamp;

public class PastFireDrillAccessDetail {

    private long fireDrillAttendanceId;
    private Timestamp dateTime;
    private String tenantEmployeeName;
    private long tenantId;
    private String tenanatName; 
    private String tenantEmployeePosition;
    private String status;
    
    public PastFireDrillAccessDetail(){
	}
    
    public PastFireDrillAccessDetail(long fireDrillAttendanceId, Timestamp dateTime, String tenantEmployeeName,
			long tenantId, String tenanatName, String tenantEmployeePosition, String status) {
		this.fireDrillAttendanceId = fireDrillAttendanceId;
		this.dateTime = dateTime;
		this.tenantEmployeeName = tenantEmployeeName;
		this.tenantId = tenantId;
		this.tenanatName = tenanatName;
		this.tenantEmployeePosition = tenantEmployeePosition;
		this.status = status;
	}
    
    public long getFireDrillAttendanceId() {
		return fireDrillAttendanceId;
	}

	public void setFireDrillAttendanceId(long fireDrillAttendanceId) {
		this.fireDrillAttendanceId = fireDrillAttendanceId;
	}

	public Timestamp getDateTime() {
		return dateTime;
	}

	public void setDateTime(Timestamp dateTime) {
		this.dateTime = dateTime;
	}

	public String getTenantEmployeeName() {
		return tenantEmployeeName;
	}

	public void setTenantEmployeeName(String tenantEmployeeName) {
		this.tenantEmployeeName = tenantEmployeeName;
	}

	public long getTenantId() {
		return tenantId;
	}

	public void setTenantId(long tenantId) {
		this.tenantId = tenantId;
	}

	public String getTenanatName() {
		return tenanatName;
	}

	public void setTenanatName(String tenanatName) {
		this.tenanatName = tenanatName;
	}

	public String getTenantEmployeePosition() {
		return tenantEmployeePosition;
	}

	public void setTenantEmployeePosition(String tenantEmployeePosition) {
		this.tenantEmployeePosition = tenantEmployeePosition;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

    
}
