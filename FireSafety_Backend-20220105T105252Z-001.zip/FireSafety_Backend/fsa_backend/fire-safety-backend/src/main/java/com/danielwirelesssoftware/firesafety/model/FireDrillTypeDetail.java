package com.danielwirelesssoftware.firesafety.model;

public class FireDrillTypeDetail {

    private long fireDrillTypeId;
    private String fireDrillTypeName;

    
    public FireDrillTypeDetail(){
	}
    
	public FireDrillTypeDetail(long fireDrillTypeId, String fireDrillTypeName) {
		this.fireDrillTypeId = fireDrillTypeId;
		this.fireDrillTypeName = fireDrillTypeName;
	}

	public long getFireDrillTypeId() {
		return fireDrillTypeId;
	}

	public void setFireDrillTypeId(long fireDrillTypeId) {
		this.fireDrillTypeId = fireDrillTypeId;
	}

	public String getFireDrillTypeName() {
		return fireDrillTypeName;
	}

	public void setFireDrillTypeName(String fireDrillTypeName) {
		this.fireDrillTypeName = fireDrillTypeName;
	}
    
}