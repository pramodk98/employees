package com.danielwirelesssoftware.firesafety.security.service;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.quartz.JobBuilder;
import org.quartz.JobDataMap;
import org.quartz.JobDetail;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.SimpleScheduleBuilder;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;
import org.springframework.stereotype.Component;

import com.danielwirelesssoftware.firesafety.common.utils.TimeProvider;
import com.danielwirelesssoftware.firesafety.model.security.Building;
import com.danielwirelesssoftware.firesafety.model.security.BuildingRole;
import com.danielwirelesssoftware.firesafety.model.security.FireDrillAttendance;
import com.danielwirelesssoftware.firesafety.model.security.FireDrillSchedule;
import com.danielwirelesssoftware.firesafety.model.security.MessageType;
import com.danielwirelesssoftware.firesafety.model.security.Role;
import com.danielwirelesssoftware.firesafety.security.repository.BuildingRoleRepository;
import com.danielwirelesssoftware.firesafety.security.repository.FireDrillAttendanceRepository;
import com.danielwirelesssoftware.firesafety.security.repository.FireDrillScheduleRepository;
import com.danielwirelesssoftware.firesafety.security.repository.RoleRepository;

import static com.danielwirelesssoftware.firesafety.common.utils.Constant.ACTION_FIREDRILL_PRESTART;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.ACTION_UPDATE_FIRE_DRILL;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.DELETE_FALSE;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.MESSAGE_TYPE_FIREDRILL_PRESTART;


@Component
public class MessageService extends QuartzJobBean {
	
	private final Log logger = LogFactory.getLog(this.getClass());
	
	@Autowired
    private FCMService fcmService;
	
	@Autowired
    private TimeProvider timeProvider;
	
	@Autowired
    private FireDrillScheduleRepository fireDrillScheduleRepository;
	
	@Autowired
    private FireDrillAttendanceRepository fireDrillAttendanceRepository;
    
	@Autowired
    private RoleRepository roleRepository;
	
	@Autowired
    private BuildingRoleRepository buildingRoleRepository;
	
	@Autowired
    private Scheduler scheduler;
    
	@Autowired
	private JobBuilderService jobBuilderService;
	
	@Override
    protected void executeInternal(JobExecutionContext jobExecutionContext) throws JobExecutionException {
       
    	logger.info("Executing Job with key {}"+ jobExecutionContext.getJobDetail().getKey());
    	
        JobDataMap jobDataMap = jobExecutionContext.getMergedJobDataMap();
        
        try
        {
        	FireDrillSchedule fireDrillSchedule = (FireDrillSchedule) jobDataMap.get("fireDrillSchedule");
       	 	runFireDrillSchedule(fireDrillSchedule);
        }
        catch(Exception e)
        {
        	logger.error("error scheduling FireDrillSchedule:" + e);
        }
        
    }

    // this is called by user 
    private void runFireDrillSchedule(FireDrillSchedule fireDrillSchedule) {
    	logger.info("//coming in to 20sec scheduling");
    	Long twentySecAgo = timeProvider.timestampToLong(timeProvider.millisecondsBefore(20000L));
    	boolean sendNotif = false;
    	//check ongoing fireDrill
    	//check by building, start date time before now, not deleted, complete date time null
    	FireDrillSchedule thisFireDrill = null;
    	thisFireDrill = fireDrillScheduleRepository
											.findByFireDrillIdAndBuildingFDSAndCompleteDateTimeIsNullAndDeleted(fireDrillSchedule.getFireDrillId(),
													 														fireDrillSchedule.getBuildingFDS(), 
    																										DELETE_FALSE);
    	
//    	List<FireDrillSchedule> existedFireDrillSchedule = fireDrillScheduleRepository
//    														.findByBuildingFDSAndStartDateTimeBeforeAndDeletedAndCompleteDateTimeIsNull(building, 
//    																																now, 
//    																																DELETE_FALSE);
//    	
    	if(thisFireDrill == null){
    		logger.info("//fireDrillhas end for fireDrillId: " + fireDrillSchedule.getFireDrillId());
    		return;
    	}
    	
    	//check if building is deleted
    	if(thisFireDrill.getBuildingFDS().isDeleted()){
    		logger.info("//BuildingId: " + thisFireDrill.getBuildingFDS().getBuildingId() 
    					+ " is deleted for fireDrillSchedule for fireDrillId: " + fireDrillSchedule.getFireDrillId());
    		return;
    	}
    	
    	//there is no update since start of fireDrill
    	if(thisFireDrill.getLastAttendanceUpdate() == null){
    		logger.info("// fireDrillSchedule for fireDrillId: " + thisFireDrill.getFireDrillId() + " there is no update yet ");
    		
    	}else{  //there is update
    	
    		//there is update in the last 20 second
    		if (timeProvider.timestampToLong(thisFireDrill.getLastAttendanceUpdate()) > twentySecAgo){
    			logger.info("//there is an update within last 20sec ");
    			sendNotif = true;
    		}else{
    			logger.info("//there is no update within last 20sec ");
    		}
    	}
    	
    	//send notification
    	if(sendNotif){
    		logger.info("//sending notif for 20sec scheduling ");
    		//get the building role to be send
    		List<BuildingRole> buildingRoleList = new ArrayList<BuildingRole>();
    	  	
        	List<Role> roleList = roleRepository.findByFireDrillAttendanceGroupAndDeletedOrFireDrillAuthorityGroupAndDeletedOrFireDrillStartGroupAndDeleted(true,
    																																						DELETE_FALSE,
    																																						true,
    																																						DELETE_FALSE,
    																																						true,
    																																						DELETE_FALSE);
        	//loop role and find relevant user
    		for(Role r : roleList){
    			logger.info("//20sec scheduling adding role "+r.getRoleName());
    			buildingRoleList.addAll(buildingRoleRepository.findByBuildingAndRoleAndDeleted(fireDrillSchedule.getBuildingFDS(),r,DELETE_FALSE));
    		}
    		
    		

        	Thread t = new Thread(updateFireDrillThread(buildingRoleList,fireDrillSchedule.getFireDrillId()));
        	
        	t.start();
    		
    	}
    	
    	//reschedule for 20 second later
    	try {
        	JobDetail jobDetail = jobBuilderService.buildJobDetail2(thisFireDrill);
        	Trigger trigger = jobBuilderService.buildJobTrigger2(jobDetail, timeProvider.millisecondsLater(20000L));
			scheduler.scheduleJob(jobDetail, trigger);
		} catch (SchedulerException e1) {
			// TODO Auto-generated catch block
			logger.error("//20sec scheduling ERROR!");
			e1.printStackTrace();
		}

    }
	
    public Thread updateFireDrillThread(List<BuildingRole> buildingRoleList, long fireDrillId){
    	
    	return new Thread() {
    		@Override
    		public void run() {
    			logger.info("/updating fireDrill1");
    			
        		for(BuildingRole br : buildingRoleList){
        			logger.info("/updating fireDrill, "+br.getBuildingRoleId());
        			if(br.getUser().isDeleted() || br.getUser().getPushNotificationToken() == null || br.getUser().getPushNotificationToken().isEmpty()){
        				continue;
        			}
        			fcmService.sendPushNotification(br.getUser().getPushNotificationToken(),
        											br.getBuildingRoleId(),
        											br.getUser().getUserId(), 
        											ACTION_UPDATE_FIRE_DRILL, 
        											"", 
        											fireDrillId, 
        											"");
        		}
    		}
    	};
    }
    
  
    

}
