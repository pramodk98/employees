package com.danielwirelesssoftware.firesafety.model.requestModel;

import java.sql.Timestamp;
import java.util.List;

import com.danielwirelesssoftware.firesafety.model.AttachDocument;

public class RequestForCompleteHazardReportUpdate {
	
	private long buildingRoleId;
	private long hazardReportId;
	private Timestamp closeReportTime;
	private String completeRemark;
	private List<AttachDocument> listOfCompletedAttachImages;
	
	public RequestForCompleteHazardReportUpdate(){
	}
	
	public RequestForCompleteHazardReportUpdate(RequestForCompleteHazardReportUpdate requestForCompleteHazardReportUpdate) {
		this.buildingRoleId = requestForCompleteHazardReportUpdate.buildingRoleId;
		this.hazardReportId = requestForCompleteHazardReportUpdate.hazardReportId;
		this.closeReportTime = requestForCompleteHazardReportUpdate.closeReportTime;
		this.completeRemark = requestForCompleteHazardReportUpdate.completeRemark;
		this.listOfCompletedAttachImages = requestForCompleteHazardReportUpdate.listOfCompletedAttachImages;
	}
	
	public RequestForCompleteHazardReportUpdate(long buildingRoleId, long hazardReportId, Timestamp closeReportTime, String completeRemark,
			List<AttachDocument> listOfCompletedAttachImages) {
		this.buildingRoleId = buildingRoleId;
		this.hazardReportId = hazardReportId;
		this.closeReportTime = closeReportTime;
		this.completeRemark = completeRemark;
		this.listOfCompletedAttachImages = listOfCompletedAttachImages;
	}
	
	public Timestamp getCloseReportTime() {
		return closeReportTime;
	}

	public void setCloseReportTime(Timestamp closeReportTime) {
		this.closeReportTime = closeReportTime;
	}

	public long getBuildingRoleId() {
		return buildingRoleId;
	}
	
	public void setBuildingRoleId(long buildingRoleId) {
		this.buildingRoleId = buildingRoleId;
	}
	
	public long getHazardReportId() {
		return hazardReportId;
	}
	
	public void setHazardReportId(long hazardReportId) {
		this.hazardReportId = hazardReportId;
	}
	
	public String getCompleteRemark() {
		return completeRemark;
	}
	
	public void setCompleteRemark(String completeRemark) {
		this.completeRemark = completeRemark;
	}
	
	public List<AttachDocument> getListOfCompletedAttachImages() {
		return listOfCompletedAttachImages;
	}
	
	public void setListOfCompletedAttachImages(List<AttachDocument> listOfCompletedAttachImages) {
		this.listOfCompletedAttachImages = listOfCompletedAttachImages;
	}
	
	
}

