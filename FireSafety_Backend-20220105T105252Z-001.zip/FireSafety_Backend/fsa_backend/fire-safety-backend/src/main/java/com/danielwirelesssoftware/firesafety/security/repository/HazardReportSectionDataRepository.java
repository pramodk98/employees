package com.danielwirelesssoftware.firesafety.security.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.danielwirelesssoftware.firesafety.model.security.HazardReport;
import com.danielwirelesssoftware.firesafety.model.security.HazardReportSection;
import com.danielwirelesssoftware.firesafety.model.security.HazardReportSectionData;

public interface HazardReportSectionDataRepository extends JpaRepository<HazardReportSectionData, Long> {
	
	HazardReportSectionData findBySectionAndHazardReport(HazardReportSection section,HazardReport hazardReport);
	
	List<HazardReportSectionData> findByHazardReport(HazardReport hazardReport);
}
