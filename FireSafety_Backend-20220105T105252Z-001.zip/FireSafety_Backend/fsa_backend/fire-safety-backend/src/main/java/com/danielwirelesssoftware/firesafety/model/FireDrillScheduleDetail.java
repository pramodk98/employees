package com.danielwirelesssoftware.firesafety.model;

import java.sql.Timestamp;

public class FireDrillScheduleDetail extends FireDrillDetail {

	private Timestamp completeDateTime;


	public FireDrillScheduleDetail(){
	}
	
	public FireDrillScheduleDetail(long fireDrillId, Timestamp scheduleDateTime, Timestamp startDateTime, String description, Timestamp completeDateTime) {
		super.setFireDrillId(fireDrillId);
		super.setScheduleDateTime(scheduleDateTime);				
		super.setDescription(description);
		super.setStartDateTime(startDateTime);
		this.completeDateTime = completeDateTime;
	}

	public Timestamp getCompleteDateTime() {
		return completeDateTime;
	}

	public void setCompleteDateTime(Timestamp completeDateTime) {
		this.completeDateTime = completeDateTime;
	}
	
	public int compareTo(FireDrillScheduleDetail o) {
		// sort by start date, if start date is null, sort by schedule date
	    try{
	    	return getStartDateTime().compareTo(o.getStartDateTime());
	    }catch(NullPointerException e){
	    	return getScheduleDateTime().compareTo(o.getScheduleDateTime());
	    }
	}
}
