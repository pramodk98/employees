package com.danielwirelesssoftware.firesafety.security.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.danielwirelesssoftware.firesafety.model.security.FSC;

public interface FSCRepository extends JpaRepository<FSC, Long> {
	
	FSC findByFscId(Long fscId);
	
	//get latest FSC object
	FSC findTopByBuildingIdOrderByFscIdDesc(Long BuildingId);
	
}
