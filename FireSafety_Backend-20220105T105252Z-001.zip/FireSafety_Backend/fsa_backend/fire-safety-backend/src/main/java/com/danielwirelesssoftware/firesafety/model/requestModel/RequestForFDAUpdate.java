package com.danielwirelesssoftware.firesafety.model.requestModel;

public class RequestForFDAUpdate {
	
	private long fireDrillId;
	private long tenantEmployeeId;
	private String status;
	
	public RequestForFDAUpdate() {
	}
	
	public RequestForFDAUpdate(long fireDrilleId,long tenantEmployeeId, String status) {
		this.fireDrillId = fireDrilleId;
		this.tenantEmployeeId = tenantEmployeeId;
		this.status = status;
	}
	
	public long getFireDrillId() {
		return fireDrillId;
	}

	public void setFireDrillId(long fireDrillId) {
		this.fireDrillId = fireDrillId;
	}

	public long getTenantEmployeeId() {
		return tenantEmployeeId;
	}

	public void setTenantEmployeeId(long tenantEmployeeId) {
		this.tenantEmployeeId = tenantEmployeeId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	
	
	
}

