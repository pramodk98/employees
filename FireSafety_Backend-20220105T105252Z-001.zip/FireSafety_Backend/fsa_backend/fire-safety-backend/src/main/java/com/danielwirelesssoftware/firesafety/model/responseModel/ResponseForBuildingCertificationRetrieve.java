package com.danielwirelesssoftware.firesafety.model.responseModel;

import java.util.List;

import com.danielwirelesssoftware.firesafety.model.security.Certification;

public class ResponseForBuildingCertificationRetrieve {
	
	private List<Certification> listOfCertification;
	
	public ResponseForBuildingCertificationRetrieve() {
	}

	public ResponseForBuildingCertificationRetrieve(List<Certification> listOfCertification) {
		this.listOfCertification = listOfCertification;
	}

	public List<Certification> getListOfCertification() {
		return listOfCertification;
	}

	public void setListOfCertification(List<Certification> listOfCertification) {
		this.listOfCertification = listOfCertification;
	}
	
	
}

