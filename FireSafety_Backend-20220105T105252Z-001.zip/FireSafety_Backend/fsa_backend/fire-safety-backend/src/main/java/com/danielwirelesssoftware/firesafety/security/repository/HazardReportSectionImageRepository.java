package com.danielwirelesssoftware.firesafety.security.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.danielwirelesssoftware.firesafety.model.security.HazardReportSectionData;
import com.danielwirelesssoftware.firesafety.model.security.HazardReportSectionImage;


public interface HazardReportSectionImageRepository extends JpaRepository<HazardReportSectionImage, Long> {

	List<HazardReportSectionImage> findByImageHazardReport(HazardReportSectionData imageHazardReport);
	
}
