package com.danielwirelesssoftware.firesafety.model.security;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import java.util.List;

@Entity
@Table(name = "User")
public class User {	
	
	@Id
    @Column(name = "userId")
	@GeneratedValue(strategy=GenerationType.AUTO)
    private Long userId;

    @Column(name = "username", length = 50)
    @NotNull
    @Size(min = 4, max = 50)
    private String username;
	
    @Column(name = "displayName", length = 100)
    @NotNull
    @Size(min = 4, max = 100)
    private String displayName;

    @Column(name = "password", length = 100)
    @NotNull
    @Size(min = 4, max = 100)
    private String password;
    
    @Column(name = "title", length = 100)
    @NotNull
    private String title;
    
    @Column(name = "email", length = 100)
    @NotNull
    private String email;
    
    @Column(name = "pushNotificationToken", length = 150)
    private String pushNotificationToken;
        
    @Column(name = "profileImage", length = 100)
    private String profileImage;
    
//    @Column(name = "tenantEmployeeId")
//    private Long tenantEmployeeId;

    @Column(name = "phoneNumber")
    private String phoneNumber;
    
    @Column(name = "deleted")
    private Boolean deleted;
    
    @Column(name = "notification")
    private Boolean notification;

    @OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "tenantEmployeeId")
    private TenantEmployee tenantEmployee;
    
    @OneToMany(mappedBy = "buildingUser", fetch = FetchType.LAZY
    		, cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.DETACH, CascadeType.REFRESH })
    @Fetch(value = FetchMode.SUBSELECT)
	private List<BuildingRole> buildingRoleList;
    
    public User() {
    }

    public User(User user) {
    	this.userId = user.userId;
    	this.username = user.username;
		this.displayName = user.displayName;
		this.password = user.password;
		this.title = user.title;
		this.email = user.email;
		this.pushNotificationToken = user.pushNotificationToken;
		this.profileImage = user.profileImage;
		this.tenantEmployee = user.tenantEmployee;
//		this.tenantEmployeeId = user.tenantEmployeeId;
		this.phoneNumber = user.phoneNumber;
		this.notification = user.notification;
    }
    
    public User(String username,String displayName, String password,String title, String email,
    			String phoneNumber) {
    	this.username = username;
		this.displayName = displayName;
		this.password = password;
		this.title = title;
		this.email = email;
		this.phoneNumber = phoneNumber;
	}
    
	public User( String username, String displayName, String password, String title,
			String email, String pushNotificationToken, String profileImage,
			TenantEmployee tenantEmployee, /*Long tenantEmployeeId,*/ String phoneNumber, boolean notification) {
		
		this.username = username;
		this.displayName = displayName;
		this.password = password;
		this.title = title;
		this.email = email;
		this.pushNotificationToken = pushNotificationToken;
		this.profileImage = profileImage;
		this.tenantEmployee = tenantEmployee;
//		this.tenantEmployeeId = tenantEmployeeId;
		this.phoneNumber = phoneNumber;
		this.notification = notification;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}
	
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPushNotificationToken() {
		return pushNotificationToken;
	}

	public void setPushNotificationToken(String pushNotificationToken) {
		this.pushNotificationToken = pushNotificationToken;
	}

	public String getProfileImage() {
		return profileImage;
	}

	public void setProfileImage(String profileImage) {
		this.profileImage = profileImage;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	
	public void setDeleted(Boolean deleted) {
		this.deleted = deleted;
	}
	
	public Boolean isDeleted() {
		return deleted;
	}
	
	public void setNotification(Boolean notification) {
		this.notification = notification;
	}

	public List<BuildingRole> getBuildingRoleList() {
		return buildingRoleList;
	}

	@Override
	public String toString() {
		return "User [userId=" + userId + ", username=" + username + ", displayName=" + displayName + ", password="
				+ password + ", title=" + title + ", email=" + email + ", pushNotificationToken="
				+ pushNotificationToken + ", profileImage=" + profileImage// + ", tenantEmployeeId=" + tenantEmployeeId
				+ ", phoneNumber=" + phoneNumber + "]";
	}

	public TenantEmployee getTenantEmployee() {
		return tenantEmployee;
	}

	public void setTenantEmployee(TenantEmployee tenantEmployee) {
		this.tenantEmployee = tenantEmployee;
	}

	public Boolean getNotification() {
		return notification;
	}

	public void setBuildingRoleList(List<BuildingRole> buildingRoleList) {
		this.buildingRoleList = buildingRoleList;
	}

    
	

    
}
