package com.danielwirelesssoftware.firesafety.security.service;

import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.danielwirelesssoftware.firesafety.common.utils.TimeProvider;
import com.danielwirelesssoftware.firesafety.model.EscalationAttendanceDetail;
import com.danielwirelesssoftware.firesafety.model.security.BuildingRole;
import com.danielwirelesssoftware.firesafety.model.security.Escalation;
import com.danielwirelesssoftware.firesafety.model.security.FireDrillAttendance;
import com.danielwirelesssoftware.firesafety.model.security.Message;
import com.danielwirelesssoftware.firesafety.model.security.MessageType;
import com.danielwirelesssoftware.firesafety.model.security.Notification;
import com.danielwirelesssoftware.firesafety.security.repository.BuildingRoleRepository;
import com.danielwirelesssoftware.firesafety.security.repository.MessageRepository;
import com.danielwirelesssoftware.firesafety.security.repository.NotificationRepository;

import static com.danielwirelesssoftware.firesafety.common.utils.Constant.ACTION_ESCALATION_START;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.DELETE_FALSE;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.MESSAGE_TITLE_ESCALATION;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.MESSAGE_DETAIL_ESCALATION;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.STATUS_FALSE;

@Component
public class EscalationService{
	
	private final Log logger = LogFactory.getLog(this.getClass());
	
	@Autowired
	private BuildingRoleRepository buildingRoleRepository;
	
	@Autowired
    private MessageRepository messageRepository;
	
	@Autowired
    private NotificationRepository notificationRepository;
	
	@Autowired
    private FCMService fcmService;

	@Autowired
    private TimeProvider timeProvider;

    
    //counter to count how many push notification sent, 
    //building to get each user buildingRoleId ,
    //fireDrillSchedule to loop the attendance
    //fireDrillStatus to set the status for notification
    public Thread escalationThread(AtomicInteger counter, List<EscalationAttendanceDetail> escalationAttendanceDetailList, long escalationId, MessageType messageType){
    	
    	return new Thread() {
    		@Override
    		public void run() {
    			logger.info("//0.1");
    			
    			
    			for(EscalationAttendanceDetail ead: escalationAttendanceDetailList){
    				
    				BuildingRole br = buildingRoleRepository.findByBuildingRoleIdAndDeleted(ead.getBuildingRoleId(),DELETE_FALSE);
    				
    				logger.info("//02");
    				
    				logger.info("//03:"+messageType.getMessageTypeId());
					
    				Message message = new Message(messageType,timeProvider.timestampNow(),
							MESSAGE_TITLE_ESCALATION, MESSAGE_DETAIL_ESCALATION,
							br.getBuilding().getBuildingId(), ead.getEscalationAttendanceId());
    				messageRepository.saveAndFlush(message);
    				
    				logger.info("//04:"+message.getMessageId());
    				Notification notification = new Notification(br.getUser(),
							STATUS_FALSE,
							message);
    				notificationRepository.save(notification);
    				
    				if(br.getUser().getPushNotificationToken() != null && br.getUser().getNotification()){
		    			logger.info("//05");

		    			//send notification
		    			fcmService.sendPushNotification(br.getUser().getPushNotificationToken(),
													ead.getBuildingRoleId(),
													br.getUser().getUserId(),
													ACTION_ESCALATION_START,
													"",
													escalationId,
													"");
		    			logger.info("//06");
		    				
		    			//add sent counter
		    			counter.getAndIncrement();
						
						logger.info("//07");
		    		}
    			}
    		}
    	};
    }}
