package com.danielwirelesssoftware.firesafety.model;

public class AnsweredQuestionDetail {

    private long questionId;
    private long answerId;
    private String remarks;
	
    public AnsweredQuestionDetail(){
	}
    
    public AnsweredQuestionDetail(long questionId, long answerId, String remarks) {
		this.questionId = questionId;
		this.answerId = answerId;
		this.remarks = remarks;
	}

	public long getQuestionId() {
		return questionId;
	}

	public void setQuestionId(long questionId) {
		this.questionId = questionId;
	}

	public long getAnswerId() {
		return answerId;
	}

	public void setAnswerId(long answerId) {
		this.answerId = answerId;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
    
    


    
}
