package com.danielwirelesssoftware.firesafety.model;

import java.util.List;
import com.danielwirelesssoftware.firesafety.model.ReviewReportSectionDetail;

public class ReviewReportDetail {

    private Long sectionId;
    private String sectionName;
    private List<AttachDocument> listOfAttachImages;
    private List<ReviewReportSectionDetail> reviewReportSection;
	
    public ReviewReportDetail() {

	}
    
    public ReviewReportDetail(Long sectionId, String sectionName, List<AttachDocument> listOfAttachImages,
								List<ReviewReportSectionDetail> reviewReportSection) {
		this.sectionId = sectionId;
		this.sectionName = sectionName;
		this.listOfAttachImages = listOfAttachImages;
		this.reviewReportSection = reviewReportSection;
	}
    
	public Long getSectionId() {
		return sectionId;
	}
	
	public void setSectionId(Long sectionId) {
		this.sectionId = sectionId;
	}
	
	public String getSectionName() {
		return sectionName;
	}
	
	public void setSectionName(String sectionName) {
		this.sectionName = sectionName;
	}
	
	public List<AttachDocument> getListOfAttachImages() {
		return listOfAttachImages;
	}
	
	public void setListOfAttachImages(List<AttachDocument> listOfAttachImages) {
		this.listOfAttachImages = listOfAttachImages;
	}
	
	public List<ReviewReportSectionDetail> getReviewReportSection() {
		return reviewReportSection;
	}
	
	public void setReviewReportSection(List<ReviewReportSectionDetail> reviewReportSection) {
		this.reviewReportSection = reviewReportSection;
	}
    
}
