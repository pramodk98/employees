package com.danielwirelesssoftware.firesafety.security.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.danielwirelesssoftware.firesafety.model.security.Configurations;


public interface ConfigurationsRepository extends JpaRepository<Configurations, Long> {
	
	List<Configurations> findAll();
	
	//get latest configurations object
	Configurations findTopByOrderByLastUpdateDesc();
}


