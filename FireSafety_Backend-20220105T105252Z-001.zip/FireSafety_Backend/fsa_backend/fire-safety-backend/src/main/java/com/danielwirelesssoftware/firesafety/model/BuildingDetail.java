package com.danielwirelesssoftware.firesafety.model;

public class BuildingDetail {
   
    private long buildingRoleId;
   
    private String buildingName;
    
    private String address;

    public BuildingDetail() {
    }

	public BuildingDetail(long buildingRoleId, String buildingName, String address) {
		this.buildingRoleId = buildingRoleId;
		this.buildingName = buildingName;
		this.address = address;
	}

	public long getBuildingRoleId() {
		return buildingRoleId;
	}

	public void setBuildingRoleId(long buildingRoleId) {
		this.buildingRoleId = buildingRoleId;
	}
	
	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
	
	public String getBuildingName() {
		return buildingName;
	}

	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}
	

}
