package com.danielwirelesssoftware.firesafety.model.responseModel;

import java.util.List;

import com.danielwirelesssoftware.firesafety.model.BuildingCertificationDetail;


public class ResponseForCertificationRetrieve{
	
		public List<BuildingCertificationDetail> certificationList;
		public boolean allowBuildingCertification;
		public boolean enableToEdit;
		
		public ResponseForCertificationRetrieve() {
		}

		public ResponseForCertificationRetrieve(ResponseForCertificationRetrieve responseForCertificationRetrieve) {
			this.certificationList = responseForCertificationRetrieve.certificationList;
			this.enableToEdit = responseForCertificationRetrieve.enableToEdit;
			this.allowBuildingCertification = responseForCertificationRetrieve.allowBuildingCertification;
			
		}
		
		public ResponseForCertificationRetrieve(List<BuildingCertificationDetail> certificationList,
												boolean allowBuildingCertification,boolean enableToEdit) {
			this.certificationList = certificationList;
			this.enableToEdit = enableToEdit;
			this.allowBuildingCertification = allowBuildingCertification;
		}

		public List<BuildingCertificationDetail> getCertificationList() {
			return certificationList;
		}

		public void setCertificationList(List<BuildingCertificationDetail> certificationList) {
			this.certificationList = certificationList;
		}

		public boolean isAllowBuildingCertification() {
			return allowBuildingCertification;
		}

		public void setAllowBuildingCertification(boolean allowBuildingCertification) {
			this.allowBuildingCertification = allowBuildingCertification;
		}

		public boolean isEnableToEdit() {
			return enableToEdit;
		}

		public void setEnableToEdit(boolean enableToEdit) {
			this.enableToEdit = enableToEdit;
		}
		
		
}
	

