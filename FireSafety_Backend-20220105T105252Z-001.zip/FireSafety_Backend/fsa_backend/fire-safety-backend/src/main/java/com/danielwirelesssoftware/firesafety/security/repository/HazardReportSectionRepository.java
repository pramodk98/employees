package com.danielwirelesssoftware.firesafety.security.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.danielwirelesssoftware.firesafety.model.security.HazardReportAnswer;
import com.danielwirelesssoftware.firesafety.model.security.HazardReportSection;

public interface HazardReportSectionRepository extends JpaRepository<HazardReportSection, Long> {
	
	HazardReportSection findBySectionIdAndDeleted(long SectionId, boolean deleted);
	
	HazardReportSection findBySectionId(long SectionId);
	
	List<HazardReportSection> findByDeleted(boolean deleted); 
	
}
