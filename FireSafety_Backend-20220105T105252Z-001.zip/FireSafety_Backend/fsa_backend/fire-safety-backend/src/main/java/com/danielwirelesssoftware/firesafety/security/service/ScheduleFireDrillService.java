package com.danielwirelesssoftware.firesafety.security.service;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.quartz.QuartzJobBean;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.danielwirelesssoftware.firesafety.common.utils.TimeProvider;
import com.danielwirelesssoftware.firesafety.model.security.Building;
import com.danielwirelesssoftware.firesafety.model.security.BuildingRole;
import com.danielwirelesssoftware.firesafety.model.security.FireDrillAttendance;
import com.danielwirelesssoftware.firesafety.model.security.FireDrillSchedule;
import com.danielwirelesssoftware.firesafety.model.security.Message;
import com.danielwirelesssoftware.firesafety.model.security.MessageType;
import com.danielwirelesssoftware.firesafety.model.security.Notification;
import com.danielwirelesssoftware.firesafety.model.security.User;
import com.danielwirelesssoftware.firesafety.model.security.TenantEmployee;
import com.danielwirelesssoftware.firesafety.security.repository.BuildingRoleRepository;
import com.danielwirelesssoftware.firesafety.security.repository.FireDrillAttendanceRepository;
import com.danielwirelesssoftware.firesafety.security.repository.FireDrillScheduleRepository;
import com.danielwirelesssoftware.firesafety.security.repository.MessageRepository;
import com.danielwirelesssoftware.firesafety.security.repository.MessageTypeRepository;
import com.danielwirelesssoftware.firesafety.security.repository.NotificationRepository;
import com.danielwirelesssoftware.firesafety.security.repository.TenantEmployeeRepository;

import static com.danielwirelesssoftware.firesafety.common.utils.Constant.DELETE_FALSE;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.STATUS_FALSE;

import static com.danielwirelesssoftware.firesafety.common.utils.Constant.MESSAGE_TYPE_FIREDRILL_DRY_RUN;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.MESSAGE_TYPE_FIREDRILL_SCHEDULE;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.MESSAGE_TYPE_FIRE_ACTIVATION;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.MESSAGE_TYPE_FIREDRILL_DELETE;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.MESSAGE_TYPE_FIREDRILL_UPDATE;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.MESSAGE_TYPE_FIREDRILL_END;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.MESSAGE_TYPE_FIREDRILL_PRESTART;

import static com.danielwirelesssoftware.firesafety.common.utils.Constant.MESSAGE_TITLE_FIREDRILL_SCHEDULE;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.MESSAGE_TITLE_FIREDRILL_DRY_RUN;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.MESSAGE_TITLE_FIRE_ACTIVATION;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.MESSAGE_TITLE_FIREDRILL_PRESTART;

import static com.danielwirelesssoftware.firesafety.common.utils.Constant.MESSAGE_DETAIL_FIREDRILL_SCHEDULE;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.MESSAGE_DETAIL_FIREDRILL_DRY_RUN;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.MESSAGE_DETAIL_FIRE_ACTIVATION;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.MESSAGE_DETAIL_FIREDRILL_DELETE_1;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.MESSAGE_DETAIL_FIREDRILL_DELETE_2;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.MESSAGE_DETAIL_FIREDRILL_PRESTART;

import static com.danielwirelesssoftware.firesafety.common.utils.Constant.ACTION_FIREDRILL_SCHEDULED;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.ACTION_FIREDRILL_START;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.ACTION_FIREDRILL_END;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.ACTION_FIREDRILL_DELETE;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.ACTION_FIREDRILL_PRESTART;

@Component
@Transactional
public class ScheduleFireDrillService extends QuartzJobBean {
	
	private final Log logger = LogFactory.getLog(this.getClass());
	
	@Autowired
	private BuildingRoleRepository buildingRoleRepository;
	    
	@Autowired
    private NotificationRepository notificationRepository;
	
	@Autowired
	private MessageRepository messageRepository;
	
	@Autowired
	private MessageTypeRepository messageTypeRepository;
	
	@Autowired
	private FireDrillAttendanceRepository fireDrillAttendanceRepository;
	
	@Autowired
	private FireDrillScheduleRepository fireDrillScheduleRepository;
	
	@Autowired
	private TenantEmployeeRepository tenantEmployeeRepository;
	
	@Autowired
    private FCMService fcmService;
	
	@Autowired
    private TimeProvider timeProvider;
     
    @Override
    protected void executeInternal(JobExecutionContext jobExecutionContext) throws JobExecutionException {
       
    	logger.info("Executing Job with key {}"+ jobExecutionContext.getJobDetail().getKey());
    	
        JobDataMap jobDataMap = jobExecutionContext.getMergedJobDataMap();
        
        try
        {
        	FireDrillSchedule fireDrillSchedule = (FireDrillSchedule) jobDataMap.get("fireDrillSchedule");
       	 	runFireDrillSchedule(fireDrillSchedule);
        }
        catch(Exception e)
        {
        	logger.error("error scheduling FireDrillSchedule:" + e);
        }
        
    }

    // this is called by user /generateNewFireDrillSchedule &
    // upon restarting server this is called from ApplicationStartup
    private void runFireDrillSchedule(FireDrillSchedule fds) {
    	
    	//get the fireDrillSchedule again because the fds param is from when its created or restarted, it might have been deleted
    	FireDrillSchedule fireDrillSchedule = null;
    	fireDrillSchedule = fireDrillScheduleRepository.findByFireDrillIdAndDeletedAndCompleteDateTimeIsNull(fds.getFireDrillId(), DELETE_FALSE);
    	
    	//check if fireDrillSchedule is deleted
    	if(fireDrillSchedule == null){
    		logger.error("FireDrillSchedule for fireDrillId: " + fds.getFireDrillId() + " is deleted");
    		return;
    	}

    	//get buildingId
    	Building building = fireDrillSchedule.getBuildingFDS();
    	Timestamp now = timeProvider.timestampNow();
    	
    	//check if building is deleted
    	if(building.isDeleted()){
    		logger.info("buildingId: " + building.getBuildingId()+" for fireDrillId: " + fireDrillSchedule.getFireDrillId() 
    					 + " is deleted");
    		return;
    	}
    	
    	//check ongoing fireDrill
    	//check by building, start date time before now, not deleted, complete date time null
    	List<FireDrillSchedule> existedFireDrillSchedule = fireDrillScheduleRepository
    														.findByBuildingFDSAndStartDateTimeBeforeAndDeletedAndCompleteDateTimeIsNull(building, 
    																																now, 
    																																DELETE_FALSE);
    	if(existedFireDrillSchedule.size()>0){
    		logger.info("onGoing fireDrill for buildingId: " + building.getBuildingId());
    		return;
    	}
    	
    	logger.debug("00");
    	

		MessageType messageType = messageTypeRepository.findByMessageTypeId(MESSAGE_TYPE_FIREDRILL_PRESTART);
		
    	
    	//for counting sent pushNotification in thread 
    	final AtomicInteger counter = new AtomicInteger();
    	
    	//treading for simultaneous sending out notification
    	Thread t = new Thread(fireDrillThread(counter,building,fireDrillSchedule,0, ACTION_FIREDRILL_PRESTART,messageType,null));

    	t.start();
    	
    	try {
			t.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

    	logger.info("total Push notification sent: "+counter.intValue());
    	
    }
    

    
    //counter to count how many push notification sent, 
    //building to get each user buildingRoleId ,
    //fireDrillSchedule to loop the attendance
    public Thread fireDrillThread(AtomicInteger counter, Building building, FireDrillSchedule fireDrillSchedule, long buildingRoleId, 
    							int action, MessageType messageType, List<FireDrillAttendance> fireDrillAttendanceList ){
    	
    	return new Thread() {
    		@Override
    		public void run() {
    			logger.debug("01");
    			
    			List<BuildingRole> buildingRoleList = buildingRoleRepository.findByBuilding(building);
    			for(BuildingRole br: buildingRoleList){
    				
    				if(br.isDeleted()){
    					logger.info("buildingRole is deleted for buildingRoleId: "+br.getBuildingRoleId());
    	    			continue;
    				}
    				
    				User user = br.getUser();
    				
    				if(user.isDeleted()){
    					logger.info("user is deleted for userId: "+user.getUserId());
    					continue;
    				}
    				
    				String title="";
					String detail="";
					Boolean silentPushNotification = false;
    				
					if(action == ACTION_FIREDRILL_START){
						silentPushNotification = true;
					}
					
    				if(messageType != null){
    					
    					
    					String dateTime = new SimpleDateFormat("dd MMMM yyyy, hh.mm a").format(fireDrillSchedule.getScheduleDateTime());
    					logger.debug("05");
    					logger.info("messageType.getMessageTypeId()"+messageType.getMessageTypeId());
    					if(messageType.getMessageTypeId() == MESSAGE_TYPE_FIREDRILL_PRESTART){
    						
    						title = MESSAGE_TITLE_FIREDRILL_PRESTART;
    						detail =  MESSAGE_DETAIL_FIREDRILL_PRESTART + dateTime ;
    					}
    					
    					if(messageType.getMessageTypeId() == MESSAGE_TYPE_FIREDRILL_SCHEDULE){
    						
    						title = MESSAGE_TITLE_FIREDRILL_SCHEDULE;
    						detail =  MESSAGE_DETAIL_FIREDRILL_SCHEDULE + dateTime ;
    					}
    					
    					if(messageType.getMessageTypeId() == MESSAGE_TYPE_FIREDRILL_DRY_RUN){
    						title = MESSAGE_TITLE_FIREDRILL_DRY_RUN;
    						detail = MESSAGE_DETAIL_FIREDRILL_DRY_RUN;
    					}
    					
    					if(messageType.getMessageTypeId() == MESSAGE_TYPE_FIRE_ACTIVATION){
    						title = MESSAGE_TITLE_FIRE_ACTIVATION;
    						detail = MESSAGE_DETAIL_FIRE_ACTIVATION;
    					}
    					
    					if(messageType.getMessageTypeId() == MESSAGE_TYPE_FIREDRILL_DELETE){
    						title = MESSAGE_TITLE_FIREDRILL_SCHEDULE;
    						detail = MESSAGE_DETAIL_FIREDRILL_DELETE_1 + dateTime + MESSAGE_DETAIL_FIREDRILL_DELETE_2 ;
    					}
    					
    					if(messageType.getMessageTypeId() == ACTION_FIREDRILL_END){
//    						detail = MESSAGE_DETAIL_FIREDRILL_END + dateTime + MESSAGE_DETAIL_FIREDRILL_DELETE_1 ;
    					}
    				}
    				
    				
    				logger.info("02, //title: "+title+ ", //detail: "+detail);
    				
    				//check user notification status and notification token
    				if(user.getPushNotificationToken() != null 
    					&& ((user.getNotification() && br.getRole().getFireDrillNotificationGroup()) || silentPushNotification)
    					){
		    			
    					logger.debug("02.5");
		    			
    					//check the condition for schedule, start , update, end fireDrill
    					//scheduleFireDrill send to everyone include the person who created it
    					//startFireDrill and endFireDrill send to everyone except the person who start/end
    					//updateFireDrillAttendance /removeAttendace only send to FSM,FW,BM
		    			if( (action == ACTION_FIREDRILL_PRESTART)
		    				|| (messageType.getMessageTypeId() == MESSAGE_TYPE_FIREDRILL_DELETE)
		    				|| (messageType.getMessageTypeId() == MESSAGE_TYPE_FIREDRILL_SCHEDULE)
		    				|| (buildingRoleId != br.getBuildingRoleId() && messageType.getMessageTypeId() == MESSAGE_TYPE_FIREDRILL_DRY_RUN)
		    				|| (buildingRoleId != br.getBuildingRoleId() && messageType.getMessageTypeId() == MESSAGE_TYPE_FIRE_ACTIVATION)
		    				|| (buildingRoleId != br.getBuildingRoleId() && messageType.getMessageTypeId() == MESSAGE_TYPE_FIREDRILL_END)
		    				|| ( (br.getRole().getFireDrillAttendanceGroup()
		    						|| br.getRole().getFireDrillAuthorityGroup()
		    						|| br.getRole().getFireDrillStartGroup()) 
		    					  &&( messageType.getMessageTypeId() == MESSAGE_TYPE_FIREDRILL_UPDATE ))){
		    				
		    				logger.info("03 , " +user.getUserId()+","+user.getDisplayName());
			    			//send notification
			    			fcmService.sendPushNotification(user.getPushNotificationToken(),br.getBuildingRoleId(), user.getUserId(), action, detail, fireDrillSchedule.getFireDrillId(), "");
			    			logger.debug("04");
			    				
			    			//add sent counter
			    			counter.getAndIncrement();
		    			}
		    			
		    		}
    				
    				if(!title.isEmpty() && !detail.isEmpty()){
    					logger.info("06");
    					FireDrillAttendance fda = null;
    					//2019/8/2 updated to find by tenantEmployee linkage
   						//fda = fireDrillAttendanceRepository.findByTenantEmployeeAndFireDrillSchedule(br.getUser().getTenantEmployee(),fireDrillSchedule);
   						
   						List<TenantEmployee> teList= tenantEmployeeRepository.findByUserAndDeleted(user,DELETE_FALSE);
   				    	TenantEmployee te = null;
   				    	for(TenantEmployee tes : teList){
   				    		if(tes.getTenant().getBuilding() == br.getBuilding())
   				    			te = tes;
   				    	}
   				    	
   				    	if(te != null){ 
   				    		fda = fireDrillAttendanceRepository.findByTenantEmployeeAndFireDrillSchedule(te, fireDrillSchedule);
   				    	}
    					
    					
   						boolean added = false;
   						if(fireDrillAttendanceList != null){
   							logger.info("06.5");
   							Iterator<FireDrillAttendance> fdal = fireDrillAttendanceList.iterator();
       						while (fdal.hasNext()) {
       						   FireDrillAttendance fireDrillAttendance = fdal.next(); // must be called before you can call i.remove()
       						   TenantEmployee tenantEmployee = null;
       						   tenantEmployee = br.getUser().getTenantEmployee();
       						   long tenantEmployeeId = -1L;
       						   if(tenantEmployee!=null){
       							   tenantEmployeeId = br.getUser().getTenantEmployee().getTenantEmployeeId();
       						   }
       						   boolean tenantEmployeeUserId = false;
       						   if(fireDrillAttendance.getTenantEmployee().getUser() !=null){
       							   logger.info("//06.7: fda id:"+fireDrillAttendance.getFireDrillAttendanceId());
       							   logger.info(fireDrillAttendance.getTenantEmployee().getUser());
       							//compare current attendance's tenantEmployeeId to buildingRole's user's tenantEmployeeId
           						   // or compare to the tenantEmployee userId 
           						   if(fireDrillAttendance.getTenantEmployee().getTenantEmployeeId() == tenantEmployeeId
           								|| fireDrillAttendance.getTenantEmployee().getUser().getUserId() == br.getUser().getUserId()
           								|| tenantEmployeeUserId){
           	    						Message message = new Message(messageType,timeProvider.timestampNow(),
           	    														title,detail,
           	    														br.getBuilding().getBuildingId(),
           	    														fireDrillAttendance.getFireDrillAttendanceId());
           													messageRepository.saveAndFlush(message);
           								   
           								Notification notification = new Notification(br.getUser(), STATUS_FALSE, message);
           								notificationRepository.save(notification);
           								added = true;
           								//fdal.remove();
           								logger.info("//added fireDrillAttendanceId :"+fireDrillAttendance.getFireDrillAttendanceId());
           								continue;
           						   	}
       						   }else{
       							//compare current attendance's tenantEmployeeId to buildingRole's user's tenantEmployeeId
           						   // or compare to the tenantEmployee userId 
           						   if(fireDrillAttendance.getTenantEmployee().getTenantEmployeeId() == tenantEmployeeId){
           	    						Message message = new Message(messageType,timeProvider.timestampNow(),
           	    														title,detail,
           	    														br.getBuilding().getBuildingId(),
           	    														fireDrillAttendance.getFireDrillAttendanceId());
           													messageRepository.saveAndFlush(message);
           								   
           								Notification notification = new Notification(br.getUser(), STATUS_FALSE, message);
           								notificationRepository.save(notification);
           								added = true;
           								//fdal.remove();
           								logger.info("//added fireDrillAttendanceId :"+fireDrillAttendance.getFireDrillAttendanceId());
           								continue;
           						   	}
       						   }
       						   
       						}
       						//non fire warden role, since they do not have tenantEmployee
       						if(!added){
       							logger.info("fda attendance id not found for userId"+br.getUser().getUserId());
       							if(br.getRole().getFireDrillAttendanceGroup() 
       								|| br.getRole().getFireDrillAuthorityGroup() 
       								|| (messageType.getMessageTypeId() == MESSAGE_TYPE_FIREDRILL_SCHEDULE)
       								|| (messageType.getMessageTypeId() == MESSAGE_TYPE_FIREDRILL_DELETE)){
       								Message message = new Message(messageType,timeProvider.timestampNow(),
																	title,detail,
																	br.getBuilding().getBuildingId(),
																	0L);
									messageRepository.saveAndFlush(message);
						
									Notification notification = new Notification(br.getUser(), STATUS_FALSE, message);
									notificationRepository.save(notification);
       							}
       							
       						logger.info("fireDrillThread, added buildingRoleId * the one who created?:"+br.getBuildingRoleId());
       						}
   						}else{
   							logger.info("07, not in list, FW");
   							//role which have tenant, like fire warden
   							if(fda!= null){
   								Message message = new Message(messageType,timeProvider.timestampNow(),
																title,detail,
																br.getBuilding().getBuildingId(),
																fda.getFireDrillAttendanceId());
						    									messageRepository.saveAndFlush(message);
								Notification notification = new Notification(br.getUser(), STATUS_FALSE, message);
								notificationRepository.save(notification);
   							}else{
   								//role without tenant, like FSM, member of EMT, BM
   								//delete fire drill will come here
   								logger.info("08, delete fire drill? FSM EMT BM");
   								Message message = new Message(messageType,timeProvider.timestampNow(),
										title,detail,
										br.getBuilding().getBuildingId(),
										0L);
    									messageRepository.saveAndFlush(message);
								Notification notification = new Notification(br.getUser(), STATUS_FALSE, message);
								notificationRepository.save(notification);
   							}
   							logger.info("fireDrillThread, coming here");
   						}
    				}
    				
    			}	
    		}
    	};
    }
    

}
