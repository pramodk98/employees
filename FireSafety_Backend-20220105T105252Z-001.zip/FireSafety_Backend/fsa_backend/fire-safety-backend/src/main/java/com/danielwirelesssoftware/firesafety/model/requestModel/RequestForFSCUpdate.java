package com.danielwirelesssoftware.firesafety.model.requestModel;

import com.danielwirelesssoftware.firesafety.model.AttachDocument;

public class RequestForFSCUpdate {
	
	private long buildingRoleId;
	private AttachDocument attachDocument;
	
	public RequestForFSCUpdate() {
	}
	
	public RequestForFSCUpdate(long buildingRoleId, AttachDocument attachDocument) {
		this.buildingRoleId = buildingRoleId;
		this.attachDocument = attachDocument;
	}

	public long getBuildingRoleId() {
		return buildingRoleId;
	}

	public void setBuildingRoleId(long buildingRoleId) {
		this.buildingRoleId = buildingRoleId;
	}

	public AttachDocument getAttachDocument() {
		return attachDocument;
	}

	public void setAttachDocument(AttachDocument attachDocument) {
		this.attachDocument = attachDocument;
	}

	
	
}
