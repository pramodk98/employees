package com.danielwirelesssoftware.firesafety.model;

import java.util.List;

public class SectionHazardReportDetail {
	
	private long sectionId;
	private String sectionName;
	private List<QuestionDetail> listOfQuestionHazardReport;
	
	public SectionHazardReportDetail() {
	}
	
	public SectionHazardReportDetail(long sectionId, String sectionName,
			List<QuestionDetail> listOfQuestionHazardReport) {
		this.sectionId = sectionId;
		this.sectionName = sectionName;
		this.listOfQuestionHazardReport = listOfQuestionHazardReport;
	}

	public long getSectionId() {
		return sectionId;
	}

	public void setSectionId(long sectionId) {
		this.sectionId = sectionId;
	}

	public String getSectionName() {
		return sectionName;
	}

	public void setSectionName(String sectionName) {
		this.sectionName = sectionName;
	}

	public List<QuestionDetail> getListOfQuestionHazardReport() {
		return listOfQuestionHazardReport;
	}

	public void setListOfQuestionHazardReport(List<QuestionDetail> listOfQuestionHazardReport) {
		this.listOfQuestionHazardReport = listOfQuestionHazardReport;
	}
	
	
}