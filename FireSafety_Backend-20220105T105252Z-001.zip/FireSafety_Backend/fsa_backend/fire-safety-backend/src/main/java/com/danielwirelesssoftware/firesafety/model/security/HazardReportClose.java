package com.danielwirelesssoftware.firesafety.model.security;

import javax.persistence.*;

@Entity
@Table(name = "HazardReportClose")
public class HazardReportClose {
    
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "hazardReportCloseId")
    private long hazardReportCloseId;
	
	@OneToOne
    @JoinColumn(name = "hazardReportId")
    private HazardReport hazardReport;
    
    @Column(name = "documentName")
    private String documentName;
    
    @Column(name = "documentKey")
    private String documentKey;
    
    public HazardReportClose(){
	}
    
    public HazardReportClose( HazardReport hazardReport, String documentName,
			String documentKey) {
		this.hazardReport = hazardReport;
		this.documentName = documentName;
		this.documentKey = documentKey;
	}
    
	public HazardReportClose(long hazardReportCloseId, HazardReport hazardReport, String documentName,
			String documentKey) {
		this.hazardReportCloseId = hazardReportCloseId;
		this.hazardReport = hazardReport;
		this.documentName = documentName;
		this.documentKey = documentKey;
	}

	public long getHazardReportCloseId() {
		return hazardReportCloseId;
	}

	public void setHazardReportCloseId(long hazardReportCloseId) {
		this.hazardReportCloseId = hazardReportCloseId;
	}

	public HazardReport getHazardReport() {
		return hazardReport;
	}

	public void setHazardReport(HazardReport hazardReport) {
		this.hazardReport = hazardReport;
	}

	public String getDocumentName() {
		return documentName;
	}

	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}

	public String getDocumentKey() {
		return documentKey;
	}

	public void setDocumentKey(String documentKey) {
		this.documentKey = documentKey;
	}
    
    
    
    
}