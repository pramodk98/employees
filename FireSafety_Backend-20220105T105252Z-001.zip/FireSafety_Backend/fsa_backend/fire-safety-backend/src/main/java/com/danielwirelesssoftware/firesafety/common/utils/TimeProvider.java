package com.danielwirelesssoftware.firesafety.common.utils;

import org.springframework.stereotype.Component;

import java.io.Serializable;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

@Component
public class TimeProvider implements Serializable {

    private static final long serialVersionUID = -3301695478208950415L;
	
    public Date now() {
        return new Date();
    }

    public Timestamp timestampNow(){
    	return new Timestamp(System.currentTimeMillis());
    }
    
    public long longNow(){
        return new Timestamp(System.currentTimeMillis()).getTime();
    }
    
    public Date timeStampToDate(Timestamp timestamp){
    	Date date = new Date(timestamp.getTime()); 
    	return date;
    }
    
    public Date longToDate(long dateTime){
    	Timestamp timestamp = new Timestamp( dateTime);
    	Date date = new Date(timestamp.getTime()); 
    	return date;
    }
    
    public Timestamp longToTimestamp(Long dateTime){
    	Timestamp timestamp = new Timestamp(dateTime);
    	return timestamp;
    }
    
    public long timestampToLong(Timestamp timestamp){
    	return timestamp.getTime();
    }
    
    public Timestamp longToTimestamp2(Long dateTime){
    	Date d = new Date(dateTime);
    	Timestamp ts=new Timestamp(d.getTime()/1000000);
    	return ts;
    }
    
    public String longToDateString(Long dateTime){
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss,SSS");
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(dateTime);
        return sdf.format(calendar.getTime());
    }

    public Timestamp millisecondsLater(Long miliseconds){
    	return new Timestamp(System.currentTimeMillis()+miliseconds);
    }
    
    public Timestamp millisecondsBefore(Long miliseconds){
    	return new Timestamp(System.currentTimeMillis()-miliseconds);
    }
    
    public LocalDate timestampToLocalDate(Timestamp timestamp){
    	TimeZone sgtTimeZone = TimeZone.getTimeZone("Asia/Singapore");
        TimeZone.setDefault(sgtTimeZone);
        return timestamp.toLocalDateTime().toLocalDate();
    }
    
    public LocalDate localDateNow(){
    	return LocalDate.now();
    }
    
    public Date localDateToDate(LocalDate localDate) {
        return Date.from(localDate.atStartOfDay().atZone(ZoneId.systemDefault()).toInstant());
    }
    
    public LocalDate dateToLocalDate(Date date) {
        return Instant.ofEpochMilli(date.getTime()).atZone(ZoneId.systemDefault()).toLocalDate();
    }

    public String timestampToFormattedDate(Timestamp timstamp) {
    	return new SimpleDateFormat("yyyy-MM-dd").format(new Date());
    }
    
    public String timestampToFormattedDateTime(Timestamp timstamp) {
    	return new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
    }
    
}
