package com.danielwirelesssoftware.firesafety.model.requestModel;


public class RequestForRegistration {
	
	private String diplayName;
	private String password;
	private String title;
	private String email;
	private long tenantEmployeeId;
	private String phoneNumber;
	
	public RequestForRegistration() {
	}
	
	public RequestForRegistration(String diplayName, String password, String title, String email,
									long tenantEmployeeId, String phoneNumber) {
		this.diplayName = diplayName;
		this.password = password;
		this.title = title;
		this.email = email;
		this.tenantEmployeeId = tenantEmployeeId;
		this.phoneNumber = phoneNumber;
	}

	public String getDiplayName() {
		return diplayName;
	}

	public void setDiplayName(String diplayName) {
		this.diplayName = diplayName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public long getTenantEmployeeId() {
		return tenantEmployeeId;
	}

	public void setTenantEmployeeId(long tenantEmployeeId) {
		this.tenantEmployeeId = tenantEmployeeId;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}	
			
	public Boolean anyUnset() {
		try{
			if (diplayName.isEmpty() || password.isEmpty() || title.isEmpty() || email.isEmpty() || phoneNumber.isEmpty()) return true;			
			if (tenantEmployeeId < 0 ) return true;
		}catch(Exception e){
			return true;
		}
	    return false;
	}
		
}

