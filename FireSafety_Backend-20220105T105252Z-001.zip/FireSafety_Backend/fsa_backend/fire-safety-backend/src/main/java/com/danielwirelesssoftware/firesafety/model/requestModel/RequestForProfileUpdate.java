package com.danielwirelesssoftware.firesafety.model.requestModel;

import com.danielwirelesssoftware.firesafety.model.UserProfileDetail;

public class RequestForProfileUpdate extends UserProfileDetail {

    private long userId;
    
    public RequestForProfileUpdate() {
	}
    
	public RequestForProfileUpdate(long userId) {
		super();
		this.userId = userId;
	}

	public RequestForProfileUpdate(long userId, String name, String email, String contactNo, String key) {
		this.userId = userId;
		super.setContactNo(contactNo);
		super.setEmail(email);
		super.setKey(key);
		super.setName(name);
	}

	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}
    
    
}
