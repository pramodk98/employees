package com.danielwirelesssoftware.firesafety.model.requestModel;

import com.danielwirelesssoftware.firesafety.model.security.Certification;

public class RequestForBuildingCertificationUpdate {

	private long buildingRoleId;
	private Certification certification;
	
	public RequestForBuildingCertificationUpdate() {
	}
	
	public RequestForBuildingCertificationUpdate(RequestForBuildingCertificationUpdate requestForBuildingCertificationUpdate) {
		this.buildingRoleId = requestForBuildingCertificationUpdate.buildingRoleId;
		this.certification = requestForBuildingCertificationUpdate.certification;

	}
	
	public RequestForBuildingCertificationUpdate(long buildingRoleId, Certification certification) {
		this.buildingRoleId = buildingRoleId;
		this.certification = certification;
	}

	public long getBuildingRoleId() {
		return buildingRoleId;
	}

	public void setBuildingRoleId(long buildingRoleId) {
		this.buildingRoleId = buildingRoleId;
	}

	public Certification getCertification() {
		return certification;
	}

	public void setCertification(Certification certification) {
		this.certification = certification;
	}
	
}
