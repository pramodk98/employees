package com.danielwirelesssoftware.firesafety.model;

import java.util.List;

public class BuildingLevelDrawingDetail {
   
    private long levelId;
   
    private String levelName;
    
    private List<DrawingsDetail> drawingList;

    public BuildingLevelDrawingDetail() {
    }

	public BuildingLevelDrawingDetail(long levelId, String levelName, List<DrawingsDetail> 
	drawingList) {
		this.levelId = levelId;
		this.levelName = levelName;
		this.drawingList = drawingList;
	}

	public long getLevelId() {
		return levelId;
	}

	public void setLevelId(long levelId) {
		this.levelId = levelId;
	}

	public String getLevelName() {
		return levelName;
	}

	public void setLevelName(String levelName) {
		this.levelName = levelName;
	}

	public List<DrawingsDetail> getDrawingList() {
		return drawingList;
	}

	public void setDrawingList(List<DrawingsDetail> drawingList) {
		this.drawingList = drawingList;
	}	

}
