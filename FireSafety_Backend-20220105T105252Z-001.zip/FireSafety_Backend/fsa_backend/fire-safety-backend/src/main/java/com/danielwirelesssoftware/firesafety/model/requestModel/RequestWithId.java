package com.danielwirelesssoftware.firesafety.model.requestModel;

public class RequestWithId {

    private Long id;
    
    public RequestWithId(){
	}
    
    public RequestWithId(RequestWithId requestWithId){
    	this.id = requestWithId.id;
	}
    
    public RequestWithId(Long id){
    	this.id = id;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
    
    
}
