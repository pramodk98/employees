package com.danielwirelesssoftware.firesafety.security.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.danielwirelesssoftware.firesafety.model.security.Tenant;
import com.danielwirelesssoftware.firesafety.model.security.TenantEmployee;
import com.danielwirelesssoftware.firesafety.model.security.User;

public interface TenantEmployeeRepository extends JpaRepository<TenantEmployee, Long> {
	
	TenantEmployee findByTenantEmployeeId(Long tenantEmployeeId);
	
	List<TenantEmployee> findByUserAndDeleted(User user,boolean deleted);
	
}
