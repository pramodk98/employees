package com.danielwirelesssoftware.firesafety.model;

public class FireDrillAttendanceDetail {

    private long tenantId;    
    private String tenantName;    
    private long tenantTotalStrength;
    private long tenantPresentStrength;
    
    public FireDrillAttendanceDetail() {
    }

    public FireDrillAttendanceDetail(FireDrillAttendanceDetail fireDrillAttendanceDetail,
										long tenantTotalStrength) {
		this.tenantId =  fireDrillAttendanceDetail.tenantId;
		this.tenantName = fireDrillAttendanceDetail.tenantName;
		this.tenantTotalStrength = fireDrillAttendanceDetail.tenantTotalStrength;
		this.tenantPresentStrength = fireDrillAttendanceDetail.tenantPresentStrength;
    }

    
    
	public FireDrillAttendanceDetail(long tenantId, String tenantName,long tenantPresentStrength,
										long tenantTotalStrength) {
		this.tenantId = tenantId;
		this.tenantName = tenantName;
		this.tenantTotalStrength = tenantTotalStrength;
		this.tenantPresentStrength = tenantPresentStrength;
	}

	public long getTenantId() {
		return tenantId;
	}

	public void setTenantId(long tenantId) {
		this.tenantId = tenantId;
	}

	public String getTenantName() {
		return tenantName;
	}

	public void setTenantName(String tenantName) {
		this.tenantName = tenantName;
	}

	public long getTenantTotalStrength() {
		return tenantTotalStrength;
	}

	public void setTenantTotalStrength(long tenantTotalStrength) {
		this.tenantTotalStrength = tenantTotalStrength;
	}

	public long getTenantPresentStrength() {
		return tenantPresentStrength;
	}

	public void setTenantPresentStrength(long tenantPresentStrength) {
		this.tenantPresentStrength = tenantPresentStrength;
	}
	
    
}
