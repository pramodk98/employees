package com.danielwirelesssoftware.firesafety.model;

import java.sql.Timestamp;

public class FireDrillDetail implements Comparable<FireDrillDetail> {

    private long fireDrillId;
    private Timestamp scheduleDateTime;
    private String description;
    private Timestamp startDateTime;
    
    public FireDrillDetail() {
    }
    
    public FireDrillDetail(FireDrillDetail fireDrillDetail) {
		this.fireDrillId = fireDrillDetail.fireDrillId;
		this.scheduleDateTime = fireDrillDetail.scheduleDateTime;
		this.description = fireDrillDetail.description;
		this.startDateTime = fireDrillDetail.startDateTime;
	}
    
	public FireDrillDetail(long fireDrillId, Timestamp scheduleDateTime, String description, Timestamp startDateTime) {
		this.fireDrillId = fireDrillId;
		this.scheduleDateTime = scheduleDateTime;
		this.description = description;
		this.startDateTime = startDateTime;
	}

	public long getFireDrillId() {
		return fireDrillId;
	}

	public void setFireDrillId(long fireDrillId) {
		this.fireDrillId = fireDrillId;
	}

	public Timestamp getScheduleDateTime() {
		return scheduleDateTime;
	}

	public void setScheduleDateTime(Timestamp scheduleDateTime) {
		this.scheduleDateTime = scheduleDateTime;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	 public Timestamp getStartDateTime() {
		return startDateTime;
	}

	public void setStartDateTime(Timestamp startDateTime) {
		this.startDateTime = startDateTime;
	}

	@Override
	public int compareTo(FireDrillDetail o) {
		// sort by start date, if start date is null, sort by schedule date
	    try{
	    	return getStartDateTime().compareTo(o.getStartDateTime());
	    }catch(NullPointerException e){
	    	return getScheduleDateTime().compareTo(o.getScheduleDateTime());
	    }
	}
	 
	 
    
}
