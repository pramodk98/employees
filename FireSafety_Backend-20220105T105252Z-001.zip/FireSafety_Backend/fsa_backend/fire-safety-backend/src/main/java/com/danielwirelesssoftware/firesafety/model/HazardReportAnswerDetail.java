package com.danielwirelesssoftware.firesafety.model;

public class HazardReportAnswerDetail {

    private long hazardReportAnswerId;
    private String answerText;

    public HazardReportAnswerDetail(){
	}
    
	public HazardReportAnswerDetail(long hazardReportAnswerId, String answerText) {
		this.hazardReportAnswerId = hazardReportAnswerId;
		this.answerText = answerText;
	}
	
	public long getHazardReportAnswerId() {
		return hazardReportAnswerId;
	}

	public void setHazardReportAnswerId(long hazardReportAnswerId) {
		this.hazardReportAnswerId = hazardReportAnswerId;
	}

	public String getAnswerText() {
		return answerText;
	}

	public void setAnswerText(String answerText) {
		this.answerText = answerText;
	}

	
    
}