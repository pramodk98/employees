package com.danielwirelesssoftware.firesafety.model.security;

import java.sql.Timestamp;

import javax.persistence.*;

@Entity
@Table(name = "ResetPassword")
public class ResetPassword {
  
    private static final int EXPIRATION = 60 * 24;
  
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long resetPasswordId;
  
    private String token;
  
    @OneToOne(targetEntity = User.class, fetch = FetchType.EAGER)
    @JoinColumn(nullable = false, name = "userId")
    private User user;
  
    private Timestamp expiryDate;
    
    private boolean used;

    public ResetPassword(ResetPassword resetPassword) {
		this.resetPasswordId = resetPassword.resetPasswordId;
		this.token = resetPassword.token;
		this.user = resetPassword.user;
		this.expiryDate = resetPassword.expiryDate;
		this.used = resetPassword.used;
	}
    
    public ResetPassword(String token, User user, Timestamp expiryDate, boolean used) {
		this.token = token;
		this.user = user;
		this.expiryDate = expiryDate;
		this.used = used;
	}
    
	public ResetPassword(Long resetPasswordId, String token, User user, Timestamp expiryDate, boolean used) {
		this.resetPasswordId = resetPasswordId;
		this.token = token;
		this.user = user;
		this.expiryDate = expiryDate;
		this.used = used;
	}

	public Long getResetPasswordId() {
		return resetPasswordId;
	}

	public void setResetPasswordId(Long resetPasswordId) {
		this.resetPasswordId = resetPasswordId;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Timestamp getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(Timestamp expiryDate) {
		this.expiryDate = expiryDate;
	}

	public static int getExpiration() {
		return EXPIRATION;
	}

	public boolean isUsed() {
		return used;
	}

	public void setUsed(boolean used) {
		this.used = used;
	}
	
	
}