package com.danielwirelesssoftware.firesafety.security.controller;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.quartz.JobBuilder;
import org.quartz.JobDataMap;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SimpleScheduleBuilder;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.danielwirelesssoftware.firesafety.common.utils.TimeProvider;
import com.danielwirelesssoftware.firesafety.model.BuildingCertificationDetail;
import com.danielwirelesssoftware.firesafety.model.requestModel.RequestForBuildingCertificationCreate;
import com.danielwirelesssoftware.firesafety.model.requestModel.RequestForCertificationRetrieve;
import com.danielwirelesssoftware.firesafety.model.requestModel.RequestForCertificationDelete;
import com.danielwirelesssoftware.firesafety.model.requestModel.RequestWithBuildingRoleId;
import com.danielwirelesssoftware.firesafety.model.responseModel.ResponseForCertificationRetrieve;
import com.danielwirelesssoftware.firesafety.model.responseModel.ResponseForGeneral;
import com.danielwirelesssoftware.firesafety.model.security.BuildingRole;
import com.danielwirelesssoftware.firesafety.model.security.Certification;
import com.danielwirelesssoftware.firesafety.model.security.User;
import com.danielwirelesssoftware.firesafety.security.JwtUser;
import com.danielwirelesssoftware.firesafety.security.repository.BuildingRoleRepository;
import com.danielwirelesssoftware.firesafety.security.repository.CertificationRepository;
import com.danielwirelesssoftware.firesafety.security.repository.UserRepository;
import com.danielwirelesssoftware.firesafety.security.service.JobBuilderService;
import com.danielwirelesssoftware.firesafety.security.service.ScheduleFireDrillService;

import static com.danielwirelesssoftware.firesafety.common.utils.Constant.DELETE_FALSE;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.DELETE_TRUE;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.SUCCESS;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.transaction.Transactional;

@RestController
public class CertificateRestController {

    private final Log logger = LogFactory.getLog(this.getClass());

    @Autowired
    private BuildingRoleRepository buildingRoleRepository;
    
    @Autowired
    private CertificationRepository certificationRepository;
    
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private TimeProvider timeProvider;

    @Autowired
	private JobBuilderService jobBuilderService;
    
    @Autowired
    private Scheduler scheduler;
    
    @RequestMapping(value = "/createBuildingCertification", method = RequestMethod.POST)
    public ResponseEntity<?> buildingCertificationCreate(@RequestBody RequestForBuildingCertificationCreate request){
    	
    	BuildingRole buildingRole = null;
    	buildingRole = buildingRoleRepository.findByBuildingRoleIdAndDeleted(request.getBuildingRoleId(),DELETE_FALSE);
    	
    	if(buildingRole == null){
    		logger.error("/createBuildingCertification API : no buildingRoleFound: ");
    		return new ResponseEntity<ResponseForGeneral>(new ResponseForGeneral("fail"), HttpStatus.BAD_REQUEST);
    	}
    	
    	if(buildingRole.getBuilding().isDeleted()){
    		logger.error("/createBuildingCertification API : no buildingFound: ");
    		return new ResponseEntity<ResponseForGeneral>(new ResponseForGeneral("fail"), HttpStatus.BAD_REQUEST);
    	}
    	
    	//check access to certificate
    	if(!buildingRole.getRole().getCertificateManagementGroup()){
    		logger.error("/createBuildingCertification API : no authority to create certification ");
    		return new ResponseEntity<ResponseForGeneral>(new ResponseForGeneral("fail"), HttpStatus.BAD_REQUEST);
    	}
    	
    	Certification certificate = null;
    	
    	try{
    		logger.info("/createBuildingCertification API : exp date: "+request.getCertification().getExpiryDate());
    		if(request.getCertification().getCertificateDocument() == null){
    			certificate = certificationRepository.saveAndFlush(new Certification(request.getCertification().getCertificationName(),
						request.getCertification().getDescription(),
				    	request.getCertification().getExpiryDate(),
				    	null,
				    	buildingRole.getBuilding(),
				    	DELETE_FALSE,
				    	buildingRole.getUser(),
				    	buildingRole.getUser(),
				    	null,
				    	null
				    	));
    		}else{
    			certificate = certificationRepository.saveAndFlush(new Certification(request.getCertification().getCertificationName(),
						request.getCertification().getDescription(),
				    	request.getCertification().getExpiryDate(),
				    	null,
				    	buildingRole.getBuilding(),
				    	DELETE_FALSE,
				    	buildingRole.getUser(),
				    	buildingRole.getUser(),
				    	request.getCertification().getCertificateDocument().getDocumentName(),
				    	request.getCertification().getCertificateDocument().getKey()
				    	));
    		}
	    	
	    	
    	}catch(Exception e){
    		logger.error("/createBuildingCertification API : error in create certification: "+e);
    		return new ResponseEntity<ResponseForGeneral>(new ResponseForGeneral("fail"), HttpStatus.BAD_REQUEST);
    	}
        
    	//this is for the scheduling
    	try{
    		//get localTime
    		LocalDate expiryDate = timeProvider.timestampToLocalDate(request.getCertification().getExpiryDate());
        	LocalDate now = LocalDate.now(); 
        	for(int i = 3;i>=0; i--){
        		LocalDate noticeDate = expiryDate.minusMonths(i);
        		//if notice date > now, schedule the closest date.
        		if(noticeDate.compareTo(now) >= 0){
        			JobDetail jobDetail = jobBuilderService.buildJobDetail(certificate);
                    Trigger trigger = jobBuilderService.buildJobTriggerCertification(jobDetail, timeProvider.localDateToDate(noticeDate));
                    scheduler.scheduleJob(jobDetail, trigger);
        			break;
        		}
        	}
    	}catch(Exception e){
    		//send email to system admin
    		logger.error("/createBuildingCertification API : scheduling error : "+e);
    	}
    	
    	
        return new ResponseEntity<ResponseForGeneral>(new ResponseForGeneral(SUCCESS), HttpStatus.OK);
    }
    
    
    @RequestMapping(value = "/retrieveBuildingCertification", method = RequestMethod.POST)
    public ResponseEntity<?> buildingCertificationRetrieve(@RequestBody RequestWithBuildingRoleId request) {
        
    	List<Certification> listOfCertification = new ArrayList<Certification>();
    	BuildingRole buildingRole = null;
    	
    	//check buildingRole exist
    	buildingRole = buildingRoleRepository.findByBuildingRoleIdAndDeleted(request.getBuildingRoleId(),DELETE_FALSE);  	
    	if(buildingRole == null){
    		logger.error("/retrieveBuildingCertification API : buildingRole not found for buildingRoleId "+request.getBuildingRoleId());
    		return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
    	}
    	
    	if(buildingRole.getBuilding().isDeleted()){
    		logger.error("/retrieveBuildingCertification API : building not found: ");
    		return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
    	}
    	
    	if(!buildingRole.getRole().getCertificateViewingGroup()){
    		logger.error("/updateBuildingCertification API : no authority to view certification ");
    		return new ResponseEntity<ResponseForGeneral>(new ResponseForGeneral("fail"), HttpStatus.BAD_REQUEST);
    	}
    	
    	listOfCertification = certificationRepository.findByBuildingAndDeleted(buildingRole.getBuilding(),
    																			DELETE_FALSE);
    	if(listOfCertification.size() == 0){
    		logger.info("/retrieveBuildingCertification API : listOfCertification is empty");
    	}
    	
    	List<BuildingCertificationDetail> list = new ArrayList<BuildingCertificationDetail>();
    	
    	for(Certification c: listOfCertification){
    		list.add(new BuildingCertificationDetail(c));
    	}
    	
    	Collections.sort(list);
    	
    	ResponseForCertificationRetrieve response = new ResponseForCertificationRetrieve(list,
    																					buildingRole.getRole().getCertificateViewingGroup(),
																						buildingRole.getRole().getCertificateManagementGroup());
    	
        return new ResponseEntity<ResponseForCertificationRetrieve>(response, HttpStatus.OK);
        
    }
    

    @Transactional
    @RequestMapping(value = "/updateBuildingCertification", method = RequestMethod.POST)
    public ResponseEntity<?> buildingCertificationUpdate(@RequestBody RequestForBuildingCertificationCreate request) {
        
    	BuildingRole buildingRole = null;
    	buildingRole = buildingRoleRepository.findByBuildingRoleIdAndDeleted(request.getBuildingRoleId(),DELETE_FALSE);
    	
    	if(buildingRole == null){
    		logger.error("/updateBuildingCertification API : no buildingRoleFound: ");
    		return new ResponseEntity<ResponseForGeneral>(new ResponseForGeneral("fail"), HttpStatus.BAD_REQUEST);
    	}
    	
    	if(buildingRole.getBuilding().isDeleted()){
    		logger.error("/updateBuildingCertification API : no buildingFound: ");
    		return new ResponseEntity<ResponseForGeneral>(new ResponseForGeneral("fail"), HttpStatus.BAD_REQUEST);
    	}
    	
    	if(!buildingRole.getRole().getCertificateManagementGroup()){
    		logger.error("/updateBuildingCertification API : no authority to update certification ");
    		return new ResponseEntity<ResponseForGeneral>(new ResponseForGeneral("fail"), HttpStatus.BAD_REQUEST);
    	}
    	
    	Certification oldCert = certificationRepository.findByCertificationIdAndDeleted(request.getCertification().getCertificationId(), DELETE_FALSE);
		
    	if(oldCert == null){
    		logger.error("/updateBuildingCertification API : certificationId not found for : "+request.getCertification().getCertificationId());
    		return new ResponseEntity<ResponseForGeneral>(new ResponseForGeneral("fail"), HttpStatus.BAD_REQUEST);
    	}
    	
    	Certification newCert = null;
    	try{
    		
    		//update the new last expiry date if a new one has been chosen
	    	if(oldCert.getExpiryDate() != request.getCertification().getExpiryDate()){
	    		oldCert.setLastExpiryDate(oldCert.getExpiryDate());
	    	}
	    	
	    	
	    	if(request.getCertification().getCertificateDocument() == null){
	    		newCert = certificationRepository.saveAndFlush(new Certification(request.getCertification().getCertificationName(),
						request.getCertification().getDescription(),
				    	request.getCertification().getExpiryDate(),
				    	null,
				    	buildingRole.getBuilding(),
				    	DELETE_FALSE,
				    	buildingRole.getUser(),
				    	buildingRole.getUser(),
				    	null,
				    	null,
				    	oldCert.getCertificationId()
				    	));
    		}else{
    			newCert = certificationRepository.saveAndFlush(new Certification(request.getCertification().getCertificationName(),
						request.getCertification().getDescription(),
				    	request.getCertification().getExpiryDate(),
				    	null,
				    	buildingRole.getBuilding(),
				    	DELETE_FALSE,
				    	buildingRole.getUser(),
				    	buildingRole.getUser(),
				    	request.getCertification().getCertificateDocument().getDocumentName(),
				    	request.getCertification().getCertificateDocument().getKey(),
				    	oldCert.getCertificationId()
				    	));
    		}
	    	//save first then delete
	    	certificationRepository.save(newCert);
	    	certificationRepository.setDeletedByCertificationId(DELETE_TRUE, oldCert.getCertificationId());

	    	
    	}catch(Exception e){
    		logger.error("/updateBuildingCertification API : error in update certification: "+e);
    		return new ResponseEntity<ResponseForGeneral>(new ResponseForGeneral("fail"), HttpStatus.BAD_REQUEST);
    	}
    	
    	//this is for the scheduling
    	try{
    		//get localTime
    		LocalDate expiryDate = timeProvider.timestampToLocalDate(request.getCertification().getExpiryDate());
        	LocalDate now = LocalDate.now(); 
        	for(int i = 3;i>=0; i--){
        		LocalDate noticeDate = expiryDate.minusMonths(i);
        		//if notice date > now, schedule the closest date.
        		if(noticeDate.compareTo(now) >= 0){
        			JobDetail jobDetail = jobBuilderService.buildJobDetail(newCert);
                    Trigger trigger = jobBuilderService.buildJobTriggerCertification(jobDetail, timeProvider.localDateToDate(noticeDate));
                    scheduler.scheduleJob(jobDetail, trigger);
        			break;
        		}
        	}
    	}catch(Exception e){
    		//send email to system admin
    		logger.error("/updateBuildingCertification API : scheduling error : "+e);
    	}
    	
    	
    	
        return new ResponseEntity<ResponseForGeneral>(new ResponseForGeneral(SUCCESS), HttpStatus.OK);
        
    }
    
    @Transactional
    @RequestMapping(value = "/deleteBuildingCertification", method = RequestMethod.POST)
    public ResponseEntity<?> buildingCertificationDelete(@RequestBody RequestForCertificationDelete request) {
    	
    	logger.debug("request.getCertificationList(): "+request.getListOfCertificationId());
    	
    	for(Long certificationId : request.getListOfCertificationId()){

        	Certification cert = null;
        	cert = certificationRepository.findByCertificationIdAndDeleted(certificationId, DELETE_FALSE);
        	
        	if(cert == null){
        		logger.error("/deleteBuildingCertification API : no cert found for certificationId: "+certificationId);
        		continue;
        	}
        	
        	BuildingRole buildingRole = null;
        	buildingRole = buildingRoleRepository.findByBuildingRoleIdAndDeleted(request.getBuildingRoleId(),DELETE_FALSE);
        	
        	if(buildingRole == null){
        		logger.error("/deleteBuildingCertification API : no buildingRoleFound: ");
        		return new ResponseEntity<ResponseForGeneral>(new ResponseForGeneral("fail"), HttpStatus.BAD_REQUEST);
        	}
        	
        	if(buildingRole.getBuilding().isDeleted()){
        		logger.error("/deleteBuildingCertification API : no buildingFound: ");
        		return new ResponseEntity<ResponseForGeneral>(new ResponseForGeneral("fail"), HttpStatus.BAD_REQUEST);
        	}
        	
        	if(!buildingRole.getRole().getCertificateManagementGroup()){
        		logger.error("/deleteBuildingCertification API : no authority to delete certification ");
        		return new ResponseEntity<ResponseForGeneral>(new ResponseForGeneral("fail"), HttpStatus.BAD_REQUEST);
        	}
        	
        	if(buildingRole.getBuilding().getBuildingId() != cert.getBuilding().getBuildingId()) {
        		logger.error("/deleteBuildingCertification API : building mismatch. buildingRole building name:"
        						+buildingRole.getBuilding().getName()+ ", cert building:"
        						+cert.getBuilding().getName());
        		continue;
        	}
        	
        	try{
    	    	cert.setDeleted(DELETE_TRUE);
    	    	cert.setEditedBy(buildingRole.getUser());
    	    	certificationRepository.save(cert);
    	    	
        	}catch(Exception e){
        		logger.error("/deleteBuildingCertification API : error in delete certification: "+e);
        		return new ResponseEntity<ResponseForGeneral>(new ResponseForGeneral("fail"), HttpStatus.BAD_REQUEST);
        	}
    	}
    	
        return new ResponseEntity<ResponseForGeneral>(new ResponseForGeneral(SUCCESS), HttpStatus.OK);
    }
    
    
  

}