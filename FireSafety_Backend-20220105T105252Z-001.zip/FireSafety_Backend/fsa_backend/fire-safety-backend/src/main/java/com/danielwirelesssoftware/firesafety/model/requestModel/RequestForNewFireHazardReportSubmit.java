package com.danielwirelesssoftware.firesafety.model.requestModel;

import java.sql.Timestamp;
import java.util.List;

import com.danielwirelesssoftware.firesafety.model.SectionAnswerHazardReportDetail;

public class RequestForNewFireHazardReportSubmit {
	
	private long buildingRoleId;
	private Timestamp reportTime;
	private String hazardReportName;
	private List<SectionAnswerHazardReportDetail> listOfSectionAnswerHazardReport;
	
	public RequestForNewFireHazardReportSubmit(){
	}

	
	public RequestForNewFireHazardReportSubmit(long buildingRoleId, Timestamp reportTime, String hazardReportName,
			List<SectionAnswerHazardReportDetail> listOfSectionAnswerHazardReport) {
		this.buildingRoleId = buildingRoleId;
		this.reportTime = reportTime;
		this.hazardReportName = hazardReportName;
		this.listOfSectionAnswerHazardReport = listOfSectionAnswerHazardReport;
	}

	public long getBuildingRoleId() {
		return buildingRoleId;
	}

	public void setBuildingRoleId(long buildingRoleId) {
		this.buildingRoleId = buildingRoleId;
	}

	public Timestamp getReportTime() {
		return reportTime;
	}

	public void setReportTime(Timestamp reportTime) {
		this.reportTime = reportTime;
	}

	public String getHazardReportName() {
		return hazardReportName;
	}

	public void setHazardReportName(String hazardReportName) {
		this.hazardReportName = hazardReportName;
	}

	public List<SectionAnswerHazardReportDetail> getListOfSectionAnswerHazardReport() {
		return listOfSectionAnswerHazardReport;
	}

	public void setListOfSectionAnswerHazardReport(List<SectionAnswerHazardReportDetail> listOfSectionAnswerHazardReport) {
		this.listOfSectionAnswerHazardReport = listOfSectionAnswerHazardReport;
	}
	
		
}
