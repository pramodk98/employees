package com.danielwirelesssoftware.firesafety.security.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.danielwirelesssoftware.firesafety.model.security.TenantEmployee;
import com.danielwirelesssoftware.firesafety.model.security.User;

@Repository
@Transactional
public interface UserRepository extends JpaRepository<User, Long> {
	
	User findByUserIdAndDeleted(Long userId, boolean deleted);
	
	User findByUsername(String username);
	
	User findByUsernameAndDeleted(String username, boolean deleted);
	
	User findByEmailAndDeleted(String email, boolean deleted);
	
	User findByEmail(String email);
	
	User findByTenantEmployee(TenantEmployee tenantEmployee);
	
	@Modifying
	@Transactional
	@Query(value = "update User u set u.displayName = ?1, u.email = ?2, u.phoneNumber = ?3, u.profileImage = ?4 where u.userId = ?5", nativeQuery = true)
	int setFixedDisplayNameAndEmailAndContactNoAndProfileImageFor(String name, String email, String contactNo, String profileImage, long userId);
	
	@Modifying
	@Transactional
	@Query(value = "update User u set u.pushNotificationToken = null where u.pushNotificationToken = ?1", nativeQuery = true)
	int setPushNotificationTokenFor(String pushNotificationToken);
	
	@Modifying
	@Transactional
	@Query(value = "update User u set u.notification = ?1 where u.userId = ?2", nativeQuery = true)
	int setFixedNotificationFor(boolean notification, long userId);
	
	@Modifying
	@Transactional
	@Query(value = "update User u set u.notification = ?1, u.pushNotificationToken = ?2 where u.userId = ?3", nativeQuery = true)
	int setFixedNotificationAndPushNotificationTokenFor(boolean notification, String pushNotificationToken, long userId);
	
	@Modifying
	@Transactional
	@Query(value = "update User u set u.pushNotificationToken = ?1 where u.username = ?2", nativeQuery = true)
	int setPushNotificationTokenFor(String pushNotificationToken, String username);
	
	@Modifying
	@Transactional
	@Query(value = "update User u set u.password = ?1 where u.username = ?2", nativeQuery = true)
	int setPasswordFor(String password, String username);
}
