
package com.danielwirelesssoftware.firesafety.model.security;

import javax.persistence.*;

@Entity
@Table(name = "MessageImage")
public class MessageImage {
    
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "messageImageId")
    private long messageImageId;

	// removed the unnecessary cascade after ManyToOne below, as it was causing an exception, see https://stackoverflow.com/questions/24721688/org-hibernate-persistentobjectexception-detached-entity-passed-to-persist-whe
	// see also https://stackoverflow.com/questions/27672337/detached-entity-passed-to-persist-when-save-the-child-data for solution ideas
	// I think it is unnecessary because we don't have a reference back from Message to MessageImage, so no need to update Message if MessageImage is deleted, updated, etc.
    @ManyToOne
    @JoinColumn(name = "messageId")
    private Message message;
    
    @Column(name = "documentName")
    private String documentName;
    
    @Column(name = "documentKey")
    private String documentKey;

    public MessageImage(){
	
    }

    public MessageImage(Message message,
			String documentName, String documentKey) {
		this.message = message;
		this.documentName = documentName;
		this.documentKey = documentKey;
	}
    
    public MessageImage(long messageImageId, Message message,
			String documentName, String documentKey) {
    	this.messageImageId = messageImageId;
		this.message = message;
		this.documentName = documentName;
		this.documentKey = documentKey;
	}

	public long getMessageImageId() {
		return messageImageId;
	}

	public void setMessageImageId(long messageImageId) {
		this.messageImageId = messageImageId;
	}

	public Message getMessage() {
		return message;
	}

	public void setMessage(Message message) {
		this.message = message;
	}

	public String getDocumentName() {
		return documentName;
	}

	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}

	public String getDocumentKey() {
		return documentKey;
	}

	public void setDocumentKey(String documentKey) {
		this.documentKey = documentKey;
	}

	
    
}