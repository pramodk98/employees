
package com.danielwirelesssoftware.firesafety.model.requestModel;

public class RequestForFireDrillCreate {

	private String description;
	private long buildingRoleId;
	private long fireDrillTypeId;
	private long fireDrillId;
	private long scheduleDateTime;
	private long startDateTime;
	private long completeDateTime;
	
	public RequestForFireDrillCreate() {
	}
	
	public RequestForFireDrillCreate(RequestForFireDrillCreate requestForFireDrillCreate) {
		this.description = requestForFireDrillCreate.description;
		this.buildingRoleId =requestForFireDrillCreate.buildingRoleId;
		this.fireDrillTypeId = requestForFireDrillCreate.fireDrillTypeId;
		this.fireDrillId = requestForFireDrillCreate.fireDrillId;
		this.scheduleDateTime = requestForFireDrillCreate.scheduleDateTime;
		this.startDateTime = requestForFireDrillCreate.startDateTime;
		this.completeDateTime = requestForFireDrillCreate.completeDateTime;
	}
	
	public RequestForFireDrillCreate( String description, long buildingRoleId, long fireDrillTypeId,
			long fireDrillId, long scheduleDateTime, long startDateTime, long completeDateTime) {
		this.description = description;
		this.buildingRoleId = buildingRoleId;
		this.fireDrillTypeId = fireDrillTypeId;
		this.fireDrillId = fireDrillId;
		this.scheduleDateTime = scheduleDateTime;
		this.startDateTime = startDateTime;
		this.completeDateTime = completeDateTime;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public long getBuildingRoleId() {
		return buildingRoleId;
	}

	public void setBuildingRoleId(long buildingRoleId) {
		this.buildingRoleId = buildingRoleId;
	}

	public long getFireDrillTypeId() {
		return fireDrillTypeId;
	}

	public void setFireDrillTypeId(long fireDrillTypeId) {
		this.fireDrillTypeId = fireDrillTypeId;
	}

	public long getFireDrillId() {
		return fireDrillId;
	}

	public void setFireDrillId(long fireDrillId) {
		this.fireDrillId = fireDrillId;
	}

	public long getScheduleDateTime() {
		return scheduleDateTime;
	}

	public void setScheduleDateTime(long scheduleDateTime) {
		this.scheduleDateTime = scheduleDateTime;
	}

	public long getStartDateTime() {
		return startDateTime;
	}

	public void setStartDateTime(long startDateTime) {
		this.startDateTime = startDateTime;
	}

	public long getCompleteDateTime() {
		return completeDateTime;
	}

	public void setCompleteDateTime(long completeDateTime) {
		this.completeDateTime = completeDateTime;
	}
	
	
}
