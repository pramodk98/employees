package com.danielwirelesssoftware.firesafety.model;

import java.util.List;

public class FireDrillWardenAttendanceDetail {

    private long tenantId;    
    private String tenantName;    
    private List<TenantEmployeeDetail> tenantEmployee;
    
    public FireDrillWardenAttendanceDetail() {
    }

	public FireDrillWardenAttendanceDetail(long tenantId, String tenantName, List<TenantEmployeeDetail> tenantEmployee) {
		this.tenantId = tenantId;
		this.tenantName = tenantName;
		this.tenantEmployee = tenantEmployee;
	}

	public long getTenantId() {
		return tenantId;
	}

	public void setTenantId(long tenantId) {
		this.tenantId = tenantId;
	}

	public String getTenantName() {
		return tenantName;
	}

	public void setTenantName(String tenantName) {
		this.tenantName = tenantName;
	}

	public List<TenantEmployeeDetail> getTenantEmployee() {
		return tenantEmployee;
	}

	public void setTenantEmployee(List<TenantEmployeeDetail> tenantEmployee) {
		this.tenantEmployee = tenantEmployee;
	}

	
	

    
}
