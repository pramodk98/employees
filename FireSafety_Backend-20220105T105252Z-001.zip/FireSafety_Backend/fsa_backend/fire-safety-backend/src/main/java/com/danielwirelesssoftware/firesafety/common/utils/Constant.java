package com.danielwirelesssoftware.firesafety.common.utils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class Constant{
	
	 public final static ArrayList<String> LEVELS = new ArrayList<>(Arrays.asList("P15", "B15", "BASEMENT15", 
			 																		"P14.5", "B14.5", "BASEMENT14.5", 
																					"P14", "B14", "BASEMENT14", 
																					"P13.5", "B13.5", "BASEMENT13.5", 
																					"P13", "B13", "BASEMENT13",
																					"P12.5", "B12.5", "BASEMENT12.5", 
																					"P12", "B12", "BASEMENT12",
																					"P11.5", "B11.5", "BASEMENT11.5", 
																					"P11", "B11", "BASEMENT11",
																					"P10.5", "B10.5", "BASEMENT10.5", 
																					"P10", "B10", "BASEMENT10",
																					"P9.5", "B9.5", "BASEMENT9.5", 
																					"P9", "B9", "BASEMENT9",
																					"P8.5", "B8.5", "BASEMENT8.5", 
																					"P8", "B8", "BASEMENT8",
																					"P7.5", "B7.5", "BASEMENT7.5", 
																					"P7", "B7", "BASEMENT7", 
																					"P6.5", "B6.5", "BASEMENT6.5", 
																					"P6", "B6", "BASEMENT6", 
																					"P5.5", "B5.5", "BASEMENT5.5", 
																					"P5", "B5", "BASEMENT5", 
																					"P4.5", "B4.5", "BASEMENT4.5", 
																					"P4", "B4", "BASEMENT4", 
																					"P3.5", "B3.5", "BASEMENT3.5", 
			 																		"P3", "B3", "BASEMENT3", 
			 																		"P2.5", "B2.5", "BASEMENT2.5", 
			 																		"P2", "B2", "BASEMENT2", 
			 																		"P1.5", "B1.5", "BASEMENT1.5", 
			 																		"P1", "B1", "BASEMENT1",  
			 																		"P", "B", "BASEMENT",
			 																		"LG10", "LOWERGROUND10",
			 																		"LG9.5", "LOWERGROUND9.5",
			 																		"LG9", "LOWERGROUND9",
			 																		"LG8.5", "LOWERGROUND8.5",
			 																		"LG8", "LOWERGROUND8",
			 																		"LG7.5", "LOWERGROUND7.5",
			 																		"LG7", "LOWERGROUND7",
			 																		"LG6.5", "LOWERGROUND6.5",
			 																		"LG6", "LOWERGROUND6",
			 																		"LG5.5", "LOWERGROUND5.5",
			 																		"LG5", "LOWERGROUND5",
			 																		"LG4.5", "LOWERGROUND4.5",
			 																		"LG4", "LOWERGROUND4",
			 																		"LG3.5", "LOWERGROUND3.5",
			 																		"LG3", "LOWERGROUND3",
			 																		"LG2.5", "LOWERGROUND2.5",
			 																		"LG2", "LOWERGROUND2",
			 																		"LG1.5", "LOWERGROUND1.5",
			 																		"LG1", "LOWERGROUND1",
			 																		"LG", "LOWERGROUND", 
			 																		"G", "GROUND", 
			 																		"1" , "2", "3", 
			 																		"4", "5", "6", 
			 																		"7", "8", "9", 
			 																		"10", "11", "12", 
			 																		"13", "14", "15", 
			 																		"16", "17", "18", 
			 																		"19", "20", "21", 
			 																		"22", "23", "24", 
			 																		"25", "26", "27", 
			 																		"28", "29", "30", 
			 																		"31", "32", "33", 
			 																		"34", "35", "36", 
			 																		"37", "38", "39", 
			 																		"40", "41", "42", 
			 																		"43", "44", "45", 
			 																		"46", "47", "48", 
			 																		"49", "50", "51", 
			 																		"52", "53", "54", 
			 																		"55", "56", "57", 
			 																		"58", "59", "60", 
			 																		"61", "62", "63", 
			 																		"64", "65", "66", 
			 																		"67", "68", "69",
			 																		"70", "71", "72", 
			 																		"73", "74", "75", 
			 																		"76", "77", "78", 
			 																		"79", "80", "81", 
			 																		"82", "83", "84", 
			 																		"85", "86", "87", 
			 																		"88", "89", "90", 
			 																		"91", "92", "93", 
			 																		"94", "95", "96", 
			 																		"97", "98", "99",
			 																		"100", "101", "102", 
			 																		"103", "104", "105", 
			 																		"106", "107", "108", 
			 																		"109", "110"));
	
	public final static String SUCCESS = "success";
	
    public final static String STATUS_ABSENT = "absent";
    public final static String STATUS_PRESENT = "present";
    public final static String STATUS_NOT_PARTICIPATING = "not participating";
    public final static String STATUS_OPEN = "open";
    public final static String STATUS_CLOSE = "close";
    public final static String STATUS_PENDING = "pending";
    public final static String STATUS_COMPLETE = "complete";
    public final static boolean STATUS_TRUE = true;
    public final static boolean STATUS_FALSE = false;
    
    public final static String ROLE_FIRE_WARDEN = "Fire Warden";
    public final static String ROLE_FIRE_SAFETY_MANAGER ="Fire Safety Manager";
    public final static String ROLE_BUILDING_MANAGER = "Building Manager";
    public final static String ROLE_ACCOUNT_MANAGER = "Account Manager";
    public final static String ROLE_ACCOUNT_DIRECTOR = "Account Director";
    
    public final static Long ROLEID_FIRE_SAFETY_MANAGER =1L;
    public final static Long ROLEID_FIRE_WARDEN = 2L;
    
    public final static boolean DELETE_FALSE = false;
    public final static boolean DELETE_TRUE = true;
    
    public final static int ACTION_FIREDRILL_SCHEDULED = 1;
    public final static int ACTION_FIREDRILL_START = 2;
    public final static int ACTION_FIREDRILL_END = 3;
    public final static int ACTION_ESCALATION_START = 4;
    public final static int ACTION_HAZARD_REPORT = 5;
    public final static int ACTION_HAZARD_REPORT_COMPLETE = 6;
    public final static int ACTION_MESSAGE = 7;
    public final static int ACTION_UPDATE_ESCALATION = 8;
    public final static int ACTION_UPDATE_FIRE_DRILL = 9;
    public final static int ACTION_FIREDRILL_DELETE = 10;
    public final static int ACTION_FIREDRILL_PRESTART = 11;
    public final static int ACTION_CERTIFICATION_EXPIRING = 13;
    public final static int  ACTION_CERTIFICATION_EXPIRED = 14;

    public final static long FIREDRILL_TYPEID_DRY_RUN = 1;
    public final static long FIREDRILL_TYPEID_FIREDRILL = 2;
    public final static long FIREDRILL_TYPEID_REAL_FIRE = 3;
    
    public final static long MESSAGE_TYPE_FIREDRILL_SCHEDULE = 1;
    public final static long MESSAGE_TYPE_FIREDRILL_DRY_RUN = 2;
    public final static long MESSAGE_TYPE_FIRE_ACTIVATION = 3;
    public final static long MESSAGE_TYPE_ESCALATION = 4;
    public final static long MESSAGE_TYPE_HAZARD_REPORT = 5;
    public final static long MESSAGE_TYPE_HAZARD_REPORT_COMPLETE = 6;
    public final static long MESSAGE_TYPE_FIREDRILL_UPDATE = 9;
    public final static long MESSAGE_TYPE_FIREDRILL_DELETE = 10;
    public final static long MESSAGE_TYPE_FIREDRILL_END = 11;
    public final static long MESSAGE_TYPE_FIREDRILL_PRESTART = 12;
    public final static long MESSAGE_TYPE_CERTIFICATE_EXPIRING = 13;
    public final static long MESSAGE_TYPE_CERTIFICATE_EXPIRED = 14;
    
    public final static String MESSAGE_TITLE_FIREDRILL_SCHEDULE = "Fire Drill Schedule";
    public final static String MESSAGE_TITLE_FIREDRILL_DRY_RUN = "Fire Drill";
    public final static String MESSAGE_TITLE_FIRE_ACTIVATION = " Fire Activation";
    public final static String MESSAGE_TITLE_ESCALATION = "Escalation";
    public final static String MESSAGE_TITLE_HAZARD_REPORT = "Hazard Report";
    public final static String MESSAGE_TITLE_HAZARD_REPORT_COMPLETE = "Hazard Report";
    public final static String MESSAGE_TITLE_FIREDRILL_PRESTART = "Fire Drill Schedule Starting Soon ";
    public final static String MESSAGE_TITLE_CERTIFICATE_EXPIRING = "Certificate Reminder";
    public final static String MESSAGE_TITLE_CERTIFICATE_EXPIRED = "Certificate Reminder";
    
    public final static String MESSAGE_DETAIL_FIREDRILL_SCHEDULE = "There will be a scheduled fire drill on ";
    public final static String MESSAGE_DETAIL_FIREDRILL_DRY_RUN = "You have been activated for dry run fire drill. Report to location below";
    public final static String MESSAGE_DETAIL_FIRE_ACTIVATION = "You have been activated due to a real fire occuring right now. Report to location below";
    public final static String MESSAGE_DETAIL_ESCALATION = "You have been activated for escalation. Report to location below";
    public final static String MESSAGE_DETAIL_FIREDRILL_DELETE_1 = "Fire drill scheduled on ";
    public final static String MESSAGE_DETAIL_FIREDRILL_DELETE_2 = " has been cancelled.";
    public final static String MESSAGE_DETAIL_FIREDRILL_PRESTART = "A scheduled fire drill will be starting soon at ";
    
    public final static String MESSAGE_DETAIL_HAZARD_REPORT_1 = "A new hazard report <";
    public final static String MESSAGE_DETAIL_HAZARD_REPORT_2 = "> is created by user: ";
    public final static String MESSAGE_DETAIL_HAZARD_REPORT_COMPLETE_1 = "Hazard report <";
    public final static String MESSAGE_DETAIL_HAZARD_REPORT_COMPLETE_2 = "> has been completed by user: ";
    public final static String MESSAGE_DEFAULT = "You have a new Message";
    
    public final static String MESSAGE_DETAIL_CERTIFICATE_EXPIRING_1 = "Certificate '";
    public final static String MESSAGE_DETAIL_CERTIFICATE_EXPIRING_2 = "' for ";
    public final static String MESSAGE_DETAIL_CERTIFICATE_EXPIRING_3 = " will be expiring at ";
    public final static String MESSAGE_DETAIL_CERTIFICATE_EXPIRING_4 = ", please update the certificate soon";
    public final static String MESSAGE_DETAIL_CERTIFICATE_EXPIRED_1 = "Certificate <";
    public final static String MESSAGE_DETAIL_CERTIFICATE_EXPIRED_2 = "> for building <";
    public final static String MESSAGE_DETAIL_CERTIFICATE_EXPIRED_3  = " is expired today, please update the certificate soon";
    
	public final static String EMAIL = "dws19559@gmail.com";
	public final static String EMAIL_NAME = "dev testing DWS";
	public final static String EMAIL_CONFIG = "ConfigSet";
	public final static String SMTP_USER = "AKIAWOYYUEQPP7ZKL7XG";
	public final static String SMTP_PASS = "BD/q8HW3CAiVRHineJdH9jICLWFUL4q+yRdvp0AKIK/O";
	public final static int PORT_NUM = 587;
	public final static String HOST_NAME = "email-smtp.us-west-2.amazonaws.com";
}
