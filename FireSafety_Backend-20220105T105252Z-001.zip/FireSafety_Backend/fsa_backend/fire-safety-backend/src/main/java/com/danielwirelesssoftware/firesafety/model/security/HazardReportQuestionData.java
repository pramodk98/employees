package com.danielwirelesssoftware.firesafety.model.security;

import javax.persistence.*;

@Entity
@Table(name = "HazardReportQuestionData")
public class HazardReportQuestionData {
    
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "hazardQuestionDataId")
    private long hazardQuestionDataId;

    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "questionId")
    private HazardReportQuestion question;
    
    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "answerId")
    private HazardReportAnswer answer;
    
    @Column(name = "observationText")
    private String observationText;
    
    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "hazardSectionId")
    private HazardReportSectionData dataHazardReport;

    public HazardReportQuestionData(){
	}
    
    public HazardReportQuestionData(HazardReportQuestion question, HazardReportAnswer answer,
    								String observationText, HazardReportSectionData dataHazardReport) {
		this.question = question;
		this.answer = answer;
		this.observationText = observationText;
		this.dataHazardReport = dataHazardReport;
	}
    
	public HazardReportQuestionData(long hazardQuestionDataId, HazardReportQuestion question, HazardReportAnswer answer,
									String observationText, HazardReportSectionData dataHazardReport) {
		this.hazardQuestionDataId = hazardQuestionDataId;
		this.question = question;
		this.answer = answer;
		this.observationText = observationText;
		this.dataHazardReport = dataHazardReport;
	}

	public long getHazardQuestionDataId() {
		return hazardQuestionDataId;
	}

	public void setHazardQuestionDataId(long hazardQuestionDataId) {
		this.hazardQuestionDataId = hazardQuestionDataId;
	}

	public HazardReportQuestion getQuestion() {
		return question;
	}

	public void setQuestion(HazardReportQuestion question) {
		this.question = question;
	}

	public HazardReportAnswer getAnswer() {
		return answer;
	}

	public void setAnswerId(HazardReportAnswer answer) {
		this.answer = answer;
	}

	public String getObservationText() {
		return observationText;
	}

	public void setObservationText(String observationText) {
		this.observationText = observationText;
	}

	public HazardReportSectionData getDataHazardReport() {
		return dataHazardReport;
	}

	public void setDataHazardReport(HazardReportSectionData dataHazardReport) {
		this.dataHazardReport = dataHazardReport;
	}

	
	
    
}