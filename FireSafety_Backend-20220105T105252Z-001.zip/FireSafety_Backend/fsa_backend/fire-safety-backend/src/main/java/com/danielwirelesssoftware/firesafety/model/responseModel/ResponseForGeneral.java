package com.danielwirelesssoftware.firesafety.model.responseModel;

public class ResponseForGeneral {
	
	private String response;
	
	public ResponseForGeneral() {
	}
	
	public ResponseForGeneral(String response) {
		this.response = response;
	}

	public String getResponse() {
		return response;
	}

	public void setResponse(String response) {
		this.response = response;
	}
	
}

