package com.danielwirelesssoftware.firesafety.security.controller;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mobile.device.Device;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.danielwirelesssoftware.firesafety.model.AttachDocument;
import com.danielwirelesssoftware.firesafety.model.EmergencyResponsePlanDetail;
import com.danielwirelesssoftware.firesafety.model.security.Building;
import com.danielwirelesssoftware.firesafety.model.requestModel.RequestForERPUpdate;
import com.danielwirelesssoftware.firesafety.model.requestModel.RequestWithBuildingRoleId;
import com.danielwirelesssoftware.firesafety.model.responseModel.ResponseForERP;
import com.danielwirelesssoftware.firesafety.model.security.BuildingRole;
import com.danielwirelesssoftware.firesafety.model.security.ERP;
import com.danielwirelesssoftware.firesafety.model.security.User;
import com.danielwirelesssoftware.firesafety.security.JwtUser;
import com.danielwirelesssoftware.firesafety.security.repository.BuildingRepository;
import com.danielwirelesssoftware.firesafety.security.repository.BuildingRoleRepository;
import com.danielwirelesssoftware.firesafety.security.repository.ERPRepository;
import com.danielwirelesssoftware.firesafety.security.repository.UserRepository;

import static com.danielwirelesssoftware.firesafety.common.utils.Constant.DELETE_FALSE;

import java.util.ArrayList;
import java.util.List;


@RestController
public class ResponsePlanRestController {

    private final Log logger = LogFactory.getLog(ResponsePlanRestController.class);
    
    @Autowired
    private BuildingRoleRepository buildingRoleRepository;
    
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private ERPRepository erpRepository;
    
    @Autowired
    private BuildingRepository buildingRepository;
  
    @RequestMapping(value = "/accessEmergencyResponsePlan", method = RequestMethod.POST)
    public ResponseEntity<?> emergencyResponsePlanAccess(@RequestBody RequestWithBuildingRoleId request, Device device){
    	
    	BuildingRole buildingRole;
    	
    	try{
    		buildingRole = buildingRoleRepository.findByBuildingRoleIdAndDeleted(request.getBuildingRoleId(),DELETE_FALSE);  	
    	}catch(Exception e){
    		logger.error("/updateEmergencyResponsePlan API : buildingRole not found for buildingRoleId "+request.getBuildingRoleId());
    		return new ResponseEntity<>("buildingRole not found",HttpStatus.BAD_REQUEST);
    	}     	
    	
    	if(buildingRole.getBuilding().isDeleted()){
    		logger.error("/updateEmergencyResponsePlan API : building is deleted for buildingId "+buildingRole.getBuilding().getBuildingId());
    		return new ResponseEntity<>("building not found",HttpStatus.BAD_REQUEST);
    	}
    	
    	long buildingId = buildingRole.getBuilding().getBuildingId();
    	
    	List<ERP> erpList = buildingRole.getBuilding().getErpList();    	
    	List<EmergencyResponsePlanDetail> emergencyResponsePlanDetailList = new ArrayList<EmergencyResponsePlanDetail>();
    	
    	logger.info("erpList: "+erpList.toString()+", size: "+erpList.size());  	
    	
    	for(ERP e:erpList){ 
    		if(!e.isDeleted()){
    			logger.info("//adding erpId: +" + e.getErpId() + " into list");
    			EmergencyResponsePlanDetail erp = new EmergencyResponsePlanDetail(e.getErpId(),
															    					new AttachDocument(
																							e.getDocumentName(),
																							e.getDocumentKey()));
    			emergencyResponsePlanDetailList.add(erp);
    		}    		
    	}
    	
    	 ResponseForERP response = new ResponseForERP(buildingId, buildingRole.getRole().getDocumentManagementGroup(), emergencyResponsePlanDetailList);
    	
        
        return new ResponseEntity<ResponseForERP>(response, HttpStatus.OK);
    }
    
    @RequestMapping(value = "/updateEmergencyResponsePlan", method = RequestMethod.POST)
    public ResponseEntity<?> emergencyResponsePlanUpdate(@RequestBody RequestForERPUpdate request, @AuthenticationPrincipal final JwtUser principle, Device device){
    	
    	Building building = null;
    	BuildingRole buildingRole = null;
    	
    	building = buildingRepository.findByBuildingIdAndDeleted(request.getBuildingId(),DELETE_FALSE);  	
    	if(building == null){
    		logger.error("/updateEmergencyResponsePlan API : building not found for buildingId "+request.getBuildingId());
    		return new ResponseEntity<>("building not found",HttpStatus.BAD_REQUEST);
    	}
    	
    	User user = userRepository.findByUserIdAndDeleted(principle.getUserId(),DELETE_FALSE);
    	logger.info("//userID:"+principle.getUserId());
    	
    	buildingRole = buildingRoleRepository.findByBuildingUserAndBuilding(user,building);
    	
    	if(buildingRole == null){
    		logger.error("/updateEmergencyResponsePlan : buildingRole not found for userId: "
    						+user.getUserId() +", buildingId: "+building.getBuildingId());
    		return new ResponseEntity<>("buildingRole not found",HttpStatus.BAD_REQUEST);
    	}
    	
    	//update emergency data, if title/file is null, set delete true, else create 
    	for(EmergencyResponsePlanDetail erpd:request.getEmergencyResponsePlanList()){
    		if(erpd.getAttachDocument().getDocumentName() == null 
    			|| erpd.getAttachDocument().getKey() == null
    			|| erpd.getAttachDocument().getDocumentName().isEmpty() 
    			|| erpd.getAttachDocument().getKey().isEmpty()){
    			try{
    				logger.info("/updateEmergencyResponsePlan API : updating (d) EmergencyPlanId: "+erpd.getEmergencyPlanId());
    				erpRepository.setFixedDeletedFor(true, erpd.getEmergencyPlanId()); 
    			}catch(Exception e){
    				logger.error("/updateEmergencyResponsePlan API : error updating: "+e);
    				return new ResponseEntity<String>("data error", HttpStatus.BAD_REQUEST);
    			}
    		}else{    			
    			ERP erp = new ERP(erpd.getAttachDocument().getDocumentName(), building, erpd.getAttachDocument().getKey(), false);
    			erpRepository.saveAndFlush(erp);
    			logger.info("/updateEmergencyResponsePlan API : updating (a) EmergencyPlanId: "+erpd.getEmergencyPlanId());
    		}
    	}
    	
    	//get return data
    	
    	//get all building level 
    	List<ERP> erpList = new ArrayList<ERP>();
    	
    	try{
    		erpList = building.getErpList();
		}catch(Exception e){
			logger.error("/updateEmergencyResponsePlan API : error in getting erpList: "+request.getBuildingId() +", error: "+e);
		}
    	
    	List<EmergencyResponsePlanDetail> emergencyResponsePlanDetailList = new ArrayList<EmergencyResponsePlanDetail>();
    	
    	//loop and check if its deleted, and add into list
    	for(ERP e:erpList){ 
    		if(!e.isDeleted()){
    			EmergencyResponsePlanDetail erp = new EmergencyResponsePlanDetail(e.getErpId(),
    																				new AttachDocument(
    																						e.getDocumentName(),
    																						e.getDocumentKey()));
    			emergencyResponsePlanDetailList.add(erp);
    		}    		
    	}
    	
        //set response
    	ResponseForERP response = new ResponseForERP(request.getBuildingId(),buildingRole.getRole().getDocumentManagementGroup(), emergencyResponsePlanDetailList);
        
        return new ResponseEntity<ResponseForERP>(response, HttpStatus.OK);
    }
    

 
    

}