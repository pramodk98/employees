package com.danielwirelesssoftware.firesafety.model.requestModel;

import java.sql.Timestamp;
import java.util.List;

public class RequestForStartEscalation {
	
	private long dateTime;
	private long buildingRoleId;
	private List<RequestWithBuildingRoleId> escalationAttendanceList;
	
	public RequestForStartEscalation() {
	}

	public RequestForStartEscalation(long dateTime, long buildingRoleId,
			List<RequestWithBuildingRoleId> escalationAttendanceList) {
		this.dateTime = dateTime;
		this.buildingRoleId = buildingRoleId;
		this.escalationAttendanceList = escalationAttendanceList;
	}

	public long getDateTime() {
		return dateTime;
	}

	public void setDateTime(long dateTime) {
		this.dateTime = dateTime;
	}

	public Long getBuildingRoleId() {
		return buildingRoleId;
	}

	public void setBuildingRoleId(Long buildingRoleId) {
		this.buildingRoleId = buildingRoleId;
	}

	public List<RequestWithBuildingRoleId> getEscalationAttendanceList() {
		return escalationAttendanceList;
	}

	public void setEscalationAttendanceList(List<RequestWithBuildingRoleId> escalationAttendanceList) {
		this.escalationAttendanceList = escalationAttendanceList;
	}
	
	
		
}

