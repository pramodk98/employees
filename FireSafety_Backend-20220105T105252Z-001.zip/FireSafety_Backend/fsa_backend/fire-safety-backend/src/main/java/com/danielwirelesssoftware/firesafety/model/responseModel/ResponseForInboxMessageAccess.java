package com.danielwirelesssoftware.firesafety.model.responseModel;

import java.util.List;

import com.danielwirelesssoftware.firesafety.model.NotificationDetail;

public class ResponseForInboxMessageAccess {
	
	private List<NotificationDetail> notifications;
	
	public ResponseForInboxMessageAccess() {
	}
	
	public ResponseForInboxMessageAccess(List<NotificationDetail> notifications) {
		this.notifications = notifications;
	}

	public List<NotificationDetail> getNotifications() {
		return notifications;
	}

	public void setNotifications(List<NotificationDetail> notifications) {
		this.notifications = notifications;
	}
	
}

