package com.danielwirelesssoftware.firesafety.model.security;

import javax.persistence.*;

@Entity
@Table(name = "HazardReportSectionImage")
public class HazardReportSectionImage {
    
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "hazardSectionImageId")
    private long hazardSectionImageId;

    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "hazardSectionDataId")
    private HazardReportSectionData imageHazardReport;
    
    @Column(name = "documentName")
    private String documentName;
    
    @Column(name = "documentKey")
    private String documentKey;

    public HazardReportSectionImage(){
	
    }

    public HazardReportSectionImage(HazardReportSectionData imageHazardReport,
			String documentName, String documentKey) {
		this.imageHazardReport = imageHazardReport;
		this.documentName = documentName;
		this.documentKey = documentKey;
	}
    
	public HazardReportSectionImage(long hazardSectionImageId, HazardReportSectionData imageHazardReport,
			String documentName, String documentKey) {
		this.hazardSectionImageId = hazardSectionImageId;
		this.imageHazardReport = imageHazardReport;
		this.documentName = documentName;
		this.documentKey = documentKey;
	}

	public long getHazardSectionImageId() {
		return hazardSectionImageId;
	}

	public void setHazardSectionImageId(long hazardSectionImageId) {
		this.hazardSectionImageId = hazardSectionImageId;
	}

	public HazardReportSectionData getImageHazardReport() {
		return imageHazardReport;
	}

	public void setImageHazardReport(HazardReportSectionData imageHazardReport) {
		this.imageHazardReport = imageHazardReport;
	}

	public String getDocumentName() {
		return documentName;
	}

	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}

	public String getDocumentKey() {
		return documentKey;
	}

	public void setDocumentKey(String documentKey) {
		this.documentKey = documentKey;
	}

    
}