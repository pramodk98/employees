
package com.danielwirelesssoftware.firesafety.model.responseModel;

import java.sql.Timestamp;
import java.util.List;

import com.danielwirelesssoftware.firesafety.model.AttachDocument;
import com.danielwirelesssoftware.firesafety.model.ReviewReportDetail;

public class ResponseForHazardReportDetailRead {
	
	private long buildingId;
	private boolean checkAllowEditHazardReport;
	private String reporterName;
	private String endReporterName;
	private String displayName;
	private Timestamp reportTime;
	private String hazardReportName;
	private String status;
	private Timestamp reportCloseTime;
	private String completeRemark;
	private List<AttachDocument> listOfCompletedAttachImages;
	private List<ReviewReportDetail> reviewReport;
	
	public ResponseForHazardReportDetailRead(){
		
	}
	
	public ResponseForHazardReportDetailRead(long buildingId, boolean checkAllowEditHazardReport, String reporterName,
												String endReporterName, String displayName, Timestamp reportTime, 
												String hazardReportName, String status, Timestamp reportCloseTime,
												String completeRemark, List<AttachDocument> listOfCompletedAttachImages,
												List<ReviewReportDetail> reviewReport) {
		this.buildingId = buildingId;
		this.checkAllowEditHazardReport = checkAllowEditHazardReport;
		this.reporterName = reporterName;
		this.endReporterName = endReporterName;
		this.displayName = displayName;
		this.reportTime = reportTime;
		this.hazardReportName = hazardReportName;
		this.status = status;
		this.reportCloseTime = reportCloseTime;
		this.completeRemark = completeRemark;
		this.listOfCompletedAttachImages = listOfCompletedAttachImages;
		this.reviewReport = reviewReport;
	}

	public String getReporterName() {
		return reporterName;
	}

	public void setReporterName(String reporterName) {
		this.reporterName = reporterName;
	}

	public String getEndReporterName() {
		return endReporterName;
	}

	public void setEndReporterName(String endReporterName) {
		this.endReporterName = endReporterName;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public Timestamp getReportTime() {
		return reportTime;
	}

	public void setReportTime(Timestamp reportTime) {
		this.reportTime = reportTime;
	}

	public String getHazardReportName() {
		return hazardReportName;
	}

	public void setHazardReportName(String hazardReportName) {
		this.hazardReportName = hazardReportName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Timestamp getReportCloseTime() {
		return reportCloseTime;
	}

	public void setReportCloseTime(Timestamp reportCloseTime) {
		this.reportCloseTime = reportCloseTime;
	}

	public String getCompleteRemark() {
		return completeRemark;
	}

	public void setCompleteRemark(String completeRemark) {
		this.completeRemark = completeRemark;
	}

	public List<AttachDocument> getListOfCompletedAttachImages() {
		return listOfCompletedAttachImages;
	}

	public void setListOfCompletedAttachImages(List<AttachDocument> listOfCompletedAttachImages) {
		this.listOfCompletedAttachImages = listOfCompletedAttachImages;
	}

	public List<ReviewReportDetail> getReviewReport() {
		return reviewReport;
	}

	public void setReviewReport(List<ReviewReportDetail> reviewReport) {
		this.reviewReport = reviewReport;
	}

	public long getBuildingId() {
		return buildingId;
	}

	public void setBuildingId(long buildingId) {
		this.buildingId = buildingId;
	}

	public boolean isCheckAllowEditHazardReport() {
		return checkAllowEditHazardReport;
	}

	public void setCheckAllowEditHazardReport(boolean checkAllowEditHazardReport) {
		this.checkAllowEditHazardReport = checkAllowEditHazardReport;
	}
	
	
}

