package com.danielwirelesssoftware.firesafety.model;

public class QuestionDetail {

    private long questionId;
    private String questionName;

    public QuestionDetail() {
    }

	public QuestionDetail(long questionId, String questionName) {
		this.questionId = questionId;
		this.questionName = questionName;
	}

	public long getQuestionId() {
		return questionId;
	}

	public void setQuestionId(long questionId) {
		this.questionId = questionId;
	}

	public String getQuestionName() {
		return questionName;
	}

	public void setQuestionName(String questionName) {
		this.questionName = questionName;
	}
    
}
