package com.danielwirelesssoftware.firesafety.security.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.danielwirelesssoftware.firesafety.model.security.HazardReport;
import com.danielwirelesssoftware.firesafety.model.security.HazardReportClose;

public interface HazardReportCloseRepository extends JpaRepository<HazardReportClose, Long> {
	
	List<HazardReportClose> findByHazardReport(HazardReport hazardReport);
	
}
