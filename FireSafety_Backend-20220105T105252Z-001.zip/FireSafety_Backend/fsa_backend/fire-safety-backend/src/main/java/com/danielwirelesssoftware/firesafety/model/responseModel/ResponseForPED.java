package com.danielwirelesssoftware.firesafety.model.responseModel;

import java.util.List;
import com.danielwirelesssoftware.firesafety.model.BuildingLevelDetail;

public class ResponseForPED {
	
	private long buildingId;
	private boolean enableEdit;
	private List<BuildingLevelDetail> listOfBuildingDetail;
	
	public ResponseForPED() {
	}
	
	public ResponseForPED(long buildingId, boolean enableEdit, List<BuildingLevelDetail> listOfBuildingDetail) {
		this.buildingId = buildingId;
		this.enableEdit = enableEdit;
		this.listOfBuildingDetail = listOfBuildingDetail;
	}

	public long getBuildingId() {
		return buildingId;
	}

	public void setBuildingId(long buildingId) {
		this.buildingId = buildingId;
	}

	public List<BuildingLevelDetail> getListOfBuildingDetail() {
		return listOfBuildingDetail;
	}

	public void setListOfBuildingDetail(List<BuildingLevelDetail> listOfBuildingDetail) {
		this.listOfBuildingDetail = listOfBuildingDetail;
	}

	public boolean isEnableEdit() {
		return enableEdit;
	}

	public void setEnableEdit(boolean enableEdit) {
		this.enableEdit = enableEdit;
	}

	
}

