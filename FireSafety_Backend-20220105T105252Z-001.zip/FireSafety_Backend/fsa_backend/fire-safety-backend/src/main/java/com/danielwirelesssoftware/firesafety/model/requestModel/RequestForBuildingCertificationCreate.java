package com.danielwirelesssoftware.firesafety.model.requestModel;

import com.danielwirelesssoftware.firesafety.model.BuildingCertificationDetail;

public class RequestForBuildingCertificationCreate {

	private long buildingRoleId;
	private BuildingCertificationDetail certification;
	
	public RequestForBuildingCertificationCreate() {
	}
	
	public RequestForBuildingCertificationCreate(RequestForBuildingCertificationCreate requestForBuildingCertificationCreate) {
		this.buildingRoleId = requestForBuildingCertificationCreate.buildingRoleId;
		this.certification = requestForBuildingCertificationCreate.certification;

	}
	
	public RequestForBuildingCertificationCreate(long buildingRoleId, BuildingCertificationDetail certification) {
		this.buildingRoleId = buildingRoleId;
		this.certification = certification;
	}

	public long getBuildingRoleId() {
		return buildingRoleId;
	}

	public void setBuildingRoleId(long buildingRoleId) {
		this.buildingRoleId = buildingRoleId;
	}

	public BuildingCertificationDetail getCertification() {
		return certification;
	}

	public void setCertification(BuildingCertificationDetail certification) {
		this.certification = certification;
	}
	
}
