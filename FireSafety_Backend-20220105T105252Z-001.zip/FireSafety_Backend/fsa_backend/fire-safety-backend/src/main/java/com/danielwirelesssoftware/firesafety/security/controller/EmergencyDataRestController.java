package com.danielwirelesssoftware.firesafety.security.controller;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mobile.device.Device;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.danielwirelesssoftware.firesafety.common.utils.TimeProvider;
import com.danielwirelesssoftware.firesafety.model.AttachDocument;
import com.danielwirelesssoftware.firesafety.model.BuildingLevelDetail;
import com.danielwirelesssoftware.firesafety.model.PremiseEmergencyData;
import com.danielwirelesssoftware.firesafety.model.security.BuildingLevel;
import com.danielwirelesssoftware.firesafety.model.requestModel.RequestForPEDUpdate;
import com.danielwirelesssoftware.firesafety.model.requestModel.RequestWithBuildingRoleId;
import com.danielwirelesssoftware.firesafety.model.responseModel.ResponseForPED;
import com.danielwirelesssoftware.firesafety.model.security.BuildingRole;
import com.danielwirelesssoftware.firesafety.model.security.EmergencyData;
import com.danielwirelesssoftware.firesafety.model.security.User;
import com.danielwirelesssoftware.firesafety.security.JwtUser;
import com.danielwirelesssoftware.firesafety.security.repository.BuildingLevelRepository;
import com.danielwirelesssoftware.firesafety.security.repository.BuildingRoleRepository;
import com.danielwirelesssoftware.firesafety.security.repository.EmergencyDataRepository;
import com.danielwirelesssoftware.firesafety.security.repository.UserRepository;

import static com.danielwirelesssoftware.firesafety.common.utils.Constant.DELETE_FALSE;
import static com.danielwirelesssoftware.firesafety.common.utils.Constant.LEVELS;

import java.util.ArrayList;
import java.util.List;

@Transactional
@RestController
public class EmergencyDataRestController {

    private final Log logger = LogFactory.getLog(this.getClass());
    
    @Autowired
    private BuildingRoleRepository buildingRoleRepository;
    
    @Autowired
    private BuildingLevelRepository buildingLevelRepository;
    
    @Autowired
    private EmergencyDataRepository emergencyDataRepository;
    
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private TimeProvider timeProvider;
  
    @RequestMapping(value = "/accessPremiseEmergencyData", method = RequestMethod.POST)
    public ResponseEntity<?> premiseEmergencyDataAccess(@RequestBody RequestWithBuildingRoleId request, Device device){
    	
    	BuildingRole buildingRole;
    	buildingRole = buildingRoleRepository.findByBuildingRoleIdAndDeleted(request.getBuildingRoleId(),DELETE_FALSE);  	

        if(buildingRole == null){
    		logger.error("/accessPremiseEmergencyData API : buildingRoleId from Request: "+request.getBuildingRoleId());
    		return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
    	}    	
    	
    	long buildingId = buildingRole.getBuilding().getBuildingId();
    	logger.info("/accessPremiseEmergencyData API : buildingRoleId: "+buildingRole.getBuildingRoleId());
    	
    	if(buildingRole.getBuilding().isDeleted()){
    		logger.error("/accessPremiseEmergencyData API : building is deleted for buildingRoleId "+request.getBuildingRoleId());
    		return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
    	}
    	
    	List<BuildingLevel> buildingLevelList = null;
    	List<BuildingLevelDetail> levelDetails = new ArrayList<BuildingLevelDetail>();
    	
    	buildingLevelList = buildingLevelRepository.findByBuildingAndDeleted(buildingRole.getBuilding(), DELETE_FALSE);    	 	
    	
    	if(buildingLevelList != null){
    		buildingLevelList.sort((left, right) -> Integer.compare(LEVELS.indexOf(left.getLevelName().toUpperCase().replaceAll("\\s","")), LEVELS.indexOf(right.getLevelName().toUpperCase().replaceAll("\\s",""))));
    	}
    	
    	for(BuildingLevel b:buildingLevelList){
    		
    		List <PremiseEmergencyData> pList = new ArrayList<PremiseEmergencyData>();

    		for(EmergencyData e : b.getEmergencyDataList()){
    			if(!e.isDeleted()){
	    			PremiseEmergencyData p = new PremiseEmergencyData(e.getEmergencyDataId(),
	    																new AttachDocument(e.getDocumentName(),
	    																e.getDocumentKey()));
	    			pList.add(p);
    			}
    		}
    		BuildingLevelDetail level = new BuildingLevelDetail(b.getBuildingLevelId(),b.getLevelName(),pList);
    		levelDetails.add(level);
    	}
    	
    	logger.info("/accessPremiseEmergencyData API : DocumentManagementGroup: "+buildingRole.getRole().getDocumentManagementGroup());
    	
        //set response
    	ResponseForPED response = new ResponseForPED(buildingId, buildingRole.getRole().getDocumentManagementGroup(), levelDetails);
        
        return new ResponseEntity<ResponseForPED>(response, HttpStatus.OK);
    }
    
    @RequestMapping(value = "/updatePremiseEmergencyData", method = RequestMethod.POST)
    public ResponseEntity<?> premiseEmergencyDataUpdate(@RequestBody RequestForPEDUpdate request, @AuthenticationPrincipal final JwtUser principle, Device device){
    	
    	BuildingLevel buildingLevel = null;
    	BuildingRole buildingRole = null;
    	
    	buildingLevel = buildingLevelRepository.findByBuildingLevelIdAndDeleted(request.getLevelId(),DELETE_FALSE);
    	
    	if(buildingLevel == null){
    		logger.error("/updatePremiseEmergencyData API : buildingLevel not found for buildingLevelId "+request.getLevelId());
    		return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
    	}
    	
    	if(buildingLevel.getBuilding().isDeleted()){
    		logger.error("/updatePremiseEmergencyData API : building is deleted for buildingLevelId "+request.getLevelId());
    		return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
    	}
    	
    	long buildingId = buildingLevel.getBuilding().getBuildingId();
    	
    	//get current user
    	User user = userRepository.findByUserIdAndDeleted(principle.getUserId(),DELETE_FALSE);
    	logger.info("//userID:"+principle.getUserId());
    	
    	buildingRole = buildingRoleRepository.findByBuildingUserAndBuilding(user,buildingLevel.getBuilding());
    	
    	if(buildingRole == null){
    		logger.error("/updatePremiseEmergencyData API : buildingRole not found for userId: "
    						+user.getUserId() +", buildingId: "+buildingLevel.getBuilding().getBuildingId());
    		return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
    	}
    	
    	//update emergency data, if title/file is null, set delete true, else create 
    	for(PremiseEmergencyData pedList:request.getPremiseEmergencyDataList()){
    		if(pedList.getAttachDocument().getKey() == null || pedList.getAttachDocument().getDocumentName() == null ||
    			pedList.getAttachDocument().getKey().isEmpty() || pedList.getAttachDocument().getDocumentName().isEmpty()){
    			try{
    				emergencyDataRepository.setFixedDeletedFor(true, pedList.getEmergencyDataId()); 
    			}catch(Exception e){
    				logger.error("error in updating PremiseEmergencyData: "+e);
    				return new ResponseEntity<String>("data error", HttpStatus.BAD_REQUEST);
    			}
    		}else{    			
    			EmergencyData e = new EmergencyData(pedList.getAttachDocument().getDocumentName(),buildingLevel,
    												pedList.getAttachDocument().getKey(), user,
    												timeProvider.timestampNow(),false);
    			emergencyDataRepository.saveAndFlush(e);
    		}
    	}
    	
    	//get return data
    	List<BuildingLevel> buildingLevelList = null;
    	List<BuildingLevelDetail> levelDetails = new ArrayList<BuildingLevelDetail>();
    	
    	buildingLevelList = buildingLevelRepository.findByBuildingAndDeleted(buildingLevel.getBuilding(), DELETE_FALSE);    	
    	if(buildingLevelList != null){
    		buildingLevelList.sort((left, right) -> Integer.compare(LEVELS.indexOf(left.getLevelName().toUpperCase().replaceAll("\\s","")), LEVELS.indexOf(right.getLevelName().toUpperCase().replaceAll("\\s",""))));
    	}
    	
    	
    	for(BuildingLevel b:buildingLevelList){
    		
    		List <PremiseEmergencyData> pList = new ArrayList<PremiseEmergencyData>();

    		for(EmergencyData e : b.getEmergencyDataList()){
    			if(!e.isDeleted()){
	    			PremiseEmergencyData p = new PremiseEmergencyData(e.getEmergencyDataId(),
	    																new AttachDocument(e.getDocumentName(),
	    																e.getDocumentKey()));
	    			pList.add(p);
    			}
    		}
    		BuildingLevelDetail level = new BuildingLevelDetail(b.getBuildingLevelId(),b.getLevelName(),pList);
    		levelDetails.add(level);
    	}
    	
         //set response
    	ResponseForPED response = new ResponseForPED(buildingId,buildingRole.getRole().getDocumentManagementGroup(), levelDetails);
        
        return new ResponseEntity<ResponseForPED>(response, HttpStatus.OK);
    }
    

 
    

}