package com.danielwirelesssoftware.firesafety.model.requestModel;

public class RequestForAttendanceRemove {
	
	private long tenantId;
	private long fireDrillId;
	
	public RequestForAttendanceRemove() {
	}
	
	public RequestForAttendanceRemove( RequestForAttendanceRemove requestForAttendanceRemove ) {
		this.tenantId = requestForAttendanceRemove.tenantId;
		this.fireDrillId = requestForAttendanceRemove.fireDrillId;
	}
	
	public RequestForAttendanceRemove(long tenantId, long fireDrillId) {
		this.tenantId = tenantId;
		this.fireDrillId = fireDrillId;
	}
	
	
	
	public long getTenantId() {
		return tenantId;
	}

	public void setTenantId(long tenantId) {
		this.tenantId = tenantId;
	}

	public long getFireDrillId() {
		return fireDrillId;
	}
	
	public void setFireDrillId(long fireDrillId) {
		this.fireDrillId = fireDrillId;
	}
	
	
}

