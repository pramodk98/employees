package com.danielwirelesssoftware.firesafety.model.security;

import java.sql.Timestamp;
import java.util.List;

import javax.persistence.*;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

@Entity
@Table(name = "Escalation")
public class Escalation {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "escalationId")
    private long escalationId;
    
    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "buildingId")
    private Building escalationBuilding;
    
    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "reporter")
    private User reporter;
    
    @Column(name = "dateTime")
    private Timestamp dateTime;
    
    @Column(name = "lastUpdate")
    private Timestamp lastUpdate;
    
    @Column(name = "status")
    private String status;
    
    @Column(name = "completeDateTime")
    private Timestamp completeDateTime;
    
    @OneToMany(mappedBy = "escalationId", fetch = FetchType.LAZY
    		, cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.DETACH, CascadeType.REFRESH })
    @Fetch(value = FetchMode.SUBSELECT)
	private List<EscalationAttendance> escalationAttendanceList;
    
    public Escalation() {
    }

	public Escalation(long escalationId, Building escalationBuilding, User reporter, Timestamp dateTime,
			Timestamp lastUpdate, String status, Timestamp completeDateTime) {
		this.escalationId = escalationId;
		this.escalationBuilding = escalationBuilding;
		this.reporter = reporter;
		this.dateTime = dateTime;
		this.lastUpdate = lastUpdate;
		this.status = status;
		this.completeDateTime = completeDateTime;
	}
	
	public Escalation(Building escalationBuilding, User reporter, Timestamp dateTime,
			Timestamp lastUpdate, String status) {
		this.escalationBuilding = escalationBuilding;
		this.reporter = reporter;
		this.dateTime = dateTime;
		this.lastUpdate = lastUpdate;
		this.status = status;
	}

	public long getEscalationId() {
		return escalationId;
	}

	public void setEscalationId(long escalationId) {
		this.escalationId = escalationId;
	}

	public Building getEscalationBuilding() {
		return escalationBuilding;
	}

	public void setEscalationBuilding(Building escalationBuilding) {
		this.escalationBuilding = escalationBuilding;
	}

	public User getReporter() {
		return reporter;
	}

	public void setReporter(User reporter) {
		this.reporter = reporter;
	}

	public Timestamp getDateTime() {
		return dateTime;
	}

	public void setDateTime(Timestamp dateTime) {
		this.dateTime = dateTime;
	}

	public Timestamp getLastUpdate() {
		return lastUpdate;
	}

	public void setLastUpdate(Timestamp lastUpdate) {
		this.lastUpdate = lastUpdate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Timestamp getCompleteDateTime() {
		return completeDateTime;
	}

	public void setCompleteDateTime(Timestamp completeDateTime) {
		this.completeDateTime = completeDateTime;
	}

	public List<EscalationAttendance> getEscalationAttendanceList() {
		return escalationAttendanceList;
	}

	public void setEscalationAttendanceList(List<EscalationAttendance> escalationAttendanceList) {
		this.escalationAttendanceList = escalationAttendanceList;
	}

	@Override
	public String toString() {
		return "Escalation [escalationId=" + escalationId + ", escalationBuilding=" + escalationBuilding + ", reporter="
				+ reporter + ", dateTime=" + dateTime + ", lastUpdate=" + lastUpdate + ", status=" + status
				+ ", completeDateTime=" + completeDateTime + "]";
	}
    
    
}
