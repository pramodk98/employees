-- MySQL dump 10.13  Distrib 5.7.17, for macos10.12 (x86_64)
--
-- Host: 127.0.0.1    Database: FSA
-- ------------------------------------------------------
-- Server version	5.5.5-10.1.37-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Building`
--

DROP TABLE IF EXISTS `Building`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Building` (
  `buildingId` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `numLevels` int(11) DEFAULT NULL,
  `latitude` decimal(11,7) NOT NULL,
  `longtitude` decimal(11,7) NOT NULL,
  `address1` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address2` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postalCode` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` varchar(75) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastUpdate` datetime(3) NOT NULL,
  `editedBy` int(11) NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`buildingId`),
  KEY `editedBy` (`editedBy`),
  CONSTRAINT `Building_ibfk_1` FOREIGN KEY (`editedBy`) REFERENCES `User` (`userId`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Building`
--

LOCK TABLES `Building` WRITE;
/*!40000 ALTER TABLE `Building` DISABLE KEYS */;
INSERT INTO `Building` VALUES (1,'NUH',25,1.2941186,104.0000000,'5 Lower Kent Ridge Rd','','s119074','singapore','2019-03-27 11:26:08.000',1,0),(2,'NUH Sports Centre',4,1.2927311,103.7853309,' Main Building Lobby B','5 Lower Kent Ridge Rd','s119074','singapore','2019-03-27 11:34:15.000',2,0),(3,'Timbre+',3,1.2904966,103.7864543,'73A Ayer Rajah Crescent','JTC Launchpad','s139957','singapore','2019-03-27 12:31:11.000',1,0),(4,'Ministry of education',4,0.0000000,0.0000000,'1 N Bouna Vista Drive ',NULL,'138675','singapore','2019-04-04 12:11:14.000',3,0);
/*!40000 ALTER TABLE `Building` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `BuildingLevel`
--

DROP TABLE IF EXISTS `BuildingLevel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `BuildingLevel` (
  `buildingLevelId` int(11) NOT NULL AUTO_INCREMENT,
  `buildingId` int(11) NOT NULL,
  `levelName` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`buildingLevelId`),
  KEY `buildingId` (`buildingId`),
  CONSTRAINT `BuildingLevel_ibfk_1` FOREIGN KEY (`buildingId`) REFERENCES `Building` (`buildingId`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BuildingLevel`
--

LOCK TABLES `BuildingLevel` WRITE;
/*!40000 ALTER TABLE `BuildingLevel` DISABLE KEYS */;
INSERT INTO `BuildingLevel` VALUES (1,1,'1',0),(2,1,'2',0),(3,1,'3',0),(4,2,'LG2',0),(5,2,'LG',0),(6,2,'G',0),(7,2,'1',0),(8,2,'2',0),(9,2,'3',0),(10,3,'1',0),(11,3,'2',0),(12,3,'3',0),(13,3,'4',0);
/*!40000 ALTER TABLE `BuildingLevel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `BuildingRole`
--

DROP TABLE IF EXISTS `BuildingRole`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `BuildingRole` (
  `buildingRoleId` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `buildingId` int(11) NOT NULL,
  `roleId` int(11) NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`buildingRoleId`),
  KEY `userId` (`userId`),
  KEY `buildingId` (`buildingId`),
  KEY `roleId` (`roleId`),
  CONSTRAINT `BuildingRole_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `User` (`userId`),
  CONSTRAINT `BuildingRole_ibfk_2` FOREIGN KEY (`buildingId`) REFERENCES `Building` (`buildingId`),
  CONSTRAINT `BuildingRole_ibfk_3` FOREIGN KEY (`roleId`) REFERENCES `Role` (`roleId`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BuildingRole`
--

LOCK TABLES `BuildingRole` WRITE;
/*!40000 ALTER TABLE `BuildingRole` DISABLE KEYS */;
INSERT INTO `BuildingRole` VALUES (1,1,1,10,0),(2,4,2,2,0),(3,1,3,1,0),(4,4,1,2,0),(5,1,4,1,0),(6,2,1,2,0),(7,2,2,1,0),(8,3,3,1,0);
/*!40000 ALTER TABLE `BuildingRole` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Certification`
--

DROP TABLE IF EXISTS `Certification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Certification` (
  `certificationId` int(11) NOT NULL AUTO_INCREMENT,
  `certificationName` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expirationDate` datetime(3) NOT NULL,
  `buildingId` int(11) NOT NULL,
  `document` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`certificationId`),
  KEY `buildingId` (`buildingId`),
  CONSTRAINT `Certification_ibfk_1` FOREIGN KEY (`buildingId`) REFERENCES `Building` (`buildingId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Certification`
--

LOCK TABLES `Certification` WRITE;
/*!40000 ALTER TABLE `Certification` DISABLE KEYS */;
/*!40000 ALTER TABLE `Certification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Configurations`
--

DROP TABLE IF EXISTS `Configurations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Configurations` (
  `configurationId` int(11) NOT NULL AUTO_INCREMENT,
  `trainingName` varchar(100) DEFAULT NULL,
  `trainingURL` varchar(255) DEFAULT NULL,
  `document` varchar(100) DEFAULT NULL,
  `lastUpdate` datetime(3) NOT NULL,
  PRIMARY KEY (`configurationId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Configurations`
--

LOCK TABLES `Configurations` WRITE;
/*!40000 ALTER TABLE `Configurations` DISABLE KEYS */;
/*!40000 ALTER TABLE `Configurations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Drawings`
--

DROP TABLE IF EXISTS `Drawings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Drawings` (
  `drawingId` int(11) NOT NULL AUTO_INCREMENT,
  `levelId` int(11) NOT NULL,
  `editedBy` int(11) DEFAULT NULL,
  `dateTime` datetime(3) NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `documentKey` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `documentName` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`drawingId`),
  KEY `editedBy` (`editedBy`),
  KEY `levelId` (`levelId`),
  CONSTRAINT `Drawings_ibfk_1` FOREIGN KEY (`editedBy`) REFERENCES `User` (`userId`),
  CONSTRAINT `Drawings_ibfk_2` FOREIGN KEY (`levelId`) REFERENCES `BuildingLevel` (`buildingLevelId`)
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Drawings`
--

LOCK TABLES `Drawings` WRITE;
/*!40000 ALTER TABLE `Drawings` DISABLE KEYS */;
INSERT INTO `Drawings` VALUES (1,1,2,'2019-04-05 12:06:14.000',1,'test/drawings/1/DrawingTest_0001_1554436577137.jpeg','IMG_20190206_001651_247.jpg'),(2,1,2,'2019-04-05 12:06:39.000',1,'test/drawings/1/DrawingTest_0001_1554436577137.jpeg','IMG_20190206_001651_247.jpg'),(3,1,2,'2019-04-05 12:06:49.000',1,'test/drawings/1/DrawingTest_0001_1554436577137.jpeg','IMG_20190206_001651_247.jpg'),(4,2,1,'2019-04-05 12:22:13.000',1,'test/drawings/2/DrawingTest_0001_1554438129998.jpeg','DrawingTest_0001_1554438129998.jpeg'),(5,2,1,'2019-04-05 12:25:37.000',1,'test/drawings/2/DrawingTest_0001_1554438333902.jpeg','IMG_20190218_000848_058.jpg'),(6,3,1,'2019-04-05 12:32:23.000',1,'test/drawings/0/DrawingTest_0001_1554438740631.jpeg','IMG_20190211_230439_161.jpg'),(7,3,1,'2019-04-05 12:42:19.000',1,'test/drawings/0/DrawingTest_0001_1554439335300.jpeg','IMG_20190211_230439_161.jpg'),(8,1,1,'2019-04-05 12:42:55.000',1,'test/drawings/0/DrawingTest_0001_1554439371669.pdf','FPTC-AB-FP-204-6-8(2s-3s-4s)_FP-204(2ND)-Model.pdf'),(9,1,1,'2019-04-05 12:43:32.000',1,'test/drawings/0/DrawingTest_0001_1554439408532.pdf','FPTC-AB-FP-204-6-8(2s-3s-4s)_FP-204(2ND)-Model.pdf'),(10,1,1,'2019-04-05 12:43:46.000',1,'test/drawings/0/DrawingTest_0001_1554439422393.pdf','FPTC-AB-FP-204-6-8(2s-3s-4s)_FP-204(2ND)-Model.pdf'),(11,3,1,'2019-04-05 12:43:58.000',0,'test/drawings/0/DrawingTest_0001_1554439430290.pdf','FPTC-AB-FP-204-6-8(2s-3s-4s)_FP-208(4TH)-Model.pdf'),(12,2,1,'2019-04-05 12:44:08.000',0,'test/drawings/0/DrawingTest_0001_1554439444465.pdf','FPTC-AB-FP-204-6-8(2s-3s-4s)_FP-204(2ND)-Model.pdf'),(13,1,1,'2019-04-05 12:44:26.000',1,'test/drawings/0/DrawingTest_0001_1554439462833.jpeg','IMG_20190211_230439_161.jpg'),(14,1,1,'2019-04-05 12:52:17.000',1,'test/drawings/0/DrawingTest_0001_1554439932241.jpeg','bg_popup_quizmax.png'),(15,1,1,'2019-04-05 12:52:34.000',1,'test/drawings/0/DrawingTest_0001_1554439944136.pdf','FPTC-AB-FP-204-6-8(2s-3s-4s)_FP-206(3RD)-Model.pdf'),(16,2,1,'2019-04-05 12:52:51.000',0,'test/drawings/0/DrawingTest_0001_1554439968681.jpeg','IMG_20190206_001651_247.jpg'),(17,2,1,'2019-04-05 12:52:59.000',0,'test/drawings/0/DrawingTest_0001_1554439976334.pdf','FPTC-AB-FP-204-6-8(2s-3s-4s)_FP-204(2ND)-Model.pdf'),(18,3,1,'2019-04-05 12:53:15.000',0,'test/drawings/0/DrawingTest_0001_1554439988927.jpeg','IMG_20190220_205148_020.jpg'),(19,3,1,'2019-04-05 12:53:25.000',0,'test/drawings/0/DrawingTest_0001_1554439999043.pdf','FPTC-AB-FP-204-6-8(2s-3s-4s)_FP-204(2ND)-Model.pdf'),(20,3,1,'2019-04-05 14:38:50.000',0,'test/drawings/0/DrawingTest_0001_1554446325907.jpeg','IMG_20190124_193842_986.jpg'),(21,1,1,'2019-04-05 14:47:14.000',1,'test/drawings/0/DrawingTest_0001_1554446821919.pdf','FPTC-AB-FP-204-6-8(2s-3s-4s)_FP-204(2ND)-Model.pdf'),(22,1,1,'2019-04-05 14:47:14.000',1,'test/drawings/0/DrawingTest_0001_1554446830381.jpeg','IMG_20190206_001651_247.jpg'),(23,1,1,'2019-04-05 14:50:25.000',1,'test/drawings/0/DrawingTest_0001_1554446996390.jpeg','IMG_20190218_000848_058.jpg'),(24,1,1,'2019-04-05 14:50:25.000',1,'test/drawings/0/DrawingTest_0001_1554447002257.pdf','FPTC-AB-FP-204-6-8(2s-3s-4s)_FP-206(3RD)-Model.pdf'),(25,1,1,'2019-04-05 14:50:25.000',1,'test/drawings/0/DrawingTest_0001_1554447008596.pdf','Escalation Process and Preparedness.pdf'),(26,1,1,'2019-04-05 14:50:25.000',1,'test/drawings/0/DrawingTest_0001_1554447020249.jpeg','DrawingTest_0001_1554447020249.jpeg'),(27,4,2,'2019-04-05 15:24:41.000',1,'test/drawings/0/DrawingTest_0001_1554449061059.pdf','fire_drill_reporting_sample.pdf'),(28,4,2,'2019-04-05 15:24:41.000',1,'test/drawings/0/DrawingTest_0001_1554449070297.jpeg','IMG_20190211_230439_161.jpg'),(29,4,2,'2019-04-05 15:24:41.000',0,'test/drawings/0/DrawingTest_0001_1554449075096.pdf','Equipment List for Fire Protection System.pdf'),(30,5,2,'2019-04-05 15:27:17.000',0,'test/drawings/0/DrawingTest_0001_1554449224044.jpeg','DrawingTest_0001_1554449224044.jpeg'),(31,5,2,'2019-04-05 15:27:17.000',0,'test/drawings/0/DrawingTest_0001_1554449228093.pdf','Escalation Process and Preparedness.pdf'),(32,5,2,'2019-04-05 15:27:17.000',0,'test/drawings/0/DrawingTest_0001_1554449234722.jpeg','bg_popup_quizmax.png'),(33,6,2,'2019-04-05 15:27:31.000',0,'test/drawings/0/DrawingTest_0001_1554449246992.pdf','Escalation Process and Preparedness.pdf'),(34,8,2,'2019-04-05 15:27:42.000',0,'test/drawings/0/DrawingTest_0001_1554449260099.jpeg','IMG_20190211_230439_161.jpg'),(35,9,2,'2019-04-05 15:27:53.000',0,'test/drawings/0/DrawingTest_0001_1554449270922.jpeg','IMG_20190208_140352_447.jpg'),(36,7,2,'2019-04-05 15:28:05.000',1,'test/drawings/0/DrawingTest_0001_1554449282240.jpeg','IMG_20190316_133404_612.jpg'),(37,4,2,'2019-04-05 15:49:49.000',1,'test/drawings/0/DrawingTest_0001_1554450585921.jpeg','IMG_20190218_000848_058.jpg'),(38,5,2,'2019-04-05 15:54:32.000',0,'test/drawings/0/DrawingTest_0001_1554450868399.jpeg','bg_popup_quizmax.png'),(39,4,2,'2019-04-05 16:41:18.000',1,'building_2/drawings/levelId_4/Drawing_2_1554453674453.jpeg','Drawing_2_1554453674453.jpeg'),(40,8,2,'2019-04-05 16:42:51.000',0,'building_2/drawings/levelId_8/Drawing_2_1554453768360.jpeg','IMG_20180920_003340_962.jpg'),(41,9,2,'2019-04-05 16:47:00.000',0,'building_2/drawings/levelId_9/Drawing_2_1554454016441.pdf','Escalation Process and Preparedness.pdf'),(42,4,2,'2019-04-05 18:06:40.000',1,'building_2/drawings/levelId_4/Drawing_2_1554458797268.jpeg','IMG_20190211_230439_161.jpg'),(43,4,2,'2019-04-05 18:06:53.000',1,'building_2/drawings/levelId_4/Drawing_2_1554458810354.jpeg','IMG_20190307_000308_863.jpg'),(44,4,2,'2019-04-05 18:07:15.000',0,'building_2/drawings/levelId_4/Drawing_2_1554458819191.jpeg','IMG_20190316_133404_612.jpg'),(45,4,2,'2019-04-05 18:07:15.000',1,'building_2/drawings/levelId_4/Drawing_2_1554458827619.jpeg','IMG_20190126_003024_052.jpg'),(46,4,2,'2019-04-05 18:57:39.000',0,'building_2/drawings/levelId_4/Drawing_2_1554461856392.jpeg','IMG_20190211_230439_161.jpg'),(47,7,2,'2019-04-05 18:57:53.000',0,'building_2/drawings/levelId_7/Drawing_2_1554461867651.jpeg','IMG_20190208_140352_447.jpg'),(48,7,2,'2019-04-08 14:39:50.000',0,'building_2/drawings/levelId_7/Drawing_2_1554705588320.jpeg','IMG_20190206_001651_247.jpg'),(49,1,2,'2019-04-08 18:44:20.000',1,'building_1/drawings/levelId_1/Drawing_2_1554720238967.pdf','Equipment List for Fire Protection System.pdf'),(50,1,2,'2019-04-08 18:44:20.000',1,'building_1/drawings/levelId_1/Drawing_2_1554720242827.pdf','Escalation Process and Preparedness.pdf'),(51,1,2,'2019-04-08 18:44:20.000',1,'building_1/drawings/levelId_1/Drawing_2_1554720250411.jpeg','Drawing_2_1554720250411.jpeg'),(52,1,2,'2019-04-08 18:44:20.000',1,'building_1/drawings/levelId_1/Drawing_2_1554720257001.jpeg','IMG_20190407_135426_965.jpg'),(53,1,2,'2019-04-08 18:45:06.000',1,'building_1/drawings/levelId_1/Drawing_2_1554720279848.jpeg','IMG_20190211_230439_161.jpg'),(54,1,2,'2019-04-08 18:45:06.000',1,'building_1/drawings/levelId_1/Drawing_2_1554720285768.jpeg','IMG_20190220_205148_020.jpg'),(55,1,2,'2019-04-08 18:45:06.000',1,'building_1/drawings/levelId_1/Drawing_2_1554720288754.pdf','Escalation Process and Preparedness.pdf'),(56,1,2,'2019-04-08 18:45:06.000',1,'building_1/drawings/levelId_1/Drawing_2_1554720292235.pdf','fire_drill_reporting_sample.pdf'),(57,1,2,'2019-04-08 18:45:38.000',1,'building_1/drawings/levelId_1/Drawing_2_1554720335810.pdf','fire_drill_reporting_sample.pdf'),(58,1,2,'2019-04-08 18:47:56.000',1,'building_1/drawings/levelId_1/Drawing_2_1554720474861.jpeg','IMG_20190407_135426_965.jpg'),(59,1,2,'2019-04-08 18:48:11.000',1,'building_1/drawings/levelId_1/Drawing_2_1554720485261.jpeg','bg_popup_quizmax.png'),(60,1,2,'2019-04-08 18:48:11.000',1,'building_1/drawings/levelId_1/Drawing_2_1554720488030.pdf','Escalation Process and Preparedness.pdf'),(61,1,2,'2019-04-08 18:48:45.000',1,'building_1/drawings/levelId_1/Drawing_2_1554720506015.jpeg','IMG_20190220_205148_020.jpg'),(62,1,2,'2019-04-08 18:48:45.000',1,'building_1/drawings/levelId_1/Drawing_2_1554720517641.jpeg','IMG_20190206_001651_247.jpg'),(63,1,2,'2019-04-08 18:48:45.000',1,'building_1/drawings/levelId_1/Drawing_2_1554720521970.pdf','Escalation Process and Preparedness.pdf'),(64,1,2,'2019-04-08 18:49:26.000',0,'building_1/drawings/levelId_1/Drawing_2_1554720538459.jpeg','Drawing_2_1554720538459.jpeg'),(65,1,2,'2019-04-08 18:49:26.000',0,'building_1/drawings/levelId_1/Drawing_2_1554720545304.pdf','FPTC-AB-FP-204-6-8(2s-3s-4s)_FP-204(2ND)-Model.pdf'),(66,1,2,'2019-04-08 18:49:26.000',1,'building_1/drawings/levelId_1/Drawing_2_1554720562820.jpeg','IMG20190331123901.jpg');
/*!40000 ALTER TABLE `Drawings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ERP`
--

DROP TABLE IF EXISTS `ERP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ERP` (
  `erpId` int(11) NOT NULL AUTO_INCREMENT,
  `buildingId` int(11) NOT NULL,
  `documentName` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `documentKey` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`erpId`),
  KEY `buildingId` (`buildingId`),
  CONSTRAINT `ERP_ibfk_1` FOREIGN KEY (`buildingId`) REFERENCES `Building` (`buildingId`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ERP`
--

LOCK TABLES `ERP` WRITE;
/*!40000 ALTER TABLE `ERP` DISABLE KEYS */;
INSERT INTO `ERP` VALUES (5,1,'IMG_20190407_135426_965.jpg','building_1/erp/erp_1_1554713823419.jpeg',1),(6,1,'Escalation Process and Preparedness.pdf','building_1/erp/erp_1_1554715701376.pdf',1),(7,1,'IMG_20190218_000848_058.jpg','building_1/erp/erp_1_1554717618788.jpeg',1),(8,1,'IMG_20190124_193842_986.jpg','building_1/erp/erp_1_1554718294675.jpeg',1),(9,1,'Escalation Process and Preparedness.pdf','building_1/erp/erp_1_1554718299846.pdf',1),(10,1,'IMG_20190206_001651_247.jpg','building_1/erp/erp_1_1554718330656.jpeg',1),(11,1,'IMG_20190307_000308_863.jpg','building_1/erp/erp_1_1554718336711.jpeg',1),(12,1,'IMG_20190316_133404_612.jpg','building_1/erp/erp_2_1554719600896.jpeg',1),(13,1,'bg_popup_quizmax.png','building_1/erp/erp_2_1554719605977.jpeg',1),(14,1,'erp_2_1554720598714.jpeg','building_1/erp/erp_2_1554720598714.jpeg',1),(15,1,'FPTC-AB-FP-204-6-8(2s-3s-4s)_FP-208(4TH)-Model.pdf','building_1/erp/erp_2_1554720602260.pdf',1),(16,1,'bg_popup_quizmax.png','building_1/erp/erp_2_1554720614362.jpeg',1),(17,1,'IMG_20190407_135426_965.jpg','building_1/erp/erp_2_1554720819163.jpeg',1),(18,1,'IMG_20190323_203830_735.jpg','building_1/erp/erp_2_1554721011084.jpeg',1),(19,1,'Escalation Process and Preparedness.pdf','building_1/erp/erp_2_1554721014401.pdf',1),(20,1,'IMG_20190211_230439_161.jpg','building_1/erp/erp_2_1554721572847.jpeg',1),(21,1,'IMG_20190220_205148_020.jpg','building_1/erp/erp_2_1554721592947.jpeg',0);
/*!40000 ALTER TABLE `ERP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EmergencyData`
--

DROP TABLE IF EXISTS `EmergencyData`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `EmergencyData` (
  `emergencyDataId` int(11) NOT NULL AUTO_INCREMENT,
  `documentName` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `documentKey` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `levelId` int(11) NOT NULL,
  `editedBy` int(11) NOT NULL,
  `dateTime` datetime(3) NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`emergencyDataId`),
  KEY `editedBy` (`editedBy`),
  KEY `levelId` (`levelId`),
  CONSTRAINT `EmergencyData_ibfk_1` FOREIGN KEY (`editedBy`) REFERENCES `User` (`userId`),
  CONSTRAINT `EmergencyData_ibfk_2` FOREIGN KEY (`levelId`) REFERENCES `BuildingLevel` (`buildingLevelId`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EmergencyData`
--

LOCK TABLES `EmergencyData` WRITE;
/*!40000 ALTER TABLE `EmergencyData` DISABLE KEYS */;
INSERT INTO `EmergencyData` VALUES (1,'IMG_20190211_230439_161.jpg','building_2/ped/levelId_4/PED_2_1554458419700.jpeg',4,2,'2019-04-05 18:00:22.000',1),(2,'Equipment List for Fire Protection System.pdf','building_2/ped/levelId_7/PED_2_1554458454970.pdf',7,2,'2019-04-05 18:00:58.000',1),(3,'IMG_20190112_203353_503.jpg','building_2/ped/levelId_4/PED_2_1554458524802.jpeg',4,2,'2019-04-05 18:02:20.000',1),(4,'IMG_20190218_000848_058.jpg','building_2/ped/levelId_4/PED_2_1554458532940.jpeg',4,2,'2019-04-05 18:02:20.000',1),(5,'Equipment List for Fire Protection System.pdf','building_2/ped/levelId_4/PED_2_1554458536527.pdf',4,2,'2019-04-05 18:02:20.000',0),(6,'IMG_20190208_140352_447.jpg','building_2/ped/levelId_9/PED_2_1554458552472.jpeg',9,2,'2019-04-05 18:02:40.000',0),(7,'bg_popup_quizmax.png','building_2/ped/levelId_9/PED_2_1554458557883.jpeg',9,2,'2019-04-05 18:02:40.000',0),(8,'IMG_20181029_033114_206.jpg','building_2/ped/levelId_4/PED_2_1554458587075.jpeg',4,2,'2019-04-05 18:03:10.000',1),(9,'IMG_20190220_205148_020.jpg','building_2/ped/levelId_4/PED_2_1554458646420.jpeg',4,2,'2019-04-05 18:04:16.000',1),(10,'IMG_20190211_230439_161.jpg','building_2/ped/levelId_4/PED_2_1554458652451.jpeg',4,2,'2019-04-05 18:04:16.000',1),(11,'IMG_20190211_230439_161.jpg','building_2/ped/levelId_4/PED_2_1554458867651.jpeg',4,2,'2019-04-05 18:07:59.000',0),(12,'IMG_20190126_003024_052.jpg','building_2/ped/levelId_4/PED_2_1554458875458.jpeg',4,2,'2019-04-05 18:07:59.000',0),(13,'Escalation Process and Preparedness.pdf','building_2/ped/levelId_5/PED_2_1554458916986.pdf',5,2,'2019-04-05 18:08:39.000',1),(14,'IMG_20190112_203353_503.jpg','building_2/ped/levelId_5/PED_2_1554458925772.jpeg',5,2,'2019-04-05 18:09:21.000',1),(15,'bg_popup_quizmax.png','building_2/ped/levelId_5/PED_2_1554458931306.jpeg',5,2,'2019-04-05 18:09:21.000',1),(16,'PED_2_1554458940535.jpeg','building_2/ped/levelId_5/PED_2_1554458940535.jpeg',5,2,'2019-04-05 18:09:21.000',0),(17,'Escalation Process and Preparedness.pdf','building_2/ped/levelId_5/PED_2_1554458944985.pdf',5,2,'2019-04-05 18:09:21.000',0),(18,'IMG_20190208_140352_447.jpg','building_2/ped/levelId_5/PED_2_1554458970332.jpeg',5,2,'2019-04-05 18:09:42.000',0),(19,'IMG20190102131741.jpg','building_2/ped/levelId_5/PED_2_1554458978824.jpeg',5,2,'2019-04-05 18:09:42.000',0),(20,'IMG_20190211_230439_161.jpg','building_2/ped/levelId_8/PED_2_1554460070508.jpeg',8,2,'2019-04-05 18:27:54.000',1),(21,'IMG_20190211_230439_161.jpg','building_2/ped/levelId_8/PED_2_1554460115641.jpeg',8,2,'2019-04-05 18:28:44.000',1),(22,'IMG_20190211_230439_161.jpg','building_2/ped/levelId_8/PED_2_1554460683021.jpeg',8,2,'2019-04-05 18:38:12.000',1),(23,'IMG_20190211_230439_161.jpg','building_1/ped/levelId_1/PED_2_1554719057300.jpeg',1,2,'2019-04-08 18:24:29.000',1),(24,'IMG_20190105_103616_324.jpg','building_1/ped/levelId_1/PED_2_1554719066196.jpeg',1,2,'2019-04-08 18:24:29.000',0),(25,'IMG_20190407_135426_965.jpg','building_1/ped/levelId_1/PED_2_1554719086694.jpeg',1,2,'2019-04-08 18:24:48.000',0),(26,'IMG_20190220_205148_020.jpg','building_1/ped/levelId_2/PED_2_1554719106817.jpeg',2,2,'2019-04-08 18:25:09.000',0),(27,'IMG_20190126_003024_052.jpg','building_1/ped/levelId_3/PED_2_1554719116830.jpeg',3,2,'2019-04-08 18:25:19.000',0);
/*!40000 ALTER TABLE `EmergencyData` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Escalation`
--

DROP TABLE IF EXISTS `Escalation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Escalation` (
  `escalationId` int(11) NOT NULL AUTO_INCREMENT,
  `buildingId` int(11) NOT NULL,
  `dateTime` datetime(3) NOT NULL,
  `reporter` int(11) NOT NULL,
  `lastUpdate` datetime(3) NOT NULL,
  `status` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `completeDateTime` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`escalationId`),
  KEY `reporter` (`reporter`),
  KEY `buildingId` (`buildingId`),
  CONSTRAINT `Escalation_ibfk_1` FOREIGN KEY (`reporter`) REFERENCES `User` (`userId`),
  CONSTRAINT `Escalation_ibfk_2` FOREIGN KEY (`buildingId`) REFERENCES `Building` (`buildingId`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Escalation`
--

LOCK TABLES `Escalation` WRITE;
/*!40000 ALTER TABLE `Escalation` DISABLE KEYS */;
INSERT INTO `Escalation` VALUES (11,1,'2019-04-08 16:47:29.000',1,'2019-04-08 16:59:57.000','close','2019-04-08 16:59:57.000'),(12,1,'2019-04-08 17:00:23.000',1,'2019-04-08 17:17:42.000','close','2019-04-08 17:17:42.000'),(13,1,'2019-04-08 17:18:02.000',1,'2019-04-08 17:46:05.000','close','2019-04-08 17:46:04.000'),(14,1,'2019-04-08 18:02:21.000',1,'2019-04-08 19:01:45.000','close','2019-04-08 19:01:43.000'),(15,1,'2019-04-08 18:09:20.000',1,'2019-04-08 18:18:12.000','close','2019-04-08 18:18:11.000'),(16,1,'2019-04-08 18:18:23.000',2,'2019-04-08 18:18:32.000','close','2019-04-08 18:18:31.000'),(17,1,'2019-04-08 18:18:35.000',2,'2019-04-08 18:19:52.000','close','2019-04-08 18:19:51.000'),(18,1,'2019-04-08 19:01:38.000',1,'2019-04-08 19:01:51.000','close','2019-04-08 19:01:50.000'),(19,1,'2019-04-08 19:01:54.000',1,'2019-04-08 19:02:02.000','close','2019-04-08 19:02:01.000'),(20,1,'2019-04-08 19:02:05.000',1,'2019-04-08 19:05:24.000','close','2019-04-08 19:05:22.000'),(21,1,'2019-04-08 19:05:28.000',1,'2019-04-08 19:05:29.000','close','2019-04-08 19:05:29.000'),(22,1,'2019-04-08 19:10:22.000',1,'2019-04-08 19:10:25.000','close','2019-04-08 19:10:24.000'),(23,1,'2019-04-08 19:10:30.000',1,'2019-04-08 19:11:31.000','close','2019-04-08 19:10:38.000'),(24,1,'2019-04-08 19:11:48.000',1,'2019-04-08 19:11:56.000','close','2019-04-08 19:11:54.000');
/*!40000 ALTER TABLE `Escalation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EscalationAttendance`
--

DROP TABLE IF EXISTS `EscalationAttendance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `EscalationAttendance` (
  `escalationAttendanceId` int(11) NOT NULL AUTO_INCREMENT,
  `escalationId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `status` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`escalationAttendanceId`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EscalationAttendance`
--

LOCK TABLES `EscalationAttendance` WRITE;
/*!40000 ALTER TABLE `EscalationAttendance` DISABLE KEYS */;
INSERT INTO `EscalationAttendance` VALUES (1,9,1,'absent'),(2,10,1,'absent'),(3,11,1,'absent'),(4,12,1,'absent'),(8,22,1,'absent'),(9,23,1,'absent'),(10,24,1,'absent');
/*!40000 ALTER TABLE `EscalationAttendance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FSC`
--

DROP TABLE IF EXISTS `FSC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `FSC` (
  `fscId` int(11) NOT NULL AUTO_INCREMENT,
  `buildingId` int(11) NOT NULL,
  `documentName` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `documentKey` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`fscId`),
  KEY `buildingId` (`buildingId`),
  CONSTRAINT `FSC_ibfk_1` FOREIGN KEY (`buildingId`) REFERENCES `Building` (`buildingId`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FSC`
--

LOCK TABLES `FSC` WRITE;
/*!40000 ALTER TABLE `FSC` DISABLE KEYS */;
INSERT INTO `FSC` VALUES (4,1,'FSCTest_0001_1554348344760.jpeg','test/fsc/FSCTest_0001_1554348344760.jpeg'),(5,1,'FSCTest_0001_1554352311818.jpeg','test/fsc/FSCTest_0001_1554352311818.jpeg'),(6,3,'FSCTest_0001_1554352541430.jpeg','test/fsc/FSCTest_0001_1554352541430.jpeg'),(7,4,'FSCTest_0001_1554352597207.jpeg','test/fsc/FSCTest_0001_1554352597207.jpeg'),(8,1,'FPTC-AB-FP-204-6-8(2s-3s-4s)_FP-204(2ND)-Model.pdf','test/fsc/FSCTest_0001_1554352645033.pdf'),(9,1,'FSCTest_0001_1554358071481.jpeg','test/fsc/FSCTest_0001_1554358071481.jpeg'),(10,1,'FSCTest_0001_1554363731075.jpeg','test/fsc/FSCTest_0001_1554363731075.jpeg'),(11,1,'IMG_2376.JPG.jpeg','test/fsc/FSCtest_userid_636899671363690240.jpeg'),(12,1,'IMG_2333.JPG.jpeg','test/fsc/FSCtest_userid_636899679276425856.jpeg'),(13,1,'IMG_2333.JPG.jpeg','test/fsc/FSCtest_userid_636899679276425856.jpeg'),(14,1,'IMG_20190105_103616_324.jpg','test/fsc/FSCTest_0001_1554372748070.jpeg'),(15,1,'IMG_2114.PNG.jpeg','test/fsc/FSCtest_userid_636899702086461184.jpeg'),(16,2,'IMG_20190112_152008_116.jpg','test/fsc/FSCTest_0001_1554374022893.jpeg'),(17,3,'FSCTest_0001_1554374283665.jpeg','test/fsc/FSCTest_0001_1554374283665.jpeg'),(18,2,'Escalation Process and Preparedness.pdf','test/fsc/FSCTest_0001_1554453999376.pdf'),(19,2,'IMG_20190220_205148_020.jpg','building_2/fsc/FSC_21554454462258.jpeg'),(20,2,'DrawingTest_0001_1554438333902.jpeg','building_2/fsc/FSC_2_1554454580285.jpeg');
/*!40000 ALTER TABLE `FSC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FireDrillAttendance`
--

DROP TABLE IF EXISTS `FireDrillAttendance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `FireDrillAttendance` (
  `fireDrillAttendanceId` int(11) NOT NULL AUTO_INCREMENT,
  `tenantEmployeeId` int(11) DEFAULT NULL,
  `fireDrillId` int(11) DEFAULT NULL,
  `status` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`fireDrillAttendanceId`),
  KEY `tenantEmployeeId` (`tenantEmployeeId`),
  KEY `fireDrillId` (`fireDrillId`),
  CONSTRAINT `FireDrillAttandence_ibfk_2` FOREIGN KEY (`fireDrillId`) REFERENCES `FireDrillSchedule` (`fireDrillId`),
  CONSTRAINT `FireDrillAttendance_ibfk_1` FOREIGN KEY (`tenantEmployeeId`) REFERENCES `TenantEmployee` (`tenantEmployeeId`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FireDrillAttendance`
--

LOCK TABLES `FireDrillAttendance` WRITE;
/*!40000 ALTER TABLE `FireDrillAttendance` DISABLE KEYS */;
INSERT INTO `FireDrillAttendance` VALUES (1,1,17,'absent'),(2,1,18,'absent'),(3,1,19,'present'),(4,1,20,'absent'),(5,1,21,'absent'),(6,1,22,'absent'),(7,1,23,'present'),(8,5,23,'present'),(9,6,23,'absent'),(10,7,23,'present'),(11,8,23,'absent');
/*!40000 ALTER TABLE `FireDrillAttendance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FireDrillSchedule`
--

DROP TABLE IF EXISTS `FireDrillSchedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `FireDrillSchedule` (
  `fireDrillId` int(11) NOT NULL AUTO_INCREMENT,
  `buildingId` int(11) NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fireDrillTypeId` int(11) DEFAULT NULL,
  `status` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `scheduledBy` int(11) NOT NULL,
  `dateTime` datetime(3) NOT NULL,
  `lastUpdate` datetime(3) NOT NULL,
  `completeDateTime` datetime(3) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `editedBy` int(11) DEFAULT NULL,
  PRIMARY KEY (`fireDrillId`),
  KEY `buildingId` (`buildingId`),
  KEY `fireDrillTypeId` (`fireDrillTypeId`),
  KEY `scheduledBy` (`scheduledBy`),
  CONSTRAINT `FireDrillSchedule_ibfk_1` FOREIGN KEY (`buildingId`) REFERENCES `Building` (`buildingId`),
  CONSTRAINT `FireDrillSchedule_ibfk_2` FOREIGN KEY (`fireDrillTypeId`) REFERENCES `FireDrillType` (`fireDrillTypeId`),
  CONSTRAINT `FireDrillSchedule_ibfk_3` FOREIGN KEY (`scheduledBy`) REFERENCES `User` (`userId`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FireDrillSchedule`
--

LOCK TABLES `FireDrillSchedule` WRITE;
/*!40000 ALTER TABLE `FireDrillSchedule` DISABLE KEYS */;
INSERT INTO `FireDrillSchedule` VALUES (1,1,NULL,NULL,'close',1,'2009-01-01 15:00:01.000','2009-01-01 15:00:10.004','2009-01-01 15:00:10.000',0,1),(2,2,NULL,NULL,'close',2,'2009-01-02 16:00:02.123','2009-01-02 16:20:00.013','2009-01-02 16:20:10.013',0,2),(3,3,NULL,NULL,'close',1,'2009-01-03 15:00:01.004','2009-01-03 17:00:10.100','2009-01-03 17:30:15.000',0,3),(4,4,NULL,NULL,'close',2,'2009-01-04 15:00:01.002','2009-01-04 18:00:10.020','2009-01-04 18:30:08.080',0,4),(5,1,'the start ',NULL,'open',3,'2009-01-05 15:00:01.034','2009-01-05 19:01:10.001',NULL,0,1),(6,2,NULL,NULL,'open',4,'2009-01-06 13:00:01.001','2009-01-06 20:02:10.020',NULL,0,2),(7,3,NULL,NULL,'open',1,'2009-01-07 14:00:01.020','2009-01-07 21:03:10.100',NULL,0,3),(8,4,NULL,NULL,'open',2,'2009-01-08 15:00:01.100','2009-01-08 22:04:10.020',NULL,0,4),(9,1,'4day later',NULL,'open',3,'2009-01-09 15:00:01.030','2009-01-09 23:05:10.003',NULL,0,1),(10,2,NULL,NULL,'open',4,'2020-01-10 16:00:01.004','2009-01-10 01:06:10.020',NULL,0,2),(11,3,NULL,NULL,'open',1,'2020-01-11 17:00:01.050','2009-01-11 02:07:10.100',NULL,0,3),(12,4,NULL,NULL,'open',2,'2020-01-12 18:00:01.000','2009-01-12 03:08:10.020',NULL,0,4),(13,1,'coming year',NULL,'open',3,'2020-01-13 19:00:01.067','2019-04-05 10:14:08.000',NULL,1,1),(14,2,NULL,NULL,'open',4,'2020-01-14 20:00:01.089','2009-01-14 05:10:10.020',NULL,0,2),(15,3,NULL,NULL,'open',2,'2020-01-15 21:00:01.012','2009-01-15 06:11:10.100',NULL,0,3),(16,4,NULL,NULL,'open',1,'2020-01-16 22:00:01.100','2009-01-16 07:12:10.020',NULL,0,4),(17,1,'',1,'open',1,'2019-04-05 11:38:16.000','2019-04-05 11:38:16.000',NULL,0,0),(18,1,'',2,'open',1,'2019-04-05 11:39:36.000','2019-04-05 11:39:36.000',NULL,0,0),(19,1,'',2,'open',1,'2019-04-06 11:46:24.000','2019-04-05 11:46:52.000',NULL,0,0),(20,1,'',3,'open',1,'2019-04-06 00:47:59.000','2019-04-05 11:47:23.000',NULL,0,0),(21,1,'',3,'open',1,'2019-04-05 11:51:26.000','2019-04-05 11:51:31.000',NULL,0,0),(22,1,'',3,'open',1,'2019-04-05 11:52:46.000','2019-04-05 11:52:51.000',NULL,0,0),(23,1,'',1,'close',2,'2019-04-08 10:25:58.000','2019-04-08 10:16:33.000','2019-04-08 13:07:43.000',0,2);
/*!40000 ALTER TABLE `FireDrillSchedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FireDrillType`
--

DROP TABLE IF EXISTS `FireDrillType`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `FireDrillType` (
  `fireDrillTypeId` int(11) NOT NULL AUTO_INCREMENT,
  `fireDrillTypeName` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`fireDrillTypeId`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FireDrillType`
--

LOCK TABLES `FireDrillType` WRITE;
/*!40000 ALTER TABLE `FireDrillType` DISABLE KEYS */;
INSERT INTO `FireDrillType` VALUES (1,'fire drill',0),(2,'dry run',0),(3,'real fire',0);
/*!40000 ALTER TABLE `FireDrillType` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `HazardReport`
--

DROP TABLE IF EXISTS `HazardReport`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `HazardReport` (
  `hazardReportId` int(11) NOT NULL AUTO_INCREMENT,
  `hazardReportName` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `buildingId` int(11) NOT NULL,
  `reporterId` int(11) NOT NULL,
  `status` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dateTime` datetime(3) NOT NULL,
  `lastUpdate` datetime(3) NOT NULL,
  `closeReporterId` int(11) DEFAULT NULL,
  `closeComment` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`hazardReportId`),
  KEY `reporterId` (`reporterId`),
  KEY `buildingId` (`buildingId`),
  KEY `closeReporterId` (`closeReporterId`),
  CONSTRAINT `HazardReport_ibfk_1` FOREIGN KEY (`reporterId`) REFERENCES `User` (`userId`),
  CONSTRAINT `HazardReport_ibfk_2` FOREIGN KEY (`closeReporterId`) REFERENCES `User` (`userId`),
  CONSTRAINT `HazardReport_ibfk_3` FOREIGN KEY (`buildingId`) REFERENCES `Building` (`buildingId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `HazardReport`
--

LOCK TABLES `HazardReport` WRITE;
/*!40000 ALTER TABLE `HazardReport` DISABLE KEYS */;
/*!40000 ALTER TABLE `HazardReport` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `HazardReportAnswer`
--

DROP TABLE IF EXISTS `HazardReportAnswer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `HazardReportAnswer` (
  `hazardReportAnswerId` int(11) NOT NULL AUTO_INCREMENT,
  `answerText` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`hazardReportAnswerId`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `HazardReportAnswer`
--

LOCK TABLES `HazardReportAnswer` WRITE;
/*!40000 ALTER TABLE `HazardReportAnswer` DISABLE KEYS */;
INSERT INTO `HazardReportAnswer` VALUES (1,'Yes',0),(2,'No',0),(3,'NA',0);
/*!40000 ALTER TABLE `HazardReportAnswer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `HazardReportClose`
--

DROP TABLE IF EXISTS `HazardReportClose`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `HazardReportClose` (
  `hazardReportCloseId` int(11) NOT NULL,
  `hazardReportId` int(11) NOT NULL,
  `documentName` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `documentKey` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`hazardReportCloseId`),
  KEY `hazardReportId` (`hazardReportId`),
  CONSTRAINT `HazardReportClose_ibfk_1` FOREIGN KEY (`hazardReportId`) REFERENCES `HazardReport` (`hazardReportId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `HazardReportClose`
--

LOCK TABLES `HazardReportClose` WRITE;
/*!40000 ALTER TABLE `HazardReportClose` DISABLE KEYS */;
/*!40000 ALTER TABLE `HazardReportClose` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `HazardReportQuestion`
--

DROP TABLE IF EXISTS `HazardReportQuestion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `HazardReportQuestion` (
  `hazardReportQuestionId` int(11) NOT NULL AUTO_INCREMENT,
  `questionTest` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sectionId` int(11) NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`hazardReportQuestionId`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `HazardReportQuestion`
--

LOCK TABLES `HazardReportQuestion` WRITE;
/*!40000 ALTER TABLE `HazardReportQuestion` DISABLE KEYS */;
INSERT INTO `HazardReportQuestion` VALUES (1,'Are all EXIT signs illuminated?',1,0),(2,'Are all the doors self-closing and kept closed at all times?',1,0),(3,'Are all escape routes free from obstructions?',1,0),(4,'Are glass panels in doors obvious and intact?',1,0),(5,'Are escape routes suitable for the people who have to used them (i.e. disabled people)?',1,0);
/*!40000 ALTER TABLE `HazardReportQuestion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `HazardReportQuestionData`
--

DROP TABLE IF EXISTS `HazardReportQuestionData`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `HazardReportQuestionData` (
  `hazardQuestionDataId` int(11) NOT NULL AUTO_INCREMENT,
  `questionId` int(11) NOT NULL,
  `answerId` int(11) NOT NULL,
  `observationText` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hazardSectionId` int(11) NOT NULL,
  PRIMARY KEY (`hazardQuestionDataId`),
  KEY `questionId` (`questionId`),
  KEY `answerId` (`answerId`),
  KEY `hazardSectionId` (`hazardSectionId`),
  CONSTRAINT `HazardReportQuestionData_ibfk_1` FOREIGN KEY (`questionId`) REFERENCES `HazardReportQuestion` (`hazardReportQuestionId`),
  CONSTRAINT `HazardReportQuestionData_ibfk_2` FOREIGN KEY (`answerId`) REFERENCES `HazardReportAnswer` (`hazardReportAnswerId`),
  CONSTRAINT `HazardReportQuestionData_ibfk_3` FOREIGN KEY (`hazardSectionId`) REFERENCES `HazardReportSection` (`sectionId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `HazardReportQuestionData`
--

LOCK TABLES `HazardReportQuestionData` WRITE;
/*!40000 ALTER TABLE `HazardReportQuestionData` DISABLE KEYS */;
/*!40000 ALTER TABLE `HazardReportQuestionData` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `HazardReportSection`
--

DROP TABLE IF EXISTS `HazardReportSection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `HazardReportSection` (
  `sectionId` int(11) NOT NULL AUTO_INCREMENT,
  `sectionName` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`sectionId`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `HazardReportSection`
--

LOCK TABLES `HazardReportSection` WRITE;
/*!40000 ALTER TABLE `HazardReportSection` DISABLE KEYS */;
INSERT INTO `HazardReportSection` VALUES (1,'hazardReport',0);
/*!40000 ALTER TABLE `HazardReportSection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `HazardReportSectionData`
--

DROP TABLE IF EXISTS `HazardReportSectionData`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `HazardReportSectionData` (
  `hazardSectionDataId` int(11) NOT NULL AUTO_INCREMENT,
  `sectionId` int(11) NOT NULL,
  `hazardReportId` int(11) NOT NULL,
  PRIMARY KEY (`hazardSectionDataId`),
  KEY `sectionId` (`sectionId`),
  KEY `hazardReportId` (`hazardReportId`),
  CONSTRAINT `HazardReportSectionData_ibfk_1` FOREIGN KEY (`sectionId`) REFERENCES `HazardReportSection` (`sectionId`),
  CONSTRAINT `HazardReportSectionData_ibfk_2` FOREIGN KEY (`hazardReportId`) REFERENCES `HazardReport` (`hazardReportId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `HazardReportSectionData`
--

LOCK TABLES `HazardReportSectionData` WRITE;
/*!40000 ALTER TABLE `HazardReportSectionData` DISABLE KEYS */;
/*!40000 ALTER TABLE `HazardReportSectionData` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `HazardReportSectionImage`
--

DROP TABLE IF EXISTS `HazardReportSectionImage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `HazardReportSectionImage` (
  `hazardSectionImageId` int(11) NOT NULL AUTO_INCREMENT,
  `hazardSectionDataId` int(11) NOT NULL,
  `documentName` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `documentKey` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`hazardSectionImageId`),
  KEY `hazardSectionDataId` (`hazardSectionDataId`),
  CONSTRAINT `HazardReportSectionImage_ibfk_1` FOREIGN KEY (`hazardSectionDataId`) REFERENCES `HazardReportSectionData` (`hazardSectionDataId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `HazardReportSectionImage`
--

LOCK TABLES `HazardReportSectionImage` WRITE;
/*!40000 ALTER TABLE `HazardReportSectionImage` DISABLE KEYS */;
/*!40000 ALTER TABLE `HazardReportSectionImage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Message`
--

DROP TABLE IF EXISTS `Message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Message` (
  `messageId` int(11) NOT NULL AUTO_INCREMENT,
  `messageTypeId` int(11) NOT NULL,
  `dateTime` datetime(3) NOT NULL,
  `messageTitle` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `messageDetails` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `buildingId` int(11) NOT NULL,
  PRIMARY KEY (`messageId`),
  KEY `messageTypeId` (`messageTypeId`),
  KEY `buildingId` (`buildingId`),
  CONSTRAINT `Message_ibfk_1` FOREIGN KEY (`messageTypeId`) REFERENCES `MessageType` (`messageTypeId`),
  CONSTRAINT `Message_ibfk_2` FOREIGN KEY (`buildingId`) REFERENCES `Building` (`buildingId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Message`
--

LOCK TABLES `Message` WRITE;
/*!40000 ALTER TABLE `Message` DISABLE KEYS */;
/*!40000 ALTER TABLE `Message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MessageType`
--

DROP TABLE IF EXISTS `MessageType`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MessageType` (
  `messageTypeId` int(11) NOT NULL AUTO_INCREMENT,
  `messageType` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`messageTypeId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MessageType`
--

LOCK TABLES `MessageType` WRITE;
/*!40000 ALTER TABLE `MessageType` DISABLE KEYS */;
/*!40000 ALTER TABLE `MessageType` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Notification`
--

DROP TABLE IF EXISTS `Notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Notification` (
  `notificationId` int(11) NOT NULL AUTO_INCREMENT,
  `messageId` int(11) DEFAULT NULL,
  `reciever` int(11) DEFAULT NULL,
  `status` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`notificationId`),
  KEY `messageId` (`messageId`),
  KEY `reciever` (`reciever`),
  CONSTRAINT `Notification_ibfk_1` FOREIGN KEY (`messageId`) REFERENCES `Message` (`messageId`),
  CONSTRAINT `Notification_ibfk_2` FOREIGN KEY (`reciever`) REFERENCES `User` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Notification`
--

LOCK TABLES `Notification` WRITE;
/*!40000 ALTER TABLE `Notification` DISABLE KEYS */;
/*!40000 ALTER TABLE `Notification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Role`
--

DROP TABLE IF EXISTS `Role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Role` (
  `roleId` int(11) NOT NULL AUTO_INCREMENT,
  `roleName` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `editHazardReportGroup` tinyint(4) NOT NULL DEFAULT '0',
  `hazardReportGroup` tinyint(4) NOT NULL DEFAULT '0',
  `authorityToEscalateGroup` tinyint(4) NOT NULL DEFAULT '0',
  `escalationGroup` tinyint(4) NOT NULL DEFAULT '0',
  `fireDrillGroup` tinyint(4) NOT NULL DEFAULT '0',
  `documentManagementGroup` tinyint(4) NOT NULL DEFAULT '0',
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`roleId`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Role`
--

LOCK TABLES `Role` WRITE;
/*!40000 ALTER TABLE `Role` DISABLE KEYS */;
INSERT INTO `Role` VALUES (1,'Leader',1,1,1,1,1,1,0),(2,'Safety & Recovery Services Section I/C',0,0,1,1,1,0,0),(3,'M&E System I/C',0,0,0,1,0,0,0),(4,'Building Section I/C',0,0,0,1,0,0,0),(5,'Cleaning Section I/C',0,0,0,0,0,0,0),(6,'Security Section I/C',0,0,0,1,0,0,0),(7,'Tenant/ Staff Liaison Section I/C',0,0,0,1,0,0,0),(8,'Office Support Section I/C',0,0,0,1,0,0,0),(9,'Other Support Staff',0,0,0,1,0,0,0),(10,'FireWarden',1,1,1,1,1,1,0);
/*!40000 ALTER TABLE `Role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Tenant`
--

DROP TABLE IF EXISTS `Tenant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Tenant` (
  `tenantId` int(11) NOT NULL AUTO_INCREMENT,
  `tenantName` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `buildingId` int(11) DEFAULT NULL,
  `editedBy` int(11) DEFAULT NULL,
  `dateTime` datetime(3) DEFAULT NULL,
  `deleted` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`tenantId`),
  KEY `buildingId` (`buildingId`),
  KEY `editedBy` (`editedBy`),
  CONSTRAINT `Tenant_ibfk_1` FOREIGN KEY (`buildingId`) REFERENCES `Building` (`buildingId`),
  CONSTRAINT `Tenant_ibfk_2` FOREIGN KEY (`editedBy`) REFERENCES `User` (`userId`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Tenant`
--

LOCK TABLES `Tenant` WRITE;
/*!40000 ALTER TABLE `Tenant` DISABLE KEYS */;
INSERT INTO `Tenant` VALUES (1,'Tenant1',1,2,'2019-03-27 14:34:15.000',0),(2,'Tenant2',2,2,'2019-03-27 15:34:15.000',0),(3,'Tenant3',3,1,'2019-04-08 11:13:15.000',0),(4,'Tenant4',4,1,'2019-04-08 12:34:15.000',0);
/*!40000 ALTER TABLE `Tenant` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TenantEmployee`
--

DROP TABLE IF EXISTS `TenantEmployee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TenantEmployee` (
  `tenantEmployeeId` int(11) NOT NULL AUTO_INCREMENT,
  `tenantEmployeeName` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tenantId` int(11) DEFAULT NULL,
  `title` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `editedBy` int(11) DEFAULT NULL,
  `dateTime` datetime(3) DEFAULT NULL,
  `deleted` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`tenantEmployeeId`),
  KEY `editedBy` (`editedBy`),
  KEY `tenantId` (`tenantId`),
  CONSTRAINT `TenantEmployee_ibfk_1` FOREIGN KEY (`tenantId`) REFERENCES `Tenant` (`tenantId`),
  CONSTRAINT `TenantEmployee_ibfk_2` FOREIGN KEY (`editedBy`) REFERENCES `User` (`userId`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TenantEmployee`
--

LOCK TABLES `TenantEmployee` WRITE;
/*!40000 ALTER TABLE `TenantEmployee` DISABLE KEYS */;
INSERT INTO `TenantEmployee` VALUES (1,'TenantEmployee1',1,'TenantHead',2,'2019-03-27 15:37:12.000',0),(2,'TenantEmployee2',2,'TenantAssistant',2,'2019-03-27 15:39:12.000',0),(3,'TenantEmployee3',3,'TenantAssistant3',1,'2019-04-08 10:14:19.000',0),(4,'TenantEmployee4',4,'TenantAssistant4',1,'2019-04-08 10:14:19.000',0),(5,'TenantEmployee5',1,'TenantEmployeeStaff',1,'2019-04-08 10:14:19.000',0),(6,'TenantEmployee6',1,'TenantEmployeeStaff',1,'2019-04-08 10:14:19.000',0),(7,'TenantEmployee7',1,'TenantEmployeeStaff',1,'2019-04-08 10:14:19.000',0),(8,'TenantEmployee8',1,'TenantEmployeeStaff',3,'2019-04-08 10:14:19.000',0);
/*!40000 ALTER TABLE `TenantEmployee` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `User`
--

DROP TABLE IF EXISTS `User`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `User` (
  `userId` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `displayName` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pushNotificationToken` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `profileImage` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tenantEmployeeId` int(11) DEFAULT NULL,
  `phoneNumber` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notification` tinyint(1) DEFAULT '1',
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`userId`),
  UNIQUE KEY `username_UNIQUE` (`username`),
  KEY `tenantEmployeeId` (`tenantEmployeeId`),
  CONSTRAINT `User_ibfk_1` FOREIGN KEY (`tenantEmployeeId`) REFERENCES `TenantEmployee` (`tenantEmployeeId`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `User`
--

LOCK TABLES `User` WRITE;
/*!40000 ALTER TABLE `User` DISABLE KEYS */;
INSERT INTO `User` VALUES (1,'user001','Cheng Su Chen','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','title1','user01@gmail.com',NULL,'test/userprofileimage/0001_1554447768518.jpeg',1,'98554069',1,0),(2,'user002','Heng Tze Kiang','$2a$10$JTKqCBDs.fRCWSY/RU2kguoF1xxn0huTkhfr1QUes9rA6sa4kwRqa','title2','user02@gmail.com',NULL,'test/userprofileimage/0001_1554453985262.jpeg',2,'97995746',1,0),(3,'user003','Christopher Loh','$2a$10$N3Mj1Q6kiKf84Z3nb2fdRubj4Eeg/Qw68JfYWe9c7PSN0GamPuDi6','title3','user03@gmail.com',NULL,'test/userprofileimage/0001_1554374300010.jpeg',1,'82002261',1,0),(4,'user004','Sunny Tan','$2a$10$X9a1lKWgUpsC78SiGPa8beZU8sitIsEcUAA76lpHkLwm4ElMShn3.','title4','user04@gmail.com',NULL,'default_image.jpeg',2,'97333632',1,0),(5,'user005','Maria Chyril','',NULL,'',NULL,NULL,NULL,'82019041',1,0),(6,'user006','Asen Chow','',NULL,'',NULL,NULL,NULL,'97913488',1,0),(7,'user007','Wilson Voon','',NULL,'',NULL,NULL,NULL,'98508971',1,0),(8,'user008','Fong Siew Cheong','',NULL,'',NULL,NULL,NULL,'96801398',1,0),(9,'user009','Lawrence Wu','',NULL,'',NULL,NULL,NULL,'91111253',1,0),(10,'user010','Sam Tan','',NULL,'',NULL,NULL,NULL,'93671215',1,0),(11,'user011','Hemalatha','',NULL,'',NULL,NULL,NULL,'96566972',1,0),(12,'user012','Patrik Poh','',NULL,'',NULL,NULL,NULL,'97422568',1,0),(13,'user013','David Tay','',NULL,'',NULL,NULL,NULL,'90051757',1,0),(14,'user014','Jenny Tan','',NULL,'',NULL,NULL,NULL,'97610551',1,0),(15,'user015','Satwant Singh','',NULL,'',NULL,NULL,NULL,'64485606',1,0),(16,'user016','Christopher Loh','',NULL,'',NULL,NULL,NULL,'82002261',1,0),(17,'user017','Simon Lim','',NULL,'',NULL,NULL,NULL,'98776159',1,0),(18,'user018','Barry Chong','',NULL,'',NULL,NULL,NULL,'90068268',1,0),(19,'user019','Png Chiew Hoon','',NULL,'',NULL,NULL,NULL,'64489262',1,0),(20,'user020','Amy Foo','',NULL,'',NULL,NULL,NULL,'93362609',1,0),(21,'user021','Dylan Wong','',NULL,'',NULL,NULL,NULL,'91776058',1,0),(22,'user022','Christina Goh','',NULL,'',NULL,NULL,NULL,'96835044',1,0),(23,'user023','Chelsia Chan','',NULL,'',NULL,NULL,NULL,'97583921',1,0),(24,'user024','Catherine Ng','',NULL,'',NULL,NULL,NULL,'91502754',1,0),(25,'user025','Alicia Tay','',NULL,'',NULL,NULL,NULL,'91013182',1,0),(26,'user026','R Sakinah','',NULL,'',NULL,NULL,NULL,'82004746',1,0),(27,'user027','Michelle lau','',NULL,'',NULL,NULL,NULL,'97614573',1,0),(28,'user028','Wong Wei Ting','',NULL,'',NULL,NULL,NULL,'97382007',1,0),(29,'user029','Alvin Loke','',NULL,'',NULL,NULL,NULL,'90210956',1,0),(30,'user030','Jaslyn Lau','',NULL,'',NULL,NULL,NULL,'97428177',1,0);
/*!40000 ALTER TABLE `User` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'FSA'
--

--
-- Dumping routines for database 'FSA'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-04-08 19:21:14
