-- MySQL dump 10.13  Distrib 5.7.17, for macos10.12 (x86_64)
--
-- Host: 127.0.0.1    Database: FSA1
-- ------------------------------------------------------
-- Server version	5.5.5-10.1.37-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Address`
--

DROP TABLE IF EXISTS `Address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Address` (
  `addressId` int(11) NOT NULL AUTO_INCREMENT,
  `address1` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address2` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postalCode` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` varchar(75) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastUpdate` datetime NOT NULL,
  `editedBy` int(11) NOT NULL,
  PRIMARY KEY (`addressId`),
  KEY `editedBy` (`editedBy`),
  CONSTRAINT `Address_ibfk_1` FOREIGN KEY (`editedBy`) REFERENCES `User` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Address`
--

LOCK TABLES `Address` WRITE;
/*!40000 ALTER TABLE `Address` DISABLE KEYS */;
/*!40000 ALTER TABLE `Address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Building`
--

DROP TABLE IF EXISTS `Building`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Building` (
  `buildingId` int(11) NOT NULL AUTO_INCREMENT,
  `addressId` int(11) NOT NULL,
  `locationId` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `numLevels` int(11) DEFAULT NULL,
  PRIMARY KEY (`buildingId`),
  KEY `addressId` (`addressId`),
  KEY `locationId` (`locationId`),
  CONSTRAINT `Building_ibfk_1` FOREIGN KEY (`addressId`) REFERENCES `Address` (`addressId`),
  CONSTRAINT `Building_ibfk_2` FOREIGN KEY (`locationId`) REFERENCES `Location` (`LocationId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Building`
--

LOCK TABLES `Building` WRITE;
/*!40000 ALTER TABLE `Building` DISABLE KEYS */;
/*!40000 ALTER TABLE `Building` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `BuildingLevel`
--

DROP TABLE IF EXISTS `BuildingLevel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `BuildingLevel` (
  `buildingLevelId` int(11) NOT NULL AUTO_INCREMENT,
  `buildingId` int(11) NOT NULL,
  `levelName` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`buildingLevelId`),
  KEY `buildingId` (`buildingId`),
  CONSTRAINT `BuildingLevel_ibfk_1` FOREIGN KEY (`buildingId`) REFERENCES `Building` (`buildingId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BuildingLevel`
--

LOCK TABLES `BuildingLevel` WRITE;
/*!40000 ALTER TABLE `BuildingLevel` DISABLE KEYS */;
/*!40000 ALTER TABLE `BuildingLevel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `BuildingRole`
--

DROP TABLE IF EXISTS `BuildingRole`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `BuildingRole` (
  `buildindRoleId` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `buildingId` int(11) NOT NULL,
  `roleId` int(11) NOT NULL,
  PRIMARY KEY (`buildindRoleId`),
  KEY `userId` (`userId`),
  KEY `buildingId` (`buildingId`),
  KEY `roleId` (`roleId`),
  CONSTRAINT `BuildingRole_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `User` (`userId`),
  CONSTRAINT `BuildingRole_ibfk_2` FOREIGN KEY (`buildingId`) REFERENCES `Building` (`buildingId`),
  CONSTRAINT `BuildingRole_ibfk_3` FOREIGN KEY (`roleId`) REFERENCES `Role` (`roleId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BuildingRole`
--

LOCK TABLES `BuildingRole` WRITE;
/*!40000 ALTER TABLE `BuildingRole` DISABLE KEYS */;
/*!40000 ALTER TABLE `BuildingRole` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Certification`
--

DROP TABLE IF EXISTS `Certification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Certification` (
  `certificationId` int(11) NOT NULL AUTO_INCREMENT,
  `certificationName` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expirationDate` datetime NOT NULL,
  `buildingId` int(11) NOT NULL,
  `document` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`certificationId`),
  KEY `buildingId` (`buildingId`),
  CONSTRAINT `Certification_ibfk_1` FOREIGN KEY (`buildingId`) REFERENCES `Building` (`buildingId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Certification`
--

LOCK TABLES `Certification` WRITE;
/*!40000 ALTER TABLE `Certification` DISABLE KEYS */;
/*!40000 ALTER TABLE `Certification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Drawings`
--

DROP TABLE IF EXISTS `Drawings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Drawings` (
  `drawingId` int(11) NOT NULL AUTO_INCREMENT,
  `drawingName` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `levelId` int(11) NOT NULL,
  `editedBy` int(11) DEFAULT NULL,
  `dateTime` datetime NOT NULL,
  `delete` tinyint(4) DEFAULT '0',
  `document` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`drawingId`),
  KEY `editedBy` (`editedBy`),
  KEY `levelId` (`levelId`),
  CONSTRAINT `Drawings_ibfk_1` FOREIGN KEY (`editedBy`) REFERENCES `User` (`userId`),
  CONSTRAINT `Drawings_ibfk_2` FOREIGN KEY (`levelId`) REFERENCES `BuildingLevel` (`buildingLevelId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Drawings`
--

LOCK TABLES `Drawings` WRITE;
/*!40000 ALTER TABLE `Drawings` DISABLE KEYS */;
/*!40000 ALTER TABLE `Drawings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ERP`
--

DROP TABLE IF EXISTS `ERP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ERP` (
  `ERPId` int(11) NOT NULL AUTO_INCREMENT,
  `ERPname` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `buildingId` int(11) NOT NULL,
  `document` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ERPId`),
  KEY `buildingId` (`buildingId`),
  CONSTRAINT `ERP_ibfk_1` FOREIGN KEY (`buildingId`) REFERENCES `Building` (`buildingId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ERP`
--

LOCK TABLES `ERP` WRITE;
/*!40000 ALTER TABLE `ERP` DISABLE KEYS */;
/*!40000 ALTER TABLE `ERP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EmergencyData`
--

DROP TABLE IF EXISTS `EmergencyData`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `EmergencyData` (
  `emergencyDataId` int(11) NOT NULL AUTO_INCREMENT,
  `emergencyDataName` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `levelId` int(11) NOT NULL,
  `editedBy` int(11) NOT NULL,
  `dateTime` datetime NOT NULL,
  `delete` tinyint(4) DEFAULT '0',
  `document` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`emergencyDataId`),
  KEY `editedBy` (`editedBy`),
  KEY `levelId` (`levelId`),
  CONSTRAINT `EmergencyData_ibfk_1` FOREIGN KEY (`editedBy`) REFERENCES `User` (`userId`),
  CONSTRAINT `EmergencyData_ibfk_2` FOREIGN KEY (`levelId`) REFERENCES `BuildingLevel` (`buildingLevelId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EmergencyData`
--

LOCK TABLES `EmergencyData` WRITE;
/*!40000 ALTER TABLE `EmergencyData` DISABLE KEYS */;
/*!40000 ALTER TABLE `EmergencyData` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Escalation`
--

DROP TABLE IF EXISTS `Escalation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Escalation` (
  `escalationId` int(11) NOT NULL AUTO_INCREMENT,
  `buildingId` int(11) NOT NULL,
  `dateTime` datetime NOT NULL,
  `reporter` int(11) NOT NULL,
  `lastUpdate` datetime NOT NULL,
  `status` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `completeDateTime` datetime DEFAULT NULL,
  PRIMARY KEY (`escalationId`),
  KEY `reporter` (`reporter`),
  KEY `buildingId` (`buildingId`),
  CONSTRAINT `Escalation_ibfk_1` FOREIGN KEY (`reporter`) REFERENCES `User` (`userId`),
  CONSTRAINT `Escalation_ibfk_2` FOREIGN KEY (`buildingId`) REFERENCES `Building` (`buildingId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Escalation`
--

LOCK TABLES `Escalation` WRITE;
/*!40000 ALTER TABLE `Escalation` DISABLE KEYS */;
/*!40000 ALTER TABLE `Escalation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EscalationAttandance`
--

DROP TABLE IF EXISTS `EscalationAttandance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `EscalationAttandance` (
  `escalationAttandanceId` int(11) NOT NULL,
  `escalationId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `status` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`escalationAttandanceId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EscalationAttandance`
--

LOCK TABLES `EscalationAttandance` WRITE;
/*!40000 ALTER TABLE `EscalationAttandance` DISABLE KEYS */;
/*!40000 ALTER TABLE `EscalationAttandance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FSC`
--

DROP TABLE IF EXISTS `FSC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `FSC` (
  `FSCId` int(11) NOT NULL AUTO_INCREMENT,
  `buildingId` int(11) NOT NULL,
  `document` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`FSCId`),
  KEY `buildingId` (`buildingId`),
  CONSTRAINT `FSC_ibfk_1` FOREIGN KEY (`buildingId`) REFERENCES `Building` (`buildingId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FSC`
--

LOCK TABLES `FSC` WRITE;
/*!40000 ALTER TABLE `FSC` DISABLE KEYS */;
/*!40000 ALTER TABLE `FSC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FireDrillAttandance`
--

DROP TABLE IF EXISTS `FireDrillAttandance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `FireDrillAttandance` (
  `fireDrillAttandanceId` int(11) NOT NULL AUTO_INCREMENT,
  `tenanatEmployeeId` int(11) DEFAULT NULL,
  `fireDrillId` int(11) DEFAULT NULL,
  `status` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`fireDrillAttandanceId`),
  KEY `tenanatEmployeeId` (`tenanatEmployeeId`),
  KEY `fireDrillId` (`fireDrillId`),
  CONSTRAINT `FireDrillAttandance_ibfk_1` FOREIGN KEY (`tenanatEmployeeId`) REFERENCES `TenantEmployee` (`tenantEmployeeId`),
  CONSTRAINT `FireDrillAttandance_ibfk_2` FOREIGN KEY (`fireDrillId`) REFERENCES `FireDrillSchedule` (`fireDrillId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FireDrillAttandance`
--

LOCK TABLES `FireDrillAttandance` WRITE;
/*!40000 ALTER TABLE `FireDrillAttandance` DISABLE KEYS */;
/*!40000 ALTER TABLE `FireDrillAttandance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FireDrillSchedule`
--

DROP TABLE IF EXISTS `FireDrillSchedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `FireDrillSchedule` (
  `fireDrillId` int(11) NOT NULL AUTO_INCREMENT,
  `buildingId` int(11) NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fireDrillTypeId` int(11) DEFAULT NULL,
  `status` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `scheduledBy` int(11) NOT NULL,
  `dateTime` datetime NOT NULL,
  `lastUpdate` datetime NOT NULL,
  `completeDateTime` datetime DEFAULT NULL,
  `delete` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`fireDrillId`),
  KEY `buildingId` (`buildingId`),
  KEY `fireDrillTypeId` (`fireDrillTypeId`),
  KEY `scheduledBy` (`scheduledBy`),
  CONSTRAINT `FireDrillSchedule_ibfk_1` FOREIGN KEY (`buildingId`) REFERENCES `Building` (`buildingId`),
  CONSTRAINT `FireDrillSchedule_ibfk_2` FOREIGN KEY (`fireDrillTypeId`) REFERENCES `FireDrillType` (`fireDrillTypeId`),
  CONSTRAINT `FireDrillSchedule_ibfk_3` FOREIGN KEY (`scheduledBy`) REFERENCES `User` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FireDrillSchedule`
--

LOCK TABLES `FireDrillSchedule` WRITE;
/*!40000 ALTER TABLE `FireDrillSchedule` DISABLE KEYS */;
/*!40000 ALTER TABLE `FireDrillSchedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FireDrillType`
--

DROP TABLE IF EXISTS `FireDrillType`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `FireDrillType` (
  `fireDrillTypeId` int(11) NOT NULL AUTO_INCREMENT,
  `fireDrillTypeName` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`fireDrillTypeId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FireDrillType`
--

LOCK TABLES `FireDrillType` WRITE;
/*!40000 ALTER TABLE `FireDrillType` DISABLE KEYS */;
/*!40000 ALTER TABLE `FireDrillType` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `HazardReport`
--

DROP TABLE IF EXISTS `HazardReport`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `HazardReport` (
  `hazardReportId` int(11) NOT NULL AUTO_INCREMENT,
  `hazardReportName` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `buildingId` int(11) NOT NULL,
  `reporterId` int(11) NOT NULL,
  `status` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dateTime` datetime NOT NULL,
  `lastUpdate` datetime NOT NULL,
  `closeReporterId` int(11) DEFAULT NULL,
  `closeComment` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`hazardReportId`),
  KEY `reporterId` (`reporterId`),
  KEY `buildingId` (`buildingId`),
  KEY `closeReporterId` (`closeReporterId`),
  CONSTRAINT `HazardReport_ibfk_1` FOREIGN KEY (`reporterId`) REFERENCES `User` (`userId`),
  CONSTRAINT `HazardReport_ibfk_2` FOREIGN KEY (`closeReporterId`) REFERENCES `User` (`userId`),
  CONSTRAINT `HazardReport_ibfk_3` FOREIGN KEY (`buildingId`) REFERENCES `Building` (`buildingId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `HazardReport`
--

LOCK TABLES `HazardReport` WRITE;
/*!40000 ALTER TABLE `HazardReport` DISABLE KEYS */;
/*!40000 ALTER TABLE `HazardReport` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `HazardReportAnswer`
--

DROP TABLE IF EXISTS `HazardReportAnswer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `HazardReportAnswer` (
  `hazardReportAnswerId` int(11) NOT NULL AUTO_INCREMENT,
  `answerText` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`hazardReportAnswerId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `HazardReportAnswer`
--

LOCK TABLES `HazardReportAnswer` WRITE;
/*!40000 ALTER TABLE `HazardReportAnswer` DISABLE KEYS */;
/*!40000 ALTER TABLE `HazardReportAnswer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `HazardReportClose`
--

DROP TABLE IF EXISTS `HazardReportClose`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `HazardReportClose` (
  `hazardReportCloseId` int(11) NOT NULL AUTO_INCREMENT,
  `hazardReportId` int(11) NOT NULL,
  `Image` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`hazardReportCloseId`),
  KEY `hazardReportId` (`hazardReportId`),
  CONSTRAINT `HazardReportClose_ibfk_1` FOREIGN KEY (`hazardReportId`) REFERENCES `HazardReport` (`hazardReportId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `HazardReportClose`
--

LOCK TABLES `HazardReportClose` WRITE;
/*!40000 ALTER TABLE `HazardReportClose` DISABLE KEYS */;
/*!40000 ALTER TABLE `HazardReportClose` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `HazardReportQuestion`
--

DROP TABLE IF EXISTS `HazardReportQuestion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `HazardReportQuestion` (
  `hazardReportQuestionId` int(11) NOT NULL AUTO_INCREMENT,
  `questionTest` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sectionId` int(11) NOT NULL,
  PRIMARY KEY (`hazardReportQuestionId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `HazardReportQuestion`
--

LOCK TABLES `HazardReportQuestion` WRITE;
/*!40000 ALTER TABLE `HazardReportQuestion` DISABLE KEYS */;
/*!40000 ALTER TABLE `HazardReportQuestion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `HazardReportQuestionData`
--

DROP TABLE IF EXISTS `HazardReportQuestionData`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `HazardReportQuestionData` (
  `hazardQuestionDataId` int(11) NOT NULL AUTO_INCREMENT,
  `questionId` int(11) NOT NULL,
  `answerId` int(11) NOT NULL,
  `observationText` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hazardSectionId` int(11) NOT NULL,
  PRIMARY KEY (`hazardQuestionDataId`),
  KEY `questionId` (`questionId`),
  KEY `answerId` (`answerId`),
  KEY `hazardSectionId` (`hazardSectionId`),
  CONSTRAINT `HazardReportQuestionData_ibfk_1` FOREIGN KEY (`questionId`) REFERENCES `HazardReportQuestion` (`hazardReportQuestionId`),
  CONSTRAINT `HazardReportQuestionData_ibfk_2` FOREIGN KEY (`answerId`) REFERENCES `HazardReportAnswer` (`hazardReportAnswerId`),
  CONSTRAINT `HazardReportQuestionData_ibfk_3` FOREIGN KEY (`hazardSectionId`) REFERENCES `HazardReportSection` (`sectionId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `HazardReportQuestionData`
--

LOCK TABLES `HazardReportQuestionData` WRITE;
/*!40000 ALTER TABLE `HazardReportQuestionData` DISABLE KEYS */;
/*!40000 ALTER TABLE `HazardReportQuestionData` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `HazardReportSection`
--

DROP TABLE IF EXISTS `HazardReportSection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `HazardReportSection` (
  `sectionId` int(11) NOT NULL AUTO_INCREMENT,
  `sectionName` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`sectionId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `HazardReportSection`
--

LOCK TABLES `HazardReportSection` WRITE;
/*!40000 ALTER TABLE `HazardReportSection` DISABLE KEYS */;
/*!40000 ALTER TABLE `HazardReportSection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `HazardReportSectionData`
--

DROP TABLE IF EXISTS `HazardReportSectionData`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `HazardReportSectionData` (
  `hazardSectionDataId` int(11) NOT NULL AUTO_INCREMENT,
  `sectionId` int(11) NOT NULL,
  `hazardReportId` int(11) NOT NULL,
  PRIMARY KEY (`hazardSectionDataId`),
  KEY `sectionId` (`sectionId`),
  KEY `hazardReportId` (`hazardReportId`),
  CONSTRAINT `HazardReportSectionData_ibfk_1` FOREIGN KEY (`sectionId`) REFERENCES `HazardReportSection` (`sectionId`),
  CONSTRAINT `HazardReportSectionData_ibfk_2` FOREIGN KEY (`hazardReportId`) REFERENCES `HazardReport` (`hazardReportId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `HazardReportSectionData`
--

LOCK TABLES `HazardReportSectionData` WRITE;
/*!40000 ALTER TABLE `HazardReportSectionData` DISABLE KEYS */;
/*!40000 ALTER TABLE `HazardReportSectionData` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `HazardReportSectionImage`
--

DROP TABLE IF EXISTS `HazardReportSectionImage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `HazardReportSectionImage` (
  `hazardSectionImageId` int(11) NOT NULL AUTO_INCREMENT,
  `hazardSectionDataId` int(11) NOT NULL,
  `image` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`hazardSectionImageId`),
  KEY `hazardSectionDataId` (`hazardSectionDataId`),
  CONSTRAINT `HazardReportSectionImage_ibfk_1` FOREIGN KEY (`hazardSectionDataId`) REFERENCES `HazardReportSectionData` (`hazardSectionDataId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `HazardReportSectionImage`
--

LOCK TABLES `HazardReportSectionImage` WRITE;
/*!40000 ALTER TABLE `HazardReportSectionImage` DISABLE KEYS */;
/*!40000 ALTER TABLE `HazardReportSectionImage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Message`
--

DROP TABLE IF EXISTS `Message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Message` (
  `messageId` int(11) NOT NULL AUTO_INCREMENT,
  `messageTypeId` int(11) NOT NULL,
  `dateTime` datetime NOT NULL,
  `messageTitle` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `messageDetails` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `buildingId` int(11) NOT NULL,
  PRIMARY KEY (`messageId`),
  KEY `messageTypeId` (`messageTypeId`),
  KEY `buildingId` (`buildingId`),
  CONSTRAINT `Message_ibfk_1` FOREIGN KEY (`messageTypeId`) REFERENCES `MessageType` (`messageTypeId`),
  CONSTRAINT `Message_ibfk_2` FOREIGN KEY (`buildingId`) REFERENCES `Building` (`buildingId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Message`
--

LOCK TABLES `Message` WRITE;
/*!40000 ALTER TABLE `Message` DISABLE KEYS */;
/*!40000 ALTER TABLE `Message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MessageType`
--

DROP TABLE IF EXISTS `MessageType`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MessageType` (
  `messageTypeId` int(11) NOT NULL AUTO_INCREMENT,
  `messageType` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`messageTypeId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MessageType`
--

LOCK TABLES `MessageType` WRITE;
/*!40000 ALTER TABLE `MessageType` DISABLE KEYS */;
/*!40000 ALTER TABLE `MessageType` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Notification`
--

DROP TABLE IF EXISTS `Notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Notification` (
  `notificationId` int(11) NOT NULL AUTO_INCREMENT,
  `messageId` int(11) DEFAULT NULL,
  `reciever` int(11) DEFAULT NULL,
  `status` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`notificationId`),
  KEY `messageId` (`messageId`),
  KEY `reciever` (`reciever`),
  CONSTRAINT `Notification_ibfk_1` FOREIGN KEY (`messageId`) REFERENCES `Message` (`messageId`),
  CONSTRAINT `Notification_ibfk_2` FOREIGN KEY (`reciever`) REFERENCES `User` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Notification`
--

LOCK TABLES `Notification` WRITE;
/*!40000 ALTER TABLE `Notification` DISABLE KEYS */;
/*!40000 ALTER TABLE `Notification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Role`
--

DROP TABLE IF EXISTS `Role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Role` (
  `roleId` int(11) NOT NULL AUTO_INCREMENT,
  `roleName` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `editHazardReportGroup` tinyint(4) NOT NULL DEFAULT '0',
  `hazardReportGroup` tinyint(4) NOT NULL DEFAULT '0',
  `authorityToEscalateGroup` tinyint(4) NOT NULL DEFAULT '0',
  `escalationGroup` tinyint(4) NOT NULL DEFAULT '0',
  `fireDrillGroup` tinyint(4) NOT NULL DEFAULT '0',
  `documentManagementGroup` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`roleId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Role`
--

LOCK TABLES `Role` WRITE;
/*!40000 ALTER TABLE `Role` DISABLE KEYS */;
/*!40000 ALTER TABLE `Role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Tenant`
--

DROP TABLE IF EXISTS `Tenant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Tenant` (
  `tenantId` int(11) NOT NULL AUTO_INCREMENT,
  `tenantName` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `buildingId` int(11) DEFAULT NULL,
  `editedBy` int(11) DEFAULT NULL,
  `dateTime` datetime DEFAULT NULL,
  `delete` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`tenantId`),
  KEY `buildingId` (`buildingId`),
  KEY `editedBy` (`editedBy`),
  CONSTRAINT `Tenant_ibfk_1` FOREIGN KEY (`buildingId`) REFERENCES `Building` (`buildingId`),
  CONSTRAINT `Tenant_ibfk_2` FOREIGN KEY (`editedBy`) REFERENCES `User` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Tenant`
--

LOCK TABLES `Tenant` WRITE;
/*!40000 ALTER TABLE `Tenant` DISABLE KEYS */;
/*!40000 ALTER TABLE `Tenant` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TenantEmployee`
--

DROP TABLE IF EXISTS `TenantEmployee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TenantEmployee` (
  `tenantEmployeeId` int(11) NOT NULL AUTO_INCREMENT,
  `tenantEmployeeName` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tenantId` int(11) DEFAULT NULL,
  `title` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `editedBy` int(11) DEFAULT NULL,
  `dateTime` datetime DEFAULT NULL,
  `delete` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`tenantEmployeeId`),
  KEY `editedBy` (`editedBy`),
  KEY `tenantId` (`tenantId`),
  CONSTRAINT `TenantEmployee_ibfk_1` FOREIGN KEY (`tenantId`) REFERENCES `Tenant` (`tenantId`),
  CONSTRAINT `TenantEmployee_ibfk_2` FOREIGN KEY (`editedBy`) REFERENCES `User` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TenantEmployee`
--

LOCK TABLES `TenantEmployee` WRITE;
/*!40000 ALTER TABLE `TenantEmployee` DISABLE KEYS */;
/*!40000 ALTER TABLE `TenantEmployee` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `User`
--

DROP TABLE IF EXISTS `User`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `User` (
  `userId` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `displayName` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pushNotificationToken` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `profileImage` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tenantEmployeeId` int(11) DEFAULT NULL,
  `phoneNumber` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `delete` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`userId`),
  UNIQUE KEY `username_UNIQUE` (`username`),
  KEY `tenantEmployeeId` (`tenantEmployeeId`),
  CONSTRAINT `User_ibfk_1` FOREIGN KEY (`tenantEmployeeId`) REFERENCES `TenantEmployee` (`tenantEmployeeId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `User`
--

LOCK TABLES `User` WRITE;
/*!40000 ALTER TABLE `User` DISABLE KEYS */;
/*!40000 ALTER TABLE `User` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'FSA1'
--

--
-- Dumping routines for database 'FSA1'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-03-25 10:37:51
