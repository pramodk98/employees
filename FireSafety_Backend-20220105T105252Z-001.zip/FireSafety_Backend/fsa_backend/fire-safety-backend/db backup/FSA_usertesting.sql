-- MySQL dump 10.13  Distrib 5.7.17, for macos10.12 (x86_64)
--
-- Host: 127.0.0.1    Database: FSA1
-- ------------------------------------------------------
-- Server version	5.5.5-10.1.37-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Building`
--

DROP TABLE IF EXISTS `Building`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Building` (
  `buildingId` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `numLevels` int(11) DEFAULT NULL,
  `latitude` double NOT NULL,
  `longtitude` double NOT NULL,
  `address1` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address2` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postalCode` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` varchar(75) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastUpdate` datetime(3) NOT NULL,
  `editedBy` int(11) NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`buildingId`),
  KEY `editedBy` (`editedBy`),
  CONSTRAINT `Building_ibfk_1` FOREIGN KEY (`editedBy`) REFERENCES `User` (`userId`),
  CONSTRAINT `FK7r17nbaomjto3q5btmsyx2q1m` FOREIGN KEY (`editedBy`) REFERENCES `User` (`userId`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Building`
--

LOCK TABLES `Building` WRITE;
/*!40000 ALTER TABLE `Building` DISABLE KEYS */;
INSERT INTO `Building` VALUES (5,'Institute of Materials Research and Engineering',4,1.2983869,103.7880998,'2 Fusionopolis Way',NULL,'138634','Singapore','2019-05-10 12:11:14.000',51,0),(6,'Singapore Institute of Manufacturing Technology ',4,1.2984136,103.7865168,'2 Fusionopolis Way',NULL,'138634','Singapore','2019-05-10 12:11:14.000',51,0),(7,'Model Factory@SIMTech ',4,1.2986742,103.7884495,'6 Fusionopolis Way','#01-06 Synthesis','138636','Singapore','2019-05-10 12:11:14.000',51,0),(8,'A*STAR',17,1.2996113,103.7877311,'1 Fusionopolis Way','#20-10 Connexis, North Tower','138632','Singapore','2019-05-10 12:11:14.000',51,0),(9,'Kinesis',4,1.2981239,103.7891073,'4 Fusionopolis Way',NULL,'138635','Singapore','2019-05-10 12:11:14.000',51,0);
/*!40000 ALTER TABLE `Building` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `BuildingLevel`
--

DROP TABLE IF EXISTS `BuildingLevel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `BuildingLevel` (
  `buildingLevelId` int(11) NOT NULL AUTO_INCREMENT,
  `buildingId` int(11) NOT NULL,
  `levelName` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`buildingLevelId`),
  KEY `buildingId` (`buildingId`),
  CONSTRAINT `BuildingLevel_ibfk_1` FOREIGN KEY (`buildingId`) REFERENCES `Building` (`buildingId`),
  CONSTRAINT `FKrebts4ub7bcxfsos932x19f6f` FOREIGN KEY (`buildingId`) REFERENCES `Building` (`buildingId`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BuildingLevel`
--

LOCK TABLES `BuildingLevel` WRITE;
/*!40000 ALTER TABLE `BuildingLevel` DISABLE KEYS */;
INSERT INTO `BuildingLevel` VALUES (1,8,'1',0),(2,8,'2',0),(3,8,'3',0),(4,8,'4',0),(5,8,'5',0),(6,8,'6',0),(7,8,'7',0),(8,8,'8',0),(9,8,'9',0),(10,8,'10',0),(11,8,'11',0),(12,8,'12',0),(13,8,'13',0),(14,8,'14',0),(15,8,'15',0),(16,8,'16',0),(17,8,'17',0),(18,9,'1',0),(19,9,'2',0),(20,9,'3',0);
/*!40000 ALTER TABLE `BuildingLevel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `BuildingRole`
--

DROP TABLE IF EXISTS `BuildingRole`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `BuildingRole` (
  `buildingRoleId` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `buildingId` int(11) NOT NULL,
  `roleId` int(11) NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`buildingRoleId`),
  KEY `userId` (`userId`),
  KEY `buildingId` (`buildingId`),
  KEY `roleId` (`roleId`),
  CONSTRAINT `BuildingRole_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `User` (`userId`),
  CONSTRAINT `BuildingRole_ibfk_2` FOREIGN KEY (`buildingId`) REFERENCES `Building` (`buildingId`),
  CONSTRAINT `BuildingRole_ibfk_3` FOREIGN KEY (`roleId`) REFERENCES `Role` (`roleId`),
  CONSTRAINT `FKajovm66ag9im10bdo30hpn7st` FOREIGN KEY (`roleId`) REFERENCES `Role` (`roleId`),
  CONSTRAINT `FKq6podpeh0d0n3tsdgc6om4b2l` FOREIGN KEY (`userId`) REFERENCES `User` (`userId`),
  CONSTRAINT `FKt05ihs1e2tut958ac3iakpinc` FOREIGN KEY (`buildingId`) REFERENCES `Building` (`buildingId`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BuildingRole`
--

LOCK TABLES `BuildingRole` WRITE;
/*!40000 ALTER TABLE `BuildingRole` DISABLE KEYS */;
INSERT INTO `BuildingRole` VALUES (1,80,9,2,0),(2,81,9,2,0),(3,82,9,2,0),(4,83,9,2,0),(5,84,9,2,0),(6,85,8,4,0),(7,41,8,2,0),(8,41,9,3,0),(9,43,8,2,0),(10,43,9,1,0),(11,46,8,1,0),(12,46,9,2,0),(13,85,9,1,0);
/*!40000 ALTER TABLE `BuildingRole` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Certification`
--

DROP TABLE IF EXISTS `Certification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Certification` (
  `certificationId` int(11) NOT NULL AUTO_INCREMENT,
  `expirationDate` datetime(3) NOT NULL,
  `buildingId` int(11) NOT NULL,
  `documentName` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `documentKey` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`certificationId`),
  KEY `buildingId` (`buildingId`),
  CONSTRAINT `Certification_ibfk_1` FOREIGN KEY (`buildingId`) REFERENCES `Building` (`buildingId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Certification`
--

LOCK TABLES `Certification` WRITE;
/*!40000 ALTER TABLE `Certification` DISABLE KEYS */;
/*!40000 ALTER TABLE `Certification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Configurations`
--

DROP TABLE IF EXISTS `Configurations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Configurations` (
  `configurationId` int(11) NOT NULL AUTO_INCREMENT,
  `trainingName` varchar(100) DEFAULT NULL,
  `trainingURL` varchar(255) DEFAULT NULL,
  `document` varchar(100) DEFAULT NULL,
  `lastUpdate` datetime(3) NOT NULL,
  `editedBy` varchar(45) NOT NULL,
  PRIMARY KEY (`configurationId`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Configurations`
--

LOCK TABLES `Configurations` WRITE;
/*!40000 ALTER TABLE `Configurations` DISABLE KEYS */;
INSERT INTO `Configurations` VALUES (1,'cnwWeb','https://www.cwservices.sg/',NULL,'2019-03-27 12:31:11.000','1');
/*!40000 ALTER TABLE `Configurations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Drawings`
--

DROP TABLE IF EXISTS `Drawings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Drawings` (
  `drawingId` int(11) NOT NULL AUTO_INCREMENT,
  `levelId` int(11) NOT NULL,
  `editedBy` int(11) DEFAULT NULL,
  `dateTime` datetime(3) NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `documentKey` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `documentName` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`drawingId`),
  KEY `editedBy` (`editedBy`),
  KEY `levelId` (`levelId`),
  CONSTRAINT `Drawings_ibfk_1` FOREIGN KEY (`editedBy`) REFERENCES `User` (`userId`),
  CONSTRAINT `Drawings_ibfk_2` FOREIGN KEY (`levelId`) REFERENCES `BuildingLevel` (`buildingLevelId`),
  CONSTRAINT `FKi2wc0kbwme6io188hqy2wykbj` FOREIGN KEY (`levelId`) REFERENCES `BuildingLevel` (`buildingLevelId`),
  CONSTRAINT `FKkmd36ahacj6jr8dclpwya27se` FOREIGN KEY (`editedBy`) REFERENCES `User` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Drawings`
--

LOCK TABLES `Drawings` WRITE;
/*!40000 ALTER TABLE `Drawings` DISABLE KEYS */;
/*!40000 ALTER TABLE `Drawings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ERP`
--

DROP TABLE IF EXISTS `ERP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ERP` (
  `erpId` int(11) NOT NULL AUTO_INCREMENT,
  `buildingId` int(11) NOT NULL,
  `documentName` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `documentKey` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`erpId`),
  KEY `buildingId` (`buildingId`),
  CONSTRAINT `ERP_ibfk_1` FOREIGN KEY (`buildingId`) REFERENCES `Building` (`buildingId`),
  CONSTRAINT `FKn0fsdxf9e8sb2t87cwqlapcgi` FOREIGN KEY (`buildingId`) REFERENCES `Building` (`buildingId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ERP`
--

LOCK TABLES `ERP` WRITE;
/*!40000 ALTER TABLE `ERP` DISABLE KEYS */;
/*!40000 ALTER TABLE `ERP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EmergencyData`
--

DROP TABLE IF EXISTS `EmergencyData`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `EmergencyData` (
  `emergencyDataId` int(11) NOT NULL AUTO_INCREMENT,
  `documentName` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `documentKey` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `levelId` int(11) NOT NULL,
  `editedBy` int(11) NOT NULL,
  `dateTime` datetime(3) NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`emergencyDataId`),
  KEY `editedBy` (`editedBy`),
  KEY `levelId` (`levelId`),
  CONSTRAINT `EmergencyData_ibfk_1` FOREIGN KEY (`editedBy`) REFERENCES `User` (`userId`),
  CONSTRAINT `EmergencyData_ibfk_2` FOREIGN KEY (`levelId`) REFERENCES `BuildingLevel` (`buildingLevelId`),
  CONSTRAINT `FKdsmeykrixv0r0kgceharmvhin` FOREIGN KEY (`levelId`) REFERENCES `BuildingLevel` (`buildingLevelId`),
  CONSTRAINT `FKpgt9kw4enaj4dhy2g1yaq1wh1` FOREIGN KEY (`editedBy`) REFERENCES `User` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EmergencyData`
--

LOCK TABLES `EmergencyData` WRITE;
/*!40000 ALTER TABLE `EmergencyData` DISABLE KEYS */;
/*!40000 ALTER TABLE `EmergencyData` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Escalation`
--

DROP TABLE IF EXISTS `Escalation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Escalation` (
  `escalationId` int(11) NOT NULL AUTO_INCREMENT,
  `buildingId` int(11) NOT NULL,
  `dateTime` datetime(3) NOT NULL,
  `reporter` int(11) NOT NULL,
  `lastUpdate` datetime(3) NOT NULL,
  `status` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `completeDateTime` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`escalationId`),
  KEY `reporter` (`reporter`),
  KEY `buildingId` (`buildingId`),
  CONSTRAINT `Escalation_ibfk_1` FOREIGN KEY (`reporter`) REFERENCES `User` (`userId`),
  CONSTRAINT `Escalation_ibfk_2` FOREIGN KEY (`buildingId`) REFERENCES `Building` (`buildingId`),
  CONSTRAINT `FK18mneqem07vh86hunbxggj8vb` FOREIGN KEY (`reporter`) REFERENCES `User` (`userId`),
  CONSTRAINT `FK9pa728b45g6l44e11v7k0mita` FOREIGN KEY (`buildingId`) REFERENCES `Building` (`buildingId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Escalation`
--

LOCK TABLES `Escalation` WRITE;
/*!40000 ALTER TABLE `Escalation` DISABLE KEYS */;
/*!40000 ALTER TABLE `Escalation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EscalationAttendance`
--

DROP TABLE IF EXISTS `EscalationAttendance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `EscalationAttendance` (
  `escalationAttendanceId` int(11) NOT NULL AUTO_INCREMENT,
  `escalationId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `status` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`escalationAttendanceId`),
  KEY `FKll6b2j7ovsbjselghi4lqikwi` (`userId`),
  KEY `FKmjxq7drymkui0eevx32qjclbr` (`escalationId`),
  CONSTRAINT `FKll6b2j7ovsbjselghi4lqikwi` FOREIGN KEY (`userId`) REFERENCES `User` (`userId`),
  CONSTRAINT `FKmjxq7drymkui0eevx32qjclbr` FOREIGN KEY (`escalationId`) REFERENCES `Escalation` (`escalationId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EscalationAttendance`
--

LOCK TABLES `EscalationAttendance` WRITE;
/*!40000 ALTER TABLE `EscalationAttendance` DISABLE KEYS */;
/*!40000 ALTER TABLE `EscalationAttendance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FSC`
--

DROP TABLE IF EXISTS `FSC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `FSC` (
  `fscId` int(11) NOT NULL AUTO_INCREMENT,
  `buildingId` int(11) NOT NULL,
  `documentName` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `documentKey` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`fscId`),
  KEY `buildingId` (`buildingId`),
  CONSTRAINT `FSC_ibfk_1` FOREIGN KEY (`buildingId`) REFERENCES `Building` (`buildingId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FSC`
--

LOCK TABLES `FSC` WRITE;
/*!40000 ALTER TABLE `FSC` DISABLE KEYS */;
/*!40000 ALTER TABLE `FSC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FireDrillAttendance`
--

DROP TABLE IF EXISTS `FireDrillAttendance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `FireDrillAttendance` (
  `fireDrillAttendanceId` int(11) NOT NULL AUTO_INCREMENT,
  `tenantEmployeeId` int(11) DEFAULT NULL,
  `fireDrillId` int(11) DEFAULT NULL,
  `status` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`fireDrillAttendanceId`),
  KEY `tenantEmployeeId` (`tenantEmployeeId`),
  KEY `fireDrillId` (`fireDrillId`),
  CONSTRAINT `FKmvhk63iltb23vieoga0ohpoap` FOREIGN KEY (`fireDrillId`) REFERENCES `FireDrillSchedule` (`fireDrillId`),
  CONSTRAINT `FKn9xj7qtbxegpsqjvgvh7hsj4p` FOREIGN KEY (`tenantEmployeeId`) REFERENCES `TenantEmployee` (`tenantEmployeeId`),
  CONSTRAINT `FireDrillAttandence_ibfk_2` FOREIGN KEY (`fireDrillId`) REFERENCES `FireDrillSchedule` (`fireDrillId`),
  CONSTRAINT `FireDrillAttendance_ibfk_1` FOREIGN KEY (`tenantEmployeeId`) REFERENCES `TenantEmployee` (`tenantEmployeeId`)
) ENGINE=InnoDB AUTO_INCREMENT=954 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FireDrillAttendance`
--

LOCK TABLES `FireDrillAttendance` WRITE;
/*!40000 ALTER TABLE `FireDrillAttendance` DISABLE KEYS */;
INSERT INTO `FireDrillAttendance` VALUES (1,220,1,'absent'),(2,221,1,'absent'),(3,222,1,'absent'),(4,223,1,'absent'),(5,224,1,'absent'),(6,225,1,'absent'),(7,226,1,'absent'),(8,227,1,'absent'),(9,228,1,'absent'),(10,229,1,'absent'),(11,230,1,'absent'),(12,231,1,'absent'),(13,232,1,'absent'),(14,233,1,'absent'),(15,234,1,'absent'),(16,235,1,'absent'),(17,236,1,'absent'),(18,237,1,'absent'),(19,238,1,'absent'),(20,239,1,'absent'),(21,240,1,'absent'),(22,241,1,'absent'),(23,242,1,'absent'),(24,243,1,'absent'),(25,244,1,'absent'),(26,245,1,'absent'),(27,246,1,'absent'),(28,247,1,'absent'),(29,248,1,'absent'),(30,249,1,'absent'),(31,250,1,'absent'),(32,251,1,'absent'),(33,252,1,'absent'),(34,253,1,'absent'),(35,254,1,'absent'),(36,255,1,'absent'),(37,256,1,'absent'),(38,257,1,'absent'),(39,258,1,'absent'),(40,259,1,'absent'),(41,260,1,'absent'),(42,261,1,'absent'),(43,262,1,'absent'),(44,263,1,'absent'),(45,264,1,'absent'),(46,265,1,'absent'),(47,266,1,'absent'),(48,267,1,'absent'),(49,268,1,'absent'),(50,269,1,'absent'),(51,270,1,'absent'),(52,271,1,'absent'),(53,272,1,'absent'),(54,273,1,'absent'),(55,274,1,'absent'),(56,275,1,'absent'),(57,276,1,'absent'),(58,277,1,'absent'),(59,278,1,'absent'),(60,279,1,'absent'),(61,280,1,'absent'),(62,281,1,'absent'),(63,282,1,'absent'),(64,283,1,'absent'),(65,284,1,'absent'),(66,285,1,'absent'),(67,286,1,'absent'),(68,287,1,'absent'),(69,288,1,'absent'),(70,289,1,'absent'),(71,290,1,'absent'),(72,291,1,'absent'),(73,292,1,'absent'),(74,293,1,'absent'),(75,294,1,'absent'),(76,295,1,'absent'),(77,296,1,'absent'),(78,297,1,'absent'),(79,298,1,'absent'),(80,299,1,'absent'),(81,300,1,'absent'),(82,301,1,'absent'),(83,302,1,'absent'),(84,303,1,'absent'),(85,304,1,'absent'),(86,305,1,'absent'),(87,306,1,'absent'),(88,307,1,'absent'),(89,308,1,'absent'),(90,309,1,'absent'),(91,310,1,'absent'),(92,311,1,'absent'),(93,312,1,'absent'),(94,313,1,'absent'),(95,314,1,'absent'),(96,315,1,'absent'),(97,316,1,'absent'),(98,317,1,'absent'),(99,318,1,'absent'),(100,319,1,'absent'),(101,320,1,'absent'),(102,321,1,'absent'),(103,322,1,'absent'),(104,323,1,'absent'),(105,324,1,'absent'),(106,325,1,'absent'),(107,326,1,'absent'),(108,327,1,'absent'),(109,328,1,'absent'),(110,329,1,'absent'),(111,330,1,'absent'),(112,331,1,'absent'),(113,332,1,'absent'),(114,333,1,'absent'),(115,334,1,'absent'),(116,335,1,'absent'),(117,336,1,'absent'),(118,337,1,'absent'),(119,338,1,'absent'),(120,339,1,'absent'),(121,340,1,'absent'),(122,341,1,'absent'),(123,342,1,'absent'),(124,343,1,'absent'),(125,344,1,'absent'),(126,345,1,'absent'),(127,346,1,'absent'),(128,347,1,'absent'),(129,348,1,'absent'),(130,349,1,'absent'),(131,350,1,'absent'),(132,351,1,'absent'),(133,352,1,'absent'),(134,353,1,'absent'),(135,220,2,'absent'),(136,221,2,'absent'),(137,222,2,'absent'),(138,223,2,'absent'),(139,224,2,'absent'),(140,225,2,'absent'),(141,226,2,'absent'),(142,227,2,'absent'),(143,228,2,'absent'),(144,229,2,'absent'),(145,230,2,'absent'),(146,231,2,'absent'),(147,232,2,'absent'),(148,233,2,'absent'),(149,234,2,'absent'),(150,235,2,'absent'),(151,236,2,'absent'),(152,237,2,'absent'),(153,238,2,'absent'),(154,239,2,'absent'),(155,240,2,'absent'),(156,241,2,'absent'),(157,242,2,'absent'),(158,243,2,'absent'),(159,244,2,'absent'),(160,245,2,'absent'),(161,246,2,'absent'),(162,247,2,'absent'),(163,248,2,'absent'),(164,249,2,'absent'),(165,250,2,'absent'),(166,251,2,'absent'),(167,252,2,'absent'),(168,253,2,'absent'),(169,254,2,'absent'),(170,255,2,'absent'),(171,256,2,'absent'),(172,257,2,'absent'),(173,258,2,'absent'),(174,259,2,'absent'),(175,260,2,'absent'),(176,261,2,'absent'),(177,262,2,'absent'),(178,263,2,'absent'),(179,264,2,'absent'),(180,265,2,'absent'),(181,266,2,'absent'),(182,267,2,'absent'),(183,268,2,'absent'),(184,269,2,'absent'),(185,270,2,'absent'),(186,271,2,'absent'),(187,272,2,'absent'),(188,273,2,'absent'),(189,274,2,'absent'),(190,275,2,'absent'),(191,276,2,'absent'),(192,277,2,'absent'),(193,278,2,'absent'),(194,279,2,'absent'),(195,280,2,'absent'),(196,281,2,'absent'),(197,282,2,'absent'),(198,283,2,'absent'),(199,284,2,'absent'),(200,285,2,'absent'),(201,286,2,'absent'),(202,287,2,'absent'),(203,288,2,'absent'),(204,289,2,'absent'),(205,290,2,'absent'),(206,291,2,'absent'),(207,292,2,'absent'),(208,293,2,'absent'),(209,294,2,'absent'),(210,295,2,'absent'),(211,296,2,'absent'),(212,297,2,'absent'),(213,298,2,'absent'),(214,299,2,'absent'),(215,300,2,'absent'),(216,301,2,'absent'),(217,302,2,'absent'),(218,303,2,'absent'),(219,304,2,'absent'),(220,305,2,'absent'),(221,306,2,'absent'),(222,307,2,'absent'),(223,308,2,'absent'),(224,309,2,'absent'),(225,310,2,'absent'),(226,311,2,'absent'),(227,312,2,'absent'),(228,313,2,'absent'),(229,314,2,'absent'),(230,315,2,'absent'),(231,316,2,'absent'),(232,317,2,'absent'),(233,318,2,'absent'),(234,319,2,'absent'),(235,320,2,'absent'),(236,321,2,'absent'),(237,322,2,'absent'),(238,323,2,'absent'),(239,324,2,'absent'),(240,325,2,'absent'),(241,326,2,'absent'),(242,327,2,'absent'),(243,328,2,'absent'),(244,329,2,'absent'),(245,330,2,'absent'),(246,331,2,'absent'),(247,332,2,'absent'),(248,333,2,'absent'),(249,334,2,'absent'),(250,335,2,'absent'),(251,336,2,'absent'),(252,337,2,'absent'),(253,338,2,'absent'),(254,339,2,'absent'),(255,340,2,'absent'),(256,341,2,'absent'),(257,342,2,'absent'),(258,343,2,'absent'),(259,344,2,'absent'),(260,345,2,'absent'),(261,346,2,'absent'),(262,347,2,'absent'),(263,348,2,'absent'),(264,349,2,'absent'),(265,350,2,'absent'),(266,351,2,'absent'),(267,352,2,'absent'),(268,353,2,'absent'),(269,354,3,'absent'),(270,355,3,'absent'),(271,356,3,'absent'),(272,357,3,'absent'),(273,358,3,'absent'),(274,359,3,'absent'),(275,360,3,'absent'),(276,361,3,'absent'),(277,362,3,'absent'),(278,363,3,'absent'),(279,364,3,'absent'),(280,365,3,'absent'),(281,366,3,'absent'),(282,367,3,'absent'),(283,368,3,'absent'),(284,369,3,'absent'),(285,370,3,'absent'),(286,371,3,'absent'),(287,372,3,'absent'),(288,373,3,'absent'),(289,374,3,'absent'),(290,375,3,'absent'),(291,376,3,'absent'),(292,377,3,'absent'),(293,378,3,'absent'),(294,379,3,'absent'),(295,380,3,'absent'),(296,381,3,'absent'),(297,382,3,'absent'),(298,383,3,'absent'),(299,384,3,'absent'),(300,385,3,'absent'),(301,386,3,'absent'),(302,387,3,'absent'),(303,388,3,'absent'),(304,389,3,'absent'),(305,390,3,'absent'),(306,391,3,'absent'),(307,392,3,'absent'),(308,393,3,'absent'),(309,394,3,'absent'),(310,395,3,'absent'),(311,396,3,'absent'),(312,397,3,'absent'),(313,398,3,'absent'),(314,399,3,'absent'),(315,400,3,'absent'),(316,401,3,'absent'),(317,402,3,'absent'),(318,403,3,'absent'),(319,404,3,'absent'),(320,405,3,'absent'),(321,406,3,'absent'),(322,407,3,'absent'),(323,408,3,'absent'),(324,409,3,'absent'),(325,410,3,'absent'),(326,411,3,'absent'),(327,412,3,'absent'),(328,413,3,'absent'),(329,414,3,'absent'),(330,415,3,'absent'),(331,416,3,'absent'),(332,417,3,'absent'),(333,418,3,'absent'),(334,419,3,'absent'),(335,420,3,'absent'),(336,421,3,'absent'),(337,422,3,'absent'),(338,423,3,'absent'),(339,424,3,'absent'),(340,425,3,'absent'),(341,426,3,'absent'),(342,427,3,'absent'),(343,428,3,'absent'),(344,429,3,'absent'),(345,430,3,'absent'),(346,431,3,'absent'),(347,432,3,'absent'),(348,433,3,'absent'),(349,434,3,'absent'),(350,435,3,'absent'),(351,436,3,'absent'),(352,437,3,'absent'),(353,438,3,'absent'),(354,439,3,'absent'),(355,440,3,'absent'),(356,441,3,'absent'),(357,442,3,'absent'),(358,443,3,'absent'),(359,444,3,'absent'),(360,445,3,'absent'),(361,446,3,'absent'),(362,447,3,'absent'),(363,448,3,'absent'),(364,449,3,'absent'),(365,450,3,'absent'),(366,451,3,'absent'),(367,452,3,'absent'),(368,453,3,'absent'),(369,454,3,'absent'),(370,455,3,'absent'),(371,456,3,'absent'),(372,457,3,'absent'),(373,458,3,'absent'),(374,459,3,'absent'),(375,460,3,'absent'),(376,461,3,'absent'),(377,462,3,'absent'),(378,463,3,'absent'),(379,464,3,'absent'),(380,465,3,'absent'),(381,466,3,'absent'),(382,467,3,'absent'),(383,468,3,'absent'),(384,469,3,'absent'),(385,470,3,'absent'),(386,471,3,'absent'),(387,472,3,'absent'),(388,473,3,'absent'),(389,474,3,'absent'),(390,475,3,'absent'),(391,476,3,'absent'),(392,477,3,'absent'),(393,478,3,'absent'),(394,479,3,'absent'),(395,480,3,'absent'),(396,481,3,'absent'),(397,482,3,'absent'),(398,483,3,'absent'),(399,484,3,'absent'),(400,485,3,'absent'),(401,486,3,'absent'),(402,487,3,'absent'),(403,488,3,'absent'),(404,489,3,'absent'),(405,490,3,'absent'),(406,627,3,'absent'),(407,628,3,'absent'),(408,491,3,'absent'),(409,492,3,'absent'),(410,493,3,'absent'),(411,494,3,'absent'),(412,495,3,'absent'),(413,496,3,'absent'),(414,497,3,'absent'),(415,498,3,'absent'),(416,499,3,'absent'),(417,500,3,'absent'),(418,501,3,'absent'),(419,502,3,'absent'),(420,503,3,'absent'),(421,504,3,'absent'),(422,505,3,'absent'),(423,506,3,'absent'),(424,507,3,'absent'),(425,508,3,'absent'),(426,509,3,'absent'),(427,510,3,'absent'),(428,511,3,'absent'),(429,512,3,'absent'),(430,513,3,'absent'),(431,514,3,'absent'),(432,515,3,'absent'),(433,516,3,'absent'),(434,517,3,'absent'),(435,518,3,'absent'),(436,519,3,'absent'),(437,520,3,'absent'),(438,521,3,'absent'),(439,522,3,'absent'),(440,523,3,'absent'),(441,524,3,'absent'),(442,525,3,'absent'),(443,526,3,'absent'),(444,527,3,'absent'),(445,528,3,'absent'),(446,529,3,'absent'),(447,530,3,'absent'),(448,531,3,'absent'),(449,532,3,'absent'),(450,533,3,'absent'),(451,534,3,'absent'),(452,535,3,'absent'),(453,536,3,'absent'),(454,537,3,'absent'),(455,538,3,'absent'),(456,539,3,'absent'),(457,540,3,'absent'),(458,541,3,'absent'),(459,542,3,'absent'),(460,543,3,'absent'),(461,544,3,'absent'),(462,545,3,'absent'),(463,546,3,'absent'),(464,547,3,'absent'),(465,548,3,'absent'),(466,549,3,'absent'),(467,550,3,'absent'),(468,551,3,'absent'),(469,552,3,'absent'),(470,553,3,'absent'),(471,554,3,'absent'),(472,555,3,'absent'),(473,556,3,'absent'),(474,557,3,'absent'),(475,558,3,'absent'),(476,559,3,'absent'),(477,560,3,'absent'),(478,561,3,'absent'),(479,562,3,'absent'),(480,563,3,'absent'),(481,564,3,'absent'),(482,565,3,'absent'),(483,566,3,'absent'),(484,567,3,'absent'),(485,568,3,'absent'),(486,569,3,'absent'),(487,570,3,'absent'),(488,571,3,'absent'),(489,572,3,'absent'),(490,573,3,'absent'),(491,574,3,'absent'),(492,575,3,'absent'),(493,576,3,'absent'),(494,577,3,'absent'),(495,578,3,'absent'),(496,579,3,'absent'),(497,580,3,'absent'),(498,581,3,'absent'),(499,582,3,'absent'),(500,583,3,'absent'),(501,584,3,'absent'),(502,585,3,'absent'),(503,586,3,'absent'),(504,587,3,'absent'),(505,588,3,'absent'),(506,589,3,'absent'),(507,590,3,'absent'),(508,591,3,'absent'),(509,592,3,'absent'),(510,593,3,'absent'),(511,594,3,'absent'),(512,595,3,'absent'),(513,596,3,'absent'),(514,597,3,'absent'),(515,598,3,'absent'),(516,599,3,'absent'),(517,600,3,'absent'),(518,601,3,'absent'),(519,602,3,'absent'),(520,603,3,'absent'),(521,604,3,'absent'),(522,605,3,'absent'),(523,606,3,'absent'),(524,607,3,'absent'),(525,608,3,'absent'),(526,609,3,'absent'),(527,610,3,'absent'),(528,611,3,'absent'),(529,612,3,'absent'),(530,613,3,'absent'),(531,614,3,'absent'),(532,615,3,'absent'),(533,616,3,'absent'),(534,617,3,'absent'),(535,618,3,'absent'),(536,619,3,'absent'),(537,620,3,'absent'),(538,621,3,'absent'),(539,622,3,'absent'),(540,623,3,'absent'),(541,624,3,'absent'),(542,625,3,'absent'),(543,626,3,'absent'),(544,354,4,'absent'),(545,355,4,'absent'),(546,356,4,'absent'),(547,357,4,'absent'),(548,358,4,'absent'),(549,359,4,'absent'),(550,360,4,'absent'),(551,361,4,'absent'),(552,362,4,'absent'),(553,363,4,'absent'),(554,364,4,'absent'),(555,365,4,'absent'),(556,366,4,'absent'),(557,367,4,'absent'),(558,368,4,'absent'),(559,369,4,'absent'),(560,370,4,'absent'),(561,371,4,'absent'),(562,372,4,'absent'),(563,373,4,'absent'),(564,374,4,'absent'),(565,375,4,'absent'),(566,376,4,'absent'),(567,377,4,'absent'),(568,378,4,'absent'),(569,379,4,'absent'),(570,380,4,'absent'),(571,381,4,'absent'),(572,382,4,'absent'),(573,383,4,'absent'),(574,384,4,'absent'),(575,385,4,'absent'),(576,386,4,'absent'),(577,387,4,'absent'),(578,388,4,'absent'),(579,389,4,'absent'),(580,390,4,'absent'),(581,391,4,'absent'),(582,392,4,'absent'),(583,393,4,'absent'),(584,394,4,'absent'),(585,395,4,'absent'),(586,396,4,'absent'),(587,397,4,'absent'),(588,398,4,'absent'),(589,399,4,'absent'),(590,400,4,'absent'),(591,401,4,'absent'),(592,402,4,'absent'),(593,403,4,'absent'),(594,404,4,'absent'),(595,405,4,'absent'),(596,406,4,'absent'),(597,407,4,'absent'),(598,408,4,'absent'),(599,409,4,'absent'),(600,410,4,'absent'),(601,411,4,'absent'),(602,412,4,'absent'),(603,413,4,'absent'),(604,414,4,'absent'),(605,415,4,'absent'),(606,416,4,'absent'),(607,417,4,'absent'),(608,418,4,'absent'),(609,419,4,'absent'),(610,420,4,'absent'),(611,421,4,'absent'),(612,422,4,'absent'),(613,423,4,'absent'),(614,424,4,'absent'),(615,425,4,'absent'),(616,426,4,'absent'),(617,427,4,'absent'),(618,428,4,'absent'),(619,429,4,'absent'),(620,430,4,'absent'),(621,431,4,'absent'),(622,432,4,'absent'),(623,433,4,'absent'),(624,434,4,'absent'),(625,435,4,'absent'),(626,436,4,'absent'),(627,437,4,'absent'),(628,438,4,'absent'),(629,439,4,'absent'),(630,440,4,'absent'),(631,441,4,'absent'),(632,442,4,'absent'),(633,443,4,'absent'),(634,444,4,'absent'),(635,445,4,'absent'),(636,446,4,'absent'),(637,447,4,'absent'),(638,448,4,'absent'),(639,449,4,'absent'),(640,450,4,'absent'),(641,451,4,'absent'),(642,452,4,'absent'),(643,453,4,'absent'),(644,454,4,'absent'),(645,455,4,'absent'),(646,456,4,'absent'),(647,457,4,'absent'),(648,458,4,'absent'),(649,459,4,'absent'),(650,460,4,'absent'),(651,461,4,'absent'),(652,462,4,'absent'),(653,463,4,'absent'),(654,464,4,'absent'),(655,465,4,'absent'),(656,466,4,'absent'),(657,467,4,'absent'),(658,468,4,'absent'),(659,469,4,'absent'),(660,470,4,'absent'),(661,471,4,'absent'),(662,472,4,'absent'),(663,473,4,'absent'),(664,474,4,'absent'),(665,475,4,'absent'),(666,476,4,'absent'),(667,477,4,'absent'),(668,478,4,'absent'),(669,479,4,'absent'),(670,480,4,'absent'),(671,481,4,'absent'),(672,482,4,'absent'),(673,483,4,'absent'),(674,484,4,'absent'),(675,485,4,'absent'),(676,486,4,'absent'),(677,487,4,'absent'),(678,488,4,'absent'),(679,489,4,'absent'),(680,490,4,'absent'),(681,627,4,'absent'),(682,628,4,'absent'),(683,491,4,'absent'),(684,492,4,'absent'),(685,493,4,'absent'),(686,494,4,'absent'),(687,495,4,'absent'),(688,496,4,'absent'),(689,497,4,'absent'),(690,498,4,'absent'),(691,499,4,'absent'),(692,500,4,'absent'),(693,501,4,'absent'),(694,502,4,'absent'),(695,503,4,'absent'),(696,504,4,'absent'),(697,505,4,'absent'),(698,506,4,'absent'),(699,507,4,'absent'),(700,508,4,'absent'),(701,509,4,'absent'),(702,510,4,'absent'),(703,511,4,'absent'),(704,512,4,'absent'),(705,513,4,'absent'),(706,514,4,'absent'),(707,515,4,'absent'),(708,516,4,'absent'),(709,517,4,'absent'),(710,518,4,'absent'),(711,519,4,'absent'),(712,520,4,'absent'),(713,521,4,'absent'),(714,522,4,'absent'),(715,523,4,'absent'),(716,524,4,'absent'),(717,525,4,'absent'),(718,526,4,'absent'),(719,527,4,'absent'),(720,528,4,'absent'),(721,529,4,'absent'),(722,530,4,'absent'),(723,531,4,'absent'),(724,532,4,'absent'),(725,533,4,'absent'),(726,534,4,'absent'),(727,535,4,'absent'),(728,536,4,'absent'),(729,537,4,'absent'),(730,538,4,'absent'),(731,539,4,'absent'),(732,540,4,'absent'),(733,541,4,'absent'),(734,542,4,'absent'),(735,543,4,'absent'),(736,544,4,'absent'),(737,545,4,'absent'),(738,546,4,'absent'),(739,547,4,'absent'),(740,548,4,'absent'),(741,549,4,'absent'),(742,550,4,'absent'),(743,551,4,'absent'),(744,552,4,'absent'),(745,553,4,'absent'),(746,554,4,'absent'),(747,555,4,'absent'),(748,556,4,'absent'),(749,557,4,'absent'),(750,558,4,'absent'),(751,559,4,'absent'),(752,560,4,'absent'),(753,561,4,'absent'),(754,562,4,'absent'),(755,563,4,'absent'),(756,564,4,'absent'),(757,565,4,'absent'),(758,566,4,'absent'),(759,567,4,'absent'),(760,568,4,'absent'),(761,569,4,'absent'),(762,570,4,'absent'),(763,571,4,'absent'),(764,572,4,'absent'),(765,573,4,'absent'),(766,574,4,'absent'),(767,575,4,'absent'),(768,576,4,'absent'),(769,577,4,'absent'),(770,578,4,'absent'),(771,579,4,'absent'),(772,580,4,'absent'),(773,581,4,'absent'),(774,582,4,'absent'),(775,583,4,'absent'),(776,584,4,'absent'),(777,585,4,'absent'),(778,586,4,'absent'),(779,587,4,'absent'),(780,588,4,'absent'),(781,589,4,'absent'),(782,590,4,'absent'),(783,591,4,'absent'),(784,592,4,'absent'),(785,593,4,'absent'),(786,594,4,'absent'),(787,595,4,'absent'),(788,596,4,'absent'),(789,597,4,'absent'),(790,598,4,'absent'),(791,599,4,'absent'),(792,600,4,'absent'),(793,601,4,'absent'),(794,602,4,'absent'),(795,603,4,'absent'),(796,604,4,'absent'),(797,605,4,'absent'),(798,606,4,'absent'),(799,607,4,'absent'),(800,608,4,'absent'),(801,609,4,'absent'),(802,610,4,'absent'),(803,611,4,'absent'),(804,612,4,'absent'),(805,613,4,'absent'),(806,614,4,'absent'),(807,615,4,'absent'),(808,616,4,'absent'),(809,617,4,'absent'),(810,618,4,'absent'),(811,619,4,'absent'),(812,620,4,'absent'),(813,621,4,'absent'),(814,622,4,'absent'),(815,623,4,'absent'),(816,624,4,'absent'),(817,625,4,'absent'),(818,626,4,'absent'),(819,220,5,'absent'),(820,221,5,'absent'),(821,222,5,'absent'),(822,223,5,'absent'),(823,224,5,'absent'),(824,225,5,'absent'),(825,226,5,'absent'),(826,227,5,'absent'),(827,228,5,'absent'),(828,229,5,'absent'),(829,230,5,'absent'),(830,231,5,'absent'),(831,232,5,'absent'),(832,233,5,'absent'),(833,234,5,'absent'),(834,235,5,'absent'),(835,236,5,'absent'),(836,237,5,'absent'),(837,238,5,'absent'),(838,239,5,'absent'),(839,240,5,'absent'),(840,241,5,'absent'),(841,242,5,'absent'),(842,243,5,'absent'),(843,244,5,'absent'),(844,245,5,'absent'),(845,246,5,'absent'),(846,247,5,'absent'),(847,248,5,'absent'),(848,249,5,'absent'),(849,250,5,'absent'),(850,251,5,'absent'),(851,252,5,'absent'),(852,253,5,'absent'),(853,254,5,'absent'),(854,255,5,'absent'),(855,256,5,'absent'),(856,257,5,'absent'),(857,258,5,'absent'),(858,259,5,'absent'),(859,260,5,'absent'),(860,261,5,'absent'),(861,262,5,'absent'),(862,263,5,'absent'),(863,264,5,'absent'),(864,265,5,'absent'),(865,266,5,'absent'),(866,267,5,'absent'),(867,268,5,'absent'),(868,269,5,'absent'),(869,270,5,'absent'),(870,271,5,'absent'),(871,272,5,'absent'),(872,273,5,'absent'),(873,274,5,'absent'),(874,275,5,'absent'),(875,276,5,'absent'),(876,277,5,'absent'),(877,278,5,'absent'),(878,279,5,'absent'),(879,280,5,'absent'),(880,281,5,'absent'),(881,282,5,'absent'),(882,283,5,'absent'),(883,284,5,'absent'),(884,285,5,'absent'),(885,286,5,'absent'),(886,287,5,'absent'),(887,288,5,'absent'),(888,289,5,'absent'),(889,290,5,'absent'),(890,291,5,'absent'),(891,292,5,'absent'),(892,293,5,'absent'),(893,294,5,'absent'),(894,295,5,'absent'),(895,296,5,'absent'),(896,297,5,'absent'),(897,298,5,'absent'),(898,299,5,'absent'),(899,300,5,'absent'),(900,301,5,'absent'),(901,302,5,'absent'),(902,303,5,'absent'),(903,304,5,'absent'),(904,305,5,'absent'),(905,306,5,'absent'),(906,307,5,'absent'),(907,308,5,'absent'),(908,309,5,'absent'),(909,310,5,'absent'),(910,311,5,'absent'),(911,312,5,'absent'),(912,313,5,'absent'),(913,314,5,'absent'),(914,315,5,'absent'),(915,316,5,'absent'),(916,317,5,'absent'),(917,318,5,'absent'),(918,319,5,'absent'),(919,320,5,'absent'),(920,321,5,'absent'),(921,322,5,'absent'),(922,323,5,'absent'),(923,324,5,'absent'),(924,325,5,'absent'),(925,326,5,'absent'),(926,327,5,'absent'),(927,328,5,'absent'),(928,329,5,'absent'),(929,330,5,'absent'),(930,331,5,'absent'),(931,332,5,'absent'),(932,333,5,'absent'),(933,334,5,'absent'),(934,335,5,'absent'),(935,336,5,'absent'),(936,337,5,'absent'),(937,338,5,'absent'),(938,339,5,'absent'),(939,340,5,'absent'),(940,341,5,'absent'),(941,342,5,'absent'),(942,343,5,'absent'),(943,344,5,'absent'),(944,345,5,'absent'),(945,346,5,'absent'),(946,347,5,'absent'),(947,348,5,'absent'),(948,349,5,'absent'),(949,350,5,'absent'),(950,351,5,'absent'),(951,352,5,'absent'),(952,353,5,'absent'),(953,629,5,'absent');
/*!40000 ALTER TABLE `FireDrillAttendance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FireDrillSchedule`
--

DROP TABLE IF EXISTS `FireDrillSchedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `FireDrillSchedule` (
  `fireDrillId` int(11) NOT NULL AUTO_INCREMENT,
  `buildingId` int(11) NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fireDrillTypeId` int(11) DEFAULT NULL,
  `status` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `scheduledBy` int(11) NOT NULL,
  `lastUpdate` datetime(3) NOT NULL,
  `scheduleDateTime` datetime(3) NOT NULL,
  `startDateTime` timestamp(3) NULL DEFAULT NULL,
  `completeDateTime` timestamp(3) NULL DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `editedBy` int(11) DEFAULT NULL,
  PRIMARY KEY (`fireDrillId`),
  KEY `buildingId` (`buildingId`),
  KEY `fireDrillTypeId` (`fireDrillTypeId`),
  KEY `scheduledBy` (`scheduledBy`),
  CONSTRAINT `FK4bpusppr0rg63abfttbw6ie9h` FOREIGN KEY (`buildingId`) REFERENCES `Building` (`buildingId`),
  CONSTRAINT `FKcvcu5ay3avkjgijv5we91ydjs` FOREIGN KEY (`scheduledBy`) REFERENCES `User` (`userId`),
  CONSTRAINT `FKseg244imedq4s9ixpnbgcaudx` FOREIGN KEY (`fireDrillTypeId`) REFERENCES `FireDrillType` (`fireDrillTypeId`),
  CONSTRAINT `FireDrillSchedule_ibfk_1` FOREIGN KEY (`buildingId`) REFERENCES `Building` (`buildingId`),
  CONSTRAINT `FireDrillSchedule_ibfk_2` FOREIGN KEY (`fireDrillTypeId`) REFERENCES `FireDrillType` (`fireDrillTypeId`),
  CONSTRAINT `FireDrillSchedule_ibfk_3` FOREIGN KEY (`scheduledBy`) REFERENCES `User` (`userId`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FireDrillSchedule`
--

LOCK TABLES `FireDrillSchedule` WRITE;
/*!40000 ALTER TABLE `FireDrillSchedule` DISABLE KEYS */;
INSERT INTO `FireDrillSchedule` VALUES (1,9,'',1,'open',41,'2019-05-24 10:29:57.000','2019-05-24 14:25:00.000',NULL,NULL,0,0),(2,9,'',3,'close',43,'2019-05-24 10:52:42.000','2019-05-24 10:52:41.000','2019-05-24 02:52:50.000','2019-05-24 03:39:39.000',0,43),(3,8,'',1,'open',46,'2019-05-24 11:32:29.000','2019-05-24 14:30:00.000',NULL,NULL,0,0),(4,8,'',3,'close',46,'2019-05-24 11:35:27.000','2019-05-24 11:35:27.000','2019-05-24 03:35:37.000','2019-05-24 03:45:37.000',0,85),(5,9,'',1,'close',43,'2019-05-24 11:39:56.000','2019-05-24 11:45:00.000','2019-05-24 03:40:04.000','2019-05-24 03:45:52.000',0,85);
/*!40000 ALTER TABLE `FireDrillSchedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FireDrillType`
--

DROP TABLE IF EXISTS `FireDrillType`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `FireDrillType` (
  `fireDrillTypeId` int(11) NOT NULL AUTO_INCREMENT,
  `fireDrillTypeName` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`fireDrillTypeId`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FireDrillType`
--

LOCK TABLES `FireDrillType` WRITE;
/*!40000 ALTER TABLE `FireDrillType` DISABLE KEYS */;
INSERT INTO `FireDrillType` VALUES (1,'fire drill',0),(2,'dry run',0),(3,'real fire',0);
/*!40000 ALTER TABLE `FireDrillType` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `HazardReport`
--

DROP TABLE IF EXISTS `HazardReport`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `HazardReport` (
  `hazardReportId` int(11) NOT NULL AUTO_INCREMENT,
  `hazardReportName` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `buildingId` int(11) NOT NULL,
  `reporterId` int(11) NOT NULL,
  `status` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dateTime` datetime(3) NOT NULL,
  `lastUpdate` datetime(3) NOT NULL,
  `closeReporterId` int(11) DEFAULT NULL,
  `closeComment` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `editedBy` int(11) NOT NULL,
  PRIMARY KEY (`hazardReportId`),
  KEY `reporterId` (`reporterId`),
  KEY `buildingId` (`buildingId`),
  KEY `closeReporterId` (`closeReporterId`),
  KEY `HazardReport_ibfk_4` (`editedBy`),
  CONSTRAINT `FK12g1xyjl1e7m331693qhoycpk` FOREIGN KEY (`reporterId`) REFERENCES `User` (`userId`),
  CONSTRAINT `FKivdasm201net8k0hlcb1xvu7q` FOREIGN KEY (`buildingId`) REFERENCES `Building` (`buildingId`),
  CONSTRAINT `FKkpeaqyjw8kro65pp7kix2a1dj` FOREIGN KEY (`closeReporterId`) REFERENCES `User` (`userId`),
  CONSTRAINT `HazardReport_ibfk_1` FOREIGN KEY (`reporterId`) REFERENCES `User` (`userId`),
  CONSTRAINT `HazardReport_ibfk_2` FOREIGN KEY (`closeReporterId`) REFERENCES `User` (`userId`),
  CONSTRAINT `HazardReport_ibfk_3` FOREIGN KEY (`buildingId`) REFERENCES `Building` (`buildingId`),
  CONSTRAINT `HazardReport_ibfk_4` FOREIGN KEY (`editedBy`) REFERENCES `User` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `HazardReport`
--

LOCK TABLES `HazardReport` WRITE;
/*!40000 ALTER TABLE `HazardReport` DISABLE KEYS */;
/*!40000 ALTER TABLE `HazardReport` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `HazardReportAnswer`
--

DROP TABLE IF EXISTS `HazardReportAnswer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `HazardReportAnswer` (
  `hazardReportAnswerId` int(11) NOT NULL AUTO_INCREMENT,
  `answerText` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`hazardReportAnswerId`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `HazardReportAnswer`
--

LOCK TABLES `HazardReportAnswer` WRITE;
/*!40000 ALTER TABLE `HazardReportAnswer` DISABLE KEYS */;
INSERT INTO `HazardReportAnswer` VALUES (1,'Yes',0),(2,'No',0),(3,'NA',0);
/*!40000 ALTER TABLE `HazardReportAnswer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `HazardReportClose`
--

DROP TABLE IF EXISTS `HazardReportClose`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `HazardReportClose` (
  `hazardReportCloseId` int(11) NOT NULL AUTO_INCREMENT,
  `hazardReportId` int(11) NOT NULL,
  `documentName` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `documentKey` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`hazardReportCloseId`),
  KEY `hazardReportId` (`hazardReportId`),
  CONSTRAINT `FK2hqsjkphdacmyel9pngdxsxol` FOREIGN KEY (`hazardReportId`) REFERENCES `HazardReport` (`hazardReportId`),
  CONSTRAINT `HazardReportClose_ibfk_1` FOREIGN KEY (`hazardReportId`) REFERENCES `HazardReport` (`hazardReportId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `HazardReportClose`
--

LOCK TABLES `HazardReportClose` WRITE;
/*!40000 ALTER TABLE `HazardReportClose` DISABLE KEYS */;
/*!40000 ALTER TABLE `HazardReportClose` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `HazardReportQuestion`
--

DROP TABLE IF EXISTS `HazardReportQuestion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `HazardReportQuestion` (
  `hazardReportQuestionId` int(11) NOT NULL AUTO_INCREMENT,
  `questionText` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sectionId` int(11) NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`hazardReportQuestionId`),
  KEY `FKstpj43306vuovb3tfvclv0enp` (`sectionId`),
  CONSTRAINT `FKstpj43306vuovb3tfvclv0enp` FOREIGN KEY (`sectionId`) REFERENCES `HazardReportSection` (`sectionId`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `HazardReportQuestion`
--

LOCK TABLES `HazardReportQuestion` WRITE;
/*!40000 ALTER TABLE `HazardReportQuestion` DISABLE KEYS */;
INSERT INTO `HazardReportQuestion` VALUES (1,'Are all EXIT signs illuminated?',1,0),(2,'Are all the doors self-closing and kept closed at all times?',1,0),(3,'Are all escape routes free from obstructions?',1,0),(4,'Are glass panels in doors obvious and intact?',1,0),(5,'Are escape routes suitable for the people who have to used them (i.e. disabled people)?',1,0),(6,'Is the fire alarm system in operations?',2,0),(7,'Are the manual fire alarm call points unobstructed and clearly visible?',2,0),(8,'Are there portable fire extinguishers (PFE)/hose reels available?',3,0),(9,'Are all extinguisher/hose reels regularly maintained with unexpired test date?',3,0),(10,'Are all extinguisher /hose reels visible and easily accessible?',3,0),(11,'Are extinguisher /hose reels wall mounted?',3,0),(12,'Are the sprinkler head covers intact?',3,0),(13,'Are there 500mm void spaces directly below any sprinkler heads?',3,0),(14,'Fire load in any rooms kept to the minimum by housekeeping efforts?',3,0),(15,'Alcohol based hand-rub kept at minimum quantities and prevented from pilfering? If potential drip onto floor, is there a drip-tray?',3,0),(16,'Are all extension leads of the correct length and fully unwound when in use?',4,0),(17,'Is the area in front of or next to or directly below the electrical panel(s) free from combustible materials?',4,0);
/*!40000 ALTER TABLE `HazardReportQuestion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `HazardReportQuestionData`
--

DROP TABLE IF EXISTS `HazardReportQuestionData`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `HazardReportQuestionData` (
  `hazardQuestionDataId` int(11) NOT NULL AUTO_INCREMENT,
  `questionId` int(11) NOT NULL,
  `answerId` int(11) NOT NULL,
  `observationText` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hazardSectionId` int(11) NOT NULL,
  PRIMARY KEY (`hazardQuestionDataId`),
  KEY `questionId` (`questionId`),
  KEY `answerId` (`answerId`),
  KEY `hazardSectionId` (`hazardSectionId`),
  CONSTRAINT `FK4ms6xfkhrvq5qwc7xqdcgqxln` FOREIGN KEY (`answerId`) REFERENCES `HazardReportAnswer` (`hazardReportAnswerId`),
  CONSTRAINT `FKcsmujnob2n9dagekk5ruxse2v` FOREIGN KEY (`hazardSectionId`) REFERENCES `HazardReportSectionData` (`hazardSectionDataId`),
  CONSTRAINT `FKje45n1wagjb2a2w9mftkuwwth` FOREIGN KEY (`questionId`) REFERENCES `HazardReportQuestion` (`hazardReportQuestionId`),
  CONSTRAINT `HazardReportQuestionData_ibfk_1` FOREIGN KEY (`questionId`) REFERENCES `HazardReportQuestion` (`hazardReportQuestionId`),
  CONSTRAINT `HazardReportQuestionData_ibfk_2` FOREIGN KEY (`answerId`) REFERENCES `HazardReportAnswer` (`hazardReportAnswerId`),
  CONSTRAINT `HazardReportQuestionData_ibfk_3` FOREIGN KEY (`hazardSectionId`) REFERENCES `HazardReportSectionData` (`hazardSectionDataId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `HazardReportQuestionData`
--

LOCK TABLES `HazardReportQuestionData` WRITE;
/*!40000 ALTER TABLE `HazardReportQuestionData` DISABLE KEYS */;
/*!40000 ALTER TABLE `HazardReportQuestionData` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `HazardReportSection`
--

DROP TABLE IF EXISTS `HazardReportSection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `HazardReportSection` (
  `sectionId` int(11) NOT NULL AUTO_INCREMENT,
  `sectionName` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`sectionId`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `HazardReportSection`
--

LOCK TABLES `HazardReportSection` WRITE;
/*!40000 ALTER TABLE `HazardReportSection` DISABLE KEYS */;
INSERT INTO `HazardReportSection` VALUES (1,'Fire Escape Routes',0),(2,'Fire Alarm Systems',0),(3,'Firefighting Equipment and prevention',0),(4,'Electrical Equipment',0);
/*!40000 ALTER TABLE `HazardReportSection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `HazardReportSectionData`
--

DROP TABLE IF EXISTS `HazardReportSectionData`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `HazardReportSectionData` (
  `hazardSectionDataId` int(11) NOT NULL AUTO_INCREMENT,
  `sectionId` int(11) NOT NULL,
  `hazardReportId` int(11) NOT NULL,
  PRIMARY KEY (`hazardSectionDataId`),
  KEY `sectionId` (`sectionId`),
  KEY `hazardReportId` (`hazardReportId`),
  CONSTRAINT `FK2w0an09q8agmki24t3bqudkdq` FOREIGN KEY (`sectionId`) REFERENCES `HazardReportSection` (`sectionId`),
  CONSTRAINT `FKr26poxylkwiibe34hg58f3x8u` FOREIGN KEY (`hazardReportId`) REFERENCES `HazardReport` (`hazardReportId`),
  CONSTRAINT `HazardReportSectionData_ibfk_1` FOREIGN KEY (`sectionId`) REFERENCES `HazardReportSection` (`sectionId`),
  CONSTRAINT `HazardReportSectionData_ibfk_2` FOREIGN KEY (`hazardReportId`) REFERENCES `HazardReport` (`hazardReportId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `HazardReportSectionData`
--

LOCK TABLES `HazardReportSectionData` WRITE;
/*!40000 ALTER TABLE `HazardReportSectionData` DISABLE KEYS */;
/*!40000 ALTER TABLE `HazardReportSectionData` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `HazardReportSectionImage`
--

DROP TABLE IF EXISTS `HazardReportSectionImage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `HazardReportSectionImage` (
  `hazardSectionImageId` int(11) NOT NULL AUTO_INCREMENT,
  `hazardSectionDataId` int(11) NOT NULL,
  `documentName` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `documentKey` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`hazardSectionImageId`),
  KEY `hazardSectionDataId` (`hazardSectionDataId`),
  CONSTRAINT `FKm3a1o7gdoqfc7oompdra69gdk` FOREIGN KEY (`hazardSectionDataId`) REFERENCES `HazardReportSectionData` (`hazardSectionDataId`),
  CONSTRAINT `HazardReportSectionImage_ibfk_1` FOREIGN KEY (`hazardSectionDataId`) REFERENCES `HazardReportSectionData` (`hazardSectionDataId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `HazardReportSectionImage`
--

LOCK TABLES `HazardReportSectionImage` WRITE;
/*!40000 ALTER TABLE `HazardReportSectionImage` DISABLE KEYS */;
/*!40000 ALTER TABLE `HazardReportSectionImage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Maintenance`
--

DROP TABLE IF EXISTS `Maintenance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Maintenance` (
  `maintenanceId` int(11) NOT NULL AUTO_INCREMENT,
  `deleted` tinyint(4) DEFAULT '0',
  `end` datetime DEFAULT NULL,
  `realEnd` datetime DEFAULT NULL,
  `start` datetime DEFAULT NULL,
  PRIMARY KEY (`maintenanceId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Maintenance`
--

LOCK TABLES `Maintenance` WRITE;
/*!40000 ALTER TABLE `Maintenance` DISABLE KEYS */;
/*!40000 ALTER TABLE `Maintenance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Message`
--

DROP TABLE IF EXISTS `Message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Message` (
  `messageId` int(11) NOT NULL AUTO_INCREMENT,
  `messageTypeId` int(11) NOT NULL,
  `dateTime` datetime(3) NOT NULL,
  `messageTitle` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `messageDetails` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `buildingId` int(11) NOT NULL,
  `contentId` int(11) NOT NULL,
  PRIMARY KEY (`messageId`),
  KEY `messageTypeId` (`messageTypeId`),
  KEY `buildingId` (`buildingId`),
  CONSTRAINT `FKh4ut7id29renn1he4gnro9bpu` FOREIGN KEY (`messageTypeId`) REFERENCES `MessageType` (`messageTypeId`),
  CONSTRAINT `Message_ibfk_1` FOREIGN KEY (`messageTypeId`) REFERENCES `MessageType` (`messageTypeId`),
  CONSTRAINT `Message_ibfk_2` FOREIGN KEY (`buildingId`) REFERENCES `Building` (`buildingId`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Message`
--

LOCK TABLES `Message` WRITE;
/*!40000 ALTER TABLE `Message` DISABLE KEYS */;
INSERT INTO `Message` VALUES (1,1,'2019-05-24 10:29:57.000','Fire Drill Schedule','There will be a scheduled fire drill on 24 May 2019, 02.25 PM',9,0),(2,1,'2019-05-24 10:29:57.000','Fire Drill Schedule','There will be a scheduled fire drill on 24 May 2019, 02.25 PM',9,0),(3,1,'2019-05-24 10:29:58.000','Fire Drill Schedule','There will be a scheduled fire drill on 24 May 2019, 02.25 PM',9,0),(4,1,'2019-05-24 10:29:58.000','Fire Drill Schedule','There will be a scheduled fire drill on 24 May 2019, 02.25 PM',9,0),(5,1,'2019-05-24 10:29:58.000','Fire Drill Schedule','There will be a scheduled fire drill on 24 May 2019, 02.25 PM',9,0),(6,1,'2019-05-24 10:29:58.000','Fire Drill Schedule','There will be a scheduled fire drill on 24 May 2019, 02.25 PM',9,0),(7,1,'2019-05-24 10:29:58.000','Fire Drill Schedule','There will be a scheduled fire drill on 24 May 2019, 02.25 PM',9,0),(8,3,'2019-05-24 10:52:43.000',' Fire Activation','You have been activated due to a real fire occuring right now. Report to location below',9,0),(9,3,'2019-05-24 10:52:43.000',' Fire Activation','You have been activated due to a real fire occuring right now. Report to location below',9,0),(10,3,'2019-05-24 10:52:43.000',' Fire Activation','You have been activated due to a real fire occuring right now. Report to location below',9,0),(11,3,'2019-05-24 10:52:43.000',' Fire Activation','You have been activated due to a real fire occuring right now. Report to location below',9,0),(12,3,'2019-05-24 10:52:43.000',' Fire Activation','You have been activated due to a real fire occuring right now. Report to location below',9,0),(13,3,'2019-05-24 10:52:43.000',' Fire Activation','You have been activated due to a real fire occuring right now. Report to location below',9,0),(14,3,'2019-05-24 10:52:43.000',' Fire Activation','You have been activated due to a real fire occuring right now. Report to location below',9,0),(15,3,'2019-05-24 10:52:50.000',' Fire Activation','You have been activated due to a real fire occuring right now. Report to location below',9,0),(16,3,'2019-05-24 10:52:50.000',' Fire Activation','You have been activated due to a real fire occuring right now. Report to location below',9,0),(17,3,'2019-05-24 10:52:50.000',' Fire Activation','You have been activated due to a real fire occuring right now. Report to location below',9,0),(18,3,'2019-05-24 10:52:50.000',' Fire Activation','You have been activated due to a real fire occuring right now. Report to location below',9,0),(19,3,'2019-05-24 10:52:50.000',' Fire Activation','You have been activated due to a real fire occuring right now. Report to location below',9,0),(20,3,'2019-05-24 10:52:50.000',' Fire Activation','You have been activated due to a real fire occuring right now. Report to location below',9,0),(21,3,'2019-05-24 10:52:50.000',' Fire Activation','You have been activated due to a real fire occuring right now. Report to location below',9,0),(22,3,'2019-05-24 10:52:50.000',' Fire Activation','You have been activated due to a real fire occuring right now. Report to location below',9,0),(23,1,'2019-05-24 11:32:29.000','Fire Drill Schedule','There will be a scheduled fire drill on 24 May 2019, 02.30 PM',8,0),(24,1,'2019-05-24 11:32:29.000','Fire Drill Schedule','There will be a scheduled fire drill on 24 May 2019, 02.30 PM',8,0),(25,1,'2019-05-24 11:32:29.000','Fire Drill Schedule','There will be a scheduled fire drill on 24 May 2019, 02.30 PM',8,0),(26,1,'2019-05-24 11:32:29.000','Fire Drill Schedule','There will be a scheduled fire drill on 24 May 2019, 02.30 PM',8,0),(27,3,'2019-05-24 11:35:28.000',' Fire Activation','You have been activated due to a real fire occuring right now. Report to location below',8,0),(28,3,'2019-05-24 11:35:28.000',' Fire Activation','You have been activated due to a real fire occuring right now. Report to location below',8,0),(29,3,'2019-05-24 11:35:28.000',' Fire Activation','You have been activated due to a real fire occuring right now. Report to location below',8,0),(30,3,'2019-05-24 11:35:37.000',' Fire Activation','You have been activated due to a real fire occuring right now. Report to location below',8,818),(31,3,'2019-05-24 11:35:37.000',' Fire Activation','You have been activated due to a real fire occuring right now. Report to location below',8,681),(32,3,'2019-05-24 11:35:37.000',' Fire Activation','You have been activated due to a real fire occuring right now. Report to location below',8,682),(33,3,'2019-05-24 11:35:37.000',' Fire Activation','You have been activated due to a real fire occuring right now. Report to location below',8,0),(34,1,'2019-05-24 11:39:56.000','Fire Drill Schedule','There will be a scheduled fire drill on 24 May 2019, 11.45 AM',9,0),(35,1,'2019-05-24 11:39:56.000','Fire Drill Schedule','There will be a scheduled fire drill on 24 May 2019, 11.45 AM',9,0),(36,12,'2019-05-24 11:39:56.000','Fire Drill Schedule Starting Soon ','A scheduled fire drill will be starting soon at 24 May 2019, 11.45 AM',9,0),(37,12,'2019-05-24 11:39:56.000','Fire Drill Schedule Starting Soon ','A scheduled fire drill will be starting soon at 24 May 2019, 11.45 AM',9,0),(38,1,'2019-05-24 11:39:56.000','Fire Drill Schedule','There will be a scheduled fire drill on 24 May 2019, 11.45 AM',9,0),(39,1,'2019-05-24 11:39:56.000','Fire Drill Schedule','There will be a scheduled fire drill on 24 May 2019, 11.45 AM',9,0),(40,12,'2019-05-24 11:39:56.000','Fire Drill Schedule Starting Soon ','A scheduled fire drill will be starting soon at 24 May 2019, 11.45 AM',9,0),(41,1,'2019-05-24 11:39:56.000','Fire Drill Schedule','There will be a scheduled fire drill on 24 May 2019, 11.45 AM',9,0),(42,12,'2019-05-24 11:39:56.000','Fire Drill Schedule Starting Soon ','A scheduled fire drill will be starting soon at 24 May 2019, 11.45 AM',9,0),(43,1,'2019-05-24 11:39:56.000','Fire Drill Schedule','There will be a scheduled fire drill on 24 May 2019, 11.45 AM',9,0),(44,12,'2019-05-24 11:39:56.000','Fire Drill Schedule Starting Soon ','A scheduled fire drill will be starting soon at 24 May 2019, 11.45 AM',9,0),(45,12,'2019-05-24 11:39:56.000','Fire Drill Schedule Starting Soon ','A scheduled fire drill will be starting soon at 24 May 2019, 11.45 AM',9,0),(46,1,'2019-05-24 11:39:56.000','Fire Drill Schedule','There will be a scheduled fire drill on 24 May 2019, 11.45 AM',9,0),(47,1,'2019-05-24 11:39:56.000','Fire Drill Schedule','There will be a scheduled fire drill on 24 May 2019, 11.45 AM',9,0),(48,12,'2019-05-24 11:39:56.000','Fire Drill Schedule Starting Soon ','A scheduled fire drill will be starting soon at 24 May 2019, 11.45 AM',9,0),(49,12,'2019-05-24 11:39:56.000','Fire Drill Schedule Starting Soon ','A scheduled fire drill will be starting soon at 24 May 2019, 11.45 AM',9,953),(50,2,'2019-05-24 11:40:04.000','Fire Drill','You have been activated for dry run fire drill. Report to location below',9,0),(51,2,'2019-05-24 11:40:04.000','Fire Drill','You have been activated for dry run fire drill. Report to location below',9,0),(52,2,'2019-05-24 11:40:05.000','Fire Drill','You have been activated for dry run fire drill. Report to location below',9,0),(53,2,'2019-05-24 11:40:05.000','Fire Drill','You have been activated for dry run fire drill. Report to location below',9,0),(54,2,'2019-05-24 11:40:05.000','Fire Drill','You have been activated for dry run fire drill. Report to location below',9,0),(55,2,'2019-05-24 11:40:05.000','Fire Drill','You have been activated for dry run fire drill. Report to location below',9,0),(56,2,'2019-05-24 11:40:05.000','Fire Drill','You have been activated for dry run fire drill. Report to location below',9,0),(57,2,'2019-05-24 11:40:05.000','Fire Drill','You have been activated for dry run fire drill. Report to location below',9,953);
/*!40000 ALTER TABLE `Message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MessageType`
--

DROP TABLE IF EXISTS `MessageType`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MessageType` (
  `messageTypeId` int(11) NOT NULL AUTO_INCREMENT,
  `messageType` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`messageTypeId`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MessageType`
--

LOCK TABLES `MessageType` WRITE;
/*!40000 ALTER TABLE `MessageType` DISABLE KEYS */;
INSERT INTO `MessageType` VALUES (1,'Fire Drill Schedule',0),(2,'Fire Drill Dry Run',0),(3,'Fire Activation',0),(4,'Escalation',0),(5,'Hazard Report',0),(6,'Hazard Report Complete',0),(7,'Message',0),(8,'Update Escalation',0),(9,'Update Fire Drill',0),(10,'Fire Drill Delete',0),(11,'Fire Drill End',0),(12,'Fire Drill Prestart',0);
/*!40000 ALTER TABLE `MessageType` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Notification`
--

DROP TABLE IF EXISTS `Notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Notification` (
  `notificationId` int(11) NOT NULL AUTO_INCREMENT,
  `messageId` int(11) DEFAULT NULL,
  `reciever` int(11) DEFAULT NULL,
  `status` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`notificationId`),
  KEY `messageId` (`messageId`),
  KEY `reciever` (`reciever`),
  CONSTRAINT `FK5is6u9shoe16sky4twug3lhat` FOREIGN KEY (`messageId`) REFERENCES `Message` (`messageId`),
  CONSTRAINT `FKcwbqh7wtdjr9xg8asef57qnup` FOREIGN KEY (`reciever`) REFERENCES `User` (`userId`),
  CONSTRAINT `Notification_ibfk_1` FOREIGN KEY (`messageId`) REFERENCES `Message` (`messageId`),
  CONSTRAINT `Notification_ibfk_2` FOREIGN KEY (`reciever`) REFERENCES `User` (`userId`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Notification`
--

LOCK TABLES `Notification` WRITE;
/*!40000 ALTER TABLE `Notification` DISABLE KEYS */;
INSERT INTO `Notification` VALUES (1,1,80,0),(2,2,81,0),(3,3,82,0),(4,4,83,0),(5,5,84,0),(6,6,85,0),(7,7,41,1),(8,8,80,0),(9,9,81,0),(10,10,82,0),(11,11,83,0),(12,12,84,0),(13,13,41,1),(14,14,43,0),(15,15,80,0),(16,16,81,0),(17,17,82,0),(18,18,83,0),(19,19,84,0),(20,20,41,1),(21,21,43,0),(22,22,46,0),(23,23,85,0),(24,24,41,0),(25,25,43,0),(26,26,46,0),(27,27,41,0),(28,28,43,0),(29,29,46,0),(30,30,85,0),(31,31,41,0),(32,32,43,0),(33,33,46,0),(34,34,80,0),(35,35,81,0),(36,36,80,0),(37,37,81,0),(38,38,82,0),(39,39,83,0),(40,40,82,0),(41,41,84,0),(42,42,83,0),(43,43,41,0),(44,44,84,0),(45,45,41,0),(46,46,43,0),(47,47,46,0),(48,48,43,0),(49,49,46,0),(50,50,80,0),(51,51,81,0),(52,52,82,0),(53,53,83,0),(54,54,84,0),(55,55,41,0),(56,56,43,0),(57,57,46,0);
/*!40000 ALTER TABLE `Notification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ResetPassword`
--

DROP TABLE IF EXISTS `ResetPassword`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ResetPassword` (
  `resetPasswordId` int(11) NOT NULL AUTO_INCREMENT,
  `token` varchar(45) NOT NULL,
  `userId` int(11) NOT NULL,
  `expiryDate` timestamp(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `used` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`resetPasswordId`),
  KEY `ResetPassword_ibfk_1_idx` (`userId`),
  CONSTRAINT `FK3mk96f96kxmd2k8tqgllebl8e` FOREIGN KEY (`userId`) REFERENCES `User` (`userId`),
  CONSTRAINT `ResetPassword_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `User` (`userId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ResetPassword`
--

LOCK TABLES `ResetPassword` WRITE;
/*!40000 ALTER TABLE `ResetPassword` DISABLE KEYS */;
INSERT INTO `ResetPassword` VALUES (1,'1d46742457502af9c014ef9ce5ef0f73',41,'2019-05-02 10:13:52.000',0),(2,'0fbacb4307c2072934bdbd16e1020d75',41,'2019-05-02 10:15:21.000',0),(3,'bc69448977d83246fd71bf518148a71e',41,'2019-05-02 10:17:40.000',0),(4,'282061eaf2bd63b532db19e1230b0241',41,'2019-05-02 10:17:41.000',0),(5,'3e363c40ca7ee7564f8be8d32280862b',41,'2019-05-02 10:17:41.000',0),(6,'43b3094313c8364f98b03cb11e6e797e',41,'2019-05-02 10:17:40.000',0),(7,'5c47b5bd53626d30a46cce3450b8139d',41,'2019-05-02 11:17:40.000',0);
/*!40000 ALTER TABLE `ResetPassword` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Role`
--

DROP TABLE IF EXISTS `Role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Role` (
  `roleId` int(11) NOT NULL AUTO_INCREMENT,
  `roleName` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `editHazardReportGroup` tinyint(1) NOT NULL DEFAULT '0',
  `hazardReportGroup` tinyint(1) NOT NULL DEFAULT '0',
  `authorityToEscalateGroup` tinyint(1) NOT NULL DEFAULT '0',
  `escalationGroup` tinyint(1) NOT NULL DEFAULT '0',
  `fireDrillAuthorityGroup` tinyint(1) NOT NULL DEFAULT '0',
  `fireDrillStartGroup` tinyint(1) NOT NULL DEFAULT '0',
  `fireDrillAttendanceGroup` tinyint(1) NOT NULL DEFAULT '0',
  `fireDrillNotificationGroup` tinyint(1) NOT NULL DEFAULT '0',
  `documentManagementGroup` tinyint(1) NOT NULL DEFAULT '0',
  `documentViewingGroup` tinyint(1) NOT NULL DEFAULT '0',
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`roleId`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Role`
--

LOCK TABLES `Role` WRITE;
/*!40000 ALTER TABLE `Role` DISABLE KEYS */;
INSERT INTO `Role` VALUES (1,'Fire Safety Manager',1,1,1,0,1,1,0,1,1,1,0),(2,'Fire Warden',0,0,0,0,0,0,1,1,0,0,0),(3,'Member of EMT',1,1,0,1,0,0,0,1,0,1,0),(4,'Building Manager',0,1,0,1,0,1,0,1,1,1,0);
/*!40000 ALTER TABLE `Role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Tenant`
--

DROP TABLE IF EXISTS `Tenant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Tenant` (
  `tenantId` int(11) NOT NULL AUTO_INCREMENT,
  `tenantName` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `buildingId` int(11) DEFAULT NULL,
  `editedBy` int(11) DEFAULT NULL,
  `dateTime` datetime(3) DEFAULT NULL,
  `deleted` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`tenantId`),
  KEY `buildingId` (`buildingId`),
  KEY `editedBy` (`editedBy`),
  CONSTRAINT `FKffmx0qyb6jiv1v5axsnm1qnaj` FOREIGN KEY (`buildingId`) REFERENCES `Building` (`buildingId`),
  CONSTRAINT `FKinjpfsv9edphf67yhub7wiiwj` FOREIGN KEY (`editedBy`) REFERENCES `User` (`userId`),
  CONSTRAINT `Tenant_ibfk_1` FOREIGN KEY (`buildingId`) REFERENCES `Building` (`buildingId`),
  CONSTRAINT `Tenant_ibfk_2` FOREIGN KEY (`editedBy`) REFERENCES `User` (`userId`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Tenant`
--

LOCK TABLES `Tenant` WRITE;
/*!40000 ALTER TABLE `Tenant` DISABLE KEYS */;
INSERT INTO `Tenant` VALUES (24,'A*Star',5,51,'2019-04-08 12:34:15.000',0),(25,'A*Star',6,51,'2019-04-08 12:34:15.000',0),(26,'A*Star',7,51,'2019-04-08 12:34:15.000',0),(27,'A*Star HQ',9,51,'2019-04-08 12:34:15.000',0),(28,'DSI',8,51,'2019-04-08 12:34:15.000',0),(29,'IME',8,51,'2019-04-08 12:34:15.000',0);
/*!40000 ALTER TABLE `Tenant` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TenantEmployee`
--

DROP TABLE IF EXISTS `TenantEmployee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TenantEmployee` (
  `tenantEmployeeId` int(11) NOT NULL AUTO_INCREMENT,
  `tenantEmployeeName` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tenantId` int(11) DEFAULT NULL,
  `title` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `editedBy` int(11) DEFAULT NULL,
  `dateTime` datetime(3) DEFAULT NULL,
  `deleted` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`tenantEmployeeId`),
  KEY `editedBy` (`editedBy`),
  KEY `tenantId` (`tenantId`),
  CONSTRAINT `FKhgvve4efro6rhofg75ihrr5yk` FOREIGN KEY (`tenantId`) REFERENCES `Tenant` (`tenantId`),
  CONSTRAINT `FKq3q4jod97vxyl62ubbmxmrqcu` FOREIGN KEY (`editedBy`) REFERENCES `User` (`userId`),
  CONSTRAINT `TenantEmployee_ibfk_1` FOREIGN KEY (`tenantId`) REFERENCES `Tenant` (`tenantId`),
  CONSTRAINT `TenantEmployee_ibfk_2` FOREIGN KEY (`editedBy`) REFERENCES `User` (`userId`)
) ENGINE=InnoDB AUTO_INCREMENT=630 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TenantEmployee`
--

LOCK TABLES `TenantEmployee` WRITE;
/*!40000 ALTER TABLE `TenantEmployee` DISABLE KEYS */;
INSERT INTO `TenantEmployee` VALUES (220,'Lai Loong Fong',27,'-',52,'2019-05-23 20:15:42.000',0),(221,'Yong Kian Chan, Jason',27,'-',52,'2019-05-23 20:15:42.000',0),(222,'Chan Min-Vey',27,'-',52,'2019-05-23 20:15:42.000',0),(223,'Tan Sen Teck',27,'-',52,'2019-05-23 20:15:42.000',0),(224,'Shen Yuguo',27,'-',52,'2019-05-23 20:15:42.000',0),(225,'Teo Li Li',27,'-',52,'2019-05-23 20:15:42.000',0),(226,'Lee Choon Hiang Wayne',27,'-',52,'2019-05-23 20:15:42.000',0),(227,'Loh Chow Meng, Kelvin',27,'-',52,'2019-05-23 20:15:42.000',0),(228,'Chan Hoong Maeng',27,'-',52,'2019-05-23 20:15:42.000',0),(229,'Tey Boon Song',27,'-',52,'2019-05-23 20:15:42.000',0),(230,'Pow Chun Ee',27,'-',52,'2019-05-23 20:15:42.000',0),(231,'Au Nor-San Lynn',27,'-',52,'2019-05-23 20:15:42.000',0),(232,'Wong Chiam Yew, Jimmy',27,'-',52,'2019-05-23 20:15:42.000',0),(233,'Bala Narayanan',27,'-',52,'2019-05-23 20:15:42.000',0),(234,'Dhanaraj Kumaravel',27,'-',52,'2019-05-23 20:15:42.000',0),(235,'Priyalatha Hariharan',27,'-',52,'2019-05-23 20:15:42.000',0),(236,'Remya Sasidharan (Are9hos)',27,'-',52,'2019-05-23 20:15:42.000',0),(237,'Kang Kian Hoe',27,'-',52,'2019-05-23 20:15:42.000',0),(238,'Victor Chen',27,'-',52,'2019-05-23 20:15:42.000',0),(239,'Jason Yip',27,'-',52,'2019-05-23 20:15:42.000',0),(240,'Tan Sok Wah, Sophia',27,'-',52,'2019-05-23 20:15:42.000',0),(241,'Chia Zuhaila Binte Chia Zainal',27,'-',52,'2019-05-23 20:15:42.000',0),(242,'Tan Yen Sze Edna',27,'-',52,'2019-05-23 20:15:42.000',0),(243,'He Jinsong, Jazsh',27,'-',52,'2019-05-23 20:15:42.000',0),(244,'Lin Guo Wei, Jason',27,'-',52,'2019-05-23 20:15:42.000',0),(245,'Chew Ming Yong Jenson',27,'-',52,'2019-05-23 20:15:42.000',0),(246,'Wang Liyan',27,'-',52,'2019-05-23 20:15:42.000',0),(247,'Leong Zi Jian, Aloysius',27,'-',52,'2019-05-23 20:15:42.000',0),(248,'Wong Kam Choy, Jack',27,'-',52,'2019-05-23 20:15:42.000',0),(249,'Serene Kiew',27,'-',52,'2019-05-23 20:15:42.000',0),(250,'Jennie Wong',27,'-',52,'2019-05-23 20:15:42.000',0),(251,'Zou Xuncheng, Jonathan',27,'-',52,'2019-05-23 20:15:42.000',0),(252,'Lim Chit Meng, Richard',27,'-',52,'2019-05-23 20:15:42.000',0),(253,'Wong Chee Kheong, Daniel',27,'-',52,'2019-05-23 20:15:42.000',0),(254,'Yong Hock Hung',27,'-',52,'2019-05-23 20:15:42.000',0),(255,'Tan Ken Boon, Ken',27,'-',52,'2019-05-23 20:15:42.000',0),(256,'Ng Aik Harm',27,'-',52,'2019-05-23 20:15:42.000',0),(257,'Lim Ai Choo (Lin Aizhu)',27,'-',52,'2019-05-23 20:15:42.000',0),(258,'Paulus Hu',27,'-',52,'2019-05-23 20:15:42.000',0),(259,'Chong Siew Loo Lydia',27,'-',52,'2019-05-23 20:15:42.000',0),(260,'Hannah Tham Favzi (NEC)',27,'-',52,'2019-05-23 20:15:42.000',0),(261,'Nur Bazlaa (NEC)',27,'-',52,'2019-05-23 20:15:42.000',0),(262,'Poon Kin Meng(NEC)',27,'-',52,'2019-05-23 20:15:42.000',0),(263,'Rachel Cheng(NEC)',27,'-',52,'2019-05-23 20:15:42.000',0),(264,'Alphaeus Wong(NEC)',27,'-',52,'2019-05-23 20:15:42.000',0),(265,'Ngu Toh King(NEC)',27,'-',52,'2019-05-23 20:15:42.000',0),(266,'Vinita Vijakumar(HCL)',27,'-',52,'2019-05-23 20:15:42.000',0),(267,'Jesse Leong(JOS)',27,'-',52,'2019-05-23 20:15:42.000',0),(268,'Iki Ng Yen Shen',27,'-',52,'2019-05-23 20:15:42.000',0),(269,'Sim Chin Yun Sherry',27,'-',52,'2019-05-23 20:15:42.000',0),(270,'Tan Lee Hia',27,'-',52,'2019-05-23 20:15:42.000',0),(271,'Yeo Chee Boon Edward',27,'-',52,'2019-05-23 20:15:42.000',0),(272,'Teo Yi Wen',27,'-',52,'2019-05-23 20:15:42.000',0),(273,'Evelyn Kuah',27,'-',52,'2019-05-23 20:15:42.000',0),(274,'Liew Wee Kiat',27,'-',52,'2019-05-23 20:15:42.000',0),(275,'Chua Poh Lian Pauline',27,'-',52,'2019-05-23 20:15:42.000',0),(276,'Tan Mei Shan',27,'-',52,'2019-05-23 20:15:42.000',0),(277,'Tan Mei Shuan',27,'-',52,'2019-05-23 20:15:42.000',0),(278,'Wu Weiqi Edwin',27,'-',52,'2019-05-23 20:15:42.000',0),(279,'Felina Tan Jee May',27,'-',52,'2019-05-23 20:15:42.000',0),(280,'Sim Hwee Lin Linda',27,'-',52,'2019-05-23 20:15:42.000',0),(281,'Low Xin Xian, Terrence',27,'-',52,'2019-05-23 20:15:42.000',0),(282,'Tan Geok Lan Jessie',27,'-',52,'2019-05-23 20:15:42.000',0),(283,'Fey Tui Phin',27,'-',52,'2019-05-23 20:15:42.000',0),(284,'Tan Siew Hoon',27,'-',52,'2019-05-23 20:15:42.000',0),(285,'Tan Hwee Leng April',27,'-',52,'2019-05-23 20:15:42.000',0),(286,'Lim Li-Ern Charis',27,'-',52,'2019-05-23 20:15:42.000',0),(287,'Tham May Hoong Sylvia',27,'-',52,'2019-05-23 20:15:42.000',0),(288,'Goh Pei Fang, Wendy',27,'-',52,'2019-05-23 20:15:42.000',0),(289,'Goh Kiao Goon Patricia',27,'-',52,'2019-05-23 20:15:42.000',0),(290,'Janice Lee Sze Min',27,'-',52,'2019-05-23 20:15:42.000',0),(291,'Sae Yip Emyi',27,'-',52,'2019-05-23 20:15:42.000',0),(292,'Jolene Chua',27,'-',52,'2019-05-23 20:15:42.000',0),(293,'Tong Wei Shan',27,'-',52,'2019-05-23 20:15:42.000',0),(294,'Evelyn Low',27,'-',52,'2019-05-23 20:15:42.000',0),(295,'Angeline Tay',27,'-',52,'2019-05-23 20:15:42.000',0),(296,'Lim Miao Qin',27,'-',52,'2019-05-23 20:15:42.000',0),(297,'Ian Teo',27,'-',52,'2019-05-23 20:15:42.000',0),(298,'Samantha Liew',27,'-',52,'2019-05-23 20:15:42.000',0),(299,'Hanisah',27,'-',52,'2019-05-23 20:15:42.000',0),(300,'Rafidah Binte Othman',27,'-',52,'2019-05-23 20:15:42.000',0),(301,'Choy Wan Moon Joanne',27,'-',52,'2019-05-23 20:15:42.000',0),(302,'Lim Gek Min Emin',27,'-',52,'2019-05-23 20:15:42.000',0),(303,'Siti Atiqah',27,'-',52,'2019-05-23 20:15:42.000',0),(304,'Roy Chua',27,'-',52,'2019-05-23 20:15:42.000',0),(305,'Hillary Tan Siow Shan',27,'-',52,'2019-05-23 20:15:42.000',0),(306,'Priscilla Ng',27,'-',52,'2019-05-23 20:15:42.000',0),(307,'Ho En Qi',27,'-',52,'2019-05-23 20:15:42.000',0),(308,'Lee Kim Yiang',27,'-',52,'2019-05-23 20:15:42.000',0),(309,'Santhy Mary',27,'-',52,'2019-05-23 20:15:42.000',0),(310,'Hamisah Bte Mohd Ariff',27,'-',52,'2019-05-23 20:15:42.000',0),(311,'Nurulhuda',27,'-',52,'2019-05-23 20:15:42.000',0),(312,'Nasirah',27,'-',52,'2019-05-23 20:15:42.000',0),(313,'Kalaiselvi d/o Paramasiwan',27,'-',52,'2019-05-23 20:15:42.000',0),(314,'Lee Soak Mei, Connie',27,'-',52,'2019-05-23 20:15:42.000',0),(315,'Cally Lim',27,'-',52,'2019-05-23 20:15:42.000',0),(316,'Toh Pei Shan (Temp)',27,'-',52,'2019-05-23 20:15:42.000',0),(317,'Sia Ming Xiang (Temp)',27,'-',52,'2019-05-23 20:15:42.000',0),(318,'Yeoh Hui Zhen (Temp)',27,'-',52,'2019-05-23 20:15:42.000',0),(319,'Piriya (Temp)',27,'-',52,'2019-05-23 20:15:42.000',0),(320,'Jaseela (Temp)',27,'-',52,'2019-05-23 20:15:42.000',0),(321,'Zhuo Xueling',27,'-',52,'2019-05-23 20:15:42.000',0),(322,'Koh Guat Sen, Elaine',27,'-',52,'2019-05-23 20:15:42.000',0),(323,'Lim Ching Peng, Yvonne',27,'-',52,'2019-05-23 20:15:42.000',0),(324,'Carine Ang Bee Leng',27,'-',52,'2019-05-23 20:15:42.000',0),(325,'Yeo Seow Poh Evelyn',27,'-',52,'2019-05-23 20:15:42.000',0),(326,'Lim Geok Ling, Carol',27,'-',52,'2019-05-23 20:15:42.000',0),(327,'Shirley Chan',27,'-',52,'2019-05-23 20:15:42.000',0),(328,'Teo Hui Min Doris',27,'-',52,'2019-05-23 20:15:42.000',0),(329,'Zarina Binte Yahaya',27,'-',52,'2019-05-23 20:15:42.000',0),(330,'Chua Loh Mui Alice',27,'-',52,'2019-05-23 20:15:42.000',0),(331,'Chua Huey Kiow',27,'-',52,'2019-05-23 20:15:42.000',0),(332,'Linda Lim',27,'-',52,'2019-05-23 20:15:42.000',0),(333,'Shirley Ong',27,'-',52,'2019-05-23 20:15:42.000',0),(334,'Clarence Cheng (Temp)',27,'-',52,'2019-05-23 20:15:42.000',0),(335,'Wong Swee Siang (Temp)',27,'-',52,'2019-05-23 20:15:42.000',0),(336,'Teo Wan Lin (Temp)',27,'-',52,'2019-05-23 20:15:42.000',0),(337,'Nicholas Koh',27,'-',52,'2019-05-23 20:15:42.000',0),(338,'Jerene Ng',27,'-',52,'2019-05-23 20:15:42.000',0),(339,'Charlene Seah',27,'-',52,'2019-05-23 20:15:42.000',0),(340,'Sidney Tio',27,'-',52,'2019-05-23 20:15:42.000',0),(341,'Claris Zhao',27,'-',52,'2019-05-23 20:15:42.000',0),(342,'Shannon Ng',27,'-',52,'2019-05-23 20:15:42.000',0),(343,'Linus Mok',27,'-',52,'2019-05-23 20:15:42.000',0),(344,'Lim Min Er',27,'-',52,'2019-05-23 20:15:42.000',0),(345,'Sophia Gan',27,'-',52,'2019-05-23 20:15:42.000',0),(346,'Loretta Low',27,'-',52,'2019-05-23 20:15:42.000',0),(347,'Janice Natalie Chong',27,'-',52,'2019-05-23 20:15:42.000',0),(348,'Benjamin Chong',27,'-',52,'2019-05-23 20:15:42.000',0),(349,'Trachelle Chye',27,'-',52,'2019-05-23 20:15:42.000',0),(350,'Connie Chua',27,'-',52,'2019-05-23 20:15:42.000',0),(351,'Karam Joti',27,'-',52,'2019-05-23 20:15:42.000',0),(352,'Elaine Lee',27,'-',52,'2019-05-23 20:15:42.000',0),(353,'Vanessa Mak',27,'-',52,'2019-05-23 20:15:42.000',0),(354,'Isabelle Tan',28,'-',52,'2019-05-23 20:15:42.000',0),(355,'Jeslyna Chow',28,'-',52,'2019-05-23 20:15:42.000',0),(356,'Ang Jie Leng',28,'-',52,'2019-05-23 20:15:42.000',0),(357,'Ng Shi Min',28,'-',52,'2019-05-23 20:15:42.000',0),(358,'An Chengwu',28,'-',52,'2019-05-23 20:43:57.000',0),(359,'Arseniy Kuznetsov',28,'-',52,'2019-05-23 20:43:57.000',0),(360,'Chen Zilong',28,'-',52,'2019-05-23 20:43:57.000',0),(361,'Choi Sumin',28,'-',52,'2019-05-23 20:43:57.000',0),(362,'Dai Jibo',28,'-',52,'2019-05-23 20:43:57.000',0),(363,'Dmitry Kalashnikov',28,'-',52,'2019-05-23 20:43:57.000',0),(364,'Fu Yuan-Hsing',28,'-',52,'2019-05-23 20:43:57.000',0),(365,'Ha Son Tung',28,'-',52,'2019-05-23 20:43:57.000',0),(366,'Krivitskiy Leonid',28,'-',52,'2019-05-23 20:43:57.000',0),(367,'Lee Chee Wei',28,'-',52,'2019-05-23 20:43:57.000',0),(368,'Leong Xu Heng Victor',28,'-',52,'2019-05-23 20:43:57.000',0),(369,'Li Dongdong',28,'-',52,'2019-05-23 20:43:57.000',0),(370,'Li Shiqiang',28,'-',52,'2019-05-23 20:43:57.000',0),(371,'Liang Xinan',28,'-',52,'2019-05-23 20:43:57.000',0),(372,'Lukiyanchuk Boris',28,'-',52,'2019-05-23 20:43:57.000',0),(373,'Morits Dmitry',28,'-',52,'2019-05-23 20:43:57.000',0),(374,'Ng Keh Ting Doris',28,'-',52,'2019-05-23 20:43:57.000',0),(375,'Padath Anthur Aravind',28,'-',52,'2019-05-23 20:43:57.000',0),(376,'Pan Zhenying',28,'-',52,'2019-05-23 20:43:57.000',0),(377,'Pu Jing',28,'-',52,'2019-05-23 20:43:57.000',0),(378,'Ramon Jose Paniagua Dominguez',28,'-',52,'2019-05-23 20:43:57.000',0),(379,'Rasna Maruthiyodan Veetil',28,'-',52,'2019-05-23 20:43:57.000',0),(380,'Ren Min',28,'-',52,'2019-05-23 20:43:57.000',0),(381,'Reuben Michael Bakker',28,'-',52,'2019-05-23 20:43:57.000',0),(382,'Vytautas Valuckas',28,'-',52,'2019-05-23 20:43:57.000',0),(383,'Xu Xuewu',28,'-',52,'2019-05-23 20:43:57.000',0),(384,'Yang Hongzhi',28,'-',52,'2019-05-23 20:43:57.000',0),(385,'Yu Yefeng',28,'-',52,'2019-05-23 20:43:57.000',0),(386,'Zhang Haizhong',28,'-',52,'2019-05-23 20:43:57.000',0),(387,'Agnes Louis',28,'-',52,'2019-05-23 20:43:57.000',0),(388,'Mohammad Taufik Bin Ismail',28,'-',52,'2019-05-23 20:43:57.000',0),(389,'Najahah Binte Abdurrahim',28,'-',52,'2019-05-23 20:43:57.000',0),(390,'Tay Shu Hui Petrina',28,'-',52,'2019-05-23 20:43:57.000',0),(391,'V. Suvita',28,'-',52,'2019-05-23 20:43:57.000',0),(392,'Wai Pei Pei',28,'-',52,'2019-05-23 20:43:57.000',0),(393,'Xiong Fei',28,'-',52,'2019-05-23 20:43:57.000',0),(394,'Woon Chin Fong Chrystine',28,'-',52,'2019-05-23 20:43:57.000',0),(395,'Cheah Kok Beng',28,'-',52,'2019-05-23 20:43:57.000',0),(396,'Teoh Jul Nee',28,'-',52,'2019-05-23 20:43:57.000',0),(397,'Ibrahim See Boon Long',28,'-',52,'2019-05-23 20:43:57.000',0),(398,'Ang Tien Sze',28,'-',52,'2019-05-23 20:43:57.000',0),(399,'Carlberg Carl Johan Patrick',28,'-',52,'2019-05-23 20:43:57.000',0),(400,'Febiana Tjiptoharsono',28,'-',52,'2019-05-23 20:43:57.000',0),(401,'Goh Choon Hwa Ken',28,'-',52,'2019-05-23 20:43:57.000',0),(402,'Huang Aihong',28,'-',52,'2019-05-23 20:43:57.000',0),(403,'Leonard Verano Gonzaga',28,'-',52,'2019-05-23 20:43:57.000',0),(404,'Lim Chee Beng',28,'-',52,'2019-05-23 20:43:57.000',0),(405,'Lu Hsiao Tzu',28,'-',52,'2019-05-23 20:43:57.000',0),(406,'Luo Ping',28,'-',52,'2019-05-23 20:43:57.000',0),(407,'Ng Siu Kit',28,'-',52,'2019-05-23 20:43:57.000',0),(408,'Salauddeen S/O Allauddin',28,'-',52,'2019-05-23 20:43:57.000',0),(409,'Tan Ai Ling',28,'-',52,'2019-05-23 20:43:57.000',0),(410,'Thong Hwee Hwee',28,'-',52,'2019-05-23 20:43:57.000',0),(411,'Toh Yeow Teck',28,'-',52,'2019-05-23 20:43:57.000',0),(412,'Yap Lee Koon Sherry',28,'-',52,'2019-05-23 20:43:57.000',0),(413,'Chua Jing Ying (Cai Jingying)',28,'-',52,'2019-05-23 20:43:57.000',0),(414,'Ho Hui Ying',28,'-',52,'2019-05-23 20:43:57.000',0),(415,'Chung Chian Yong Darren (Zeng Jianyong D',28,'-',52,'2019-05-23 20:43:57.000',0),(416,'Chen Xiuying',28,'-',52,'2019-05-23 20:43:57.000',0),(417,'Chen Yunjie',28,'-',52,'2019-05-23 20:43:57.000',0),(418,'Hnin Yu Yu Ko',28,'-',52,'2019-05-23 20:43:57.000',0),(419,'Ji Rong',28,'-',52,'2019-05-23 20:43:57.000',0),(420,'Toh Suey Li',28,'-',52,'2019-05-23 20:43:57.000',0),(421,'Wong Seng Kai',28,'-',52,'2019-05-23 20:43:57.000',0),(422,'Xie Huiqing',28,'-',52,'2019-05-23 20:43:57.000',0),(423,'Xing Zhenxiang',28,'-',52,'2019-05-23 20:43:57.000',0),(424,'Zhang Mingsheng',28,'-',52,'2019-05-23 20:43:57.000',0),(425,'Zheng Rongyan',28,'-',52,'2019-05-23 20:43:57.000',0),(426,'Soumyanarayanan Anjan',28,'-',52,'2019-05-23 20:43:57.000',0),(427,'Tan Hang Khume',28,'-',52,'2019-05-23 20:43:57.000',0),(428,'Tan Kok Cheng Anthony',28,'-',52,'2019-05-23 20:43:57.000',0),(429,'Tan Seng Ghee',28,'-',52,'2019-05-23 20:43:57.000',0),(430,'Wang Hongtao',28,'-',52,'2019-05-23 20:43:57.000',0),(431,'Wang Weijie',28,'-',52,'2019-05-23 20:43:57.000',0),(432,'Yap Qi Jia',28,'-',52,'2019-05-23 20:43:57.000',0),(433,'Yuan Zhimin',28,'-',52,'2019-05-23 20:43:57.000',0),(434,'Zeng Minggang',28,'-',52,'2019-05-23 20:43:57.000',0),(435,'Zhuo Yiqian Victor',28,'-',52,'2019-05-23 20:43:57.000',0),(436,'Alan Yeo Kwan Yong',28,'-',52,'2019-05-23 20:43:57.000',0),(437,'Ang Shiming',28,'-',52,'2019-05-23 20:43:57.000',0),(438,'Chan Fook Mun',28,'-',52,'2019-05-23 20:43:57.000',0),(439,'Chan Joo Keng Joseph',28,'-',52,'2019-05-23 20:43:57.000',0),(440,'Chatterjee Ayantika',28,'-',52,'2019-05-23 20:43:57.000',0),(441,'Chen Cheng',28,'-',52,'2019-05-23 20:43:57.000',0),(442,'Chen Shibin',28,'-',52,'2019-05-23 20:43:57.000',0),(443,'Ching Zhi Yong',28,'-',52,'2019-05-23 20:43:57.000',0),(444,'Hamadi Charef Brahim Ahmed Salah',28,'-',52,'2019-05-23 20:43:57.000',0),(445,'Hsu Ruei-Hau',28,'-',52,'2019-05-23 20:43:57.000',0),(446,'Jayakrishnan Melur Madhathil',28,'-',52,'2019-05-23 20:43:57.000',0),(447,'Jestine Paul',28,'-',52,'2019-05-23 20:43:57.000',0),(448,'Jin Chao',28,'-',52,'2019-05-23 20:43:57.000',0),(449,'Juniarto Samsudin',28,'-',52,'2019-05-23 20:43:57.000',0),(450,'Kang Dee Meng',28,'-',52,'2019-05-23 20:43:57.000',0),(451,'Khin Mi Mi Aung',28,'-',52,'2019-05-23 20:43:57.000',0),(452,'Koh Eng Kiat',28,'-',52,'2019-05-23 20:43:57.000',0),(453,'Lim Chun Teck (Lin Junde)',28,'-',52,'2019-05-23 20:43:57.000',0),(454,'Ng Ming Jie Luke',28,'-',52,'2019-05-23 20:43:57.000',0),(455,'Peter Jagadpramana',28,'-',52,'2019-05-23 20:43:57.000',0),(456,'Renuga Kanagavelu',28,'-',52,'2019-05-23 20:43:57.000',0),(457,'Sergio Ruocco',28,'-',52,'2019-05-23 20:43:57.000',0),(458,'Shi Haixiang',28,'-',52,'2019-05-23 20:43:57.000',0),(459,'Sim Jun Jie',28,'-',52,'2019-05-23 20:43:57.000',0),(460,'Tan Cheng Wee',28,'-',52,'2019-05-23 20:43:57.000',0),(461,'Teo Kim Keng',28,'-',52,'2019-05-23 20:43:57.000',0),(462,'Toh Liew Loong',28,'-',52,'2019-05-23 20:43:57.000',0),(463,'Wang Chundong',28,'-',52,'2019-05-23 20:43:57.000',0),(464,'Wang Donghong',28,'-',52,'2019-05-23 20:43:57.000',0),(465,'Wang Nan',28,'-',52,'2019-05-23 20:43:57.000',0),(466,'Wei Qingsong',28,'-',52,'2019-05-23 20:43:57.000',0),(467,'Xi Weiya',28,'-',52,'2019-05-23 20:43:57.000',0),(468,'Xiao Nan',28,'-',52,'2019-05-23 20:43:57.000',0),(469,'Xu Quanqing',28,'-',52,'2019-05-23 20:43:57.000',0),(470,'Xue Mingdi',28,'-',52,'2019-05-23 20:43:57.000',0),(471,'Yang Hong',28,'-',52,'2019-05-23 20:43:57.000',0),(472,'Yang Jun',28,'-',52,'2019-05-23 20:43:57.000',0),(473,'Yang Yechao',28,'-',52,'2019-05-23 20:43:57.000',0),(474,'Yong Khai Leong',28,'-',52,'2019-05-23 20:43:57.000',0),(475,'Zhang Yu',28,'-',52,'2019-05-23 20:43:57.000',0),(476,'Zhu Yongqing',28,'-',52,'2019-05-23 20:43:57.000',0),(477,'Anna Paterova',28,'-',52,'2019-05-23 20:43:57.000',0),(478,'Darien Tan Shi Feng',28,'-',52,'2019-05-23 20:43:57.000',0),(479,'Egor Khaidarov',28,'-',52,'2019-05-23 20:43:57.000',0),(480,'Indra Raditya Gunawan',28,'-',52,'2019-05-23 20:43:57.000',0),(481,'Jin TianLi',28,'-',52,'2019-05-23 20:43:57.000',0),(482,'Karim Ali Abd El Tawwab Ahmed',28,'-',52,'2019-05-23 20:43:57.000',0),(483,'Li Sihua',28,'-',52,'2019-05-23 20:43:57.000',0),(484,'Mylnikov Vasilii',28,'-',52,'2019-05-23 20:43:57.000',0),(485,'Ngui Phui Yook',28,'-',52,'2019-05-23 20:43:57.000',0),(486,'Qin Qing',28,'-',52,'2019-05-23 20:43:57.000',0),(487,'Salih Yanikgönül',28,'-',52,'2019-05-23 20:43:57.000',0),(488,'Sun Mingyu',28,'-',52,'2019-05-23 20:43:57.000',0),(489,'Xu Kaichen',28,'-',52,'2019-05-23 20:43:57.000',0),(490,'Yoong Herng Yau',28,'-',52,'2019-05-23 20:43:57.000',0),(491,'Hong Yan',29,'-',52,'2019-05-23 21:00:04.000',0),(492,'Tang Tao',29,'-',52,'2019-05-23 21:00:04.000',0),(493,'Zhou Wei',29,'-',52,'2019-05-23 21:00:04.000',0),(494,'David Orlando Kurniawan',29,'-',52,'2019-05-23 21:00:04.000',0),(495,'Lim Jia Song John',29,'-',52,'2019-05-23 21:00:04.000',0),(496,'RIZZO Roberto Giorgio',29,'-',52,'2019-05-23 21:00:04.000',0),(497,'Xie Yuxiang',29,'-',52,'2019-05-23 21:00:04.000',0),(498,'Manuela Loeblein',29,'-',52,'2019-05-23 21:00:04.000',0),(499,'Ding Henghui',29,'-',52,'2019-05-23 21:00:04.000',0),(500,'Huang Jianguo',29,'-',52,'2019-05-23 21:00:04.000',0),(501,'Jin Lin',29,'-',52,'2019-05-23 21:00:04.000',0),(502,'Wang Yuxiang',29,'-',52,'2019-05-23 21:00:04.000',0),(503,'Yan Libin',29,'-',52,'2019-05-23 21:00:04.000',0),(504,'Zhang Gong',29,'-',52,'2019-05-23 21:00:04.000',0),(505,'Zheng Shaonan',29,'-',52,'2019-05-23 21:00:04.000',0),(506,'Chen Nan',29,'-',52,'2019-05-23 21:00:04.000',0),(507,'Dong Bowei',29,'-',52,'2019-05-23 21:00:04.000',0),(508,'Tan Kang',29,'-',52,'2019-05-23 21:00:04.000',0),(509,'BHUVANENDRAN NAIR Gourikutty Sajay',29,'-',52,'2019-05-23 21:00:04.000',0),(510,'CHEN Yu',29,'-',52,'2019-05-23 21:00:04.000',0),(511,'CHUNG Jaehoon',29,'-',52,'2019-05-23 21:00:04.000',0),(512,'KONGSUPHOL Patthara',29,'-',52,'2019-05-23 21:00:04.000',0),(513,'LIM Boon Kiat',29,'-',52,'2019-05-23 21:00:04.000',0),(514,'LIM Swee Yin',29,'-',52,'2019-05-23 21:00:04.000',0),(515,'LIU Qing',29,'-',52,'2019-05-23 21:00:04.000',0),(516,'LIU Yunxiao',29,'-',52,'2019-05-23 21:00:04.000',0),(517,'MOHAMED RAFEI Siti Rafeah',29,'-',52,'2019-05-23 21:00:04.000',0),(518,'Qasem Moh\'d Hindi ALRAMADAN',29,'-',52,'2019-05-23 21:00:04.000',0),(519,'WANG Yanping Karen',29,'-',52,'2019-05-23 21:00:04.000',0),(520,'CHEW Si Yin',29,'-',52,'2019-05-23 21:00:04.000',0),(521,'GUO Zhen Angela',29,'-',52,'2019-05-23 21:00:04.000',0),(522,'Leong Poh Huat Jeffrey',29,'-',52,'2019-05-23 21:00:04.000',0),(523,'LIM Ching Yun',29,'-',52,'2019-05-23 21:00:04.000',0),(524,'LOO Wai Lin Betty',29,'-',52,'2019-05-23 21:00:04.000',0),(525,'MOI Lai Keng Wendy',29,'-',52,'2019-05-23 21:00:04.000',0),(526,'SOH Mei Cheng Cindy',29,'-',52,'2019-05-23 21:00:04.000',0),(527,'TAN Eng Khim Joanne',29,'-',52,'2019-05-23 21:00:04.000',0),(528,'TEO Hwee Gee Selin',29,'-',52,'2019-05-23 21:00:04.000',0),(529,'WANG Hua Sandy',29,'-',52,'2019-05-23 21:00:04.000',0),(530,'FUKUZAWA Hideaki',29,'-',52,'2019-05-23 21:00:04.000',0),(531,'WANG Xin Peng',29,'-',52,'2019-05-23 21:00:04.000',0),(532,'YU Jun(Ms)',29,'-',52,'2019-05-23 21:00:04.000',0),(533,'CHEN Bing',29,'-',52,'2019-05-23 21:00:04.000',0),(534,'Lai Keng Heng',29,'-',52,'2019-05-23 21:00:04.000',0),(535,'LIN Qunying',29,'-',52,'2019-05-23 21:00:04.000',0),(536,'LIN Ying',29,'-',52,'2019-05-23 21:00:04.000',0),(537,'Serene TAN',29,'-',52,'2019-05-23 21:00:04.000',0),(538,'WANG Shijie',29,'-',52,'2019-05-23 21:00:04.000',0),(539,'LAU Guan Kian',29,'-',52,'2019-05-23 21:00:04.000',0),(540,'TEO Eng Siong',29,'-',52,'2019-05-23 21:00:04.000',0),(541,'CHEMMANDA John Leo',29,'-',52,'2019-05-23 21:00:04.000',0),(542,'CHEONG Jia Hao',29,'-',52,'2019-05-23 21:00:04.000',0),(543,'CHIA Zhenguo Vincent',29,'-',52,'2019-05-23 21:00:04.000',0),(544,'GAO Yuan',29,'-',52,'2019-05-23 21:00:04.000',0),(545,'I MADE Darmayuda',29,'-',52,'2019-05-23 21:00:04.000',0),(546,'JEON Yong Joon',29,'-',52,'2019-05-23 21:00:04.000',0),(547,'SARBUDEEN Mohamed Rabeek',29,'-',52,'2019-05-23 21:00:04.000',0),(548,'YAO Lei',29,'-',52,'2019-05-23 21:00:04.000',0),(549,'ZHAO Jianming',29,'-',52,'2019-05-23 21:00:04.000',0),(550,'CHANG Kah Hyong',29,'-',52,'2019-05-23 21:00:04.000',0),(551,'DO Anh Tuan',29,'-',52,'2019-05-23 21:00:04.000',0),(552,'LAN Jingjing',29,'-',52,'2019-05-23 21:00:04.000',0),(553,'LIM Lay Keng',29,'-',52,'2019-05-23 21:00:04.000',0),(554,'LIU Xin',29,'-',52,'2019-05-23 21:00:04.000',0),(555,'WANG Chao',29,'-',52,'2019-05-23 21:00:04.000',0),(556,'ZHANG Hongbao',29,'-',52,'2019-05-23 21:00:04.000',0),(557,'ZHAO Bin',29,'-',52,'2019-05-23 21:00:04.000',0),(558,'ZHOU Jun',29,'-',52,'2019-05-23 21:00:04.000',0),(559,'DUTTA Rahul',29,'-',52,'2019-05-23 21:00:04.000',0),(560,'GOH Kim Seng',29,'-',52,'2019-05-23 21:00:04.000',0),(561,'JAIN Vibhor',29,'-',52,'2019-05-23 21:00:04.000',0),(562,'LIM Keng Chuan',29,'-',52,'2019-05-23 21:00:04.000',0),(563,'LIM Zhi Xian',29,'-',52,'2019-05-23 21:00:04.000',0),(564,'LOW Shaw Chin',29,'-',52,'2019-05-23 21:00:04.000',0),(565,'Nursuria Binte ANNUAR',29,'-',52,'2019-05-23 21:00:04.000',0),(566,'PHOON Mun Wei',29,'-',52,'2019-05-23 21:00:04.000',0),(567,'TAN Tsuen Hui',29,'-',52,'2019-05-23 21:00:04.000',0),(568,'YONG Chin Siang',29,'-',52,'2019-05-23 21:00:04.000',0),(569,'LIU Hang',29,'-',52,'2019-05-23 21:00:04.000',0),(570,'MUTHUSAMY Kumarasamy Raja',29,'-',52,'2019-05-23 21:00:04.000',0),(571,'YAN Dan Lei',29,'-',52,'2019-05-23 21:00:04.000',0),(572,'CHAI Tshun Chuan',29,'-',52,'2019-05-23 21:00:04.000',0),(573,'NAG Dipankar',29,'-',52,'2019-05-23 21:00:04.000',0),(574,'Narasimman Neelakantan',29,'-',52,'2019-05-23 21:00:04.000',0),(575,'NISHIDA Yoshio',29,'-',52,'2019-05-23 21:00:04.000',0),(576,'SINGH Ravinder Pal',29,'-',52,'2019-05-23 21:00:04.000',0),(577,'CHUA Yi Fen',29,'-',52,'2019-05-23 21:00:04.000',0),(578,'WICKRAMANAYAKA Senerath W M Sunil',29,'-',52,'2019-05-23 21:00:04.000',0),(579,'WONG She Mein',29,'-',52,'2019-05-23 21:00:04.000',0),(580,'BUDDHARAJU Kavitha Devi',29,'-',52,'2019-05-23 21:00:04.000',0),(581,'TAN Wee Ming',29,'-',52,'2019-05-23 21:00:04.000',0),(582,'WALIA Rajan',29,'-',52,'2019-05-23 21:00:04.000',0),(583,'CHUA Yi Fang Joey',29,'-',52,'2019-05-23 21:00:04.000',0),(584,'CHUI King Jien',29,'-',52,'2019-05-23 21:00:04.000',0),(585,'MUTHUKUMARASWAMY Annamalai Arasu',29,'-',52,'2019-05-23 21:00:04.000',0),(586,'BHATTACHARYA Suryanarayana Shivakumar',29,'-',52,'2019-05-23 21:00:04.000',0),(587,'CHE Fa Xing',29,'-',52,'2019-05-23 21:00:04.000',0),(588,'CHEN Zhaohui',29,'-',52,'2019-05-23 21:00:04.000',0),(589,'Chen Zihao',29,'-',52,'2019-05-23 21:00:04.000',0),(590,'JONG Ming Chinq',29,'-',52,'2019-05-23 21:00:04.000',0),(591,'KIM Dowon',29,'-',52,'2019-05-23 21:00:04.000',0),(592,'LIM Teck Guan',29,'-',52,'2019-05-23 21:00:04.000',0),(593,'CHEN Weiguo',29,'-',52,'2019-05-23 21:00:04.000',0),(594,'CHENG Ming-Yuan',29,'-',52,'2019-05-23 21:00:04.000',0),(595,'DAMALERIO Maria Ramona Ninfa Bautista',29,'-',52,'2019-05-23 21:00:04.000',0),(596,'LIM Ruiqi',29,'-',52,'2019-05-23 21:00:04.000',0),(597,'VEMPATI Srinivasa Rao',29,'-',52,'2019-05-23 21:00:04.000',0),(598,'BU Lin',29,'-',52,'2019-05-23 21:00:04.000',0),(599,'HAN Yong',29,'-',52,'2019-05-23 21:00:04.000',0),(600,'TANG Gongyue',29,'-',52,'2019-05-23 21:00:04.000',0),(601,'ZHANG Xiaowu',29,'-',52,'2019-05-23 21:00:04.000',0),(602,'JI Hongmiao',29,'-',52,'2019-05-23 21:00:04.000',0),(603,'AU Keng Yuen',29,'-',52,'2019-05-23 21:00:04.000',0),(604,'CHAI Tai Chong',29,'-',52,'2019-05-23 21:00:04.000',0),(605,'LEE Jong Bum',29,'-',52,'2019-05-23 21:00:04.000',0),(606,'LIM Seow Huang Sharon',29,'-',52,'2019-05-23 21:00:04.000',0),(607,'SINGH Navab',29,'-',52,'2019-05-23 21:00:04.000',0),(608,'CAI Hong',29,'-',52,'2019-05-23 21:00:04.000',0),(609,'CHANG Hyun Kee',29,'-',52,'2019-05-23 21:00:04.000',0),(610,'GU Yuandong',29,'-',52,'2019-05-23 21:00:04.000',0),(611,'HAN Beibei',29,'-',52,'2019-05-23 21:00:04.000',0),(612,'LEE Yao Ting Lennon',29,'-',52,'2019-05-23 21:00:04.000',0),(613,'LOU Liang',29,'-',52,'2019-05-23 21:00:04.000',0),(614,'Ng Jiaqiang, Eldwin',29,'-',52,'2019-05-23 21:00:04.000',0),(615,'SUN Chengliang',29,'-',52,'2019-05-23 21:00:04.000',0),(616,'SUN Tao',29,'-',52,'2019-05-23 21:00:04.000',0),(617,'TAO Jifang',29,'-',52,'2019-05-23 21:00:04.000',0),(618,'WANG Nan',29,'-',52,'2019-05-23 21:00:04.000',0),(619,'WONG You Liang Lionel',29,'-',52,'2019-05-23 21:00:04.000',0),(620,'WU Guoqiang',29,'-',52,'2019-05-23 21:00:04.000',0),(621,'XIE Qingyun',29,'-',52,'2019-05-23 21:00:04.000',0),(622,'XU Jinghui',29,'-',52,'2019-05-23 21:00:04.000',0),(623,'XUE Ning',29,'-',52,'2019-05-23 21:00:04.000',0),(624,'ZHANG Songsong',29,'-',52,'2019-05-23 21:00:04.000',0),(625,'ZHU Yao',29,'-',52,'2019-05-23 21:00:04.000',0),(626,'Keng Fu',29,'-',52,'2019-05-23 21:00:04.000',0),(627,'Raisa Green',29,'-',52,'2019-05-23 21:00:04.000',0),(628,'Sameer Hodge',28,'-',52,'2019-05-23 21:00:04.000',0),(629,'Charly Olson',27,'-',52,'2019-05-23 21:00:04.000',0);
/*!40000 ALTER TABLE `TenantEmployee` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `User`
--

DROP TABLE IF EXISTS `User`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `User` (
  `userId` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `displayName` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pushNotificationToken` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `profileImage` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tenantEmployeeId` int(11) DEFAULT NULL,
  `phoneNumber` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notification` tinyint(1) DEFAULT '1',
  `deleted` tinyint(1) DEFAULT '0',
  `isAdmin` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`userId`),
  UNIQUE KEY `username_UNIQUE` (`username`),
  KEY `tenantEmployeeId` (`tenantEmployeeId`),
  CONSTRAINT `FKhqf58jo4condsam0xi9aftup2` FOREIGN KEY (`tenantEmployeeId`) REFERENCES `TenantEmployee` (`tenantEmployeeId`),
  CONSTRAINT `User_ibfk_1` FOREIGN KEY (`tenantEmployeeId`) REFERENCES `TenantEmployee` (`tenantEmployeeId`)
) ENGINE=InnoDB AUTO_INCREMENT=86 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `User`
--

LOCK TABLES `User` WRITE;
/*!40000 ALTER TABLE `User` DISABLE KEYS */;
INSERT INTO `User` VALUES (1,'user001','ChengSuChen','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','Leader','user01@gmail.com',NULL,'test/userprofileimage/0001_1555468500233.jpeg',NULL,'98554069',1,0,0),(2,'user002','Heng Tze Kiang','$2a$10$JTKqCBDs.fRCWSY/RU2kguoF1xxn0huTkhfr1QUes9rA6sa4kwRqa','Leader','user02@gmail.com',NULL,'test/userprofileimage/0001_1554453985262.jpeg',NULL,'97995746',1,0,0),(3,'user003','Christopher Loh','$2a$10$N3Mj1Q6kiKf84Z3nb2fdRubj4Eeg/Qw68JfYWe9c7PSN0GamPuDi6','Leader','user03@gmail.com',NULL,'test/userprofileimage/0001_1554374300010.jpeg',NULL,'82002261',1,0,0),(4,'user004','Sunny Tan','$2a$10$X9a1lKWgUpsC78SiGPa8beZU8sitIsEcUAA76lpHkLwm4ElMShn3.','Safety & Recovery Services Section I/C','user04@gmail.com',NULL,'default_image.jpeg',NULL,'97333632',1,0,0),(5,'user005','Maria Chyril','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','Safety & Recovery Services Section I/C','',NULL,'default_image.jpeg',NULL,'82019041',1,0,0),(6,'user006','Asen Chow','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','Safety & Recovery Services Section I/C','',NULL,'default_image.jpeg',NULL,'97913488',1,1,0),(7,'user007','Wilson Voon','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','M&E System I/C','',NULL,'default_image.jpeg',NULL,'98508971',1,0,0),(8,'user008','Fong Siew Cheong','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','M&E System I/C','',NULL,'default_image.jpeg',NULL,'96801398',1,1,0),(9,'user009','Lawrence Wu','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','M&E System I/C','',NULL,'default_image.jpeg',NULL,'91111253',1,0,0),(10,'user010','Sam Tan','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','Building Section I/C','',NULL,'default_image.jpeg',NULL,'93671215',1,1,0),(11,'user011','Hemalatha','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','Building Section I/C','',NULL,'default_image.jpeg',NULL,'96566972',1,0,0),(12,'user012','Patrik Poh','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','Building Section I/C','',NULL,'default_image.jpeg',NULL,'97422568',1,1,0),(13,'user013','David Tay','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','Cleaning Section I/C','',NULL,'default_image.jpeg',NULL,'90051757',1,0,0),(14,'user014','Jenny Tan','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','Cleaning Section I/C','',NULL,'default_image.jpeg',NULL,'97610551',1,1,0),(15,'user015','Satwant Singh','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','Cleaning Section I/C','',NULL,'default_image.jpeg',NULL,'64485606',1,0,0),(16,'user016','Christopher Loh','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','Security Section I/C','',NULL,'default_image.jpeg',NULL,'82002261',1,1,0),(17,'user017','Simon Lim','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','Security Section I/C','',NULL,'default_image.jpeg',NULL,'98776159',1,0,0),(18,'user018','Barry Chong','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','Security Section I/C','',NULL,'default_image.jpeg',NULL,'90068268',1,1,0),(19,'user019','Png Chiew Hoon','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','Tenant/ Staff Liaison Section I/C','',NULL,'default_image.jpeg',NULL,'64489262',1,0,0),(20,'user020','Amy Foo','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','Tenant/ Staff Liaison Section I/C','',NULL,'default_image.jpeg',NULL,'93362609',1,1,0),(21,'user021','Dylan Wong','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','Tenant/ Staff Liaison Section I/C','',NULL,'default_image.jpeg',NULL,'91776058',1,0,0),(22,'user022','Christina Goh','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','Office Support Section I/C','',NULL,'default_image.jpeg',NULL,'96835044',1,1,0),(23,'user023','Chelsia Chan','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','Office Support Section I/C','',NULL,'default_image.jpeg',NULL,'97583921',1,0,0),(24,'user024','Catherine Ng','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','Office Support Section I/C','',NULL,'default_image.jpeg',NULL,'91502754',1,1,0),(25,'user025','Alicia Tay','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','Other Support Staff','',NULL,'default_image.jpeg',NULL,'91013182',1,0,0),(26,'user026','R Sakinah','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','Other Support Staff','',NULL,'default_image.jpeg',NULL,'82004746',1,1,0),(27,'user027','Michelle lau','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','Other Support Staff','',NULL,'default_image.jpeg',NULL,'97614573',1,0,0),(28,'user028','Wong Wei Ting','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','Other Support Staff','',NULL,'default_image.jpeg',NULL,'97382007',1,1,0),(29,'user029','Alvin Loke','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','Other Support Staff','',NULL,'default_image.jpeg',NULL,'90210956',1,0,0),(30,'user030','Jaslyn Lau','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','Other Support Staff','',NULL,'default_image.jpeg',NULL,'97428177',1,1,0),(31,'tester001','Katlyn Timms','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','Technician Manager','',NULL,'default_image.jpeg',NULL,NULL,1,0,0),(32,'tester002','Sophie Hughes','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','Technician Manager','',NULL,'default_image.jpeg',NULL,NULL,1,1,0),(33,'tester003','Mahi Fletcher','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','Technician Manager','',NULL,'default_image.jpeg',NULL,NULL,1,0,0),(34,'tester004','Stuart Marsh','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','Technician','','cQ9Tn7lcQ04:APA91bEhpSPVI3ImsGqImA3cEuC69PUfk5YEv9UvAeHyG9MXl_QUiwYJsEZfj_SZTQSBWu0JgX7rwDnOBImUHGTcqkjMUSsDXvZT9a25_uOxJnys4gvxxAylORhCiKNpAK08YbFKug_S','default_image.jpeg',NULL,NULL,1,0,0),(35,'tester005','Lyla John','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','Technician','',NULL,'default_image.jpeg',NULL,NULL,1,0,0),(36,'tester006','Jacob Wainwright','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','Technician','',NULL,'default_image.jpeg',NULL,NULL,1,1,0),(37,'tester007','Natalie Hampton','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','Accountant','',NULL,'default_image.jpeg',NULL,NULL,1,0,0),(38,'tester008','Arnold Osborn','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','Accountant','',NULL,'default_image.jpeg',NULL,NULL,1,1,0),(39,'tester009','Gertrude Dillon','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','Accountant','',NULL,'default_image.jpeg',NULL,NULL,1,0,0),(40,'tester010','Hettie Chung','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','Senior Accountant','',NULL,'default_image.jpeg',NULL,NULL,1,1,0),(41,'tester011','Raisa Green','$2a$10$FGxi1l9pgId7OXn4BEPLtuxliiz/KOUP7zblREgCP26S0DJGU1uOq','Senior Accountant','chinwq92@gmail.com',NULL,'userprofileimage/41_1555988157467.jpeg',627,'',1,0,0),(42,'tester012','Cathy Molloy','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','Senior Accountant','',NULL,'default_image.jpeg',NULL,NULL,1,0,0),(43,'tester013','Sameer Hodge','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','IT Manager','',NULL,'userprofileimage/43_1556073213138.jpeg',628,'',1,0,0),(44,'tester014','Maha Felix','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','IT Manager','',NULL,'default_image.jpeg',NULL,NULL,1,0,0),(45,'tester015','Nishat Carter','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','IT Manager','',NULL,'default_image.jpeg',NULL,NULL,1,0,0),(46,'tester016','Charly Olson','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','IT Personal','asansa@arya',NULL,'userprofileimage46_636915242603383936.jpeg',629,'9198899',1,0,0),(47,'tester017','Chandni Wardle','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','IT Personal','',NULL,'default_image.jpeg',NULL,NULL,1,0,0),(48,'tester018','Mali Middleton','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','IT Personal','',NULL,'default_image.jpeg',NULL,NULL,1,0,0),(49,'tester019','Filip Whelan','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','Manager','',NULL,'default_image.jpeg',NULL,NULL,1,0,0),(50,'tester020','Alessia Grainger','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','Manager','','euY83oDoBo4:APA91bE_JUgw4IPk_nDhMPDD-igGOuIK7Xu4X8M8cxNIFTtCClx67xKdkbfOISMW9ilQjkuCTlUEapQ4pDYsBarYTeblpIshZdrVW2tWuAWKddrNvjbLNf9flQ0D9KAmB2qcH8AUabG5','default_image.jpeg',NULL,NULL,1,0,0),(51,'admin','Admin','$2a$10$LWfkCaMUfmdO9F/8/T1XH.IIMy5k0hf/W5LvA.Bb/biLb82Zs/m6u','system admin','dws19559@gmail.com',NULL,'default_image.jpeg',NULL,'+6588881111',1,0,1),(52,'admin2','admin 00','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','system admin','chinwq92@gmail.com',NULL,'default_image.jpeg',NULL,NULL,1,0,1),(53,'user031','Phang In Yee','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC',NULL,'phangiy@imre.a-star.edu.sg',NULL,'default_image.jpeg',NULL,'65011862',1,0,1),(54,'user032','Wang Yi','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC',NULL,'wang_yi@simtech.a-star.edu.sg',NULL,'default_image.jpeg',NULL,'65903105',1,0,0),(55,'user033','Tan Jun Liang','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC',NULL,'junliang@simtech.a-star.edu.sg',NULL,'default_image.jpeg',NULL,'63194491',1,0,0),(56,'user034','Ng Boon Ping','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC',NULL,'bpng@simtech.a-star.edu.sg',NULL,'default_image.jpeg',NULL,'67149101',1,0,0),(57,'user035','Man Shu Mei','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC',NULL,'mansm@imre.a-star.edu.sg',NULL,'default_image.jpeg',NULL,'65011866',1,0,0),(58,'user036','He Ai Yu','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC',NULL,'heay@imre.a-star.edu.sg',NULL,'default_image.jpeg',NULL,'65101655',1,0,0),(59,'user037','Liu Rong','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC',NULL,'liurr@imre.a-star.edu.sg',NULL,'default_image.jpeg',NULL,'63194807',1,0,0),(60,'user038','Tan Chin Yaw','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC',NULL,'cy-tan@imre.a-star.edu.sg',NULL,'default_image.jpeg',NULL,'64168968',1,0,0),(61,'user039','Febiana Tjiptoharsono','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC',NULL,'febiana_tjiptoharsono@imre.a-star.edu.sg',NULL,'default_image.jpeg',NULL,'67149134',1,0,0),(62,'user040','Thong Hwee','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC',NULL,'thong_hwee_hwee@imre.a-star.edu.sg',NULL,'default_image.jpeg',NULL,'67149167',1,0,0),(63,'user041','CHENG Mei Ling','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC',NULL,'chengml@imre.a-star.edu.sg',NULL,'default_image.jpeg',NULL,'64168903',1,0,0),(64,'user042','LI Ming Hui','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC',NULL,'limh@imre.a-star.edu.sg',NULL,'default_image.jpeg',NULL,'64168904',1,0,0),(65,'user043','Cindy LIM Mui Hoon','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC',NULL,'cindy-lim@imre.a-star.edu.sg',NULL,'default_image.jpeg',NULL,'63194755',1,0,0),(66,'user044','SOH Chew Lea','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC',NULL,'sohcl@imre.a-star.edu.sg',NULL,'default_image.jpeg',NULL,'64168905',1,0,0),(67,'user045','Lee Pui Lye','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC',NULL,'lee_pui_lye@imre.a-star.edu.sg',NULL,'default_image.jpeg',NULL,'64168902',1,0,0),(68,'user046','SUNG Gek Kheng Migi','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC',NULL,'migi_sung@imre.a-star.edu.sg',NULL,'default_image.jpeg',NULL,'64168905',1,0,0),(69,'user047','Wendy Moi Lai Keng','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC',NULL,'wendy@ime.a-star.edu.sg',NULL,'default_image.jpeg',NULL,'67705304',1,0,0),(70,'user048','Joanne Tan Eng Khim','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC',NULL,'tanekj@ime.a-star.edu.sg',NULL,'default_image.jpeg',NULL,'67705328',1,0,0),(71,'user049','Valerie Ng Pei Yi','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC',NULL,'valerie_ng@ime.a-star.edu.sg',NULL,'default_image.jpeg',NULL,'67705351',1,0,0),(72,'user050','Yeo Yee Wan','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC',NULL,'yeo_yee_wan@ime.a-star.edu.sg',NULL,'default_image.jpeg',NULL,'67705424',1,0,0),(73,'user051','Cindy Soh Mei Cheng','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC',NULL,'meicheng@ime.a-star.edu.sg',NULL,'default_image.jpeg',NULL,'67705798',1,0,0),(74,'user052','Lim Ching Yun','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC',NULL,'limcy@ime.a-star.edu.sg',NULL,'default_image.jpeg',NULL,'67705319',1,0,0),(75,'user053','Yee Choon Seng','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC',NULL,'csyee@simtech.a-star.edu.sg',NULL,'default_image.jpeg',NULL,'65101665',1,0,0),(76,'user054','Wan Yin Chi','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC',NULL,'wanyc@simtech.a-star.edu.sg',NULL,'default_image.jpeg',NULL,'64197403',1,0,0),(77,'user055','Li Xiang, Leon','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC',NULL,'lixiang@simtech.a-star.edu.sg',NULL,'default_image.jpeg',NULL,'63194481',1,0,0),(78,'user056','Ng Shu Pei','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC',NULL,'ngsp@simtech.a-star.edu.sg',NULL,'default_image.jpeg',NULL,'65903176',1,0,0),(79,'user057','Julie Chua Chak Lun','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC',NULL,'chuaj8@hq.a-star.edu.sg',NULL,'default_image.jpeg',NULL,'65177869',1,0,0),(80,'user058','Sam Chan','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC',NULL,'',NULL,'default_image.jpeg',NULL,NULL,1,0,0),(81,'user059','Nicholas Koh','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC',NULL,'',NULL,'default_image.jpeg',NULL,NULL,1,0,0),(82,'user060','Fey Tui Phin','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC',NULL,'','dPZ9SueS7_8:APA91bEXNXbB2c_-QP53eFhHxyt8JKajvLQgzmKkMtfpn-EOQUZBg3URGu0dhBa_3-diXvzMdrj0n4D7wq7Vd6BAZYDkSbocZiM7u9Y1jAVpbBIEQ48XPsoRjmWW9ua19sGrhzw_aaym','default_image.jpeg',NULL,NULL,1,0,0),(83,'user061','Alice Chua','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC',NULL,'',NULL,'default_image.jpeg',NULL,NULL,1,0,0),(84,'user062','Benjamin Chong','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC',NULL,'',NULL,'default_image.jpeg',NULL,NULL,1,0,0),(85,'user063','Keng Fu','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC',NULL,'keng.fu@cwservices.com','dLPMU0oQBVY:APA91bE-3HaGLPRzsZZxqRji3eGJO0YeUbdqdNDsI1yCH6dG5ZvZHQXHRWtTC39uhyysDgXVbRNwJGwO6BqECmGH6pl0vzZWBVoSGLYMpB1gnj07UmcnoEAyaN-jlQ34d8HViTg3eWY0','default_image.jpeg',626,NULL,1,0,0);
/*!40000 ALTER TABLE `User` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'FSA1'
--

--
-- Dumping routines for database 'FSA1'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-05-24 12:01:32
