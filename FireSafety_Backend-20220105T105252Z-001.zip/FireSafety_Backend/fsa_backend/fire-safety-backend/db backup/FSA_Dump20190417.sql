-- MySQL dump 10.13  Distrib 5.7.17, for macos10.12 (x86_64)
--
-- Host: 127.0.0.1    Database: FSA
-- ------------------------------------------------------
-- Server version	5.5.5-10.1.37-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Building`
--

DROP TABLE IF EXISTS `Building`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Building` (
  `buildingId` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `numLevels` int(11) DEFAULT NULL,
  `latitude` double NOT NULL,
  `longtitude` double NOT NULL,
  `address1` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address2` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postalCode` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` varchar(75) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastUpdate` datetime(3) NOT NULL,
  `editedBy` int(11) NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`buildingId`),
  KEY `editedBy` (`editedBy`),
  CONSTRAINT `Building_ibfk_1` FOREIGN KEY (`editedBy`) REFERENCES `User` (`userId`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Building`
--

LOCK TABLES `Building` WRITE;
/*!40000 ALTER TABLE `Building` DISABLE KEYS */;
INSERT INTO `Building` VALUES (1,'NUH',25,1.2941186,104,'5 Lower Kent Ridge Rd','','s119074','singapore','2019-03-27 11:26:08.000',1,0),(2,'NUH Sports Centre',4,1.2927311,103.7853309,' Main Building Lobby B','5 Lower Kent Ridge Rd','s119074','singapore','2019-03-27 11:34:15.000',2,0),(3,'Timbre+',3,1.2904966,103.7864543,'73A Ayer Rajah Crescent','JTC Launchpad','s139957','singapore','2019-03-27 12:31:11.000',1,0),(4,'Ministry of education',4,0,0,'1 N Bouna Vista Drive ',NULL,'138675','singapore','2019-04-04 12:11:14.000',3,0);
/*!40000 ALTER TABLE `Building` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `BuildingLevel`
--

DROP TABLE IF EXISTS `BuildingLevel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `BuildingLevel` (
  `buildingLevelId` int(11) NOT NULL AUTO_INCREMENT,
  `buildingId` int(11) NOT NULL,
  `levelName` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`buildingLevelId`),
  KEY `buildingId` (`buildingId`),
  CONSTRAINT `BuildingLevel_ibfk_1` FOREIGN KEY (`buildingId`) REFERENCES `Building` (`buildingId`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BuildingLevel`
--

LOCK TABLES `BuildingLevel` WRITE;
/*!40000 ALTER TABLE `BuildingLevel` DISABLE KEYS */;
INSERT INTO `BuildingLevel` VALUES (1,1,'1',0),(2,1,'2',0),(3,1,'3',0),(4,2,'LG2',0),(5,2,'LG',0),(6,2,'G',0),(7,2,'1',0),(8,2,'2',0),(9,2,'3',0),(10,3,'1',0),(11,3,'2',0),(12,3,'3',0),(13,3,'4',0);
/*!40000 ALTER TABLE `BuildingLevel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `BuildingRole`
--

DROP TABLE IF EXISTS `BuildingRole`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `BuildingRole` (
  `buildingRoleId` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `buildingId` int(11) NOT NULL,
  `roleId` int(11) NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`buildingRoleId`),
  KEY `userId` (`userId`),
  KEY `buildingId` (`buildingId`),
  KEY `roleId` (`roleId`),
  CONSTRAINT `BuildingRole_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `User` (`userId`),
  CONSTRAINT `BuildingRole_ibfk_2` FOREIGN KEY (`buildingId`) REFERENCES `Building` (`buildingId`),
  CONSTRAINT `BuildingRole_ibfk_3` FOREIGN KEY (`roleId`) REFERENCES `Role` (`roleId`)
) ENGINE=InnoDB AUTO_INCREMENT=81 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BuildingRole`
--

LOCK TABLES `BuildingRole` WRITE;
/*!40000 ALTER TABLE `BuildingRole` DISABLE KEYS */;
INSERT INTO `BuildingRole` VALUES (1,1,1,2,0),(2,2,1,2,1),(3,3,1,2,0),(4,4,1,2,1),(5,5,1,2,0),(6,6,1,2,1),(7,7,1,2,0),(8,8,1,2,1),(9,9,1,2,0),(10,10,1,2,1),(11,11,2,2,0),(12,12,2,2,1),(13,13,2,2,0),(14,14,2,2,1),(15,15,2,2,0),(16,16,2,2,1),(17,17,2,2,0),(18,18,2,2,1),(19,19,2,2,0),(20,20,2,2,1),(21,21,3,2,0),(22,22,3,2,1),(23,23,3,2,0),(24,24,3,2,1),(25,25,3,2,0),(26,26,3,2,1),(27,27,3,2,0),(28,28,3,2,1),(29,29,3,2,0),(30,30,3,2,1),(31,31,4,2,0),(32,32,4,2,1),(33,33,4,2,0),(34,34,4,2,1),(35,35,4,2,0),(36,36,4,2,1),(37,37,4,2,0),(38,38,4,2,1),(39,39,4,2,0),(40,40,4,2,1),(41,41,1,1,0),(42,42,2,1,0),(43,43,3,1,0),(44,44,4,1,0),(45,42,1,1,0),(46,43,2,1,0),(47,44,3,1,0),(48,41,4,1,0),(49,43,1,3,0),(50,44,2,3,0),(51,41,3,3,0),(52,42,4,3,0),(53,45,1,3,0),(54,46,2,3,0),(55,47,3,3,0),(56,48,4,3,0),(57,49,1,3,0),(58,50,2,3,0),(59,42,3,3,0),(60,47,4,3,0),(61,50,1,3,0),(62,45,2,3,0),(63,49,3,3,0),(64,43,4,3,0),(65,48,1,3,0),(66,41,2,3,0),(67,50,3,3,0),(68,49,4,3,0),(69,47,1,4,0),(70,48,2,4,0),(71,46,3,4,0),(72,50,4,4,0),(73,44,1,4,0),(74,49,2,4,0),(75,45,3,4,0),(76,46,4,4,0),(77,46,1,1,0),(78,47,2,1,0),(79,48,3,1,0),(80,45,4,1,0);
/*!40000 ALTER TABLE `BuildingRole` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Certification`
--

DROP TABLE IF EXISTS `Certification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Certification` (
  `certificationId` int(11) NOT NULL AUTO_INCREMENT,
  `expirationDate` datetime(3) NOT NULL,
  `buildingId` int(11) NOT NULL,
  `documentName` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `documentKey` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`certificationId`),
  KEY `buildingId` (`buildingId`),
  CONSTRAINT `Certification_ibfk_1` FOREIGN KEY (`buildingId`) REFERENCES `Building` (`buildingId`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Certification`
--

LOCK TABLES `Certification` WRITE;
/*!40000 ALTER TABLE `Certification` DISABLE KEYS */;
INSERT INTO `Certification` VALUES (2,'2019-07-16 12:02:09.000',1,NULL,NULL,0),(3,'2019-07-16 12:16:03.000',1,NULL,NULL,0),(4,'2019-04-17 13:21:59.000',1,NULL,NULL,0);
/*!40000 ALTER TABLE `Certification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Configurations`
--

DROP TABLE IF EXISTS `Configurations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Configurations` (
  `configurationId` int(11) NOT NULL AUTO_INCREMENT,
  `trainingName` varchar(100) DEFAULT NULL,
  `trainingURL` varchar(255) DEFAULT NULL,
  `document` varchar(100) DEFAULT NULL,
  `lastUpdate` datetime(3) NOT NULL,
  `editedBy` varchar(45) NOT NULL,
  PRIMARY KEY (`configurationId`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Configurations`
--

LOCK TABLES `Configurations` WRITE;
/*!40000 ALTER TABLE `Configurations` DISABLE KEYS */;
INSERT INTO `Configurations` VALUES (1,'cnwWeb','https://www.cwservices.sg/',NULL,'2019-03-27 12:31:11.000','1');
/*!40000 ALTER TABLE `Configurations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Drawings`
--

DROP TABLE IF EXISTS `Drawings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Drawings` (
  `drawingId` int(11) NOT NULL AUTO_INCREMENT,
  `levelId` int(11) NOT NULL,
  `editedBy` int(11) DEFAULT NULL,
  `dateTime` datetime(3) NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `documentKey` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `documentName` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`drawingId`),
  KEY `editedBy` (`editedBy`),
  KEY `levelId` (`levelId`),
  CONSTRAINT `Drawings_ibfk_1` FOREIGN KEY (`editedBy`) REFERENCES `User` (`userId`),
  CONSTRAINT `Drawings_ibfk_2` FOREIGN KEY (`levelId`) REFERENCES `BuildingLevel` (`buildingLevelId`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Drawings`
--

LOCK TABLES `Drawings` WRITE;
/*!40000 ALTER TABLE `Drawings` DISABLE KEYS */;
INSERT INTO `Drawings` VALUES (1,10,48,'2019-04-17 09:35:14.000',0,'building_3/drawings/levelId_10/Drawing_48_1555464886197.jpeg','Drawing_48_1555464886197.jpeg'),(2,1,48,'2019-04-17 09:41:28.000',0,'building_1/drawings/levelId_1/Drawing_48_1555465284548.jpeg','Drawing_48_1555465284548.jpeg'),(3,4,45,'2019-04-17 09:47:58.000',0,'building_2/drawings/levelId_4/Drawing_45_1555465674887.jpeg','Drawing_45_1555465674887.jpeg'),(4,1,41,'2019-04-17 14:47:19.000',0,'building_1/drawings/levelId_1/Drawing_41_1555483637455.pdf','Demo Lift Inspection_Full_Report_DANIEL150202_2019-02-17'),(5,4,44,'2019-04-17 15:01:23.000',0,'building_2/drawings/levelId_4/Drawing_44_1555484480059.jpeg','Drawing_44_1555484480059.jpeg'),(6,4,44,'2019-04-17 15:01:44.000',0,'building_2/drawings/levelId_4/Drawing_44_1555484502077.jpeg','IMG_20190220_205148_020.jpg'),(7,4,44,'2019-04-17 15:02:00.000',0,'building_2/drawings/levelId_4/Drawing_44_1555484515359.pdf','Escalation Process and Preparedness.pdf'),(8,2,41,'2019-04-17 18:15:17.000',0,'building_1/drawings/levelId_2/Drawing_41_1555496113447.jpeg','Drawing_41_1555496113447.jpeg');
/*!40000 ALTER TABLE `Drawings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ERP`
--

DROP TABLE IF EXISTS `ERP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ERP` (
  `erpId` int(11) NOT NULL AUTO_INCREMENT,
  `buildingId` int(11) NOT NULL,
  `documentName` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `documentKey` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`erpId`),
  KEY `buildingId` (`buildingId`),
  CONSTRAINT `ERP_ibfk_1` FOREIGN KEY (`buildingId`) REFERENCES `Building` (`buildingId`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ERP`
--

LOCK TABLES `ERP` WRITE;
/*!40000 ALTER TABLE `ERP` DISABLE KEYS */;
INSERT INTO `ERP` VALUES (1,2,'7546','building_2/erp/erp_46_1555387176773.pdf',1),(2,2,'Blueberry-Pie-3-600x900.jpg','building_2/erp/erp_46_1555387185548.jpeg',0),(3,2,'7548','building_2/erp/erp_46_1555387229168.pdf',0),(4,2,'7546','building_2/erp/erp_46_1555387677267.pdf',0),(5,2,'1555383551435.jpg','building_2/erp/erp_46_1555387683733.jpeg',0),(6,2,'erp_45_1555466317969.jpeg','building_2/erp/erp_45_1555466317969.jpeg',0),(7,2,'erp_45_1555466326787.jpeg','building_2/erp/erp_45_1555466326787.jpeg',0),(8,1,'Demo Lift Inspection_Full_Report_OPH_2019-02-11','building_1/erp/erp_41_1555483622106.pdf',0);
/*!40000 ALTER TABLE `ERP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EmergencyData`
--

DROP TABLE IF EXISTS `EmergencyData`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `EmergencyData` (
  `emergencyDataId` int(11) NOT NULL AUTO_INCREMENT,
  `documentName` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `documentKey` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `levelId` int(11) NOT NULL,
  `editedBy` int(11) NOT NULL,
  `dateTime` datetime(3) NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`emergencyDataId`),
  KEY `editedBy` (`editedBy`),
  KEY `levelId` (`levelId`),
  CONSTRAINT `EmergencyData_ibfk_1` FOREIGN KEY (`editedBy`) REFERENCES `User` (`userId`),
  CONSTRAINT `EmergencyData_ibfk_2` FOREIGN KEY (`levelId`) REFERENCES `BuildingLevel` (`buildingLevelId`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EmergencyData`
--

LOCK TABLES `EmergencyData` WRITE;
/*!40000 ALTER TABLE `EmergencyData` DISABLE KEYS */;
INSERT INTO `EmergencyData` VALUES (1,'IMG_20190211_230439_161.jpg','building_2/ped/levelId_4/PED_2_1554458419700.jpeg',4,2,'2019-04-05 18:00:22.000',1),(2,'Equipment List for Fire Protection System.pdf','building_2/ped/levelId_7/PED_2_1554458454970.pdf',7,2,'2019-04-05 18:00:58.000',1),(3,'IMG_20190112_203353_503.jpg','building_2/ped/levelId_4/PED_2_1554458524802.jpeg',4,2,'2019-04-05 18:02:20.000',1),(4,'IMG_20190218_000848_058.jpg','building_2/ped/levelId_4/PED_2_1554458532940.jpeg',4,2,'2019-04-05 18:02:20.000',1),(5,'Equipment List for Fire Protection System.pdf','building_2/ped/levelId_4/PED_2_1554458536527.pdf',4,2,'2019-04-05 18:02:20.000',0),(6,'IMG_20190208_140352_447.jpg','building_2/ped/levelId_9/PED_2_1554458552472.jpeg',9,2,'2019-04-05 18:02:40.000',0),(7,'bg_popup_quizmax.png','building_2/ped/levelId_9/PED_2_1554458557883.jpeg',9,2,'2019-04-05 18:02:40.000',0),(8,'IMG_20181029_033114_206.jpg','building_2/ped/levelId_4/PED_2_1554458587075.jpeg',4,2,'2019-04-05 18:03:10.000',1),(9,'IMG_20190220_205148_020.jpg','building_2/ped/levelId_4/PED_2_1554458646420.jpeg',4,2,'2019-04-05 18:04:16.000',1),(10,'IMG_20190211_230439_161.jpg','building_2/ped/levelId_4/PED_2_1554458652451.jpeg',4,2,'2019-04-05 18:04:16.000',1),(11,'IMG_20190211_230439_161.jpg','building_2/ped/levelId_4/PED_2_1554458867651.jpeg',4,2,'2019-04-05 18:07:59.000',0),(12,'IMG_20190126_003024_052.jpg','building_2/ped/levelId_4/PED_2_1554458875458.jpeg',4,2,'2019-04-05 18:07:59.000',0),(13,'Escalation Process and Preparedness.pdf','building_2/ped/levelId_5/PED_2_1554458916986.pdf',5,2,'2019-04-05 18:08:39.000',1),(14,'IMG_20190112_203353_503.jpg','building_2/ped/levelId_5/PED_2_1554458925772.jpeg',5,2,'2019-04-05 18:09:21.000',1),(15,'bg_popup_quizmax.png','building_2/ped/levelId_5/PED_2_1554458931306.jpeg',5,2,'2019-04-05 18:09:21.000',1),(16,'PED_2_1554458940535.jpeg','building_2/ped/levelId_5/PED_2_1554458940535.jpeg',5,2,'2019-04-05 18:09:21.000',0),(17,'Escalation Process and Preparedness.pdf','building_2/ped/levelId_5/PED_2_1554458944985.pdf',5,2,'2019-04-05 18:09:21.000',0),(18,'IMG_20190208_140352_447.jpg','building_2/ped/levelId_5/PED_2_1554458970332.jpeg',5,2,'2019-04-05 18:09:42.000',0),(19,'IMG20190102131741.jpg','building_2/ped/levelId_5/PED_2_1554458978824.jpeg',5,2,'2019-04-05 18:09:42.000',0),(20,'IMG_20190211_230439_161.jpg','building_2/ped/levelId_8/PED_2_1554460070508.jpeg',8,2,'2019-04-05 18:27:54.000',1),(21,'IMG_20190211_230439_161.jpg','building_2/ped/levelId_8/PED_2_1554460115641.jpeg',8,2,'2019-04-05 18:28:44.000',1),(22,'IMG_20190211_230439_161.jpg','building_2/ped/levelId_8/PED_2_1554460683021.jpeg',8,2,'2019-04-05 18:38:12.000',1),(23,'IMG_20190211_230439_161.jpg','building_1/ped/levelId_1/PED_2_1554719057300.jpeg',1,2,'2019-04-08 18:24:29.000',1),(24,'IMG_20190105_103616_324.jpg','building_1/ped/levelId_1/PED_2_1554719066196.jpeg',1,2,'2019-04-08 18:24:29.000',1),(25,'IMG_20190407_135426_965.jpg','building_1/ped/levelId_1/PED_2_1554719086694.jpeg',1,2,'2019-04-08 18:24:48.000',0),(26,'IMG_20190220_205148_020.jpg','building_1/ped/levelId_2/PED_2_1554719106817.jpeg',2,2,'2019-04-08 18:25:09.000',0),(27,'IMG_20190126_003024_052.jpg','building_1/ped/levelId_3/PED_2_1554719116830.jpeg',3,2,'2019-04-08 18:25:19.000',0),(28,'PED_2_1554956556489.jpeg','building_1/ped/levelId_2/PED_2_1554956556489.jpeg',2,2,'2019-04-11 12:22:39.000',0),(29,'IMG_20190220_205148_020.jpg','building_1/ped/levelId_1/PED_2_1554956623862.jpeg',1,2,'2019-04-11 12:23:47.000',0),(30,'PED_45_1555466365809.jpeg','building_2/ped/levelId_4/PED_45_1555466365809.jpeg',4,45,'2019-04-17 09:59:28.000',0),(31,'Demo Lift Inspection_Full_Report_XU  1B_2019-01-17','building_1/ped/levelId_1/PED_46_1555483889975.pdf',1,46,'2019-04-17 14:51:33.000',0),(32,'Requirements Specifications Fire Safety Mobile App 1.1.pdf','building_2/ped/levelId_4/PED_44_1555484435937.pdf',4,44,'2019-04-17 15:00:43.000',0);
/*!40000 ALTER TABLE `EmergencyData` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Escalation`
--

DROP TABLE IF EXISTS `Escalation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Escalation` (
  `escalationId` int(11) NOT NULL AUTO_INCREMENT,
  `buildingId` int(11) NOT NULL,
  `dateTime` datetime(3) NOT NULL,
  `reporter` int(11) NOT NULL,
  `lastUpdate` datetime(3) NOT NULL,
  `status` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `completeDateTime` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`escalationId`),
  KEY `reporter` (`reporter`),
  KEY `buildingId` (`buildingId`),
  CONSTRAINT `Escalation_ibfk_1` FOREIGN KEY (`reporter`) REFERENCES `User` (`userId`),
  CONSTRAINT `Escalation_ibfk_2` FOREIGN KEY (`buildingId`) REFERENCES `Building` (`buildingId`)
) ENGINE=InnoDB AUTO_INCREMENT=126 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Escalation`
--

LOCK TABLES `Escalation` WRITE;
/*!40000 ALTER TABLE `Escalation` DISABLE KEYS */;
INSERT INTO `Escalation` VALUES (11,1,'2019-04-08 16:47:29.000',1,'2019-04-08 16:59:57.000','close','2019-04-08 16:59:57.000'),(12,1,'2019-04-08 17:00:23.000',1,'2019-04-08 17:17:42.000','close','2019-04-08 17:17:42.000'),(13,1,'2019-04-08 17:18:02.000',1,'2019-04-08 17:46:05.000','close','2019-04-08 17:46:04.000'),(14,1,'2019-04-08 18:02:21.000',1,'2019-04-08 19:01:45.000','close','2019-04-08 19:01:43.000'),(15,1,'2019-04-08 18:09:20.000',1,'2019-04-08 18:18:12.000','close','2019-04-08 18:18:11.000'),(16,1,'2019-04-08 18:18:23.000',2,'2019-04-08 18:18:32.000','close','2019-04-08 18:18:31.000'),(17,1,'2019-04-08 18:18:35.000',2,'2019-04-08 18:19:52.000','close','2019-04-08 18:19:51.000'),(18,1,'2019-04-08 19:01:38.000',1,'2019-04-08 19:01:51.000','close','2019-04-08 19:01:50.000'),(19,1,'2019-04-08 19:01:54.000',1,'2019-04-08 19:02:02.000','close','2019-04-08 19:02:01.000'),(20,1,'2019-04-08 19:02:05.000',1,'2019-04-08 19:05:24.000','close','2019-04-08 19:05:22.000'),(21,1,'2019-04-08 19:05:28.000',1,'2019-04-08 19:05:29.000','close','2019-04-08 19:05:29.000'),(22,1,'2019-04-08 19:10:22.000',1,'2019-04-08 19:10:25.000','close','2019-04-08 19:10:24.000'),(23,1,'2019-04-08 19:10:30.000',1,'2019-04-08 19:11:31.000','close','2019-04-08 19:10:38.000'),(24,1,'2019-04-08 19:11:48.000',1,'2019-04-08 19:11:56.000','close','2019-04-08 19:11:54.000'),(25,1,'2019-04-09 09:23:05.000',2,'2019-04-09 09:23:54.000','close','2019-04-09 09:23:54.000'),(26,1,'2019-04-09 09:24:08.000',2,'2019-04-09 09:25:05.000','close','2019-04-09 09:25:05.000'),(27,1,'2019-04-09 09:41:50.000',2,'2019-04-09 09:42:16.000','close','2019-04-09 09:42:15.000'),(28,1,'2019-04-09 09:42:38.000',2,'2019-04-09 09:43:36.000','close','2019-04-09 09:43:36.000'),(29,1,'2019-04-09 09:44:17.000',2,'2019-04-09 09:44:34.000','close','2019-04-09 09:44:34.000'),(30,1,'2019-04-09 09:46:07.000',2,'2019-04-09 09:46:59.000','close','2019-04-09 09:46:59.000'),(31,1,'2019-04-09 09:48:40.000',2,'2019-04-09 09:49:20.000','close','2019-04-09 09:49:20.000'),(32,1,'2019-04-09 09:49:27.000',2,'2019-04-09 09:51:18.000','close','2019-04-09 09:51:18.000'),(33,1,'2019-04-09 09:53:07.000',2,'2019-04-09 10:13:13.000','close','2019-04-09 10:13:13.000'),(34,1,'2019-04-09 10:23:33.000',2,'2019-04-09 10:25:34.000','close','2019-04-09 10:25:34.000'),(35,1,'2019-04-09 10:25:58.000',2,'2019-04-09 10:29:20.000','close','2019-04-09 10:29:19.000'),(36,1,'2019-04-09 10:29:55.000',2,'2019-04-09 10:30:36.000','close','2019-04-09 10:30:35.000'),(37,1,'2019-04-09 10:31:17.000',2,'2019-04-09 10:31:26.000','close','2019-04-09 10:31:26.000'),(38,1,'2019-04-09 10:32:36.000',2,'2019-04-09 10:32:42.000','close','2019-04-09 10:32:41.000'),(39,1,'2019-04-09 10:32:47.000',2,'2019-04-09 10:33:05.000','close','2019-04-09 10:33:04.000'),(40,1,'2019-04-09 10:33:14.000',2,'2019-04-09 10:37:07.000','close','2019-04-09 10:37:06.000'),(41,1,'2019-04-09 10:37:28.000',2,'2019-04-09 10:39:09.000','close','2019-04-09 10:39:08.000'),(42,1,'2019-04-09 10:41:56.000',2,'2019-04-09 10:53:27.000','close','2019-04-09 10:53:27.000'),(43,1,'2019-04-09 10:53:58.000',2,'2019-04-09 10:55:20.000','close','2019-04-09 10:55:20.000'),(44,1,'2019-04-09 10:59:38.000',2,'2019-04-09 10:59:48.000','close','2019-04-09 10:59:48.000'),(45,1,'2019-04-09 11:00:35.000',2,'2019-04-09 11:02:29.000','close','2019-04-09 11:02:28.000'),(46,1,'2019-04-09 11:03:50.000',2,'2019-04-09 11:04:48.000','close','2019-04-09 11:04:47.000'),(47,1,'2019-04-09 11:04:57.000',2,'2019-04-09 11:06:19.000','close','2019-04-09 11:06:18.000'),(48,1,'2019-04-09 11:06:52.000',2,'2019-04-09 11:08:29.000','close','2019-04-09 11:08:28.000'),(49,1,'2019-04-09 11:09:04.000',2,'2019-04-09 11:10:58.000','close','2019-04-09 11:10:57.000'),(50,1,'2019-04-09 11:11:10.000',2,'2019-04-09 11:13:52.000','close','2019-04-09 11:13:51.000'),(51,1,'2019-04-09 11:14:27.000',2,'2019-04-09 11:15:59.000','close','2019-04-09 11:15:59.000'),(52,1,'2019-04-09 11:16:26.000',2,'2019-04-09 11:19:10.000','close','2019-04-09 11:19:08.000'),(53,1,'2019-04-09 11:19:43.000',2,'2019-04-09 11:22:42.000','close','2019-04-09 11:22:42.000'),(54,1,'2019-04-09 11:22:49.000',2,'2019-04-09 11:40:27.000','close','2019-04-09 11:40:26.000'),(55,1,'2019-04-09 11:55:44.000',2,'2019-04-09 11:56:10.000','close','2019-04-09 11:56:10.000'),(56,3,'2019-04-09 12:00:39.000',3,'2019-04-09 12:00:53.000','close','2019-04-09 12:00:53.000'),(57,1,'2019-04-09 12:00:45.000',2,'2019-04-09 12:01:15.000','close','2019-04-09 12:01:14.000'),(58,2,'2019-04-09 12:02:15.000',4,'2019-04-09 12:02:32.000','close','2019-04-09 12:02:32.000'),(59,1,'2019-04-09 12:02:23.000',2,'2019-04-09 12:04:05.000','close','2019-04-09 12:04:05.000'),(60,1,'2019-04-09 12:04:12.000',1,'2019-04-09 12:04:20.000','close','2019-04-09 12:04:19.000'),(61,2,'2019-04-09 12:04:57.000',4,'2019-04-09 12:08:47.000','close','2019-04-09 12:08:47.000'),(62,1,'2019-04-09 12:05:02.000',2,'2019-04-09 12:05:11.000','close','2019-04-09 12:05:10.000'),(63,2,'2019-04-09 16:59:06.000',2,'2019-04-09 17:00:20.000','close','2019-04-09 17:00:20.000'),(64,1,'2019-04-09 18:32:49.000',1,'2019-04-09 18:33:01.000','close','2019-04-09 18:33:01.000'),(65,1,'2019-04-10 18:07:07.000',4,'2019-04-10 18:07:17.000','close','2019-04-10 18:07:16.000'),(66,1,'2019-04-10 18:10:24.000',2,'2019-04-10 18:15:34.000','close','2019-04-10 18:15:34.000'),(67,1,'2019-04-16 11:38:18.000',1,'2019-04-16 11:38:20.000','open',NULL),(68,1,'2019-04-16 11:38:26.000',1,'2019-04-16 11:43:34.000','close','2019-04-16 11:43:32.000'),(69,1,'2019-04-16 11:43:37.000',1,'2019-04-16 11:52:56.000','close','2019-04-16 11:52:55.000'),(70,1,'2019-04-16 11:52:59.000',1,'2019-04-16 12:17:40.000','close','2019-04-16 12:17:39.000'),(71,1,'2019-04-16 12:17:45.000',1,'2019-04-16 12:21:07.000','close','2019-04-16 12:21:05.000'),(72,3,'2019-04-16 12:21:34.000',29,'2019-04-16 12:28:57.000','close','2019-04-16 12:28:55.000'),(73,1,'2019-04-16 12:30:01.000',1,'2019-04-16 12:31:30.000','close','2019-04-16 12:31:29.000'),(74,1,'2019-04-16 12:32:00.000',1,'2019-04-16 12:32:30.000','close','2019-04-16 12:32:28.000'),(75,1,'2019-04-16 12:34:22.000',1,'2019-04-16 12:34:41.000','close','2019-04-16 12:34:40.000'),(76,1,'2019-04-16 12:55:38.000',1,'2019-04-16 12:58:20.000','close','2019-04-16 12:58:19.000'),(77,1,'2019-04-16 12:59:48.000',1,'2019-04-16 13:00:59.000','close','2019-04-16 13:00:58.000'),(78,1,'2019-04-16 13:01:14.000',1,'2019-04-16 13:02:01.000','close','2019-04-16 13:02:00.000'),(79,1,'2019-04-16 16:04:56.000',46,'2019-04-16 16:05:53.000','close','2019-04-16 16:05:52.000'),(80,3,'2019-04-16 16:52:16.000',48,'2019-04-16 17:10:03.000','close','2019-04-16 17:10:01.000'),(81,3,'2019-04-16 17:10:36.000',29,'2019-04-16 17:15:30.000','close','2019-04-16 17:15:29.000'),(82,3,'2019-04-16 17:15:34.000',29,'2019-04-16 17:28:12.000','close','2019-04-16 17:28:11.000'),(83,3,'2019-04-16 17:28:21.000',21,'2019-04-16 17:29:29.000','close','2019-04-16 17:29:29.000'),(84,3,'2019-04-16 17:29:46.000',48,'2019-04-16 17:31:16.000','close','2019-04-16 17:31:15.000'),(85,3,'2019-04-16 17:44:48.000',29,'2019-04-16 17:45:23.000','close','2019-04-16 17:45:23.000'),(86,3,'2019-04-16 17:45:31.000',48,'2019-04-16 18:05:54.000','close','2019-04-16 18:05:53.000'),(87,3,'2019-04-16 18:14:23.000',48,'2019-04-16 18:15:29.000','close','2019-04-16 18:15:28.000'),(88,3,'2019-04-16 18:15:52.000',29,'2019-04-16 18:24:41.000','close','2019-04-16 18:24:40.000'),(89,3,'2019-04-16 18:24:46.000',29,'2019-04-16 18:25:15.000','close','2019-04-16 18:25:14.000'),(90,3,'2019-04-16 18:25:22.000',29,'2019-04-16 18:34:40.000','close','2019-04-16 18:34:40.000'),(91,3,'2019-04-16 18:34:44.000',29,'2019-04-16 18:37:59.000','close','2019-04-16 18:37:59.000'),(92,1,'2019-04-16 18:38:22.000',1,'2019-04-16 18:53:22.000','close','2019-04-16 18:53:22.000'),(93,1,'2019-04-17 10:20:06.000',1,'2019-04-17 10:46:55.000','close','2019-04-17 10:46:53.000'),(94,1,'2019-04-17 10:47:28.000',9,'2019-04-17 10:47:52.000','close','2019-04-17 10:47:50.000'),(95,1,'2019-04-17 10:47:57.000',7,'2019-04-17 10:48:39.000','close','2019-04-17 10:48:39.000'),(96,1,'2019-04-17 13:03:50.000',41,'2019-04-17 13:04:47.000','close','2019-04-17 13:04:46.000'),(97,1,'2019-04-17 13:03:50.000',41,'2019-04-17 13:04:36.000','close','2019-04-17 13:04:35.000'),(98,1,'2019-04-17 13:06:46.000',46,'2019-04-17 13:07:14.000','close','2019-04-17 13:07:15.000'),(99,1,'2019-04-17 13:11:14.000',46,'2019-04-17 13:12:05.000','close','2019-04-17 13:12:05.000'),(100,1,'2019-04-17 13:12:19.000',41,'2019-04-17 13:13:13.000','close','2019-04-17 13:13:12.000'),(101,1,'2019-04-17 13:13:17.000',41,'2019-04-17 13:15:43.000','close','2019-04-17 13:15:42.000'),(102,1,'2019-04-17 14:57:17.000',46,'2019-04-17 14:59:02.000','close','2019-04-17 14:59:02.000'),(103,1,'2019-04-17 15:06:10.000',46,'2019-04-17 15:06:22.000','close','2019-04-17 15:06:22.000'),(104,1,'2019-04-17 15:21:50.000',46,'2019-04-17 15:24:09.000','close','2019-04-17 15:24:09.000'),(105,1,'2019-04-17 15:31:50.000',46,'2019-04-17 15:37:24.000','close','2019-04-17 15:37:24.000'),(106,1,'2019-04-17 15:37:29.000',46,'2019-04-17 15:38:33.000','close','2019-04-17 15:38:33.000'),(107,1,'2019-04-17 15:43:32.000',46,'2019-04-17 15:45:05.000','close','2019-04-17 15:45:05.000'),(108,1,'2019-04-17 15:45:46.000',46,'2019-04-17 15:46:08.000','close','2019-04-17 15:46:08.000'),(109,1,'2019-04-17 15:53:50.000',46,'2019-04-17 15:54:06.000','close','2019-04-17 15:54:06.000'),(110,1,'2019-04-17 15:56:27.000',46,'2019-04-17 15:58:18.000','close','2019-04-17 15:57:39.000'),(111,1,'2019-04-17 15:58:33.000',46,'2019-04-17 15:58:53.000','close','2019-04-17 15:58:53.000'),(112,1,'2019-04-17 16:02:01.000',46,'2019-04-17 16:02:08.000','close','2019-04-17 16:02:08.000'),(113,1,'2019-04-17 16:12:55.000',46,'2019-04-17 16:16:45.000','close','2019-04-17 16:16:45.000'),(114,1,'2019-04-17 16:54:25.000',46,'2019-04-17 16:55:24.000','close','2019-04-17 16:55:24.000'),(115,1,'2019-04-17 17:08:18.000',46,'2019-04-17 17:08:57.000','close','2019-04-17 17:08:57.000'),(116,1,'2019-04-17 17:10:27.000',46,'2019-04-17 17:10:32.000','close','2019-04-17 17:10:32.000'),(117,1,'2019-04-17 17:11:07.000',41,'2019-04-17 17:11:33.000','close','2019-04-17 17:11:32.000'),(118,1,'2019-04-17 17:16:27.000',46,'2019-04-17 17:16:43.000','close','2019-04-17 17:16:42.000'),(119,1,'2019-04-17 17:17:14.000',46,'2019-04-17 17:17:17.000','close','2019-04-17 17:17:16.000'),(120,1,'2019-04-17 17:30:26.000',46,'2019-04-17 17:31:11.000','close','2019-04-17 17:31:10.000'),(121,1,'2019-04-17 17:31:20.000',46,'2019-04-17 17:31:41.000','close','2019-04-17 17:31:41.000'),(122,1,'2019-04-17 17:31:44.000',46,'2019-04-17 17:31:53.000','close','2019-04-17 17:31:52.000'),(123,1,'2019-04-17 17:31:56.000',46,'2019-04-17 17:32:28.000','close','2019-04-17 17:32:28.000'),(124,1,'2019-04-17 17:35:03.000',46,'2019-04-17 17:35:12.000','close','2019-04-17 17:35:11.000'),(125,3,'2019-04-17 17:38:53.000',43,'2019-04-17 17:45:28.000','close','2019-04-17 17:45:29.000');
/*!40000 ALTER TABLE `Escalation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EscalationAttendance`
--

DROP TABLE IF EXISTS `EscalationAttendance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `EscalationAttendance` (
  `escalationAttendanceId` int(11) NOT NULL AUTO_INCREMENT,
  `escalationId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `status` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`escalationAttendanceId`)
) ENGINE=InnoDB AUTO_INCREMENT=694 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EscalationAttendance`
--

LOCK TABLES `EscalationAttendance` WRITE;
/*!40000 ALTER TABLE `EscalationAttendance` DISABLE KEYS */;
INSERT INTO `EscalationAttendance` VALUES (1,9,1,'absent'),(2,10,1,'absent'),(3,11,1,'absent'),(4,12,1,'absent'),(8,22,1,'absent'),(9,23,1,'absent'),(10,24,1,'absent'),(11,25,2,'absent'),(12,26,2,'absent'),(13,27,1,'absent'),(14,27,4,'absent'),(15,27,2,'absent'),(16,28,1,'absent'),(17,28,4,'absent'),(18,28,2,'absent'),(19,29,1,'absent'),(20,29,4,'absent'),(21,29,2,'present'),(22,30,1,'absent'),(23,30,4,'absent'),(24,30,2,'absent'),(25,31,1,'absent'),(26,31,4,'absent'),(27,31,2,'absent'),(28,32,1,'absent'),(29,32,4,'absent'),(30,32,2,'absent'),(31,33,1,'present'),(32,33,4,'not participating'),(33,33,2,'absent'),(34,34,1,'present'),(35,34,4,'absent'),(36,34,2,'absent'),(37,35,1,'absent'),(38,35,4,'absent'),(39,35,2,'absent'),(40,36,1,'absent'),(41,36,4,'absent'),(42,36,2,'absent'),(43,37,1,'present'),(44,37,4,'absent'),(45,37,2,'absent'),(46,38,1,'absent'),(47,38,4,'absent'),(48,38,2,'absent'),(49,39,1,'absent'),(50,39,4,'absent'),(51,39,2,'absent'),(52,40,1,'absent'),(53,40,4,'absent'),(54,40,2,'absent'),(55,41,1,'absent'),(56,41,4,'absent'),(57,41,2,'absent'),(58,42,1,'absent'),(59,42,4,'absent'),(60,42,2,'absent'),(61,43,1,'absent'),(62,43,4,'absent'),(63,43,2,'absent'),(64,44,1,'absent'),(65,44,4,'absent'),(66,44,2,'absent'),(67,45,1,'absent'),(68,45,4,'absent'),(69,45,2,'absent'),(70,46,1,'absent'),(71,46,4,'absent'),(72,46,2,'absent'),(73,47,1,'absent'),(74,47,4,'absent'),(75,47,2,'absent'),(76,48,1,'absent'),(77,48,4,'absent'),(78,48,2,'absent'),(79,49,1,'absent'),(80,49,4,'absent'),(81,49,2,'absent'),(82,50,1,'absent'),(83,50,4,'absent'),(84,50,2,'absent'),(85,51,1,'absent'),(86,51,4,'absent'),(87,51,2,'absent'),(88,52,1,'absent'),(89,52,4,'absent'),(90,52,2,'absent'),(91,53,1,'absent'),(92,53,4,'absent'),(93,53,2,'absent'),(94,54,1,'absent'),(95,54,4,'absent'),(96,54,2,'absent'),(97,55,1,'absent'),(98,55,4,'absent'),(99,55,2,'absent'),(100,56,1,'absent'),(101,56,3,'absent'),(102,57,1,'absent'),(103,57,4,'absent'),(104,57,2,'absent'),(105,58,4,'absent'),(106,58,2,'absent'),(107,59,1,'absent'),(108,59,4,'absent'),(109,59,2,'absent'),(110,60,1,'absent'),(111,60,4,'absent'),(112,60,2,'absent'),(113,61,4,'absent'),(114,61,2,'absent'),(115,62,1,'absent'),(116,62,4,'absent'),(117,62,2,'absent'),(118,63,4,'absent'),(119,63,2,'absent'),(120,64,1,'present'),(121,64,4,'present'),(122,64,2,'present'),(123,65,1,'absent'),(124,65,4,'absent'),(125,65,2,'absent'),(126,66,1,'absent'),(127,66,4,'present'),(128,66,2,'absent'),(129,67,1,'absent'),(130,68,1,'absent'),(131,69,1,'absent'),(132,70,1,'absent'),(133,71,1,'absent'),(134,72,21,'present'),(135,72,23,'absent'),(136,72,25,'absent'),(137,72,27,'absent'),(138,72,29,'present'),(139,72,43,'absent'),(140,72,44,'absent'),(141,72,41,'absent'),(142,72,47,'present'),(143,72,49,'present'),(144,72,50,'not participating'),(145,72,46,'absent'),(146,72,45,'absent'),(147,72,48,'present'),(148,73,1,'present'),(149,73,3,'absent'),(150,73,5,'absent'),(151,73,7,'present'),(152,73,9,'absent'),(153,73,41,'absent'),(154,73,42,'absent'),(155,73,43,'absent'),(156,73,45,'present'),(157,73,50,'present'),(158,73,48,'absent'),(159,73,47,'present'),(160,73,44,'absent'),(161,73,46,'absent'),(162,74,1,'present'),(163,74,3,'present'),(164,74,7,'present'),(165,74,9,'present'),(166,75,1,'absent'),(167,75,3,'absent'),(168,75,5,'present'),(169,75,9,'absent'),(170,75,41,'absent'),(171,75,42,'absent'),(172,75,43,'present'),(173,75,50,'absent'),(174,75,44,'absent'),(175,75,46,'absent'),(176,76,1,'present'),(177,76,3,'present'),(178,76,5,'absent'),(179,76,7,'absent'),(180,76,9,'absent'),(181,76,41,'absent'),(182,76,42,'present'),(183,76,43,'absent'),(184,76,45,'absent'),(185,76,50,'present'),(186,76,48,'absent'),(187,76,47,'absent'),(188,76,44,'absent'),(189,76,46,'absent'),(190,77,1,'absent'),(191,77,3,'present'),(192,77,5,'absent'),(193,77,7,'absent'),(194,77,9,'absent'),(195,77,41,'absent'),(196,77,42,'absent'),(197,77,43,'absent'),(198,77,45,'absent'),(199,77,50,'absent'),(200,77,48,'absent'),(201,77,47,'absent'),(202,77,44,'absent'),(203,77,46,'absent'),(204,78,1,'absent'),(205,78,3,'present'),(206,78,5,'absent'),(207,78,7,'absent'),(208,79,1,'absent'),(209,79,3,'absent'),(210,79,5,'absent'),(211,79,7,'absent'),(212,79,9,'absent'),(213,79,41,'absent'),(214,79,42,'absent'),(215,79,43,'absent'),(216,79,45,'absent'),(217,79,50,'absent'),(218,79,48,'absent'),(219,79,47,'absent'),(220,79,44,'absent'),(221,79,46,'absent'),(222,80,21,'absent'),(223,80,23,'absent'),(224,80,25,'absent'),(225,80,27,'absent'),(226,80,29,'present'),(227,80,43,'absent'),(228,80,44,'absent'),(229,80,41,'absent'),(230,80,47,'absent'),(231,80,49,'absent'),(232,80,50,'absent'),(233,80,46,'absent'),(234,80,45,'absent'),(235,80,48,'absent'),(236,81,21,'absent'),(237,81,23,'absent'),(238,81,25,'absent'),(239,81,27,'absent'),(240,81,29,'absent'),(241,81,43,'absent'),(242,81,44,'absent'),(243,81,41,'absent'),(244,81,47,'absent'),(245,81,49,'absent'),(246,81,50,'absent'),(247,81,46,'not participating'),(248,81,45,'absent'),(249,81,48,'absent'),(250,82,21,'present'),(251,82,23,'absent'),(252,82,25,'absent'),(253,82,27,'absent'),(254,82,29,'absent'),(255,82,43,'absent'),(256,82,44,'absent'),(257,82,41,'absent'),(258,82,47,'absent'),(259,82,49,'absent'),(260,82,50,'absent'),(261,82,46,'absent'),(262,82,45,'absent'),(263,82,48,'present'),(264,83,21,'absent'),(265,83,23,'absent'),(266,83,25,'absent'),(267,83,27,'absent'),(268,83,29,'absent'),(269,83,43,'absent'),(270,83,44,'absent'),(271,83,41,'absent'),(272,83,47,'absent'),(273,83,49,'absent'),(274,83,50,'absent'),(275,83,46,'absent'),(276,83,45,'absent'),(277,83,48,'present'),(278,84,21,'present'),(279,84,23,'absent'),(280,84,25,'absent'),(281,84,27,'absent'),(282,84,29,'absent'),(283,84,43,'absent'),(284,84,44,'absent'),(285,84,41,'absent'),(286,84,47,'absent'),(287,84,49,'absent'),(288,84,50,'absent'),(289,84,46,'absent'),(290,84,45,'absent'),(291,84,48,'absent'),(292,85,21,'absent'),(293,85,23,'absent'),(294,85,25,'absent'),(295,85,27,'absent'),(296,85,29,'absent'),(297,85,43,'absent'),(298,85,44,'absent'),(299,85,41,'absent'),(300,85,47,'absent'),(301,85,49,'absent'),(302,85,50,'absent'),(303,85,46,'absent'),(304,85,45,'absent'),(305,85,48,'absent'),(306,86,21,'absent'),(307,86,23,'absent'),(308,86,25,'present'),(309,86,27,'absent'),(310,86,29,'present'),(311,86,43,'absent'),(312,86,44,'absent'),(313,86,41,'absent'),(314,86,47,'absent'),(315,86,49,'absent'),(316,86,50,'absent'),(317,86,46,'present'),(318,86,45,'absent'),(319,86,48,'absent'),(320,87,21,'absent'),(321,87,23,'absent'),(322,87,25,'absent'),(323,87,27,'absent'),(324,87,29,'absent'),(325,87,43,'absent'),(326,87,44,'absent'),(327,87,41,'absent'),(328,87,47,'absent'),(329,87,49,'absent'),(330,87,50,'absent'),(331,87,46,'present'),(332,87,45,'absent'),(333,87,48,'absent'),(334,88,21,'present'),(335,88,23,'present'),(336,88,25,'present'),(337,88,27,'present'),(338,88,29,'present'),(339,88,43,'present'),(340,88,44,'present'),(341,88,41,'present'),(342,88,47,'present'),(343,88,49,'present'),(344,88,50,'present'),(345,88,46,'present'),(346,88,45,'present'),(347,88,48,'present'),(348,89,21,'present'),(349,89,23,'present'),(350,89,25,'present'),(351,89,27,'present'),(352,89,29,'present'),(353,89,43,'present'),(354,89,44,'present'),(355,89,41,'present'),(356,89,47,'present'),(357,89,49,'present'),(358,89,50,'present'),(359,89,46,'present'),(360,89,45,'present'),(361,89,48,'present'),(362,90,21,'present'),(363,90,23,'present'),(364,90,25,'present'),(365,90,27,'present'),(366,90,29,'present'),(367,90,43,'present'),(368,90,44,'present'),(369,90,41,'present'),(370,90,47,'present'),(371,90,49,'present'),(372,90,50,'present'),(373,90,46,'present'),(374,90,45,'present'),(375,90,48,'present'),(376,91,21,'present'),(377,91,23,'absent'),(378,91,25,'absent'),(379,91,27,'absent'),(380,91,29,'absent'),(381,91,43,'absent'),(382,91,44,'absent'),(383,91,41,'absent'),(384,91,47,'absent'),(385,91,49,'absent'),(386,91,50,'absent'),(387,91,46,'absent'),(388,91,45,'absent'),(389,91,48,'absent'),(390,92,1,'present'),(391,92,3,'absent'),(392,92,5,'present'),(393,92,7,'absent'),(394,92,9,'absent'),(395,92,41,'absent'),(396,92,42,'present'),(397,92,43,'absent'),(398,92,45,'absent'),(399,92,50,'absent'),(400,92,48,'absent'),(401,92,47,'absent'),(402,92,44,'absent'),(403,92,46,'present'),(404,93,1,'absent'),(405,93,3,'present'),(406,93,5,'absent'),(407,93,7,'absent'),(408,93,9,'absent'),(409,93,41,'absent'),(410,93,42,'absent'),(411,93,43,'absent'),(412,93,45,'absent'),(413,93,50,'absent'),(414,93,48,'absent'),(415,93,47,'absent'),(416,93,44,'present'),(417,93,46,'absent'),(418,94,1,'absent'),(419,94,3,'absent'),(420,94,5,'absent'),(421,94,7,'absent'),(422,94,9,'absent'),(423,94,41,'absent'),(424,94,42,'absent'),(425,94,43,'absent'),(426,94,45,'absent'),(427,94,50,'absent'),(428,94,48,'absent'),(429,94,47,'absent'),(430,94,44,'absent'),(431,94,46,'absent'),(432,95,1,'absent'),(433,95,3,'absent'),(434,95,5,'absent'),(435,95,7,'absent'),(436,95,9,'absent'),(437,95,41,'absent'),(438,95,42,'absent'),(439,95,43,'absent'),(440,95,45,'absent'),(441,95,50,'absent'),(442,95,48,'absent'),(443,95,47,'absent'),(444,95,44,'absent'),(445,95,46,'absent'),(446,96,41,'absent'),(447,96,42,'absent'),(448,96,43,'absent'),(449,96,45,'absent'),(450,96,50,'absent'),(451,96,48,'absent'),(452,96,47,'absent'),(453,96,44,'absent'),(454,96,46,'absent'),(455,97,41,'absent'),(456,97,42,'absent'),(457,97,43,'absent'),(458,97,45,'absent'),(459,97,50,'absent'),(460,97,48,'absent'),(461,97,47,'absent'),(462,97,44,'absent'),(463,97,46,'absent'),(464,98,41,'absent'),(465,98,42,'absent'),(466,98,43,'absent'),(467,98,45,'absent'),(468,98,50,'absent'),(469,98,48,'absent'),(470,98,47,'absent'),(471,98,44,'absent'),(472,98,46,'absent'),(473,99,41,'absent'),(474,99,42,'absent'),(475,99,43,'absent'),(476,99,45,'absent'),(477,99,50,'absent'),(478,99,48,'absent'),(479,99,47,'absent'),(480,99,44,'absent'),(481,99,46,'absent'),(482,100,41,'absent'),(483,100,42,'absent'),(484,100,43,'absent'),(485,100,45,'absent'),(486,100,50,'absent'),(487,100,48,'absent'),(488,100,47,'absent'),(489,100,44,'absent'),(490,100,46,'absent'),(491,101,41,'absent'),(492,101,42,'absent'),(493,101,43,'absent'),(494,101,45,'absent'),(495,101,50,'absent'),(496,101,48,'absent'),(497,101,47,'absent'),(498,101,44,'absent'),(499,101,46,'absent'),(500,102,41,'absent'),(501,102,42,'absent'),(502,102,43,'absent'),(503,102,45,'absent'),(504,102,50,'absent'),(505,102,48,'absent'),(506,102,47,'absent'),(507,102,44,'absent'),(508,102,46,'absent'),(509,103,41,'absent'),(510,103,42,'absent'),(511,103,43,'absent'),(512,103,45,'absent'),(513,103,50,'absent'),(514,103,48,'absent'),(515,103,47,'absent'),(516,103,44,'absent'),(517,103,46,'absent'),(518,104,41,'absent'),(519,104,42,'absent'),(520,104,43,'absent'),(521,104,45,'absent'),(522,104,50,'absent'),(523,104,48,'absent'),(524,104,47,'absent'),(525,104,44,'absent'),(526,104,46,'absent'),(527,105,41,'absent'),(528,105,42,'absent'),(529,105,43,'absent'),(530,105,45,'absent'),(531,105,50,'absent'),(532,105,48,'absent'),(533,105,47,'absent'),(534,105,44,'absent'),(535,105,46,'absent'),(536,106,41,'absent'),(537,106,42,'absent'),(538,106,43,'absent'),(539,106,45,'absent'),(540,106,50,'absent'),(541,106,48,'absent'),(542,106,47,'absent'),(543,106,44,'absent'),(544,106,46,'absent'),(545,107,41,'absent'),(546,107,42,'absent'),(547,107,43,'absent'),(548,107,45,'absent'),(549,107,50,'absent'),(550,107,48,'absent'),(551,107,47,'absent'),(552,107,44,'absent'),(553,107,46,'absent'),(554,108,41,'absent'),(555,108,42,'absent'),(556,108,43,'absent'),(557,108,45,'absent'),(558,108,50,'absent'),(559,108,48,'absent'),(560,108,47,'absent'),(561,108,44,'absent'),(562,108,46,'absent'),(563,109,41,'absent'),(564,109,42,'absent'),(565,109,43,'absent'),(566,109,45,'absent'),(567,109,50,'absent'),(568,109,48,'absent'),(569,109,47,'absent'),(570,109,44,'absent'),(571,109,46,'absent'),(572,110,41,'absent'),(573,110,42,'absent'),(574,110,43,'absent'),(575,110,45,'absent'),(576,110,50,'absent'),(577,110,48,'absent'),(578,110,47,'absent'),(579,110,44,'absent'),(580,110,46,'absent'),(581,111,41,'absent'),(582,111,42,'absent'),(583,111,43,'absent'),(584,111,45,'absent'),(585,111,50,'absent'),(586,111,48,'absent'),(587,111,47,'absent'),(588,111,44,'absent'),(589,111,46,'absent'),(590,112,41,'absent'),(591,112,42,'absent'),(592,112,43,'absent'),(593,112,45,'absent'),(594,112,50,'absent'),(595,112,48,'absent'),(596,112,47,'absent'),(597,112,44,'absent'),(598,112,46,'absent'),(599,113,41,'absent'),(600,113,42,'absent'),(601,113,43,'absent'),(602,113,45,'absent'),(603,113,50,'absent'),(604,113,48,'absent'),(605,113,47,'absent'),(606,113,44,'absent'),(607,113,46,'absent'),(608,114,41,'absent'),(609,114,42,'absent'),(610,114,43,'absent'),(611,114,45,'absent'),(612,114,50,'absent'),(613,114,48,'absent'),(614,114,47,'absent'),(615,114,44,'absent'),(616,114,46,'absent'),(617,115,43,'absent'),(618,115,45,'absent'),(619,115,49,'absent'),(620,115,50,'absent'),(621,115,48,'absent'),(622,115,47,'absent'),(623,115,44,'absent'),(624,116,43,'absent'),(625,116,45,'absent'),(626,116,49,'absent'),(627,116,50,'absent'),(628,116,48,'absent'),(629,116,47,'absent'),(630,116,44,'absent'),(631,117,43,'absent'),(632,117,45,'absent'),(633,117,49,'absent'),(634,117,50,'absent'),(635,117,48,'absent'),(636,117,47,'absent'),(637,117,44,'absent'),(638,118,43,'absent'),(639,118,45,'absent'),(640,118,49,'absent'),(641,118,50,'absent'),(642,118,48,'absent'),(643,118,47,'absent'),(644,118,44,'absent'),(645,119,43,'absent'),(646,119,45,'absent'),(647,119,49,'absent'),(648,119,50,'absent'),(649,119,48,'absent'),(650,119,47,'absent'),(651,119,44,'absent'),(652,120,43,'absent'),(653,120,45,'absent'),(654,120,49,'absent'),(655,120,50,'absent'),(656,120,48,'absent'),(657,120,47,'absent'),(658,120,44,'absent'),(659,121,43,'absent'),(660,121,45,'absent'),(661,121,49,'absent'),(662,121,50,'absent'),(663,121,48,'absent'),(664,121,47,'absent'),(665,121,44,'absent'),(666,122,43,'absent'),(667,122,45,'absent'),(668,122,49,'absent'),(669,122,50,'absent'),(670,122,48,'absent'),(671,122,47,'absent'),(672,122,44,'absent'),(673,123,43,'absent'),(674,123,45,'absent'),(675,123,49,'absent'),(676,123,50,'absent'),(677,123,48,'absent'),(678,123,47,'absent'),(679,123,44,'absent'),(680,124,43,'absent'),(681,124,45,'absent'),(682,124,49,'absent'),(683,124,50,'absent'),(684,124,48,'absent'),(685,124,47,'absent'),(686,124,44,'absent'),(687,125,41,'present'),(688,125,47,'present'),(689,125,42,'present'),(690,125,49,'present'),(691,125,50,'present'),(692,125,46,'present'),(693,125,45,'present');
/*!40000 ALTER TABLE `EscalationAttendance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FSC`
--

DROP TABLE IF EXISTS `FSC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `FSC` (
  `fscId` int(11) NOT NULL AUTO_INCREMENT,
  `buildingId` int(11) NOT NULL,
  `documentName` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `documentKey` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`fscId`),
  KEY `buildingId` (`buildingId`),
  CONSTRAINT `FSC_ibfk_1` FOREIGN KEY (`buildingId`) REFERENCES `Building` (`buildingId`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FSC`
--

LOCK TABLES `FSC` WRITE;
/*!40000 ALTER TABLE `FSC` DISABLE KEYS */;
INSERT INTO `FSC` VALUES (1,1,'FSC_1_1555383848356.jpeg','building_1/fsc/FSC_1_1555383848356.jpeg'),(2,1,'1544512994150.jpg','building_1/fsc/FSC_1_1555385394889.jpeg'),(3,1,'FSC_1_1555385679511.jpeg','building_1/fsc/FSC_1_1555385679511.jpeg'),(4,1,'7670','building_1/fsc/FSC_1_1555386955442.pdf'),(5,1,'7482','building_1/fsc/FSC_1_1555387062523.pdf'),(6,1,'FSC_46_1555392228193.jpeg','building_1/fsc/FSC_46_1555392228193.jpeg'),(7,3,'FSC_48_1555402908422.jpeg','building_3/fsc/FSC_48_1555402908422.jpeg'),(8,1,'FSC_41_1555483465151.jpeg','building_1/fsc/FSC_41_1555483465151.jpeg');
/*!40000 ALTER TABLE `FSC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FireDrillAttendance`
--

DROP TABLE IF EXISTS `FireDrillAttendance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `FireDrillAttendance` (
  `fireDrillAttendanceId` int(11) NOT NULL AUTO_INCREMENT,
  `tenantEmployeeId` int(11) DEFAULT NULL,
  `fireDrillId` int(11) DEFAULT NULL,
  `status` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`fireDrillAttendanceId`),
  KEY `tenantEmployeeId` (`tenantEmployeeId`),
  KEY `fireDrillId` (`fireDrillId`),
  CONSTRAINT `FireDrillAttandence_ibfk_2` FOREIGN KEY (`fireDrillId`) REFERENCES `FireDrillSchedule` (`fireDrillId`),
  CONSTRAINT `FireDrillAttendance_ibfk_1` FOREIGN KEY (`tenantEmployeeId`) REFERENCES `TenantEmployee` (`tenantEmployeeId`)
) ENGINE=InnoDB AUTO_INCREMENT=1733 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FireDrillAttendance`
--

LOCK TABLES `FireDrillAttendance` WRITE;
/*!40000 ALTER TABLE `FireDrillAttendance` DISABLE KEYS */;
INSERT INTO `FireDrillAttendance` VALUES (1,1,11,'absent'),(2,1,18,'absent'),(3,1,19,'present'),(4,1,20,'absent'),(5,1,21,'absent'),(6,1,22,'absent'),(7,1,23,'present'),(8,5,23,'present'),(9,6,23,'absent'),(10,7,23,'present'),(11,8,23,'absent'),(12,1,24,'absent'),(13,5,24,'absent'),(14,6,24,'present'),(15,7,24,'present'),(16,8,24,'present'),(17,1,25,'absent'),(18,5,25,'absent'),(19,6,25,'absent'),(20,7,25,'absent'),(21,8,25,'absent'),(22,1,26,'absent'),(23,5,26,'absent'),(24,6,26,'absent'),(25,7,26,'absent'),(26,8,26,'absent'),(27,1,27,'absent'),(28,5,27,'absent'),(29,6,27,'absent'),(30,7,27,'absent'),(31,8,27,'absent'),(32,1,28,'absent'),(33,5,28,'absent'),(34,6,28,'absent'),(35,7,28,'absent'),(36,8,28,'absent'),(37,1,29,'absent'),(38,5,29,'absent'),(39,6,29,'absent'),(40,7,29,'absent'),(41,8,29,'absent'),(42,1,30,'absent'),(43,5,30,'absent'),(44,6,30,'absent'),(45,7,30,'absent'),(46,8,30,'absent'),(47,1,31,'absent'),(48,5,31,'absent'),(49,6,31,'absent'),(50,7,31,'absent'),(51,8,31,'absent'),(52,1,32,'absent'),(53,5,32,'absent'),(54,6,32,'absent'),(55,7,32,'absent'),(56,8,32,'absent'),(57,1,33,'absent'),(58,5,33,'absent'),(59,6,33,'absent'),(60,7,33,'absent'),(61,8,33,'absent'),(62,1,34,'absent'),(63,2,34,'absent'),(64,3,34,'absent'),(65,4,34,'absent'),(66,8,34,'absent'),(67,1,35,'absent'),(68,5,35,'absent'),(69,6,35,'absent'),(70,7,35,'absent'),(71,8,35,'absent'),(72,1,36,'absent'),(73,2,36,'absent'),(74,3,36,'absent'),(75,4,36,'absent'),(76,8,36,'absent'),(77,1,37,'absent'),(78,2,37,'absent'),(79,3,37,'absent'),(80,4,37,'absent'),(81,8,37,'absent'),(82,1,38,'absent'),(83,2,38,'absent'),(84,3,38,'absent'),(85,4,38,'absent'),(86,8,38,'absent'),(87,1,39,'absent'),(88,5,39,'absent'),(89,6,39,'absent'),(90,7,39,'absent'),(91,8,39,'absent'),(92,1,40,'absent'),(93,4,40,'absent'),(94,6,40,'absent'),(95,7,40,'absent'),(96,8,40,'absent'),(97,1,41,'absent'),(98,4,41,'absent'),(99,6,41,'absent'),(100,7,41,'absent'),(101,8,41,'absent'),(102,1,42,'absent'),(103,4,42,'absent'),(104,6,42,'absent'),(105,7,42,'absent'),(106,8,42,'absent'),(107,1,43,'absent'),(108,4,43,'absent'),(109,6,43,'absent'),(110,7,43,'absent'),(111,8,43,'absent'),(112,1,44,'absent'),(113,4,44,'absent'),(114,6,44,'absent'),(115,7,44,'absent'),(116,8,44,'absent'),(117,1,45,'absent'),(118,4,45,'absent'),(119,6,45,'absent'),(120,7,45,'absent'),(121,8,45,'absent'),(122,1,46,'absent'),(123,4,46,'absent'),(124,6,46,'absent'),(125,7,46,'absent'),(126,8,46,'absent'),(127,1,47,'absent'),(128,4,47,'absent'),(129,6,47,'absent'),(130,7,47,'absent'),(131,8,47,'absent'),(132,1,48,'absent'),(133,4,48,'absent'),(134,6,48,'absent'),(135,7,48,'absent'),(136,8,48,'absent'),(137,1,49,'absent'),(138,4,49,'absent'),(139,6,49,'absent'),(140,7,49,'absent'),(141,8,49,'absent'),(142,1,50,'absent'),(143,4,50,'absent'),(144,6,50,'absent'),(145,7,50,'absent'),(146,8,50,'absent'),(147,1,51,'absent'),(148,4,51,'absent'),(149,6,51,'absent'),(150,7,51,'absent'),(151,8,51,'absent'),(152,1,52,'absent'),(153,4,52,'absent'),(154,6,52,'absent'),(155,7,52,'absent'),(156,8,52,'absent'),(157,1,53,'absent'),(158,4,53,'absent'),(159,6,53,'absent'),(160,7,53,'absent'),(161,8,53,'absent'),(162,1,54,'absent'),(163,4,54,'absent'),(164,6,54,'absent'),(165,7,54,'absent'),(166,8,54,'absent'),(167,1,55,'absent'),(168,4,55,'absent'),(169,6,55,'absent'),(170,7,55,'absent'),(171,8,55,'absent'),(172,1,56,'absent'),(173,4,56,'absent'),(174,6,56,'absent'),(175,7,56,'absent'),(176,8,56,'absent'),(177,1,57,'absent'),(178,4,57,'absent'),(179,6,57,'absent'),(180,7,57,'absent'),(181,8,57,'absent'),(182,1,58,'absent'),(183,4,58,'absent'),(184,6,58,'absent'),(185,7,58,'absent'),(186,8,58,'absent'),(187,1,59,'absent'),(188,4,59,'absent'),(189,6,59,'absent'),(190,7,59,'absent'),(191,8,59,'absent'),(192,1,60,'absent'),(193,4,60,'absent'),(194,6,60,'absent'),(195,7,60,'absent'),(196,8,60,'absent'),(197,1,61,'absent'),(198,4,61,'absent'),(199,6,61,'absent'),(200,7,61,'absent'),(201,8,61,'absent'),(202,1,62,'absent'),(203,4,62,'absent'),(204,6,62,'absent'),(205,7,62,'absent'),(206,8,62,'absent'),(207,1,63,'absent'),(208,4,63,'absent'),(209,6,63,'absent'),(210,7,63,'absent'),(211,8,63,'absent'),(212,1,64,'absent'),(213,4,64,'absent'),(214,6,64,'absent'),(215,7,64,'absent'),(216,8,64,'absent'),(217,1,65,'absent'),(218,4,65,'absent'),(219,6,65,'absent'),(220,7,65,'absent'),(221,8,65,'absent'),(222,1,66,'absent'),(223,4,66,'absent'),(224,6,66,'absent'),(225,7,66,'absent'),(226,8,66,'absent'),(227,1,67,'absent'),(228,4,67,'absent'),(229,6,67,'absent'),(230,7,67,'absent'),(231,8,67,'absent'),(232,1,68,'absent'),(233,4,68,'absent'),(234,6,68,'absent'),(235,7,68,'absent'),(236,8,68,'absent'),(237,1,69,'absent'),(238,4,69,'absent'),(239,6,69,'absent'),(240,7,69,'absent'),(241,8,69,'absent'),(242,1,70,'absent'),(243,4,70,'absent'),(244,6,70,'absent'),(245,7,70,'absent'),(246,8,70,'absent'),(247,1,71,'absent'),(248,4,71,'absent'),(249,6,71,'absent'),(250,7,71,'absent'),(251,8,71,'absent'),(252,1,72,'absent'),(253,4,72,'absent'),(254,6,72,'absent'),(255,7,72,'absent'),(256,8,72,'absent'),(257,1,73,'absent'),(258,4,73,'absent'),(259,6,73,'absent'),(260,7,73,'absent'),(261,8,73,'absent'),(262,1,74,'absent'),(263,4,74,'absent'),(264,6,74,'absent'),(265,7,74,'absent'),(266,8,74,'absent'),(267,1,75,'absent'),(268,4,75,'absent'),(269,6,75,'absent'),(270,7,75,'absent'),(271,8,75,'absent'),(272,1,76,'absent'),(273,4,76,'absent'),(274,6,76,'absent'),(275,7,76,'absent'),(276,8,76,'absent'),(277,1,77,'absent'),(278,4,77,'absent'),(279,6,77,'absent'),(280,7,77,'absent'),(281,8,77,'absent'),(282,1,78,'absent'),(283,4,78,'absent'),(284,6,78,'absent'),(285,7,78,'absent'),(286,8,78,'absent'),(287,1,79,'absent'),(288,4,79,'absent'),(289,6,79,'absent'),(290,7,79,'absent'),(291,8,79,'absent'),(292,1,80,'present'),(293,4,80,'absent'),(294,6,80,'absent'),(295,7,80,'absent'),(296,8,80,'present'),(297,1,81,'absent'),(298,5,81,'absent'),(299,6,81,'absent'),(300,7,81,'absent'),(301,8,81,'absent'),(302,1,82,'absent'),(303,3,82,'absent'),(304,4,82,'absent'),(305,5,82,'absent'),(306,6,82,'absent'),(307,7,82,'absent'),(308,8,82,'absent'),(309,9,82,'absent'),(310,196,82,'absent'),(311,20,82,'absent'),(312,22,82,'absent'),(313,23,82,'absent'),(314,24,82,'absent'),(315,25,82,'absent'),(316,26,82,'absent'),(317,27,82,'absent'),(318,28,82,'absent'),(319,29,82,'absent'),(320,30,82,'absent'),(321,32,82,'absent'),(322,33,82,'absent'),(323,34,82,'absent'),(324,35,82,'absent'),(325,36,82,'absent'),(326,37,82,'absent'),(327,38,82,'absent'),(328,39,82,'absent'),(329,40,82,'absent'),(330,41,82,'absent'),(331,43,82,'absent'),(332,44,82,'absent'),(333,45,82,'absent'),(334,46,82,'absent'),(335,47,82,'absent'),(336,48,82,'absent'),(337,49,82,'absent'),(338,1,83,'absent'),(339,3,83,'absent'),(340,4,83,'absent'),(341,5,83,'absent'),(342,6,83,'absent'),(343,7,83,'absent'),(344,8,83,'absent'),(345,9,83,'absent'),(346,196,83,'absent'),(347,20,83,'absent'),(348,22,83,'absent'),(349,23,83,'absent'),(350,24,83,'absent'),(351,25,83,'absent'),(352,26,83,'absent'),(353,27,83,'absent'),(354,28,83,'absent'),(355,29,83,'absent'),(356,30,83,'absent'),(357,32,83,'absent'),(358,33,83,'absent'),(359,34,83,'absent'),(360,35,83,'absent'),(361,36,83,'absent'),(362,37,83,'absent'),(363,38,83,'absent'),(364,39,83,'absent'),(365,40,83,'absent'),(366,41,83,'absent'),(367,43,83,'absent'),(368,44,83,'absent'),(369,45,83,'absent'),(370,46,83,'absent'),(371,47,83,'absent'),(372,48,83,'absent'),(373,49,83,'absent'),(374,1,84,'absent'),(375,3,84,'absent'),(376,4,84,'absent'),(377,5,84,'absent'),(378,6,84,'absent'),(379,7,84,'absent'),(380,8,84,'absent'),(381,9,84,'absent'),(382,196,84,'absent'),(383,20,84,'absent'),(384,22,84,'absent'),(385,23,84,'absent'),(386,24,84,'absent'),(387,25,84,'absent'),(388,26,84,'absent'),(389,27,84,'absent'),(390,28,84,'absent'),(391,29,84,'absent'),(392,30,84,'absent'),(393,32,84,'absent'),(394,33,84,'absent'),(395,34,84,'absent'),(396,35,84,'absent'),(397,36,84,'absent'),(398,37,84,'absent'),(399,38,84,'absent'),(400,39,84,'absent'),(401,40,84,'absent'),(402,41,84,'absent'),(403,43,84,'absent'),(404,44,84,'absent'),(405,45,84,'absent'),(406,46,84,'absent'),(407,47,84,'absent'),(408,48,84,'absent'),(409,49,84,'absent'),(410,1,85,'absent'),(411,3,85,'absent'),(412,4,85,'absent'),(413,5,85,'absent'),(414,6,85,'absent'),(415,7,85,'absent'),(416,8,85,'absent'),(417,9,85,'absent'),(418,196,85,'absent'),(419,20,85,'absent'),(420,22,85,'absent'),(421,23,85,'absent'),(422,24,85,'absent'),(423,25,85,'absent'),(424,26,85,'absent'),(425,27,85,'absent'),(426,28,85,'absent'),(427,29,85,'absent'),(428,30,85,'absent'),(429,32,85,'absent'),(430,33,85,'absent'),(431,34,85,'absent'),(432,35,85,'absent'),(433,36,85,'absent'),(434,37,85,'absent'),(435,38,85,'absent'),(436,39,85,'absent'),(437,40,85,'absent'),(438,41,85,'absent'),(439,43,85,'absent'),(440,44,85,'absent'),(441,45,85,'absent'),(442,46,85,'absent'),(443,47,85,'absent'),(444,48,85,'absent'),(445,49,85,'absent'),(446,1,86,'absent'),(447,3,86,'absent'),(448,4,86,'absent'),(449,5,86,'absent'),(450,6,86,'absent'),(451,7,86,'absent'),(452,8,86,'absent'),(453,9,86,'absent'),(454,196,86,'absent'),(455,20,86,'absent'),(456,22,86,'absent'),(457,23,86,'absent'),(458,24,86,'absent'),(459,25,86,'absent'),(460,26,86,'absent'),(461,27,86,'absent'),(462,28,86,'absent'),(463,29,86,'absent'),(464,30,86,'absent'),(465,32,86,'absent'),(466,33,86,'absent'),(467,34,86,'absent'),(468,35,86,'absent'),(469,36,86,'absent'),(470,37,86,'absent'),(471,38,86,'absent'),(472,39,86,'absent'),(473,40,86,'absent'),(474,41,86,'absent'),(475,43,86,'absent'),(476,44,86,'absent'),(477,45,86,'absent'),(478,46,86,'absent'),(479,47,86,'absent'),(480,48,86,'absent'),(481,49,86,'absent'),(482,1,87,'absent'),(483,3,87,'absent'),(484,4,87,'absent'),(485,5,87,'absent'),(486,6,87,'absent'),(487,7,87,'absent'),(488,8,87,'absent'),(489,9,87,'absent'),(490,196,87,'absent'),(491,20,87,'absent'),(492,22,87,'absent'),(493,23,87,'absent'),(494,24,87,'absent'),(495,25,87,'absent'),(496,26,87,'absent'),(497,27,87,'absent'),(498,28,87,'absent'),(499,29,87,'absent'),(500,30,87,'absent'),(501,32,87,'absent'),(502,33,87,'absent'),(503,34,87,'absent'),(504,35,87,'absent'),(505,36,87,'absent'),(506,37,87,'absent'),(507,38,87,'absent'),(508,39,87,'absent'),(509,40,87,'absent'),(510,41,87,'absent'),(511,43,87,'absent'),(512,44,87,'absent'),(513,45,87,'absent'),(514,46,87,'absent'),(515,47,87,'absent'),(516,48,87,'absent'),(517,49,87,'absent'),(518,1,88,'absent'),(519,3,88,'absent'),(520,4,88,'absent'),(521,5,88,'absent'),(522,6,88,'absent'),(523,7,88,'absent'),(524,8,88,'absent'),(525,9,88,'absent'),(526,196,88,'absent'),(527,20,88,'absent'),(528,22,88,'absent'),(529,23,88,'absent'),(530,24,88,'absent'),(531,25,88,'absent'),(532,26,88,'absent'),(533,27,88,'absent'),(534,28,88,'absent'),(535,29,88,'absent'),(536,30,88,'absent'),(537,32,88,'absent'),(538,33,88,'absent'),(539,34,88,'absent'),(540,35,88,'absent'),(541,36,88,'absent'),(542,37,88,'absent'),(543,38,88,'absent'),(544,39,88,'absent'),(545,40,88,'absent'),(546,41,88,'absent'),(547,43,88,'absent'),(548,44,88,'absent'),(549,45,88,'absent'),(550,46,88,'absent'),(551,47,88,'absent'),(552,48,88,'absent'),(553,49,88,'absent'),(554,1,89,'absent'),(555,3,89,'absent'),(556,4,89,'absent'),(557,5,89,'absent'),(558,6,89,'absent'),(559,7,89,'absent'),(560,8,89,'absent'),(561,9,89,'absent'),(562,196,89,'absent'),(563,20,89,'absent'),(564,22,89,'absent'),(565,23,89,'absent'),(566,24,89,'absent'),(567,25,89,'absent'),(568,26,89,'absent'),(569,27,89,'absent'),(570,28,89,'absent'),(571,29,89,'absent'),(572,30,89,'absent'),(573,32,89,'absent'),(574,33,89,'absent'),(575,34,89,'absent'),(576,35,89,'absent'),(577,36,89,'absent'),(578,37,89,'absent'),(579,38,89,'absent'),(580,39,89,'absent'),(581,40,89,'absent'),(582,41,89,'absent'),(583,43,89,'absent'),(584,44,89,'absent'),(585,45,89,'absent'),(586,46,89,'absent'),(587,47,89,'absent'),(588,48,89,'absent'),(589,49,89,'absent'),(590,1,90,'absent'),(591,3,90,'absent'),(592,4,90,'absent'),(593,5,90,'absent'),(594,6,90,'absent'),(595,7,90,'absent'),(596,8,90,'absent'),(597,9,90,'absent'),(598,196,90,'absent'),(599,20,90,'absent'),(600,22,90,'absent'),(601,23,90,'absent'),(602,24,90,'absent'),(603,25,90,'absent'),(604,26,90,'absent'),(605,27,90,'absent'),(606,28,90,'absent'),(607,29,90,'absent'),(608,30,90,'absent'),(609,32,90,'absent'),(610,33,90,'absent'),(611,34,90,'absent'),(612,35,90,'absent'),(613,36,90,'absent'),(614,37,90,'absent'),(615,38,90,'absent'),(616,39,90,'absent'),(617,40,90,'absent'),(618,41,90,'absent'),(619,43,90,'absent'),(620,44,90,'absent'),(621,45,90,'absent'),(622,46,90,'absent'),(623,47,90,'absent'),(624,48,90,'absent'),(625,49,90,'absent'),(626,1,91,'absent'),(627,3,91,'absent'),(628,4,91,'present'),(629,5,91,'absent'),(630,6,91,'absent'),(631,7,91,'absent'),(632,8,91,'absent'),(633,9,91,'absent'),(634,196,91,'present'),(635,20,91,'absent'),(636,22,91,'absent'),(637,23,91,'absent'),(638,24,91,'absent'),(639,25,91,'absent'),(640,26,91,'absent'),(641,27,91,'absent'),(642,28,91,'absent'),(643,29,91,'absent'),(644,30,91,'absent'),(645,32,91,'absent'),(646,33,91,'absent'),(647,34,91,'absent'),(648,35,91,'absent'),(649,36,91,'absent'),(650,37,91,'absent'),(651,38,91,'absent'),(652,39,91,'absent'),(653,40,91,'absent'),(654,41,91,'absent'),(655,43,91,'absent'),(656,44,91,'absent'),(657,45,91,'absent'),(658,46,91,'absent'),(659,47,91,'absent'),(660,48,91,'absent'),(661,49,91,'absent'),(662,1,92,'absent'),(663,3,92,'absent'),(664,4,92,'absent'),(665,5,92,'absent'),(666,6,92,'absent'),(667,7,92,'absent'),(668,8,92,'absent'),(669,9,92,'absent'),(670,196,92,'absent'),(671,20,92,'absent'),(672,22,92,'absent'),(673,23,92,'absent'),(674,24,92,'absent'),(675,25,92,'absent'),(676,26,92,'absent'),(677,27,92,'absent'),(678,28,92,'absent'),(679,29,92,'absent'),(680,30,92,'absent'),(681,32,92,'absent'),(682,33,92,'absent'),(683,34,92,'absent'),(684,35,92,'absent'),(685,36,92,'absent'),(686,37,92,'absent'),(687,38,92,'absent'),(688,39,92,'absent'),(689,40,92,'absent'),(690,41,92,'absent'),(691,43,92,'absent'),(692,44,92,'absent'),(693,45,92,'absent'),(694,46,92,'absent'),(695,47,92,'absent'),(696,48,92,'absent'),(697,49,92,'absent'),(698,1,93,'absent'),(699,3,93,'absent'),(700,4,93,'absent'),(701,5,93,'absent'),(702,6,93,'absent'),(703,7,93,'absent'),(704,8,93,'absent'),(705,9,93,'absent'),(706,196,93,'absent'),(707,20,93,'absent'),(708,22,93,'absent'),(709,23,93,'absent'),(710,24,93,'absent'),(711,25,93,'absent'),(712,26,93,'absent'),(713,27,93,'absent'),(714,28,93,'absent'),(715,29,93,'absent'),(716,30,93,'absent'),(717,32,93,'absent'),(718,33,93,'absent'),(719,34,93,'absent'),(720,35,93,'absent'),(721,36,93,'absent'),(722,37,93,'absent'),(723,38,93,'absent'),(724,39,93,'absent'),(725,40,93,'absent'),(726,41,93,'absent'),(727,43,93,'absent'),(728,44,93,'absent'),(729,45,93,'absent'),(730,46,93,'absent'),(731,47,93,'absent'),(732,48,93,'absent'),(733,49,93,'absent'),(734,1,94,'absent'),(735,3,94,'absent'),(736,4,94,'absent'),(737,5,94,'absent'),(738,6,94,'absent'),(739,7,94,'absent'),(740,8,94,'absent'),(741,9,94,'absent'),(742,196,94,'absent'),(743,20,94,'absent'),(744,22,94,'absent'),(745,23,94,'absent'),(746,24,94,'absent'),(747,25,94,'absent'),(748,26,94,'absent'),(749,27,94,'absent'),(750,28,94,'absent'),(751,29,94,'absent'),(752,30,94,'absent'),(753,32,94,'absent'),(754,33,94,'absent'),(755,34,94,'absent'),(756,35,94,'absent'),(757,36,94,'absent'),(758,37,94,'absent'),(759,38,94,'absent'),(760,39,94,'absent'),(761,40,94,'absent'),(762,41,94,'absent'),(763,43,94,'absent'),(764,44,94,'absent'),(765,45,94,'absent'),(766,46,94,'absent'),(767,47,94,'absent'),(768,48,94,'absent'),(769,49,94,'absent'),(770,1,95,'absent'),(771,3,95,'absent'),(772,4,95,'present'),(773,5,95,'present'),(774,6,95,'present'),(775,7,95,'absent'),(776,8,95,'absent'),(777,9,95,'absent'),(778,196,95,'absent'),(779,20,95,'absent'),(780,22,95,'absent'),(781,23,95,'absent'),(782,24,95,'absent'),(783,25,95,'absent'),(784,26,95,'absent'),(785,27,95,'absent'),(786,28,95,'absent'),(787,29,95,'absent'),(788,30,95,'absent'),(789,32,95,'absent'),(790,33,95,'absent'),(791,34,95,'absent'),(792,35,95,'absent'),(793,36,95,'absent'),(794,37,95,'absent'),(795,38,95,'absent'),(796,39,95,'absent'),(797,40,95,'absent'),(798,41,95,'absent'),(799,43,95,'absent'),(800,44,95,'absent'),(801,45,95,'absent'),(802,46,95,'absent'),(803,47,95,'absent'),(804,48,95,'absent'),(805,49,95,'absent'),(806,1,96,'absent'),(807,3,96,'absent'),(808,4,96,'absent'),(809,5,96,'absent'),(810,6,96,'absent'),(811,7,96,'absent'),(812,8,96,'absent'),(813,9,96,'absent'),(814,196,96,'absent'),(815,20,96,'absent'),(816,22,96,'absent'),(817,23,96,'absent'),(818,24,96,'absent'),(819,25,96,'absent'),(820,26,96,'absent'),(821,27,96,'absent'),(822,28,96,'absent'),(823,29,96,'absent'),(824,30,96,'absent'),(825,32,96,'absent'),(826,33,96,'absent'),(827,34,96,'absent'),(828,35,96,'absent'),(829,36,96,'absent'),(830,37,96,'absent'),(831,38,96,'absent'),(832,39,96,'absent'),(833,40,96,'absent'),(834,41,96,'absent'),(835,43,96,'absent'),(836,44,96,'absent'),(837,45,96,'absent'),(838,46,96,'absent'),(839,47,96,'absent'),(840,48,96,'absent'),(841,49,96,'absent'),(842,1,97,'absent'),(843,3,97,'absent'),(844,4,97,'absent'),(845,5,97,'absent'),(846,6,97,'absent'),(847,7,97,'absent'),(848,8,97,'absent'),(849,9,97,'absent'),(850,196,97,'absent'),(851,20,97,'absent'),(852,22,97,'absent'),(853,23,97,'absent'),(854,24,97,'absent'),(855,25,97,'absent'),(856,26,97,'absent'),(857,27,97,'absent'),(858,28,97,'absent'),(859,29,97,'absent'),(860,30,97,'absent'),(861,32,97,'absent'),(862,33,97,'absent'),(863,34,97,'absent'),(864,35,97,'absent'),(865,36,97,'absent'),(866,37,97,'absent'),(867,38,97,'absent'),(868,39,97,'absent'),(869,40,97,'absent'),(870,41,97,'absent'),(871,43,97,'absent'),(872,44,97,'absent'),(873,45,97,'absent'),(874,46,97,'absent'),(875,47,97,'absent'),(876,48,97,'absent'),(877,49,97,'absent'),(878,1,98,'absent'),(879,3,98,'absent'),(880,4,98,'absent'),(881,5,98,'absent'),(882,6,98,'absent'),(883,7,98,'absent'),(884,8,98,'absent'),(885,9,98,'absent'),(886,196,98,'absent'),(887,20,98,'absent'),(888,22,98,'absent'),(889,23,98,'absent'),(890,24,98,'absent'),(891,25,98,'absent'),(892,26,98,'absent'),(893,27,98,'absent'),(894,28,98,'absent'),(895,29,98,'absent'),(896,30,98,'absent'),(897,32,98,'absent'),(898,33,98,'absent'),(899,34,98,'absent'),(900,35,98,'absent'),(901,36,98,'absent'),(902,37,98,'absent'),(903,38,98,'absent'),(904,39,98,'absent'),(905,40,98,'absent'),(906,41,98,'absent'),(907,43,98,'absent'),(908,44,98,'absent'),(909,45,98,'absent'),(910,46,98,'absent'),(911,47,98,'absent'),(912,48,98,'absent'),(913,49,98,'absent'),(914,1,99,'absent'),(915,3,99,'absent'),(916,4,99,'absent'),(917,5,99,'absent'),(918,6,99,'absent'),(919,7,99,'absent'),(920,8,99,'absent'),(921,9,99,'absent'),(922,196,99,'absent'),(923,20,99,'absent'),(924,22,99,'absent'),(925,23,99,'absent'),(926,24,99,'absent'),(927,25,99,'absent'),(928,26,99,'absent'),(929,27,99,'absent'),(930,28,99,'absent'),(931,29,99,'absent'),(932,30,99,'absent'),(933,32,99,'absent'),(934,33,99,'absent'),(935,34,99,'absent'),(936,35,99,'absent'),(937,36,99,'absent'),(938,37,99,'absent'),(939,38,99,'absent'),(940,39,99,'absent'),(941,40,99,'absent'),(942,41,99,'absent'),(943,43,99,'absent'),(944,44,99,'absent'),(945,45,99,'absent'),(946,46,99,'absent'),(947,47,99,'absent'),(948,48,99,'absent'),(949,49,99,'absent'),(950,1,100,'absent'),(951,3,100,'absent'),(952,4,100,'absent'),(953,5,100,'absent'),(954,6,100,'absent'),(955,7,100,'absent'),(956,8,100,'absent'),(957,9,100,'absent'),(958,196,100,'absent'),(959,20,100,'absent'),(960,22,100,'absent'),(961,23,100,'absent'),(962,24,100,'absent'),(963,25,100,'absent'),(964,26,100,'absent'),(965,27,100,'absent'),(966,28,100,'absent'),(967,29,100,'absent'),(968,30,100,'absent'),(969,32,100,'absent'),(970,33,100,'absent'),(971,34,100,'absent'),(972,35,100,'absent'),(973,36,100,'absent'),(974,37,100,'absent'),(975,38,100,'absent'),(976,39,100,'absent'),(977,40,100,'absent'),(978,41,100,'absent'),(979,43,100,'absent'),(980,44,100,'absent'),(981,45,100,'absent'),(982,46,100,'absent'),(983,47,100,'absent'),(984,48,100,'absent'),(985,49,100,'absent'),(986,1,101,'absent'),(987,3,101,'absent'),(988,4,101,'absent'),(989,5,101,'absent'),(990,6,101,'absent'),(991,7,101,'absent'),(992,8,101,'absent'),(993,9,101,'absent'),(994,196,101,'absent'),(995,20,101,'absent'),(996,22,101,'absent'),(997,23,101,'absent'),(998,24,101,'absent'),(999,25,101,'absent'),(1000,26,101,'absent'),(1001,27,101,'absent'),(1002,28,101,'absent'),(1003,29,101,'absent'),(1004,30,101,'absent'),(1005,32,101,'absent'),(1006,33,101,'absent'),(1007,34,101,'absent'),(1008,35,101,'absent'),(1009,36,101,'absent'),(1010,37,101,'absent'),(1011,38,101,'absent'),(1012,39,101,'absent'),(1013,40,101,'absent'),(1014,41,101,'absent'),(1015,43,101,'absent'),(1016,44,101,'absent'),(1017,45,101,'absent'),(1018,46,101,'absent'),(1019,47,101,'absent'),(1020,48,101,'absent'),(1021,49,101,'absent'),(1022,1,102,'absent'),(1023,3,102,'absent'),(1024,4,102,'absent'),(1025,5,102,'absent'),(1026,6,102,'absent'),(1027,7,102,'absent'),(1028,8,102,'absent'),(1029,9,102,'absent'),(1030,196,102,'absent'),(1031,20,102,'absent'),(1032,22,102,'absent'),(1033,23,102,'absent'),(1034,24,102,'absent'),(1035,25,102,'absent'),(1036,26,102,'absent'),(1037,27,102,'absent'),(1038,28,102,'absent'),(1039,29,102,'absent'),(1040,30,102,'absent'),(1041,32,102,'absent'),(1042,33,102,'absent'),(1043,34,102,'absent'),(1044,35,102,'absent'),(1045,36,102,'absent'),(1046,37,102,'absent'),(1047,38,102,'absent'),(1048,39,102,'absent'),(1049,40,102,'absent'),(1050,41,102,'absent'),(1051,43,102,'absent'),(1052,44,102,'absent'),(1053,45,102,'absent'),(1054,46,102,'absent'),(1055,47,102,'absent'),(1056,48,102,'absent'),(1057,49,102,'absent'),(1058,1,103,'absent'),(1059,3,103,'absent'),(1060,4,103,'absent'),(1061,5,103,'absent'),(1062,6,103,'absent'),(1063,7,103,'absent'),(1064,8,103,'absent'),(1065,9,103,'absent'),(1066,196,103,'absent'),(1067,20,103,'absent'),(1068,22,103,'absent'),(1069,23,103,'absent'),(1070,24,103,'absent'),(1071,25,103,'absent'),(1072,26,103,'absent'),(1073,27,103,'absent'),(1074,28,103,'absent'),(1075,29,103,'absent'),(1076,30,103,'absent'),(1077,32,103,'absent'),(1078,33,103,'absent'),(1079,34,103,'absent'),(1080,35,103,'absent'),(1081,36,103,'absent'),(1082,37,103,'absent'),(1083,38,103,'absent'),(1084,39,103,'absent'),(1085,40,103,'absent'),(1086,41,103,'absent'),(1087,43,103,'absent'),(1088,44,103,'absent'),(1089,45,103,'absent'),(1090,46,103,'absent'),(1091,47,103,'absent'),(1092,48,103,'absent'),(1093,49,103,'absent'),(1094,1,104,'absent'),(1095,3,104,'absent'),(1096,4,104,'absent'),(1097,5,104,'absent'),(1098,6,104,'absent'),(1099,7,104,'absent'),(1100,8,104,'absent'),(1101,9,104,'absent'),(1102,196,104,'absent'),(1103,20,104,'absent'),(1104,22,104,'absent'),(1105,23,104,'absent'),(1106,24,104,'absent'),(1107,25,104,'absent'),(1108,26,104,'absent'),(1109,27,104,'absent'),(1110,28,104,'absent'),(1111,29,104,'absent'),(1112,30,104,'absent'),(1113,32,104,'absent'),(1114,33,104,'absent'),(1115,34,104,'absent'),(1116,35,104,'absent'),(1117,36,104,'absent'),(1118,37,104,'absent'),(1119,38,104,'absent'),(1120,39,104,'absent'),(1121,40,104,'absent'),(1122,41,104,'absent'),(1123,43,104,'absent'),(1124,44,104,'absent'),(1125,45,104,'absent'),(1126,46,104,'absent'),(1127,47,104,'absent'),(1128,48,104,'absent'),(1129,49,104,'absent'),(1130,1,105,'absent'),(1131,3,105,'absent'),(1132,4,105,'absent'),(1133,5,105,'absent'),(1134,6,105,'absent'),(1135,7,105,'absent'),(1136,8,105,'absent'),(1137,9,105,'absent'),(1138,196,105,'absent'),(1139,20,105,'absent'),(1140,22,105,'absent'),(1141,23,105,'absent'),(1142,24,105,'absent'),(1143,25,105,'absent'),(1144,26,105,'absent'),(1145,27,105,'absent'),(1146,28,105,'absent'),(1147,29,105,'absent'),(1148,30,105,'absent'),(1149,32,105,'absent'),(1150,33,105,'absent'),(1151,34,105,'absent'),(1152,35,105,'absent'),(1153,36,105,'absent'),(1154,37,105,'absent'),(1155,38,105,'absent'),(1156,39,105,'absent'),(1157,40,105,'absent'),(1158,41,105,'absent'),(1159,43,105,'absent'),(1160,44,105,'absent'),(1161,45,105,'absent'),(1162,46,105,'absent'),(1163,47,105,'absent'),(1164,48,105,'absent'),(1165,49,105,'absent'),(1166,1,106,'absent'),(1167,3,106,'absent'),(1168,4,106,'absent'),(1169,5,106,'absent'),(1170,6,106,'absent'),(1171,7,106,'absent'),(1172,8,106,'absent'),(1173,9,106,'absent'),(1174,196,106,'absent'),(1175,20,106,'absent'),(1176,22,106,'absent'),(1177,23,106,'absent'),(1178,24,106,'absent'),(1179,25,106,'absent'),(1180,26,106,'absent'),(1181,27,106,'absent'),(1182,28,106,'absent'),(1183,29,106,'absent'),(1184,30,106,'absent'),(1185,32,106,'absent'),(1186,33,106,'absent'),(1187,34,106,'absent'),(1188,35,106,'absent'),(1189,36,106,'absent'),(1190,37,106,'absent'),(1191,38,106,'absent'),(1192,39,106,'absent'),(1193,40,106,'absent'),(1194,41,106,'absent'),(1195,43,106,'absent'),(1196,44,106,'absent'),(1197,45,106,'absent'),(1198,46,106,'absent'),(1199,47,106,'absent'),(1200,48,106,'absent'),(1201,49,106,'absent'),(1202,96,107,'absent'),(1203,98,107,'absent'),(1204,99,107,'absent'),(1205,100,107,'absent'),(1206,101,107,'absent'),(1207,102,107,'absent'),(1208,103,107,'absent'),(1209,104,107,'absent'),(1210,105,107,'absent'),(1211,116,107,'absent'),(1212,118,107,'absent'),(1213,119,107,'absent'),(1214,120,107,'absent'),(1215,121,107,'absent'),(1216,122,107,'absent'),(1217,123,107,'absent'),(1218,124,107,'absent'),(1219,125,107,'absent'),(1220,126,107,'absent'),(1221,128,107,'absent'),(1222,129,107,'absent'),(1223,130,107,'absent'),(1224,131,107,'absent'),(1225,132,107,'absent'),(1226,133,107,'absent'),(1227,134,107,'absent'),(1228,135,107,'absent'),(1229,136,107,'absent'),(1230,138,107,'absent'),(1231,139,107,'absent'),(1232,140,107,'absent'),(1233,141,107,'absent'),(1234,142,107,'absent'),(1235,143,107,'absent'),(1236,144,107,'absent'),(1237,145,107,'absent'),(1238,96,108,'absent'),(1239,98,108,'absent'),(1240,99,108,'absent'),(1241,100,108,'absent'),(1242,101,108,'absent'),(1243,102,108,'absent'),(1244,103,108,'absent'),(1245,104,108,'absent'),(1246,105,108,'absent'),(1247,116,108,'absent'),(1248,118,108,'absent'),(1249,119,108,'absent'),(1250,120,108,'absent'),(1251,121,108,'absent'),(1252,122,108,'absent'),(1253,123,108,'absent'),(1254,124,108,'absent'),(1255,125,108,'absent'),(1256,126,108,'absent'),(1257,128,108,'absent'),(1258,129,108,'absent'),(1259,130,108,'absent'),(1260,131,108,'absent'),(1261,132,108,'absent'),(1262,133,108,'absent'),(1263,134,108,'absent'),(1264,135,108,'absent'),(1265,136,108,'absent'),(1266,138,108,'absent'),(1267,139,108,'absent'),(1268,140,108,'absent'),(1269,141,108,'absent'),(1270,142,108,'absent'),(1271,143,108,'absent'),(1272,144,108,'absent'),(1273,145,108,'absent'),(1274,96,109,'absent'),(1275,98,109,'absent'),(1276,99,109,'absent'),(1277,100,109,'absent'),(1278,101,109,'absent'),(1279,102,109,'absent'),(1280,103,109,'absent'),(1281,104,109,'absent'),(1282,105,109,'absent'),(1283,116,109,'absent'),(1284,118,109,'absent'),(1285,119,109,'absent'),(1286,120,109,'absent'),(1287,121,109,'absent'),(1288,122,109,'absent'),(1289,123,109,'absent'),(1290,124,109,'absent'),(1291,125,109,'absent'),(1292,126,109,'absent'),(1293,128,109,'absent'),(1294,129,109,'absent'),(1295,130,109,'absent'),(1296,131,109,'absent'),(1297,132,109,'absent'),(1298,133,109,'absent'),(1299,134,109,'absent'),(1300,135,109,'absent'),(1301,136,109,'absent'),(1302,138,109,'absent'),(1303,139,109,'absent'),(1304,140,109,'absent'),(1305,141,109,'absent'),(1306,142,109,'absent'),(1307,143,109,'absent'),(1308,144,109,'absent'),(1309,145,109,'absent'),(1310,96,110,'absent'),(1311,98,110,'absent'),(1312,99,110,'absent'),(1313,100,110,'absent'),(1314,101,110,'absent'),(1315,102,110,'absent'),(1316,103,110,'absent'),(1317,104,110,'absent'),(1318,105,110,'absent'),(1319,116,110,'absent'),(1320,118,110,'absent'),(1321,119,110,'absent'),(1322,120,110,'absent'),(1323,121,110,'absent'),(1324,122,110,'absent'),(1325,123,110,'absent'),(1326,124,110,'absent'),(1327,125,110,'absent'),(1328,126,110,'absent'),(1329,128,110,'absent'),(1330,129,110,'absent'),(1331,130,110,'absent'),(1332,131,110,'absent'),(1333,132,110,'absent'),(1334,133,110,'absent'),(1335,134,110,'absent'),(1336,135,110,'absent'),(1337,136,110,'absent'),(1338,138,110,'absent'),(1339,139,110,'absent'),(1340,140,110,'absent'),(1341,141,110,'absent'),(1342,142,110,'absent'),(1343,143,110,'absent'),(1344,144,110,'absent'),(1345,145,110,'absent'),(1346,96,111,'absent'),(1347,98,111,'absent'),(1348,99,111,'absent'),(1349,100,111,'absent'),(1350,101,111,'absent'),(1351,102,111,'absent'),(1352,103,111,'absent'),(1353,104,111,'absent'),(1354,105,111,'absent'),(1355,116,111,'absent'),(1356,118,111,'absent'),(1357,119,111,'absent'),(1358,120,111,'absent'),(1359,121,111,'absent'),(1360,122,111,'absent'),(1361,123,111,'absent'),(1362,124,111,'absent'),(1363,125,111,'absent'),(1364,126,111,'absent'),(1365,128,111,'absent'),(1366,129,111,'absent'),(1367,130,111,'absent'),(1368,131,111,'absent'),(1369,132,111,'absent'),(1370,133,111,'absent'),(1371,134,111,'absent'),(1372,135,111,'absent'),(1373,136,111,'absent'),(1374,138,111,'absent'),(1375,139,111,'absent'),(1376,140,111,'absent'),(1377,141,111,'absent'),(1378,142,111,'absent'),(1379,143,111,'absent'),(1380,144,111,'absent'),(1381,145,111,'absent'),(1382,96,112,'absent'),(1383,98,112,'absent'),(1384,99,112,'absent'),(1385,100,112,'absent'),(1386,101,112,'absent'),(1387,102,112,'absent'),(1388,103,112,'absent'),(1389,104,112,'absent'),(1390,105,112,'absent'),(1391,116,112,'absent'),(1392,118,112,'absent'),(1393,119,112,'absent'),(1394,120,112,'absent'),(1395,121,112,'absent'),(1396,122,112,'absent'),(1397,123,112,'absent'),(1398,124,112,'absent'),(1399,125,112,'absent'),(1400,126,112,'absent'),(1401,128,112,'absent'),(1402,129,112,'absent'),(1403,130,112,'absent'),(1404,131,112,'absent'),(1405,132,112,'absent'),(1406,133,112,'absent'),(1407,134,112,'absent'),(1408,135,112,'absent'),(1409,136,112,'absent'),(1410,138,112,'absent'),(1411,139,112,'absent'),(1412,140,112,'absent'),(1413,141,112,'absent'),(1414,142,112,'absent'),(1415,143,112,'absent'),(1416,144,112,'absent'),(1417,145,112,'absent'),(1418,96,113,'absent'),(1419,98,113,'absent'),(1420,99,113,'absent'),(1421,100,113,'absent'),(1422,101,113,'absent'),(1423,102,113,'absent'),(1424,103,113,'absent'),(1425,104,113,'absent'),(1426,105,113,'absent'),(1427,116,113,'absent'),(1428,118,113,'absent'),(1429,119,113,'absent'),(1430,120,113,'absent'),(1431,121,113,'absent'),(1432,122,113,'absent'),(1433,123,113,'absent'),(1434,124,113,'absent'),(1435,125,113,'absent'),(1436,126,113,'absent'),(1437,128,113,'absent'),(1438,129,113,'absent'),(1439,130,113,'absent'),(1440,131,113,'absent'),(1441,132,113,'absent'),(1442,133,113,'absent'),(1443,134,113,'absent'),(1444,135,113,'absent'),(1445,136,113,'absent'),(1446,138,113,'absent'),(1447,139,113,'absent'),(1448,140,113,'absent'),(1449,141,113,'absent'),(1450,142,113,'absent'),(1451,143,113,'absent'),(1452,144,113,'absent'),(1453,145,113,'absent'),(1454,96,114,'absent'),(1455,98,114,'absent'),(1456,99,114,'absent'),(1457,100,114,'absent'),(1458,101,114,'absent'),(1459,102,114,'absent'),(1460,103,114,'absent'),(1461,104,114,'absent'),(1462,105,114,'absent'),(1463,116,114,'absent'),(1464,118,114,'absent'),(1465,119,114,'absent'),(1466,120,114,'absent'),(1467,121,114,'absent'),(1468,122,114,'absent'),(1469,123,114,'absent'),(1470,124,114,'absent'),(1471,125,114,'absent'),(1472,126,114,'absent'),(1473,128,114,'absent'),(1474,129,114,'absent'),(1475,130,114,'absent'),(1476,131,114,'absent'),(1477,132,114,'absent'),(1478,133,114,'absent'),(1479,134,114,'absent'),(1480,135,114,'absent'),(1481,136,114,'absent'),(1482,138,114,'absent'),(1483,139,114,'absent'),(1484,140,114,'absent'),(1485,141,114,'absent'),(1486,142,114,'absent'),(1487,143,114,'absent'),(1488,144,114,'absent'),(1489,145,114,'absent'),(1490,96,115,'absent'),(1491,98,115,'absent'),(1492,99,115,'absent'),(1493,100,115,'absent'),(1494,101,115,'absent'),(1495,102,115,'absent'),(1496,103,115,'absent'),(1497,104,115,'absent'),(1498,105,115,'absent'),(1499,116,115,'absent'),(1500,118,115,'absent'),(1501,119,115,'absent'),(1502,120,115,'absent'),(1503,121,115,'absent'),(1504,122,115,'absent'),(1505,123,115,'absent'),(1506,124,115,'absent'),(1507,125,115,'absent'),(1508,126,115,'absent'),(1509,128,115,'absent'),(1510,129,115,'absent'),(1511,130,115,'absent'),(1512,131,115,'absent'),(1513,132,115,'absent'),(1514,133,115,'absent'),(1515,134,115,'absent'),(1516,135,115,'absent'),(1517,136,115,'absent'),(1518,138,115,'absent'),(1519,139,115,'absent'),(1520,140,115,'absent'),(1521,141,115,'absent'),(1522,142,115,'absent'),(1523,143,115,'absent'),(1524,144,115,'absent'),(1525,145,115,'absent'),(1526,96,116,'absent'),(1527,98,116,'absent'),(1528,99,116,'absent'),(1529,100,116,'absent'),(1530,101,116,'absent'),(1531,102,116,'absent'),(1532,103,116,'absent'),(1533,104,116,'absent'),(1534,105,116,'absent'),(1535,116,116,'absent'),(1536,118,116,'absent'),(1537,119,116,'absent'),(1538,120,116,'absent'),(1539,121,116,'absent'),(1540,122,116,'absent'),(1541,123,116,'absent'),(1542,124,116,'absent'),(1543,125,116,'absent'),(1544,126,116,'absent'),(1545,96,117,'absent'),(1546,128,116,'absent'),(1547,98,117,'absent'),(1548,129,116,'absent'),(1549,99,117,'absent'),(1550,130,116,'absent'),(1551,100,117,'absent'),(1552,101,117,'absent'),(1553,131,116,'absent'),(1554,132,116,'absent'),(1555,102,117,'absent'),(1556,103,117,'absent'),(1557,133,116,'absent'),(1558,134,116,'absent'),(1559,104,117,'absent'),(1560,105,117,'absent'),(1561,135,116,'absent'),(1562,136,116,'absent'),(1563,116,117,'absent'),(1564,138,116,'absent'),(1565,118,117,'absent'),(1566,139,116,'absent'),(1567,119,117,'absent'),(1568,140,116,'absent'),(1569,120,117,'absent'),(1570,121,117,'absent'),(1571,141,116,'absent'),(1572,122,117,'absent'),(1573,142,116,'absent'),(1574,143,116,'absent'),(1575,123,117,'absent'),(1576,144,116,'absent'),(1577,124,117,'absent'),(1578,145,116,'absent'),(1579,125,117,'absent'),(1580,126,117,'absent'),(1581,128,117,'absent'),(1582,129,117,'absent'),(1583,130,117,'absent'),(1584,131,117,'absent'),(1585,132,117,'absent'),(1586,133,117,'absent'),(1587,134,117,'absent'),(1588,135,117,'absent'),(1589,136,117,'absent'),(1590,138,117,'absent'),(1591,139,117,'absent'),(1592,140,117,'absent'),(1593,141,117,'absent'),(1594,142,117,'absent'),(1595,143,117,'absent'),(1596,144,117,'absent'),(1597,145,117,'absent'),(1598,146,119,'absent'),(1599,148,119,'absent'),(1600,149,119,'absent'),(1601,150,119,'absent'),(1602,151,119,'absent'),(1603,152,119,'absent'),(1604,153,119,'absent'),(1605,154,119,'absent'),(1606,155,119,'absent'),(1607,156,119,'absent'),(1608,158,119,'absent'),(1609,159,119,'absent'),(1610,160,119,'absent'),(1611,161,119,'absent'),(1612,162,119,'absent'),(1613,163,119,'absent'),(1614,164,119,'absent'),(1615,165,119,'absent'),(1616,166,119,'absent'),(1617,168,119,'absent'),(1618,169,119,'absent'),(1619,170,119,'absent'),(1620,171,119,'absent'),(1621,172,119,'absent'),(1622,173,119,'absent'),(1623,174,119,'absent'),(1624,175,119,'absent'),(1625,176,119,'absent'),(1626,178,119,'absent'),(1627,179,119,'absent'),(1628,180,119,'absent'),(1629,181,119,'absent'),(1630,182,119,'absent'),(1631,183,119,'absent'),(1632,184,119,'absent'),(1633,185,119,'absent'),(1634,186,119,'absent'),(1635,188,119,'absent'),(1636,189,119,'absent'),(1637,190,119,'absent'),(1638,191,119,'absent'),(1639,192,119,'absent'),(1640,193,119,'absent'),(1641,194,119,'absent'),(1642,195,119,'absent'),(1643,146,120,'absent'),(1644,148,120,'absent'),(1645,149,120,'absent'),(1646,150,120,'absent'),(1647,151,120,'absent'),(1648,152,120,'absent'),(1649,153,120,'absent'),(1650,154,120,'absent'),(1651,155,120,'absent'),(1652,156,120,'absent'),(1653,158,120,'absent'),(1654,159,120,'absent'),(1655,160,120,'absent'),(1656,161,120,'absent'),(1657,162,120,'absent'),(1658,163,120,'absent'),(1659,164,120,'absent'),(1660,165,120,'absent'),(1661,166,120,'absent'),(1662,168,120,'absent'),(1663,169,120,'absent'),(1664,170,120,'absent'),(1665,171,120,'absent'),(1666,172,120,'absent'),(1667,173,120,'absent'),(1668,174,120,'absent'),(1669,175,120,'absent'),(1670,176,120,'absent'),(1671,178,120,'absent'),(1672,179,120,'absent'),(1673,180,120,'absent'),(1674,181,120,'absent'),(1675,182,120,'absent'),(1676,183,120,'absent'),(1677,184,120,'absent'),(1678,185,120,'absent'),(1679,186,120,'absent'),(1680,188,120,'absent'),(1681,189,120,'absent'),(1682,190,120,'absent'),(1683,191,120,'absent'),(1684,192,120,'absent'),(1685,193,120,'absent'),(1686,194,120,'absent'),(1687,195,120,'absent'),(1688,146,121,'absent'),(1689,148,121,'absent'),(1690,149,121,'absent'),(1691,150,121,'absent'),(1692,151,121,'absent'),(1693,152,121,'absent'),(1694,153,121,'absent'),(1695,154,121,'absent'),(1696,155,121,'absent'),(1697,156,121,'absent'),(1698,158,121,'absent'),(1699,159,121,'absent'),(1700,160,121,'absent'),(1701,161,121,'absent'),(1702,162,121,'absent'),(1703,163,121,'absent'),(1704,164,121,'absent'),(1705,165,121,'absent'),(1706,166,121,'absent'),(1707,168,121,'absent'),(1708,169,121,'absent'),(1709,170,121,'absent'),(1710,171,121,'absent'),(1711,172,121,'absent'),(1712,173,121,'absent'),(1713,174,121,'absent'),(1714,175,121,'absent'),(1715,176,121,'absent'),(1716,178,121,'absent'),(1717,179,121,'absent'),(1718,180,121,'absent'),(1719,181,121,'absent'),(1720,182,121,'absent'),(1721,183,121,'absent'),(1722,184,121,'absent'),(1723,185,121,'absent'),(1724,186,121,'absent'),(1725,188,121,'absent'),(1726,189,121,'absent'),(1727,190,121,'absent'),(1728,191,121,'absent'),(1729,192,121,'absent'),(1730,193,121,'absent'),(1731,194,121,'absent'),(1732,195,121,'absent');
/*!40000 ALTER TABLE `FireDrillAttendance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FireDrillSchedule`
--

DROP TABLE IF EXISTS `FireDrillSchedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `FireDrillSchedule` (
  `fireDrillId` int(11) NOT NULL AUTO_INCREMENT,
  `buildingId` int(11) NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fireDrillTypeId` int(11) DEFAULT NULL,
  `status` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `scheduledBy` int(11) NOT NULL,
  `lastUpdate` datetime(3) NOT NULL,
  `scheduleDateTime` datetime(3) NOT NULL,
  `startDateTime` datetime(3) DEFAULT NULL,
  `completeDateTime` datetime(3) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `editedBy` int(11) DEFAULT NULL,
  PRIMARY KEY (`fireDrillId`),
  KEY `buildingId` (`buildingId`),
  KEY `fireDrillTypeId` (`fireDrillTypeId`),
  KEY `scheduledBy` (`scheduledBy`),
  CONSTRAINT `FireDrillSchedule_ibfk_1` FOREIGN KEY (`buildingId`) REFERENCES `Building` (`buildingId`),
  CONSTRAINT `FireDrillSchedule_ibfk_2` FOREIGN KEY (`fireDrillTypeId`) REFERENCES `FireDrillType` (`fireDrillTypeId`),
  CONSTRAINT `FireDrillSchedule_ibfk_3` FOREIGN KEY (`scheduledBy`) REFERENCES `User` (`userId`)
) ENGINE=InnoDB AUTO_INCREMENT=122 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FireDrillSchedule`
--

LOCK TABLES `FireDrillSchedule` WRITE;
/*!40000 ALTER TABLE `FireDrillSchedule` DISABLE KEYS */;
INSERT INTO `FireDrillSchedule` VALUES (1,1,NULL,NULL,'close',1,'2009-01-01 15:00:10.004','2009-01-01 15:00:01.000',NULL,'2009-01-01 15:00:10.000',0,1),(2,2,NULL,NULL,'close',2,'2009-01-02 16:20:00.013','2009-01-02 16:00:02.123',NULL,'2009-01-02 16:20:10.013',0,2),(3,3,NULL,NULL,'close',1,'2009-01-03 17:00:10.100','2009-01-03 15:00:01.004',NULL,'2009-01-03 17:30:15.000',0,3),(4,4,NULL,NULL,'close',2,'2009-01-04 18:00:10.020','2009-01-04 15:00:01.002',NULL,'2009-01-04 18:30:08.080',0,4),(5,1,'the start ',NULL,'close',3,'2009-01-05 19:01:10.001','2009-01-05 15:00:01.034',NULL,'2019-04-09 10:03:50.000',0,2),(6,2,NULL,NULL,'close',4,'2019-04-10 11:04:16.000','2019-04-10 11:04:16.000',NULL,'2019-04-12 11:24:37.000',0,46),(7,3,NULL,NULL,'open',1,'2019-04-16 11:04:54.000','2020-01-11 17:00:01.050',NULL,NULL,1,48),(8,4,NULL,NULL,'open',2,'2009-01-08 22:04:10.020','2009-01-08 15:00:01.100',NULL,NULL,1,4),(9,1,'4day later',NULL,'close',3,'2009-01-09 23:05:10.003','2009-01-09 15:00:01.030',NULL,'2019-04-09 10:04:13.000',0,2),(10,2,NULL,NULL,'close',4,'2019-04-10 11:09:16.000','2019-04-10 11:09:16.000',NULL,'2019-04-16 09:28:08.000',0,46),(11,3,NULL,NULL,'open',1,'2019-04-16 11:04:56.000','2020-01-11 17:00:01.050',NULL,NULL,1,48),(12,4,NULL,NULL,'open',2,'2009-01-12 03:08:10.020','2020-01-12 18:00:01.000',NULL,NULL,1,4),(13,1,'coming year',NULL,'open',3,'2019-04-05 10:14:08.000','2020-01-13 19:00:01.067',NULL,NULL,1,1),(14,2,NULL,NULL,'open',4,'2009-01-14 05:10:10.020','2020-01-14 20:00:01.089',NULL,NULL,0,2),(15,3,NULL,NULL,'open',2,'2009-01-15 06:11:10.100','2020-01-15 21:00:01.012',NULL,NULL,0,3),(16,4,NULL,NULL,'open',1,'2009-01-16 07:12:10.020','2020-01-16 22:00:01.100',NULL,NULL,1,4),(17,1,'',1,'close',1,'2019-04-05 11:38:16.000','2019-04-05 11:38:16.000',NULL,'2019-04-09 10:04:16.000',0,2),(18,1,'',2,'close',1,'2019-04-10 11:09:16.000','2019-04-05 11:39:36.000',NULL,'2019-04-09 10:04:19.000',0,2),(19,1,'',2,'close',1,'2019-04-05 11:46:52.000','2019-04-06 11:46:24.000',NULL,'2019-04-09 10:04:21.000',0,2),(20,1,'',3,'close',1,'2019-04-05 11:47:23.000','2019-04-06 00:47:59.000',NULL,'2019-04-09 10:04:24.000',0,2),(21,1,'',3,'close',1,'2019-04-05 11:51:31.000','2019-04-05 11:51:26.000',NULL,'2019-04-09 10:04:27.000',0,2),(22,1,'',3,'close',1,'2019-04-05 11:52:51.000','2019-04-05 11:52:46.000',NULL,'2019-04-10 11:14:56.000',0,2),(23,1,'',1,'close',2,'2019-04-08 10:16:33.000','2019-04-08 10:25:58.000',NULL,'2019-04-08 13:07:43.000',0,2),(24,1,'This is the fire drill dry run testing 1',1,'close',2,'2019-04-09 09:45:22.000','2019-04-09 09:50:27.000',NULL,'2019-04-09 10:02:32.000',0,2),(25,1,'Fire Drill Now',3,'close',2,'2019-04-09 10:04:38.000','2019-04-09 10:04:52.000',NULL,'2019-04-09 10:05:09.000',0,2),(26,1,'',1,'close',2,'2019-04-09 11:59:43.000','2019-04-09 12:05:27.000',NULL,'2019-04-10 11:15:02.000',0,2),(27,1,'',1,'close',2,'2019-04-10 11:20:10.000','2019-04-10 11:21:52.000',NULL,'2019-04-10 11:24:35.000',0,2),(28,1,'',1,'open',1,'2019-04-10 11:29:13.000','2019-04-10 11:29:48.000',NULL,NULL,1,1),(29,1,'',1,'close',1,'2019-04-10 11:30:30.000','2019-04-10 11:32:14.000',NULL,'2019-04-10 11:37:28.000',0,2),(30,1,'',1,'close',1,'2019-04-10 11:30:46.000','2019-04-10 11:35:33.000',NULL,'2019-04-10 13:17:14.000',0,2),(31,1,'',2,'close',2,'2019-04-10 13:27:26.000','2019-04-10 14:40:14.000',NULL,'2019-04-10 14:45:29.000',0,2),(32,1,'',1,'close',2,'2019-04-10 14:46:00.000','2019-04-10 14:50:41.000',NULL,'2019-04-10 15:11:38.000',0,2),(33,1,'',1,'close',2,'2019-04-10 15:11:53.000','2019-04-10 15:15:40.000',NULL,'2019-04-10 15:31:41.000',0,4),(34,1,'e\n',1,'close',2,'2019-04-10 15:12:17.000','2019-04-10 15:30:55.000',NULL,'2019-04-10 15:31:39.000',0,4),(35,1,'',1,'close',4,'2019-04-10 15:37:28.000','2019-04-10 15:40:43.000',NULL,'2019-04-10 15:42:39.000',0,4),(36,1,'',1,'close',4,'2019-04-10 15:43:29.000','2019-04-10 15:44:07.000',NULL,'2019-04-10 15:44:45.000',0,4),(37,1,'',1,'close',4,'2019-04-10 15:44:43.000','2019-04-10 15:47:27.000',NULL,'2019-04-10 15:48:24.000',0,4),(38,1,'',1,'close',4,'2019-04-10 15:48:48.000','2019-04-10 15:49:33.000',NULL,'2019-04-10 15:50:24.000',0,4),(39,1,'',1,'open',4,'2019-04-10 15:51:35.000','2019-04-10 15:55:30.000',NULL,NULL,1,4),(40,1,'',1,'close',4,'2019-04-10 15:51:51.000','2019-04-10 15:52:36.000',NULL,'2019-04-10 16:24:15.000',0,2),(41,1,'',1,'close',2,'2019-04-10 16:24:46.000','2019-04-10 16:26:32.000',NULL,'2019-04-10 16:41:34.000',0,2),(42,1,'',1,'close',2,'2019-04-10 16:25:14.000','2019-04-10 16:28:48.000',NULL,'2019-04-10 16:41:36.000',0,2),(43,1,'',1,'close',2,'2019-04-10 16:42:54.000','2019-04-10 16:44:42.000',NULL,'2019-04-10 16:46:00.000',0,2),(44,1,'j\n',1,'close',2,'2019-04-10 16:43:17.000','2019-04-10 16:47:56.000',NULL,'2019-04-10 16:53:59.000',0,2),(45,1,'',1,'close',2,'2019-04-10 16:54:15.000','2019-04-10 16:57:04.000',NULL,'2019-04-10 16:57:52.000',0,2),(46,1,'',1,'close',2,'2019-04-10 16:58:12.000','2019-04-10 17:00:57.000',NULL,'2019-04-10 17:02:28.000',0,2),(47,1,'',1,'close',2,'2019-04-10 17:02:54.000','2019-04-10 17:04:31.000',NULL,'2019-04-10 17:05:37.000',0,4),(48,1,'',1,'close',4,'2019-04-10 17:05:53.000','2019-04-10 17:06:40.000',NULL,'2019-04-10 17:08:09.000',0,4),(49,1,'',1,'close',4,'2019-04-10 17:08:24.000','2019-04-10 17:09:11.000',NULL,'2019-04-10 17:55:49.000',0,2),(50,1,'',1,'close',2,'2019-04-10 18:03:05.000','2019-04-11 09:30:51.000',NULL,'2019-04-11 14:13:00.000',0,2),(51,1,'',1,'close',2,'2019-04-10 17:56:45.000','2019-04-11 09:59:21.000',NULL,'2019-04-11 14:13:03.000',0,2),(52,1,'',1,'close',2,'2019-04-10 17:57:03.000','2019-04-11 09:45:49.000',NULL,'2019-04-11 14:13:05.000',0,2),(53,1,'',1,'close',2,'2019-04-10 17:57:27.000','2019-04-11 10:15:14.000',NULL,'2019-04-11 14:13:06.000',0,2),(54,1,'',1,'close',2,'2019-04-10 17:57:49.000','2019-04-11 10:30:31.000',NULL,'2019-04-11 14:13:08.000',0,2),(55,1,'',1,'close',2,'2019-04-10 17:58:10.000','2019-04-11 10:45:58.000',NULL,'2019-04-11 14:13:10.000',0,2),(56,1,'',1,'close',2,'2019-04-10 17:58:23.000','2019-04-11 11:00:11.000',NULL,'2019-04-11 14:13:12.000',0,2),(57,1,'',1,'close',2,'2019-04-10 17:58:44.000','2019-04-11 11:15:28.000',NULL,'2019-04-11 14:13:15.000',0,2),(58,1,'',1,'close',2,'2019-04-10 17:59:24.000','2019-04-11 11:30:13.000',NULL,'2019-04-11 14:13:18.000',0,2),(59,1,'',1,'close',2,'2019-04-10 17:59:41.000','2019-04-11 11:45:26.000',NULL,'2019-04-11 14:13:20.000',0,2),(60,1,'',1,'close',2,'2019-04-10 18:00:13.000','2019-04-11 12:00:48.000',NULL,'2019-04-11 14:13:22.000',0,2),(61,1,'',2,'close',2,'2019-04-10 18:00:40.000','2019-04-11 12:15:19.000',NULL,'2019-04-11 14:13:26.000',0,2),(62,1,'',2,'open',2,'2019-04-10 18:03:04.000','2019-04-11 12:15:19.000',NULL,NULL,1,2),(63,1,'',1,'open',2,'2019-04-11 14:18:17.000','2019-04-12 12:30:18.000',NULL,NULL,1,2),(64,1,'',1,'open',2,'2019-04-11 14:18:20.000','2019-04-12 12:45:25.000',NULL,NULL,1,2),(65,1,'',1,'close',2,'2019-04-10 18:07:04.000','2019-04-11 13:00:50.000',NULL,'2019-04-11 14:13:47.000',0,2),(66,1,'',1,'close',2,'2019-04-10 18:07:49.000','2019-04-11 13:15:39.000',NULL,'2019-04-11 14:13:50.000',0,2),(67,1,'',1,'close',2,'2019-04-10 18:08:06.000','2019-04-11 13:45:57.000',NULL,'2019-04-11 14:13:53.000',0,2),(68,1,'',1,'close',2,'2019-04-11 14:19:14.000','2019-04-11 14:21:55.000',NULL,'2019-04-11 14:23:10.000',0,2),(69,1,'',1,'open',2,'2019-04-11 14:36:41.000','2019-04-11 14:35:42.000',NULL,NULL,1,2),(70,1,'',1,'close',1,'2019-04-11 14:52:04.000','1970-01-03 11:34:38.000',NULL,'2019-04-11 14:53:34.000',0,2),(71,1,'',1,'close',2,'2019-04-11 15:03:34.000','1970-01-03 11:45:56.000',NULL,'2019-04-11 15:04:15.000',0,2),(72,1,'',1,'close',2,'2019-04-11 15:11:11.000','1970-01-01 07:55:54.000',NULL,'2019-04-11 15:11:19.000',0,2),(73,1,'',1,'close',2,'2019-04-11 15:11:12.000','1970-01-01 07:55:54.000',NULL,'2019-04-11 15:12:03.000',0,2),(74,1,'',1,'close',2,'2019-04-11 15:11:30.000','1970-01-01 07:55:54.000',NULL,'2019-04-11 15:14:58.000',0,2),(75,1,'',1,'open',2,'2019-04-11 15:17:39.000','2019-04-11 15:17:12.000',NULL,NULL,1,2),(76,1,'',1,'open',2,'2019-04-11 15:21:50.000','2019-04-11 15:20:03.000',NULL,NULL,1,2),(77,1,'',1,'open',2,'2019-04-11 15:23:03.000','2019-04-11 15:22:50.000',NULL,NULL,1,2),(78,1,'',1,'close',2,'2019-04-11 15:23:16.000','2019-04-11 15:24:03.000',NULL,'2019-04-11 16:10:04.000',0,2),(79,1,'',1,'close',2,'2019-04-11 16:14:41.000','2019-04-11 16:17:21.000',NULL,'2019-04-11 16:28:29.000',0,2),(80,1,'',1,'close',2,'2019-04-11 16:32:33.000','2019-04-11 16:35:00.000',NULL,'2019-04-11 16:35:42.000',0,2),(81,1,'',1,'close',2,'2019-04-11 16:59:46.000','2019-04-11 17:01:00.000',NULL,'2019-04-11 17:02:52.000',0,2),(82,1,'first testing after database reform',1,'close',46,'2019-04-12 12:04:23.000','2019-04-12 12:15:00.000',NULL,'2019-04-12 12:16:35.000',0,46),(83,1,'',1,'close',46,'2019-04-12 12:29:47.000','2019-04-12 12:30:00.000',NULL,'2019-04-12 12:32:02.000',0,46),(84,1,'',1,'open',46,'2019-04-12 12:33:35.000','2019-04-12 12:33:00.000',NULL,NULL,1,46),(85,1,'',1,'open',46,'2019-04-12 12:35:52.000','2019-04-12 12:34:00.000',NULL,NULL,1,46),(86,1,'',1,'open',46,'2019-04-12 12:37:38.000','2019-04-12 12:37:00.000',NULL,NULL,1,46),(87,1,'',1,'open',46,'2019-04-12 12:39:42.000','2019-04-12 12:39:00.000',NULL,NULL,1,46),(88,1,'',1,'open',46,'2019-04-12 12:42:22.000','2019-04-12 12:42:00.000',NULL,NULL,1,46),(89,1,'',1,'open',46,'2019-04-12 12:44:34.000','2019-04-12 12:44:00.000',NULL,NULL,1,46),(90,1,'',1,'close',46,'2019-04-12 12:44:46.000','2019-04-12 12:45:00.000',NULL,'2019-04-12 14:48:52.000',0,46),(91,1,'',1,'close',46,'2019-04-15 12:28:18.000','2019-04-15 12:29:00.000',NULL,'2019-04-15 12:34:04.000',0,46),(92,1,'',3,'close',46,'2019-04-15 12:36:59.000','2019-04-15 12:36:59.000',NULL,'2019-04-15 12:38:03.000',0,46),(93,1,'',3,'close',46,'2019-04-15 12:41:06.000','2019-04-15 12:41:06.000',NULL,'2019-04-15 12:46:05.000',0,46),(94,1,'',1,'close',46,'2019-04-15 12:46:26.000','2019-04-15 12:47:00.000',NULL,'2019-04-16 09:29:41.000',0,46),(95,1,'',1,'close',46,'2019-04-16 09:32:41.000','2019-04-16 09:33:00.000',NULL,'2019-04-16 09:35:45.000',0,46),(96,1,'',1,'close',46,'2019-04-16 09:37:37.000','2019-04-16 09:39:00.000',NULL,'2019-04-16 09:40:17.000',0,46),(97,1,'',1,'close',46,'2019-04-16 09:41:52.000','2019-04-16 09:42:00.000',NULL,'2019-04-16 09:42:35.000',0,46),(98,1,'',3,'close',46,'2019-04-16 09:43:02.000','2019-04-16 09:43:01.000',NULL,'2019-04-16 09:43:18.000',0,46),(99,1,'',3,'close',46,'2019-04-16 09:45:13.000','2019-04-16 09:45:12.000',NULL,'2019-04-16 09:45:48.000',0,46),(100,1,'',3,'close',46,'2019-04-16 09:46:55.000','2019-04-16 09:46:55.000',NULL,'2019-04-16 09:47:11.000',0,46),(101,1,'',3,'close',46,'2019-04-16 09:50:24.000','2019-04-16 09:50:24.000',NULL,'2019-04-16 09:50:39.000',0,46),(102,1,'',3,'close',46,'2019-04-16 09:51:43.000','2019-04-16 09:51:42.000',NULL,'2019-04-16 09:52:51.000',0,46),(103,1,'',3,'close',46,'2019-04-16 09:56:31.000','2019-04-16 09:56:30.000',NULL,'2019-04-16 09:56:43.000',0,46),(104,1,'',3,'close',46,'2019-04-16 10:06:22.000','2019-04-16 10:06:21.000',NULL,'2019-04-16 10:06:34.000',0,46),(105,1,'',3,'close',46,'2019-04-16 10:07:36.000','2019-04-16 10:07:35.000',NULL,'2019-04-16 10:07:56.000',0,46),(106,1,'',2,'close',46,'2019-04-16 10:16:11.000','2019-04-16 10:17:00.000',NULL,'2019-04-16 10:18:38.000',0,46),(107,3,'',1,'close',48,'2019-04-16 10:36:29.000','2019-04-16 10:38:00.000',NULL,'2019-04-16 10:39:13.000',0,48),(108,3,'',3,'close',48,'2019-04-16 10:44:37.000','2019-04-16 10:44:37.000',NULL,'2019-04-16 10:46:08.000',0,48),(109,3,'',1,'close',48,'2019-04-16 10:53:42.000','2019-04-16 10:55:00.000',NULL,'2019-04-16 10:55:23.000',0,48),(110,3,'',2,'close',48,'2019-04-16 10:56:20.000','2019-04-16 11:00:00.000',NULL,'2019-04-16 11:00:10.000',0,48),(111,3,'',3,'close',48,'2019-04-16 11:00:47.000','2019-04-16 11:00:47.000',NULL,'2019-04-16 11:01:09.000',0,48),(112,3,'',3,'close',48,'2019-04-16 11:01:52.000','2019-04-16 11:01:51.000',NULL,'2019-04-16 11:02:10.000',0,48),(113,3,'',1,'open',48,'2019-04-16 11:05:26.000','2021-04-16 11:00:00.000',NULL,NULL,0,0),(114,3,'',1,'close',48,'2019-04-16 11:05:52.000','2019-04-16 11:07:00.000',NULL,'2019-04-16 11:07:52.000',0,48),(115,3,'',3,'close',48,'2019-04-16 11:10:20.000','2019-04-16 11:10:20.000',NULL,'2019-04-16 11:11:06.000',0,48),(116,3,'',1,'open',48,'2019-04-16 17:43:13.000','2019-04-16 17:45:00.000',NULL,NULL,0,0),(117,3,'',1,'open',48,'2019-04-16 17:43:13.000','2019-04-16 17:45:00.000',NULL,NULL,0,0),(118,4,'no attendance',1,'open',45,'2019-04-17 11:48:36.000','2025-04-16 17:45:00.000',NULL,NULL,1,45),(119,4,'',1,'open',45,'2019-04-17 11:51:44.000','2025-04-17 11:00:00.000',NULL,NULL,1,45),(120,4,'',2,'open',45,'2019-04-17 12:47:11.000','2019-04-17 11:53:00.000',NULL,NULL,1,45),(121,4,'',1,'open',45,'2019-04-17 12:47:54.000','2019-04-17 12:48:00.000',NULL,NULL,0,0);
/*!40000 ALTER TABLE `FireDrillSchedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FireDrillType`
--

DROP TABLE IF EXISTS `FireDrillType`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `FireDrillType` (
  `fireDrillTypeId` int(11) NOT NULL AUTO_INCREMENT,
  `fireDrillTypeName` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`fireDrillTypeId`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FireDrillType`
--

LOCK TABLES `FireDrillType` WRITE;
/*!40000 ALTER TABLE `FireDrillType` DISABLE KEYS */;
INSERT INTO `FireDrillType` VALUES (1,'fire drill',0),(2,'dry run',0),(3,'real fire',0);
/*!40000 ALTER TABLE `FireDrillType` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `HazardReport`
--

DROP TABLE IF EXISTS `HazardReport`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `HazardReport` (
  `hazardReportId` int(11) NOT NULL AUTO_INCREMENT,
  `hazardReportName` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `buildingId` int(11) NOT NULL,
  `reporterId` int(11) NOT NULL,
  `status` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dateTime` datetime(3) NOT NULL,
  `lastUpdate` datetime(3) NOT NULL,
  `closeReporterId` int(11) DEFAULT NULL,
  `closeComment` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `editedBy` int(11) NOT NULL,
  PRIMARY KEY (`hazardReportId`),
  KEY `reporterId` (`reporterId`),
  KEY `buildingId` (`buildingId`),
  KEY `closeReporterId` (`closeReporterId`),
  CONSTRAINT `HazardReport_ibfk_1` FOREIGN KEY (`reporterId`) REFERENCES `User` (`userId`),
  CONSTRAINT `HazardReport_ibfk_2` FOREIGN KEY (`closeReporterId`) REFERENCES `User` (`userId`),
  CONSTRAINT `HazardReport_ibfk_3` FOREIGN KEY (`buildingId`) REFERENCES `Building` (`buildingId`),
  CONSTRAINT `HazardReport_ibfk_4` FOREIGN KEY (`editedBy`) REFERENCES `User` (`userId`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `HazardReport`
--

LOCK TABLES `HazardReport` WRITE;
/*!40000 ALTER TABLE `HazardReport` DISABLE KEYS */;
INSERT INTO `HazardReport` VALUES (18,'Testing',1,1,'close','2019-04-15 18:56:43.000','2019-04-15 18:56:50.000',1,'End',0,0),(19,'Testing002',1,1,'close','2019-04-16 11:39:35.000','2019-04-16 11:39:52.000',1,'testing',0,0),(20,'Testing002',1,46,'close','2019-04-16 13:26:57.000','2019-04-16 13:28:27.000',46,'Testing',0,0),(21,'Testing003',1,46,'open','2019-04-16 13:27:26.000','2019-04-16 13:27:26.000',NULL,NULL,0,0),(22,'Testing004',1,1,'close','2019-04-17 10:13:28.000','2019-04-17 10:17:47.000',7,'Remarks',0,0);
/*!40000 ALTER TABLE `HazardReport` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `HazardReportAnswer`
--

DROP TABLE IF EXISTS `HazardReportAnswer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `HazardReportAnswer` (
  `hazardReportAnswerId` int(11) NOT NULL AUTO_INCREMENT,
  `answerText` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`hazardReportAnswerId`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `HazardReportAnswer`
--

LOCK TABLES `HazardReportAnswer` WRITE;
/*!40000 ALTER TABLE `HazardReportAnswer` DISABLE KEYS */;
INSERT INTO `HazardReportAnswer` VALUES (1,'Yes',0),(2,'No',0),(3,'NA',0);
/*!40000 ALTER TABLE `HazardReportAnswer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `HazardReportClose`
--

DROP TABLE IF EXISTS `HazardReportClose`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `HazardReportClose` (
  `hazardReportCloseId` int(11) NOT NULL AUTO_INCREMENT,
  `hazardReportId` int(11) NOT NULL,
  `documentName` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `documentKey` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`hazardReportCloseId`),
  KEY `hazardReportId` (`hazardReportId`),
  CONSTRAINT `HazardReportClose_ibfk_1` FOREIGN KEY (`hazardReportId`) REFERENCES `HazardReport` (`hazardReportId`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `HazardReportClose`
--

LOCK TABLES `HazardReportClose` WRITE;
/*!40000 ALTER TABLE `HazardReportClose` DISABLE KEYS */;
INSERT INTO `HazardReportClose` VALUES (1,15,'HazardClose_1_1555322694790.jpeg','building_0/hazardreportclose/HazardClose_1_1555322694790.jpeg'),(2,16,'IMG_20190208_140352_447.jpg','building_0/hazardreportclose/HazardClose_1_1555324244587.jpeg'),(3,18,'HazardClose_1_1555325818698.jpeg','building_1/hazardreportclose/HazardClose_1_1555325818698.jpeg'),(4,19,'HazardClose_1_1555386008846.jpeg','building_1/hazardreportclose/HazardClose_1_1555386008846.jpeg'),(5,20,'IMG_20190220_205148_020.jpg','building_1/hazardreportclose/HazardClose_46_1555392525498.jpeg'),(6,22,'HazardClose_7_1555467496673.jpeg','building_1/hazardreportclose/HazardClose_7_1555467496673.jpeg');
/*!40000 ALTER TABLE `HazardReportClose` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `HazardReportQuestion`
--

DROP TABLE IF EXISTS `HazardReportQuestion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `HazardReportQuestion` (
  `hazardReportQuestionId` int(11) NOT NULL AUTO_INCREMENT,
  `questionText` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sectionId` int(11) NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`hazardReportQuestionId`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `HazardReportQuestion`
--

LOCK TABLES `HazardReportQuestion` WRITE;
/*!40000 ALTER TABLE `HazardReportQuestion` DISABLE KEYS */;
INSERT INTO `HazardReportQuestion` VALUES (1,'Are all EXIT signs illuminated?',1,0),(2,'Are all the doors self-closing and kept closed at all times?',1,0),(3,'Are all escape routes free from obstructions?',1,0),(4,'Are glass panels in doors obvious and intact?',1,0),(5,'Are escape routes suitable for the people who have to used them (i.e. disabled people)?',1,0),(6,'Is the fire alarm system in operations?',2,0),(7,'Are the manual fire alarm call points unobstructed and clearly visible?',2,0),(8,'Are there portable fire extinguishers (PFE)/hose reels available?',3,0),(9,'Are all extinguisher/hose reels regularly maintained with unexpired test date?',3,0),(10,'Are all extinguisher /hose reels visible and easily accessible?',3,0),(11,'Are extinguisher /hose reels wall mounted?',3,0),(12,'Are the sprinkler head covers intact?',3,0),(13,'Are there 500mm void spaces directly below any sprinkler heads?',3,0),(14,'Fire load in any rooms kept to the minimum by housekeeping efforts?',3,0),(15,'Alcohol based hand-rub kept at minimum quantities and prevented from pilfering? If potential drip onto floor, is there a drip-tray?',3,0),(16,'Are all extension leads of the correct length and fully unwound when in use?',4,0),(17,'Is the area in front of or next to or directly below the electrical panel(s) free from combustible materials?',4,0);
/*!40000 ALTER TABLE `HazardReportQuestion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `HazardReportQuestionData`
--

DROP TABLE IF EXISTS `HazardReportQuestionData`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `HazardReportQuestionData` (
  `hazardQuestionDataId` int(11) NOT NULL AUTO_INCREMENT,
  `questionId` int(11) NOT NULL,
  `answerId` int(11) NOT NULL,
  `observationText` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hazardSectionId` int(11) NOT NULL,
  PRIMARY KEY (`hazardQuestionDataId`),
  KEY `questionId` (`questionId`),
  KEY `answerId` (`answerId`),
  KEY `hazardSectionId` (`hazardSectionId`),
  CONSTRAINT `HazardReportQuestionData_ibfk_1` FOREIGN KEY (`questionId`) REFERENCES `HazardReportQuestion` (`hazardReportQuestionId`),
  CONSTRAINT `HazardReportQuestionData_ibfk_2` FOREIGN KEY (`answerId`) REFERENCES `HazardReportAnswer` (`hazardReportAnswerId`),
  CONSTRAINT `HazardReportQuestionData_ibfk_3` FOREIGN KEY (`hazardSectionId`) REFERENCES `HazardReportSectionData` (`hazardSectionDataId`)
) ENGINE=InnoDB AUTO_INCREMENT=124 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `HazardReportQuestionData`
--

LOCK TABLES `HazardReportQuestionData` WRITE;
/*!40000 ALTER TABLE `HazardReportQuestionData` DISABLE KEYS */;
INSERT INTO `HazardReportQuestionData` VALUES (57,1,1,NULL,54),(58,2,2,NULL,54),(59,3,3,NULL,54),(60,4,1,NULL,54),(61,6,3,NULL,55),(62,8,1,NULL,56),(63,9,2,NULL,56),(64,16,2,NULL,57),(65,1,2,NULL,58),(66,2,2,NULL,58),(67,3,1,NULL,58),(68,4,3,NULL,58),(69,5,2,NULL,58),(70,6,2,NULL,59),(71,8,2,'test',60),(72,10,3,NULL,60),(73,15,1,NULL,60),(74,1,1,'Testing',62),(75,2,2,NULL,62),(76,3,3,NULL,62),(77,4,1,NULL,62),(78,5,2,NULL,62),(79,6,3,NULL,63),(80,7,1,NULL,63),(81,8,2,NULL,64),(82,9,2,NULL,64),(83,10,1,NULL,64),(84,11,3,NULL,64),(85,13,2,NULL,64),(86,14,1,NULL,64),(87,15,3,NULL,64),(88,16,3,NULL,65),(89,17,1,NULL,65),(90,1,1,NULL,66),(91,2,2,NULL,66),(92,3,3,NULL,66),(93,4,1,NULL,66),(94,5,1,NULL,66),(95,6,3,NULL,67),(96,7,1,NULL,67),(97,8,2,NULL,68),(98,9,2,NULL,68),(99,10,3,NULL,68),(100,11,2,NULL,68),(101,12,2,NULL,68),(102,13,2,NULL,68),(103,14,3,NULL,68),(104,15,1,NULL,68),(105,16,2,NULL,69),(106,17,3,NULL,69),(107,1,1,NULL,70),(108,2,3,NULL,70),(109,3,1,NULL,70),(110,4,3,NULL,70),(111,5,1,NULL,70),(112,6,2,NULL,71),(113,7,3,NULL,71),(114,8,2,NULL,72),(115,9,1,NULL,72),(116,10,2,NULL,72),(117,11,3,NULL,72),(118,12,3,NULL,72),(119,13,3,NULL,72),(120,14,3,NULL,72),(121,15,2,NULL,72),(122,16,1,NULL,73),(123,17,2,NULL,73);
/*!40000 ALTER TABLE `HazardReportQuestionData` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `HazardReportSection`
--

DROP TABLE IF EXISTS `HazardReportSection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `HazardReportSection` (
  `sectionId` int(11) NOT NULL AUTO_INCREMENT,
  `sectionName` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`sectionId`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `HazardReportSection`
--

LOCK TABLES `HazardReportSection` WRITE;
/*!40000 ALTER TABLE `HazardReportSection` DISABLE KEYS */;
INSERT INTO `HazardReportSection` VALUES (1,'Fire Escape Routes',0),(2,'Fire Alarm Systems',0),(3,'Firefighting Equipment and prevention',0),(4,'Electrical Equipment',0);
/*!40000 ALTER TABLE `HazardReportSection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `HazardReportSectionData`
--

DROP TABLE IF EXISTS `HazardReportSectionData`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `HazardReportSectionData` (
  `hazardSectionDataId` int(11) NOT NULL AUTO_INCREMENT,
  `sectionId` int(11) NOT NULL,
  `hazardReportId` int(11) NOT NULL,
  PRIMARY KEY (`hazardSectionDataId`),
  KEY `sectionId` (`sectionId`),
  KEY `hazardReportId` (`hazardReportId`),
  CONSTRAINT `HazardReportSectionData_ibfk_1` FOREIGN KEY (`sectionId`) REFERENCES `HazardReportSection` (`sectionId`),
  CONSTRAINT `HazardReportSectionData_ibfk_2` FOREIGN KEY (`hazardReportId`) REFERENCES `HazardReport` (`hazardReportId`)
) ENGINE=InnoDB AUTO_INCREMENT=74 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `HazardReportSectionData`
--

LOCK TABLES `HazardReportSectionData` WRITE;
/*!40000 ALTER TABLE `HazardReportSectionData` DISABLE KEYS */;
INSERT INTO `HazardReportSectionData` VALUES (54,1,18),(55,2,18),(56,3,18),(57,4,18),(58,1,19),(59,2,19),(60,3,19),(61,4,19),(62,1,20),(63,2,20),(64,3,20),(65,4,20),(66,1,21),(67,2,21),(68,3,21),(69,4,21),(70,1,22),(71,2,22),(72,3,22),(73,4,22);
/*!40000 ALTER TABLE `HazardReportSectionData` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `HazardReportSectionImage`
--

DROP TABLE IF EXISTS `HazardReportSectionImage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `HazardReportSectionImage` (
  `hazardSectionImageId` int(11) NOT NULL AUTO_INCREMENT,
  `hazardSectionDataId` int(11) NOT NULL,
  `documentName` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `documentKey` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`hazardSectionImageId`),
  KEY `hazardSectionDataId` (`hazardSectionDataId`),
  CONSTRAINT `HazardReportSectionImage_ibfk_1` FOREIGN KEY (`hazardSectionDataId`) REFERENCES `HazardReportSectionData` (`hazardSectionDataId`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `HazardReportSectionImage`
--

LOCK TABLES `HazardReportSectionImage` WRITE;
/*!40000 ALTER TABLE `HazardReportSectionImage` DISABLE KEYS */;
INSERT INTO `HazardReportSectionImage` VALUES (10,54,'NewHazardReport_1_1555325763578.jpeg','building_1/hazardreport/NewHazardReport_1_1555325763578.jpeg'),(11,54,'IMG_20190220_205148_020.jpg','building_1/hazardreport/NewHazardReport_1_1555325770245.jpeg'),(12,56,'IMG_20190220_205148_020.jpg','building_1/hazardreport/NewHazardReport_1_1555325784744.jpeg'),(13,58,'NewHazardReport_1_1555385939402.jpeg','building_1/hazardreport/NewHazardReport_1_1555385939402.jpeg'),(14,61,'Blueberry-Pie-3-600x900.jpg','building_1/hazardreport/NewHazardReport_1_1555385958809.jpeg'),(15,62,'IMG_20190220_205148_020.jpg','building_1/hazardreport/NewHazardReport_46_1555392396304.jpeg'),(16,70,'NewHazardReport_1_1555467155660.jpeg','building_1/hazardreport/NewHazardReport_1_1555467155660.jpeg'),(17,73,'NewHazardReport_1_1555467182860.jpeg','building_1/hazardreport/NewHazardReport_1_1555467182860.jpeg');
/*!40000 ALTER TABLE `HazardReportSectionImage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Maintenance`
--

DROP TABLE IF EXISTS `Maintenance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Maintenance` (
  `maintenanceId` int(11) NOT NULL AUTO_INCREMENT,
  `deleted` tinyint(4) DEFAULT '0',
  `end` datetime DEFAULT NULL,
  `realEnd` datetime DEFAULT NULL,
  `start` datetime DEFAULT NULL,
  PRIMARY KEY (`maintenanceId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Maintenance`
--

LOCK TABLES `Maintenance` WRITE;
/*!40000 ALTER TABLE `Maintenance` DISABLE KEYS */;
/*!40000 ALTER TABLE `Maintenance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Message`
--

DROP TABLE IF EXISTS `Message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Message` (
  `messageId` int(11) NOT NULL AUTO_INCREMENT,
  `messageTypeId` int(11) NOT NULL,
  `dateTime` datetime(3) NOT NULL,
  `messageTitle` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `messageDetails` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `buildingId` int(11) NOT NULL,
  PRIMARY KEY (`messageId`),
  KEY `messageTypeId` (`messageTypeId`),
  KEY `buildingId` (`buildingId`),
  CONSTRAINT `Message_ibfk_1` FOREIGN KEY (`messageTypeId`) REFERENCES `MessageType` (`messageTypeId`),
  CONSTRAINT `Message_ibfk_2` FOREIGN KEY (`buildingId`) REFERENCES `Building` (`buildingId`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Message`
--

LOCK TABLES `Message` WRITE;
/*!40000 ALTER TABLE `Message` DISABLE KEYS */;
INSERT INTO `Message` VALUES (5,4,'2019-04-17 16:02:02.000','Escalation','You have been activated for escalation. Report to location below',1),(6,4,'2019-04-17 16:02:03.000','Escalation','You have been activated for escalation. Report to location below',1),(7,4,'2019-04-17 16:02:03.000','Escalation','You have been activated for escalation. Report to location below',1),(8,4,'2019-04-17 16:02:03.000','Escalation','You have been activated for escalation. Report to location below',1),(9,4,'2019-04-17 16:12:56.000','Escalation','You have been activated for escalation. Report to location below',1),(10,4,'2019-04-17 16:12:56.000','Escalation','You have been activated for escalation. Report to location below',1),(11,4,'2019-04-17 16:12:56.000','Escalation','You have been activated for escalation. Report to location below',1),(12,4,'2019-04-17 16:12:56.000','Escalation','You have been activated for escalation. Report to location below',1),(13,4,'2019-04-17 16:54:25.000','Escalation','You have been activated for escalation. Report to location below',1),(14,4,'2019-04-17 16:54:25.000','Escalation','You have been activated for escalation. Report to location below',1),(15,4,'2019-04-17 16:54:26.000','Escalation','You have been activated for escalation. Report to location below',1),(16,4,'2019-04-17 16:54:26.000','Escalation','You have been activated for escalation. Report to location below',1),(17,4,'2019-04-17 17:08:18.000','Escalation','You have been activated for escalation. Report to location below',1),(18,4,'2019-04-17 17:08:19.000','Escalation','You have been activated for escalation. Report to location below',1),(19,4,'2019-04-17 17:10:27.000','Escalation','You have been activated for escalation. Report to location below',1),(20,4,'2019-04-17 17:10:27.000','Escalation','You have been activated for escalation. Report to location below',1),(21,4,'2019-04-17 17:11:08.000','Escalation','You have been activated for escalation. Report to location below',1),(22,4,'2019-04-17 17:11:09.000','Escalation','You have been activated for escalation. Report to location below',1),(23,4,'2019-04-17 17:16:28.000','Escalation','You have been activated for escalation. Report to location below',1),(24,4,'2019-04-17 17:16:29.000','Escalation','You have been activated for escalation. Report to location below',1),(25,4,'2019-04-17 17:16:29.000','Escalation','You have been activated for escalation. Report to location below',1),(26,4,'2019-04-17 17:17:15.000','Escalation','You have been activated for escalation. Report to location below',1),(27,4,'2019-04-17 17:17:15.000','Escalation','You have been activated for escalation. Report to location below',1),(28,4,'2019-04-17 17:17:15.000','Escalation','You have been activated for escalation. Report to location below',1),(29,4,'2019-04-17 17:30:28.000','Escalation','You have been activated for escalation. Report to location below',1),(30,4,'2019-04-17 17:30:28.000','Escalation','You have been activated for escalation. Report to location below',1),(31,4,'2019-04-17 17:30:28.000','Escalation','You have been activated for escalation. Report to location below',1),(32,4,'2019-04-17 17:31:21.000','Escalation','You have been activated for escalation. Report to location below',1),(33,4,'2019-04-17 17:31:21.000','Escalation','You have been activated for escalation. Report to location below',1),(34,4,'2019-04-17 17:31:22.000','Escalation','You have been activated for escalation. Report to location below',1),(35,4,'2019-04-17 17:31:45.000','Escalation','You have been activated for escalation. Report to location below',1),(36,4,'2019-04-17 17:31:46.000','Escalation','You have been activated for escalation. Report to location below',1),(37,4,'2019-04-17 17:31:46.000','Escalation','You have been activated for escalation. Report to location below',1),(38,4,'2019-04-17 17:31:57.000','Escalation','You have been activated for escalation. Report to location below',1),(39,4,'2019-04-17 17:31:57.000','Escalation','You have been activated for escalation. Report to location below',1),(40,4,'2019-04-17 17:31:57.000','Escalation','You have been activated for escalation. Report to location below',1),(41,4,'2019-04-17 17:35:04.000','Escalation','You have been activated for escalation. Report to location below',1),(42,4,'2019-04-17 17:35:05.000','Escalation','You have been activated for escalation. Report to location below',1),(43,4,'2019-04-17 17:35:05.000','Escalation','You have been activated for escalation. Report to location below',1),(44,4,'2019-04-17 17:38:53.000','Escalation','You have been activated for escalation. Report to location below',3),(45,4,'2019-04-17 17:38:53.000','Escalation','You have been activated for escalation. Report to location below',3),(46,4,'2019-04-17 17:38:54.000','Escalation','You have been activated for escalation. Report to location below',3);
/*!40000 ALTER TABLE `Message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MessageType`
--

DROP TABLE IF EXISTS `MessageType`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MessageType` (
  `messageTypeId` int(11) NOT NULL AUTO_INCREMENT,
  `messageType` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`messageTypeId`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MessageType`
--

LOCK TABLES `MessageType` WRITE;
/*!40000 ALTER TABLE `MessageType` DISABLE KEYS */;
INSERT INTO `MessageType` VALUES (1,'Fire Drill Schedule',0),(2,'Fire Drill Dry Run',0),(3,'Fire Activation',0),(4,'Escalation',0),(5,'Hazard Report',0);
/*!40000 ALTER TABLE `MessageType` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Notification`
--

DROP TABLE IF EXISTS `Notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Notification` (
  `notificationId` int(11) NOT NULL AUTO_INCREMENT,
  `messageId` int(11) DEFAULT NULL,
  `reciever` int(11) DEFAULT NULL,
  `status` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`notificationId`),
  KEY `messageId` (`messageId`),
  KEY `reciever` (`reciever`),
  CONSTRAINT `Notification_ibfk_1` FOREIGN KEY (`messageId`) REFERENCES `Message` (`messageId`),
  CONSTRAINT `Notification_ibfk_2` FOREIGN KEY (`reciever`) REFERENCES `User` (`userId`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Notification`
--

LOCK TABLES `Notification` WRITE;
/*!40000 ALTER TABLE `Notification` DISABLE KEYS */;
INSERT INTO `Notification` VALUES (1,5,41,1),(2,6,48,0),(3,7,47,0),(4,8,46,1),(5,9,41,1),(6,10,48,0),(7,11,47,0),(8,12,46,1),(9,13,41,1),(10,14,48,0),(11,15,47,0),(12,16,46,1),(13,17,48,0),(14,18,47,0),(15,19,48,0),(16,20,47,0),(17,21,48,0),(18,22,47,0),(19,23,43,1),(20,24,48,0),(21,25,47,0),(22,26,43,1),(23,27,48,0),(24,28,47,0),(25,29,43,1),(26,30,48,0),(27,31,47,0),(28,32,43,1),(29,33,48,0),(30,34,47,0),(31,35,43,1),(32,36,48,0),(33,37,47,0),(34,38,43,1),(35,39,48,0),(36,40,47,0),(37,41,43,1),(38,42,48,0),(39,43,47,0),(40,44,41,1),(41,45,47,0),(42,46,46,0);
/*!40000 ALTER TABLE `Notification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Role`
--

DROP TABLE IF EXISTS `Role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Role` (
  `roleId` int(11) NOT NULL AUTO_INCREMENT,
  `roleName` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `editHazardReportGroup` tinyint(4) NOT NULL DEFAULT '0',
  `hazardReportGroup` tinyint(4) NOT NULL DEFAULT '0',
  `authorityToEscalateGroup` tinyint(4) NOT NULL DEFAULT '0',
  `escalationGroup` tinyint(4) NOT NULL DEFAULT '0',
  `fireDrillGroup` tinyint(4) NOT NULL DEFAULT '0',
  `documentManagementGroup` tinyint(4) NOT NULL DEFAULT '0',
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`roleId`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Role`
--

LOCK TABLES `Role` WRITE;
/*!40000 ALTER TABLE `Role` DISABLE KEYS */;
INSERT INTO `Role` VALUES (1,'Fire Safety Manager',1,1,1,0,0,1,0),(2,'Fire Warden',0,0,0,0,0,0,0),(3,'Member of EMT',1,1,0,1,1,0,0),(4,'Building Manager',0,1,0,1,1,0,0);
/*!40000 ALTER TABLE `Role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Tenant`
--

DROP TABLE IF EXISTS `Tenant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Tenant` (
  `tenantId` int(11) NOT NULL AUTO_INCREMENT,
  `tenantName` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `buildingId` int(11) DEFAULT NULL,
  `editedBy` int(11) DEFAULT NULL,
  `dateTime` datetime(3) DEFAULT NULL,
  `deleted` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`tenantId`),
  KEY `buildingId` (`buildingId`),
  KEY `editedBy` (`editedBy`),
  CONSTRAINT `Tenant_ibfk_1` FOREIGN KEY (`buildingId`) REFERENCES `Building` (`buildingId`),
  CONSTRAINT `Tenant_ibfk_2` FOREIGN KEY (`editedBy`) REFERENCES `User` (`userId`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Tenant`
--

LOCK TABLES `Tenant` WRITE;
/*!40000 ALTER TABLE `Tenant` DISABLE KEYS */;
INSERT INTO `Tenant` VALUES (1,'Low Tide Industries',1,2,'2019-03-27 14:34:15.000',0),(2,'Beedle Entertainment',1,2,'2019-03-27 15:34:15.000',1),(3,'Twilight Corp',1,1,'2019-04-08 11:13:15.000',0),(4,'Spideradio',1,1,'2019-04-08 12:34:15.000',0),(5,'Aurarts',1,3,'2019-04-08 12:34:15.000',0),(6,'Moondustries',2,3,'2019-04-08 12:34:15.000',0),(7,'Starlightning',2,2,'2019-04-08 12:34:15.000',0),(8,'Heroaid',2,2,'2019-04-08 12:34:15.000',0),(9,'Ridgeshack',2,2,'2019-04-08 12:34:15.000',0),(10,'Freakbeat',2,2,'2019-04-08 12:34:15.000',0),(11,'Deluge Softwares',3,2,'2019-04-08 12:34:15.000',0),(12,'Willow Electronics',3,2,'2019-04-08 12:34:15.000',1),(13,'Griffin Solutions',3,3,'2019-04-08 12:34:15.000',0),(14,'Alphacom',3,3,'2019-04-08 12:34:15.000',0),(15,'Bluetronics',3,2,'2019-04-08 12:34:15.000',0),(16,'Delugation',4,3,'2019-04-08 12:34:15.000',0),(17,'Titaniumotors',4,1,'2019-04-08 12:34:15.000',0),(18,'Driftstar',4,1,'2019-04-08 12:34:15.000',0),(19,'Joycoms',4,3,'2019-04-08 12:34:15.000',0),(20,'Roottechs',4,1,'2019-04-08 12:34:15.000',0);
/*!40000 ALTER TABLE `Tenant` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TenantEmployee`
--

DROP TABLE IF EXISTS `TenantEmployee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TenantEmployee` (
  `tenantEmployeeId` int(11) NOT NULL AUTO_INCREMENT,
  `tenantEmployeeName` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tenantId` int(11) DEFAULT NULL,
  `title` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `editedBy` int(11) DEFAULT NULL,
  `dateTime` datetime(3) DEFAULT NULL,
  `deleted` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`tenantEmployeeId`),
  KEY `editedBy` (`editedBy`),
  KEY `tenantId` (`tenantId`),
  CONSTRAINT `TenantEmployee_ibfk_1` FOREIGN KEY (`tenantId`) REFERENCES `Tenant` (`tenantId`),
  CONSTRAINT `TenantEmployee_ibfk_2` FOREIGN KEY (`editedBy`) REFERENCES `User` (`userId`)
) ENGINE=InnoDB AUTO_INCREMENT=201 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TenantEmployee`
--

LOCK TABLES `TenantEmployee` WRITE;
/*!40000 ALTER TABLE `TenantEmployee` DISABLE KEYS */;
INSERT INTO `TenantEmployee` VALUES (1,'Nicky Schneider',1,'TenantHead',1,'2019-03-27 15:37:12.000',0),(2,'Jessie Stevens',1,'TenantAssistant',1,'2019-03-27 15:37:12.000',1),(3,'Rome Milner',1,'TenantAssistant3',1,'2019-03-27 15:37:12.000',0),(4,'Nicola Cordova',1,'TenantAssistant4',1,'2019-03-27 15:37:12.000',0),(5,'Kylan Doyle',1,'TenantEmployeeStaff',1,'2019-03-27 15:37:12.000',0),(6,'Zuzanna Larson',1,'TenantEmployeeStaff',1,'2019-03-27 15:37:12.000',0),(7,'Kyan Mccoy',1,'TenantEmployeeStaff',1,'2019-03-27 15:37:12.000',0),(8,'Anil Walker',1,'TenantHead',1,'2019-03-27 15:37:12.000',0),(9,'Zidan Mathis',1,'TenantEmployeeStaff',1,'2019-03-27 15:37:12.000',0),(10,'Lilly-Grace Garza',2,'TenantEmployeeStaff',1,'2019-03-27 15:37:12.000',0),(11,'Axl Shelton',2,'TenantEmployeeStaff',1,'2019-03-27 15:37:12.000',1),(12,'Alisha Chung',2,'TenantEmployeeStaff',1,'2019-03-27 15:37:12.000',0),(13,'Ariyan Meadows',2,'TenantEmployeeStaff',1,'2019-03-27 15:37:12.000',0),(14,'Aalia Rodgers',2,'TenantEmployeeStaff',1,'2019-03-27 15:37:12.000',0),(15,'Brian Small',2,'TenantHead',1,'2019-03-27 15:37:12.000',0),(16,'Emilee Swift',2,'TenantEmployeeStaff',1,'2019-03-27 15:37:12.000',0),(17,'Jarrad Brooks',2,'TenantEmployeeStaff',1,'2019-03-27 15:37:12.000',0),(18,'Rumaysa Heaton',2,'TenantEmployeeStaff',1,'2019-03-27 15:37:12.000',0),(19,'Andreea Conner',2,'TenantEmployeeStaff',1,'2019-03-27 15:37:12.000',0),(20,'Aniela Simmons',3,'TenantEmployeeStaff',1,'2019-03-27 15:37:12.000',0),(21,'Miriam Huynh',3,'TenantEmployeeStaff',1,'2019-03-27 15:37:12.000',1),(22,'Devin Swan',3,'TenantEmployeeStaff',1,'2019-03-27 15:37:12.000',0),(23,'Holli Robbins',3,'TenantEmployeeStaff',1,'2019-03-27 15:37:12.000',0),(24,'Lillia Hancock',3,'TenantAssistant',1,'2019-03-27 15:37:12.000',0),(25,'Montague Lyon',3,'TenantEmployeeStaff',1,'2019-03-27 15:37:12.000',0),(26,'Ashlee Bonner',3,'TenantEmployeeStaff',1,'2019-03-27 15:37:12.000',0),(27,'Haydon Buchanan',3,'TenantHead',1,'2019-03-27 15:37:12.000',0),(28,'Stacey Lott',3,'TenantEmployeeStaff',1,'2019-03-27 15:37:12.000',0),(29,'Jason Philip',3,'TenantEmployeeStaff',1,'2019-03-27 15:37:12.000',0),(30,'Amba Gonzalez',4,'TenantEmployeeStaff',1,'2019-03-27 15:37:12.000',0),(31,'Hilda Hatfield',4,'TenantAssistant',1,'2019-03-27 15:37:12.000',1),(32,'Vikki Baird',4,'TenantEmployeeStaff',1,'2019-03-27 15:37:12.000',0),(33,'Wesley Patton',4,'TenantEmployeeStaff',1,'2019-03-27 15:37:12.000',0),(34,'Connagh Callahan',4,'TenantEmployeeStaff',1,'2019-03-27 15:37:12.000',0),(35,'Hussain Hassan',4,'TenantHead',1,'2019-03-27 15:37:12.000',0),(36,'Jeanne Valenzuela',4,'TenantEmployeeStaff',1,'2019-03-27 15:37:12.000',0),(37,'Keziah Christie',4,'TenantEmployeeStaff',1,'2019-03-27 15:37:12.000',0),(38,'Jemimah Waters',4,'TenantEmployeeStaff',1,'2019-03-27 15:37:12.000',0),(39,'Kush Tierney',4,'TenantEmployeeStaff',1,'2019-03-27 15:37:12.000',0),(40,'Veronika Calderon',5,'TenantEmployeeStaff',1,'2019-03-27 15:37:12.000',0),(41,'Kean Goff',5,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(42,'Johan Quinn',5,'TenantHead',2,'2019-03-27 15:37:12.000',1),(43,'Billy-Joe Harwood',5,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(44,'Stanislaw Brock',5,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(45,'Jared Joyner',5,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(46,'Zachariah Whitley',5,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(47,'Affan Mair',5,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(48,'Shahid Padilla',5,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(49,'Dawud Bowes',5,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(50,'Haroon Conway',6,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(51,'Adeeb Stanton',6,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',1),(52,'Zaine Clay',6,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(53,'Duncan Boone',6,'TenantHead',2,'2019-03-27 15:37:12.000',0),(54,'Evangeline Cameron',6,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(55,'Helen Legge',6,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(56,'Caolan Lloyd',6,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(57,'Jaye Doherty',6,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(58,'Arnie Emery',6,'TenantAssistant',2,'2019-03-27 15:37:12.000',0),(59,'Jaidan Villalobos',6,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(60,'Zephaniah Markham',7,'TenantHead',2,'2019-03-27 15:37:12.000',0),(61,'Eliza Hoover',7,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',1),(62,'Dwayne Hamer',7,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(63,'Jacque Lawrence',7,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(64,'Rochelle George',7,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(65,'Hanan Lozano',7,'TenantAssistant',2,'2019-03-27 15:37:12.000',0),(66,'Ellise Benitez',7,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(67,'Shanna Singh',7,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(68,'Bonita Mendoza',7,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(69,'Lexi-Mae Busby',7,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(70,'Fathima Felix',8,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(71,'Leandro Gillespie',8,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',1),(72,'Rivka Bauer',8,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(73,'Ammara Thomas',8,'TenantHead',2,'2019-03-27 15:37:12.000',0),(74,'Rosalind Robins',8,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(75,'Marley Amin',8,'TenantAssistant',2,'2019-03-27 15:37:12.000',0),(76,'Emmett Mcgregor',8,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(77,'Lola-Rose Redman',9,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',1),(78,'Isabelle Guzman',9,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(79,'Nyla Hale',9,'TenantHead',2,'2019-03-27 15:37:12.000',0),(80,'Jannah Kane',9,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(81,'Ava-Mai Mcdowell',9,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(82,'Savannah Price',9,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(83,'Pablo Holman',9,'TenantAssistant',2,'2019-03-27 15:37:12.000',0),(84,'Ashlyn Whitworth',9,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(85,'Faith Salt',9,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(86,'Lee Charlton',10,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(87,'Kia Navarro',10,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',1),(88,'Olli Frank',10,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(89,'Finnlay Dougherty',10,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(90,'Shanon Smith',10,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(91,'Giorgia Lawson',10,'TenantHead',2,'2019-03-27 15:37:12.000',0),(92,'Enzo Bean',10,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(93,'Inez Sloan',10,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(94,'Neil Chang',10,'TenantAssistant',2,'2019-03-27 15:37:12.000',0),(95,'Oscar Burn',10,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(96,'Reef Ramsey',11,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(97,'Amaya Bernal',11,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',1),(98,'Keanu Floyd',11,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(99,'Salman Brooks',11,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(100,'Bertie Frey',11,'TenantHead',2,'2019-03-27 15:37:12.000',0),(101,'Tre Gamble',11,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(102,'Raiden Wallace',11,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(103,'Priscilla Tillman',11,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(104,'Bibi Preston',11,'TenantAssistant',3,'2019-03-27 15:37:12.000',0),(105,'Wilbur Guzman',11,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(106,'Melanie Peters',12,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(107,'Chelsey Hutchinson',12,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',1),(108,'Adam Cairns',12,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(109,'Akbar Craft',12,'TenantAssistant',3,'2019-03-27 15:37:12.000',0),(110,'Lucy Bush',12,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(111,'Arabella Dodd',12,'TenantHead',3,'2019-03-27 15:37:12.000',0),(112,'Leona Horn',12,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(113,'Alfie Pennington',12,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(114,'Imaad Fowler',12,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(115,'Jo Aguirre',12,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(116,'Gabriela Brett',13,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(117,'Susan Herberta',13,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',1),(118,'Shazia Chan',13,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(119,'May Garner',13,'TenantAssistant',3,'2019-03-27 15:37:12.000',0),(120,'Alanah Gates',13,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(121,'Suhail Magana',13,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(122,'Estelle Howell',13,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(123,'Fay Rivera',13,'TenantHead',3,'2019-03-27 15:37:12.000',0),(124,'Daniela Mcneil',13,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(125,'Kalum Kent',13,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(126,'Luc Justice',14,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(127,'Beck Mercer',14,'TenantAssistant',3,'2019-03-27 15:37:12.000',1),(128,'Susanna Adkins',14,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(129,'Borys Ayala',14,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(130,'Mylee Sutherland',14,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(131,'Samiha Chen',14,'TenantHead',3,'2019-03-27 15:37:12.000',0),(132,'Kenan Calvert',14,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(133,'Blanka Hart',14,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(134,'Ann-Marie Stuart',14,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(135,'Rhiann Zhang',14,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(136,'Marianne Naylor',15,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(137,'Leoni Curran',15,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',1),(138,'Eliott Wilkinson',15,'TenantAssistant',3,'2019-03-27 15:37:12.000',0),(139,'Fred Wooten',15,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(140,'Abi Andrews',15,'TenantHead',3,'2019-03-27 15:37:12.000',0),(141,'Lowri Davey',15,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(142,'Rocco Woolley',15,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(143,'Sebastien Connelly',15,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(144,'Richie Ho',15,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(145,'Woodrow Baxter',15,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(146,'Katlyn Timms',16,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(147,'Sophie Hughes',16,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',1),(148,'Lubna Mckenzie',16,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(149,'Ava-May Bridges',16,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(150,'Vernon Fountain',16,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(151,'Samera Le',16,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(152,'Bobbi Powers',16,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(153,'Brayden Arnold',16,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(154,'Nancie Melia',16,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(155,'Ryan Hulme',16,'TenantHead',3,'2019-03-27 15:37:12.000',0),(156,'Mahi Fletcher',17,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(157,'Stuart Marsh',17,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',1),(158,'Marlie Simon',17,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(159,'Yvonne Guerrero',17,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(160,'Tehya Anthony',17,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(161,'Mikail Mohammed',17,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(162,'Nuha Melendez',17,'TenantHead',3,'2019-03-27 15:37:12.000',0),(163,'Yaseen Espinosa',17,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(164,'Shelbie Begum',17,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(165,'Silas Mosley',17,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(166,'Lyla John',18,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(167,'Jacob Wainwright',18,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',1),(168,'Vincenzo Nixon',18,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(169,'Blaine Wise',18,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(170,'Maisy Hoffman',18,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(171,'Aya Carson',18,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(172,'Jemima O\'Neill',18,'TenantHead',3,'2019-03-27 15:37:12.000',0),(173,'Hassan Prince',18,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(174,'Omer Alvarez',18,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(175,'Caitlan Hinton',18,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(176,'Natalie Hampton',19,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(177,'Arnold Osborn',19,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',1),(178,'Adela Barton',19,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(179,'Makenzie Ellis',19,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(180,'Selin Macfarlane',19,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(181,'Michael Ventura',19,'TenantHead',3,'2019-03-27 15:37:12.000',0),(182,'Neil Lim',19,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(183,'Om Clements',19,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(184,'Ayra Ellwood',19,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(185,'Niam Pearson',19,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(186,'Gertrude Dillon',20,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(187,'Hettie Chung',20,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',1),(188,'Lynn Greer',20,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(189,'Carter Pearce',20,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(190,'Shoaib Brookes',20,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(191,'Mathew Wilder',20,'TenantHead',3,'2019-03-27 15:37:12.000',0),(192,'Ingrid Fenton',20,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(193,'Kelvin Villanueva',20,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(194,'Jokubas Nielsen',20,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(195,'Cadence Walters',20,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(196,'Mahira Ellison',1,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(197,'Oluwatobiloba Hines',8,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(198,'Tiarna Rose',8,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(199,'Mitchell John',8,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(200,'Caroline Pitts',9,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0);
/*!40000 ALTER TABLE `TenantEmployee` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `User`
--

DROP TABLE IF EXISTS `User`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `User` (
  `userId` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `displayName` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pushNotificationToken` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `profileImage` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tenantEmployeeId` int(11) DEFAULT NULL,
  `phoneNumber` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notification` tinyint(1) DEFAULT '1',
  `deleted` tinyint(1) DEFAULT '0',
  `isAdmin` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`userId`),
  UNIQUE KEY `username_UNIQUE` (`username`),
  KEY `tenantEmployeeId` (`tenantEmployeeId`),
  CONSTRAINT `User_ibfk_1` FOREIGN KEY (`tenantEmployeeId`) REFERENCES `TenantEmployee` (`tenantEmployeeId`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `User`
--

LOCK TABLES `User` WRITE;
/*!40000 ALTER TABLE `User` DISABLE KEYS */;
INSERT INTO `User` VALUES (1,'user001','Cheng Su Chen','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','Leader','user01@gmail.com','','test/userprofileimage/0001_1555468500233.jpeg',1,'98554069',1,0,0),(2,'user002','Heng Tze Kiang','$2a$10$JTKqCBDs.fRCWSY/RU2kguoF1xxn0huTkhfr1QUes9rA6sa4kwRqa','Leader','user02@gmail.com','','test/userprofileimage/0001_1554453985262.jpeg',2,'97995746',1,0,0),(3,'user003','Christopher Loh','$2a$10$N3Mj1Q6kiKf84Z3nb2fdRubj4Eeg/Qw68JfYWe9c7PSN0GamPuDi6','Leader','user03@gmail.com','','test/userprofileimage/0001_1554374300010.jpeg',11,'82002261',1,0,0),(4,'user004','Sunny Tan','$2a$10$X9a1lKWgUpsC78SiGPa8beZU8sitIsEcUAA76lpHkLwm4ElMShn3.','Safety & Recovery Services Section I/C','user04@gmail.com','','default_image.jpeg',12,'97333632',1,0,0),(5,'user005','Maria Chyril','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','Safety & Recovery Services Section I/C','','','default_image.jpeg',21,'82019041',1,0,0),(6,'user006','Asen Chow','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','Safety & Recovery Services Section I/C','',NULL,'default_image.jpeg',31,'97913488',1,1,0),(7,'user007','Wilson Voon','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','M&E System I/C','','dsvIJd5E9TE:APA91bEolNpGmjzy9Sqghc1aw29hqh-vq5FBCZ8ZN9sSxBTk_hYJiFWMCv64CPKM6asBpe9AuPpLQ9NJc-evBFiKGXgtsFzftOSBN2d6NTiPes68EOqT8ZCIAvz3ZGWrjdluy4pFKK8d','default_image.jpeg',32,'98508971',1,0,0),(8,'user008','Fong Siew Cheong','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','M&E System I/C','',NULL,'default_image.jpeg',41,'96801398',1,1,0),(9,'user009','Lawrence Wu','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','M&E System I/C','','eebxoEghNqU:APA91bEFWXtZ3t5T6gYtVI_1Xg3mHo_YUTOvkRU4vIKIEaWsb3vDZ5NJVBa6HQD-z4b2oZqq4eiFfpJOt87xdZWYiXjqUseaj5ozFYBFapLpztk40MzjpDAZ6_yDNQ0XNgFGxQPWIIyT','default_image.jpeg',42,'91111253',1,0,0),(10,'user010','Sam Tan','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','Building Section I/C','',NULL,'default_image.jpeg',51,'93671215',1,1,0),(11,'user011','Hemalatha','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','Building Section I/C','',NULL,'default_image.jpeg',52,'96566972',1,0,0),(12,'user012','Patrik Poh','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','Building Section I/C','',NULL,'default_image.jpeg',61,'97422568',1,1,0),(13,'user013','David Tay','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','Cleaning Section I/C','',NULL,'default_image.jpeg',62,'90051757',1,0,0),(14,'user014','Jenny Tan','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','Cleaning Section I/C','',NULL,'default_image.jpeg',71,'97610551',1,1,0),(15,'user015','Satwant Singh','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','Cleaning Section I/C','',NULL,'default_image.jpeg',72,'64485606',1,0,0),(16,'user016','Christopher Loh','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','Security Section I/C','','','default_image.jpeg',81,'82002261',1,1,0),(17,'user017','Simon Lim','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','Security Section I/C','',NULL,'default_image.jpeg',82,'98776159',1,0,0),(18,'user018','Barry Chong','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','Security Section I/C','',NULL,'default_image.jpeg',91,'90068268',1,1,0),(19,'user019','Png Chiew Hoon','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','Tenant/ Staff Liaison Section I/C','','','default_image.jpeg',92,'64489262',1,0,0),(20,'user020','Amy Foo','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','Tenant/ Staff Liaison Section I/C','',NULL,'default_image.jpeg',101,'93362609',1,1,0),(21,'user021','Dylan Wong','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','Tenant/ Staff Liaison Section I/C','','','default_image.jpeg',102,'91776058',1,0,0),(22,'user022','Christina Goh','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','Office Support Section I/C','','','default_image.jpeg',111,'96835044',1,1,0),(23,'user023','Chelsia Chan','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','Office Support Section I/C','','','default_image.jpeg',112,'97583921',1,0,0),(24,'user024','Catherine Ng','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','Office Support Section I/C','',NULL,'default_image.jpeg',121,'91502754',1,1,0),(25,'user025','Alicia Tay','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','Other Support Staff','','','default_image.jpeg',122,'91013182',1,0,0),(26,'user026','R Sakinah','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','Other Support Staff','','','default_image.jpeg',131,'82004746',1,1,0),(27,'user027','Michelle lau','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','Other Support Staff','','','default_image.jpeg',132,'97614573',1,0,0),(28,'user028','Wong Wei Ting','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','title28','',NULL,'default_image.jpeg',141,'97382007',1,1,0),(29,'user029','Alvin Loke','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','title29','','','default_image.jpeg',142,'90210956',1,0,0),(30,'user030','Jaslyn Lau','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','title30','',NULL,'default_image.jpeg',151,'97428177',1,1,0),(31,'tester001','Katlyn Timms','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','Technician Manager','',NULL,'default_image.jpeg',152,NULL,1,0,0),(32,'tester002','Sophie Hughes','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','Technician Manager','',NULL,'default_image.jpeg',161,NULL,1,1,0),(33,'tester003','Mahi Fletcher','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','Technician Manager','',NULL,'default_image.jpeg',162,NULL,1,0,0),(34,'tester004','Stuart Marsh','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','Technician','',NULL,'default_image.jpeg',171,NULL,1,1,0),(35,'tester005','Lyla John','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','Technician','','cQZiv0h8y8c:APA91bGOoJ0fs2cdoeUYvkwPAlO_v967ckG8TQ245aVQnjr8VKE7HZcQHpMDwVkMHP-B9QzXTtaeG29czM3VDU9mCUedTZ_x8hJGEc2nAFup_jT1i8eMt1B7wQ3Ci60yP6zC-Kcb4XhG','default_image.jpeg',172,NULL,1,0,0),(36,'tester006','Jacob Wainwright','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','Technician','',NULL,'default_image.jpeg',181,NULL,1,1,0),(37,'tester007','Natalie Hampton','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','Accountant','',NULL,'default_image.jpeg',182,NULL,1,0,0),(38,'tester008','Arnold Osborn','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','Accountant','',NULL,'default_image.jpeg',191,NULL,1,1,0),(39,'tester009','Gertrude Dillon','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','Accountant','','','default_image.jpeg',192,NULL,1,0,0),(40,'tester010','Hettie Chung','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','Senior Accountant','',NULL,'default_image.jpeg',NULL,NULL,1,1,0),(41,'tester011','Raisa Green','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','Senior Accountant','','eebxoEghNqU:APA91bEFWXtZ3t5T6gYtVI_1Xg3mHo_YUTOvkRU4vIKIEaWsb3vDZ5NJVBa6HQD-z4b2oZqq4eiFfpJOt87xdZWYiXjqUseaj5ozFYBFapLpztk40MzjpDAZ6_yDNQ0XNgFGxQPWIIyT','default_image.jpeg',NULL,NULL,1,0,0),(42,'tester012','Cathy Molloy','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','Senior Accountant','',NULL,'default_image.jpeg',NULL,NULL,1,0,0),(43,'tester013','Sameer Hodge','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','IT Manager','','dsvIJd5E9TE:APA91bEolNpGmjzy9Sqghc1aw29hqh-vq5FBCZ8ZN9sSxBTk_hYJiFWMCv64CPKM6asBpe9AuPpLQ9NJc-evBFiKGXgtsFzftOSBN2d6NTiPes68EOqT8ZCIAvz3ZGWrjdluy4pFKK8d','default_image.jpeg',NULL,NULL,1,0,0),(44,'tester014','Maha Felix','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','IT Manager','',NULL,'default_image.jpeg',NULL,NULL,1,0,0),(45,'tester015','Nishat Carter','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','IT Manager','',NULL,'default_image.jpeg',NULL,NULL,1,0,0),(46,'tester016','Charly Olson','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','IT Personal','','eebxoEghNqU:APA91bEFWXtZ3t5T6gYtVI_1Xg3mHo_YUTOvkRU4vIKIEaWsb3vDZ5NJVBa6HQD-z4b2oZqq4eiFfpJOt87xdZWYiXjqUseaj5ozFYBFapLpztk40MzjpDAZ6_yDNQ0XNgFGxQPWIIyT','default_image.jpeg',NULL,NULL,1,0,0),(47,'tester017','Chandni Wardle','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','IT Personal','','eebxoEghNqU:APA91bEFWXtZ3t5T6gYtVI_1Xg3mHo_YUTOvkRU4vIKIEaWsb3vDZ5NJVBa6HQD-z4b2oZqq4eiFfpJOt87xdZWYiXjqUseaj5ozFYBFapLpztk40MzjpDAZ6_yDNQ0XNgFGxQPWIIyT','default_image.jpeg',NULL,NULL,1,0,0),(48,'tester018','Mali Middleton','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','IT Personal','','','default_image.jpeg',NULL,NULL,1,0,0),(49,'tester019','Filip Whelan','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','Manager','',NULL,'default_image.jpeg',NULL,NULL,1,0,0),(50,'tester020','Alessia Grainger','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','Manager','',NULL,'default_image.jpeg',NULL,NULL,1,0,0);
/*!40000 ALTER TABLE `User` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'FSA'
--

--
-- Dumping routines for database 'FSA'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-04-17 19:28:30
