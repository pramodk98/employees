-- MySQL dump 10.13  Distrib 5.7.17, for macos10.12 (x86_64)
--
-- Host: 127.0.0.1    Database: FSA
-- ------------------------------------------------------
-- Server version	5.5.5-10.1.37-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Building`
--

DROP TABLE IF EXISTS `Building`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Building` (
  `buildingId` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `numLevels` int(11) DEFAULT NULL,
  `latitude` double NOT NULL,
  `longtitude` double NOT NULL,
  `address1` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address2` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postalCode` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` varchar(75) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastUpdate` datetime(3) NOT NULL,
  `editedBy` int(11) NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`buildingId`),
  KEY `editedBy` (`editedBy`),
  CONSTRAINT `Building_ibfk_1` FOREIGN KEY (`editedBy`) REFERENCES `User` (`userId`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Building`
--

LOCK TABLES `Building` WRITE;
/*!40000 ALTER TABLE `Building` DISABLE KEYS */;
INSERT INTO `Building` VALUES (1,'NUH',25,1.2941186,104,'5 Lower Kent Ridge Rd','','s119074','singapore','2019-03-27 11:26:08.000',1,0),(2,'NUH Sports Centre',4,1.2927311,103.7853309,' Main Building Lobby B','5 Lower Kent Ridge Rd','s119074','singapore','2019-03-27 11:34:15.000',2,0),(3,'Timbre+',3,1.2904966,103.7864543,'73A Ayer Rajah Crescent','JTC Launchpad','s139957','singapore','2019-03-27 12:31:11.000',1,0),(4,'Ministry of education',4,0,0,'1 N Bouna Vista Drive ',NULL,'138675','singapore','2019-04-04 12:11:14.000',3,0);
/*!40000 ALTER TABLE `Building` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `BuildingLevel`
--

DROP TABLE IF EXISTS `BuildingLevel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `BuildingLevel` (
  `buildingLevelId` int(11) NOT NULL AUTO_INCREMENT,
  `buildingId` int(11) NOT NULL,
  `levelName` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`buildingLevelId`),
  KEY `buildingId` (`buildingId`),
  CONSTRAINT `BuildingLevel_ibfk_1` FOREIGN KEY (`buildingId`) REFERENCES `Building` (`buildingId`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BuildingLevel`
--

LOCK TABLES `BuildingLevel` WRITE;
/*!40000 ALTER TABLE `BuildingLevel` DISABLE KEYS */;
INSERT INTO `BuildingLevel` VALUES (1,1,'1',0),(2,1,'2',0),(3,1,'3',0),(4,2,'LG2',0),(5,2,'LG',0),(6,2,'G',0),(7,2,'1',0),(8,2,'2',0),(9,2,'3',0),(10,3,'1',0),(11,3,'2',0),(12,3,'3',0),(13,3,'4',0);
/*!40000 ALTER TABLE `BuildingLevel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `BuildingRole`
--

DROP TABLE IF EXISTS `BuildingRole`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `BuildingRole` (
  `buildingRoleId` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `buildingId` int(11) NOT NULL,
  `roleId` int(11) NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`buildingRoleId`),
  KEY `userId` (`userId`),
  KEY `buildingId` (`buildingId`),
  KEY `roleId` (`roleId`),
  CONSTRAINT `BuildingRole_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `User` (`userId`),
  CONSTRAINT `BuildingRole_ibfk_2` FOREIGN KEY (`buildingId`) REFERENCES `Building` (`buildingId`),
  CONSTRAINT `BuildingRole_ibfk_3` FOREIGN KEY (`roleId`) REFERENCES `Role` (`roleId`)
) ENGINE=InnoDB AUTO_INCREMENT=81 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BuildingRole`
--

LOCK TABLES `BuildingRole` WRITE;
/*!40000 ALTER TABLE `BuildingRole` DISABLE KEYS */;
INSERT INTO `BuildingRole` VALUES (1,1,1,10,0),(2,2,1,10,1),(3,3,1,10,0),(4,4,1,10,1),(5,5,1,10,0),(6,6,1,10,1),(7,7,1,10,0),(8,8,1,10,1),(9,9,1,10,0),(10,10,1,10,1),(11,11,2,10,0),(12,12,2,10,1),(13,13,2,10,0),(14,14,2,10,1),(15,15,2,10,0),(16,16,2,10,1),(17,17,2,10,0),(18,18,2,10,1),(19,19,2,10,0),(20,20,2,10,1),(21,21,3,10,0),(22,22,3,10,1),(23,23,3,10,0),(24,24,3,10,1),(25,25,3,10,0),(26,26,3,10,1),(27,27,3,10,0),(28,28,3,10,1),(29,29,3,10,0),(30,30,3,10,1),(31,31,4,10,0),(32,32,4,10,1),(33,33,4,10,0),(34,34,4,10,1),(35,35,4,10,0),(36,36,4,10,1),(37,37,4,10,0),(38,38,4,10,1),(39,39,4,10,0),(40,40,4,10,1),(41,41,1,1,0),(42,42,2,1,0),(43,43,3,1,0),(44,44,4,1,0),(45,42,1,2,0),(46,43,2,2,0),(47,44,3,2,0),(48,41,4,2,0),(49,43,1,3,0),(50,44,2,3,0),(51,41,3,3,0),(52,42,4,3,0),(53,45,1,4,0),(54,46,2,4,0),(55,47,3,4,0),(56,48,4,4,0),(57,49,1,5,0),(58,50,2,5,0),(59,42,3,5,0),(60,47,4,5,0),(61,50,1,6,0),(62,45,2,6,0),(63,49,3,6,0),(64,43,4,6,0),(65,48,1,7,0),(66,41,2,7,0),(67,50,3,7,0),(68,49,4,7,0),(69,47,1,8,0),(70,48,2,8,0),(71,46,3,8,0),(72,50,4,8,0),(73,44,1,9,0),(74,49,2,9,0),(75,45,3,9,0),(76,46,4,9,0),(77,46,1,11,0),(78,47,2,11,0),(79,48,3,11,0),(80,45,4,11,0);
/*!40000 ALTER TABLE `BuildingRole` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Certification`
--

DROP TABLE IF EXISTS `Certification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Certification` (
  `certificationId` int(11) NOT NULL AUTO_INCREMENT,
  `certificationName` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expirationDate` datetime(3) NOT NULL,
  `buildingId` int(11) NOT NULL,
  `document` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`certificationId`),
  KEY `buildingId` (`buildingId`),
  CONSTRAINT `Certification_ibfk_1` FOREIGN KEY (`buildingId`) REFERENCES `Building` (`buildingId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Certification`
--

LOCK TABLES `Certification` WRITE;
/*!40000 ALTER TABLE `Certification` DISABLE KEYS */;
/*!40000 ALTER TABLE `Certification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Configurations`
--

DROP TABLE IF EXISTS `Configurations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Configurations` (
  `configurationId` int(11) NOT NULL AUTO_INCREMENT,
  `trainingName` varchar(100) DEFAULT NULL,
  `trainingURL` varchar(255) DEFAULT NULL,
  `document` varchar(100) DEFAULT NULL,
  `lastUpdate` datetime(3) NOT NULL,
  PRIMARY KEY (`configurationId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Configurations`
--

LOCK TABLES `Configurations` WRITE;
/*!40000 ALTER TABLE `Configurations` DISABLE KEYS */;
/*!40000 ALTER TABLE `Configurations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Drawings`
--

DROP TABLE IF EXISTS `Drawings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Drawings` (
  `drawingId` int(11) NOT NULL AUTO_INCREMENT,
  `levelId` int(11) NOT NULL,
  `editedBy` int(11) DEFAULT NULL,
  `dateTime` datetime(3) NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `documentKey` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `documentName` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`drawingId`),
  KEY `editedBy` (`editedBy`),
  KEY `levelId` (`levelId`),
  CONSTRAINT `Drawings_ibfk_1` FOREIGN KEY (`editedBy`) REFERENCES `User` (`userId`),
  CONSTRAINT `Drawings_ibfk_2` FOREIGN KEY (`levelId`) REFERENCES `BuildingLevel` (`buildingLevelId`)
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Drawings`
--

LOCK TABLES `Drawings` WRITE;
/*!40000 ALTER TABLE `Drawings` DISABLE KEYS */;
INSERT INTO `Drawings` VALUES (1,1,2,'2019-04-05 12:06:14.000',1,'test/drawings/1/DrawingTest_0001_1554436577137.jpeg','IMG_20190206_001651_247.jpg'),(2,1,2,'2019-04-05 12:06:39.000',1,'test/drawings/1/DrawingTest_0001_1554436577137.jpeg','IMG_20190206_001651_247.jpg'),(3,1,2,'2019-04-05 12:06:49.000',1,'test/drawings/1/DrawingTest_0001_1554436577137.jpeg','IMG_20190206_001651_247.jpg'),(4,2,1,'2019-04-05 12:22:13.000',1,'test/drawings/2/DrawingTest_0001_1554438129998.jpeg','DrawingTest_0001_1554438129998.jpeg'),(5,2,1,'2019-04-05 12:25:37.000',1,'test/drawings/2/DrawingTest_0001_1554438333902.jpeg','IMG_20190218_000848_058.jpg'),(6,3,1,'2019-04-05 12:32:23.000',1,'test/drawings/0/DrawingTest_0001_1554438740631.jpeg','IMG_20190211_230439_161.jpg'),(7,3,1,'2019-04-05 12:42:19.000',1,'test/drawings/0/DrawingTest_0001_1554439335300.jpeg','IMG_20190211_230439_161.jpg'),(8,1,1,'2019-04-05 12:42:55.000',1,'test/drawings/0/DrawingTest_0001_1554439371669.pdf','FPTC-AB-FP-204-6-8(2s-3s-4s)_FP-204(2ND)-Model.pdf'),(9,1,1,'2019-04-05 12:43:32.000',1,'test/drawings/0/DrawingTest_0001_1554439408532.pdf','FPTC-AB-FP-204-6-8(2s-3s-4s)_FP-204(2ND)-Model.pdf'),(10,1,1,'2019-04-05 12:43:46.000',1,'test/drawings/0/DrawingTest_0001_1554439422393.pdf','FPTC-AB-FP-204-6-8(2s-3s-4s)_FP-204(2ND)-Model.pdf'),(11,3,1,'2019-04-05 12:43:58.000',1,'test/drawings/0/DrawingTest_0001_1554439430290.pdf','FPTC-AB-FP-204-6-8(2s-3s-4s)_FP-208(4TH)-Model.pdf'),(12,2,1,'2019-04-05 12:44:08.000',0,'test/drawings/0/DrawingTest_0001_1554439444465.pdf','FPTC-AB-FP-204-6-8(2s-3s-4s)_FP-204(2ND)-Model.pdf'),(13,1,1,'2019-04-05 12:44:26.000',1,'test/drawings/0/DrawingTest_0001_1554439462833.jpeg','IMG_20190211_230439_161.jpg'),(14,1,1,'2019-04-05 12:52:17.000',1,'test/drawings/0/DrawingTest_0001_1554439932241.jpeg','bg_popup_quizmax.png'),(15,1,1,'2019-04-05 12:52:34.000',1,'test/drawings/0/DrawingTest_0001_1554439944136.pdf','FPTC-AB-FP-204-6-8(2s-3s-4s)_FP-206(3RD)-Model.pdf'),(16,2,1,'2019-04-05 12:52:51.000',0,'test/drawings/0/DrawingTest_0001_1554439968681.jpeg','IMG_20190206_001651_247.jpg'),(17,2,1,'2019-04-05 12:52:59.000',0,'test/drawings/0/DrawingTest_0001_1554439976334.pdf','FPTC-AB-FP-204-6-8(2s-3s-4s)_FP-204(2ND)-Model.pdf'),(18,3,1,'2019-04-05 12:53:15.000',1,'test/drawings/0/DrawingTest_0001_1554439988927.jpeg','IMG_20190220_205148_020.jpg'),(19,3,1,'2019-04-05 12:53:25.000',0,'test/drawings/0/DrawingTest_0001_1554439999043.pdf','FPTC-AB-FP-204-6-8(2s-3s-4s)_FP-204(2ND)-Model.pdf'),(20,3,1,'2019-04-05 14:38:50.000',0,'test/drawings/0/DrawingTest_0001_1554446325907.jpeg','IMG_20190124_193842_986.jpg'),(21,1,1,'2019-04-05 14:47:14.000',1,'test/drawings/0/DrawingTest_0001_1554446821919.pdf','FPTC-AB-FP-204-6-8(2s-3s-4s)_FP-204(2ND)-Model.pdf'),(22,1,1,'2019-04-05 14:47:14.000',1,'test/drawings/0/DrawingTest_0001_1554446830381.jpeg','IMG_20190206_001651_247.jpg'),(23,1,1,'2019-04-05 14:50:25.000',1,'test/drawings/0/DrawingTest_0001_1554446996390.jpeg','IMG_20190218_000848_058.jpg'),(24,1,1,'2019-04-05 14:50:25.000',1,'test/drawings/0/DrawingTest_0001_1554447002257.pdf','FPTC-AB-FP-204-6-8(2s-3s-4s)_FP-206(3RD)-Model.pdf'),(25,1,1,'2019-04-05 14:50:25.000',1,'test/drawings/0/DrawingTest_0001_1554447008596.pdf','Escalation Process and Preparedness.pdf'),(26,1,1,'2019-04-05 14:50:25.000',1,'test/drawings/0/DrawingTest_0001_1554447020249.jpeg','DrawingTest_0001_1554447020249.jpeg'),(27,4,2,'2019-04-05 15:24:41.000',1,'test/drawings/0/DrawingTest_0001_1554449061059.pdf','fire_drill_reporting_sample.pdf'),(28,4,2,'2019-04-05 15:24:41.000',1,'test/drawings/0/DrawingTest_0001_1554449070297.jpeg','IMG_20190211_230439_161.jpg'),(29,4,2,'2019-04-05 15:24:41.000',0,'test/drawings/0/DrawingTest_0001_1554449075096.pdf','Equipment List for Fire Protection System.pdf'),(30,5,2,'2019-04-05 15:27:17.000',0,'test/drawings/0/DrawingTest_0001_1554449224044.jpeg','DrawingTest_0001_1554449224044.jpeg'),(31,5,2,'2019-04-05 15:27:17.000',0,'test/drawings/0/DrawingTest_0001_1554449228093.pdf','Escalation Process and Preparedness.pdf'),(32,5,2,'2019-04-05 15:27:17.000',0,'test/drawings/0/DrawingTest_0001_1554449234722.jpeg','bg_popup_quizmax.png'),(33,6,2,'2019-04-05 15:27:31.000',0,'test/drawings/0/DrawingTest_0001_1554449246992.pdf','Escalation Process and Preparedness.pdf'),(34,8,2,'2019-04-05 15:27:42.000',0,'test/drawings/0/DrawingTest_0001_1554449260099.jpeg','IMG_20190211_230439_161.jpg'),(35,9,2,'2019-04-05 15:27:53.000',0,'test/drawings/0/DrawingTest_0001_1554449270922.jpeg','IMG_20190208_140352_447.jpg'),(36,7,2,'2019-04-05 15:28:05.000',1,'test/drawings/0/DrawingTest_0001_1554449282240.jpeg','IMG_20190316_133404_612.jpg'),(37,4,2,'2019-04-05 15:49:49.000',1,'test/drawings/0/DrawingTest_0001_1554450585921.jpeg','IMG_20190218_000848_058.jpg'),(38,5,2,'2019-04-05 15:54:32.000',0,'test/drawings/0/DrawingTest_0001_1554450868399.jpeg','bg_popup_quizmax.png'),(39,4,2,'2019-04-05 16:41:18.000',1,'building_2/drawings/levelId_4/Drawing_2_1554453674453.jpeg','Drawing_2_1554453674453.jpeg'),(40,8,2,'2019-04-05 16:42:51.000',0,'building_2/drawings/levelId_8/Drawing_2_1554453768360.jpeg','IMG_20180920_003340_962.jpg'),(41,9,2,'2019-04-05 16:47:00.000',0,'building_2/drawings/levelId_9/Drawing_2_1554454016441.pdf','Escalation Process and Preparedness.pdf'),(42,4,2,'2019-04-05 18:06:40.000',1,'building_2/drawings/levelId_4/Drawing_2_1554458797268.jpeg','IMG_20190211_230439_161.jpg'),(43,4,2,'2019-04-05 18:06:53.000',1,'building_2/drawings/levelId_4/Drawing_2_1554458810354.jpeg','IMG_20190307_000308_863.jpg'),(44,4,2,'2019-04-05 18:07:15.000',0,'building_2/drawings/levelId_4/Drawing_2_1554458819191.jpeg','IMG_20190316_133404_612.jpg'),(45,4,2,'2019-04-05 18:07:15.000',1,'building_2/drawings/levelId_4/Drawing_2_1554458827619.jpeg','IMG_20190126_003024_052.jpg'),(46,4,2,'2019-04-05 18:57:39.000',0,'building_2/drawings/levelId_4/Drawing_2_1554461856392.jpeg','IMG_20190211_230439_161.jpg'),(47,7,2,'2019-04-05 18:57:53.000',0,'building_2/drawings/levelId_7/Drawing_2_1554461867651.jpeg','IMG_20190208_140352_447.jpg'),(48,7,2,'2019-04-08 14:39:50.000',0,'building_2/drawings/levelId_7/Drawing_2_1554705588320.jpeg','IMG_20190206_001651_247.jpg'),(49,1,2,'2019-04-08 18:44:20.000',1,'building_1/drawings/levelId_1/Drawing_2_1554720238967.pdf','Equipment List for Fire Protection System.pdf'),(50,1,2,'2019-04-08 18:44:20.000',1,'building_1/drawings/levelId_1/Drawing_2_1554720242827.pdf','Escalation Process and Preparedness.pdf'),(51,1,2,'2019-04-08 18:44:20.000',1,'building_1/drawings/levelId_1/Drawing_2_1554720250411.jpeg','Drawing_2_1554720250411.jpeg'),(52,1,2,'2019-04-08 18:44:20.000',1,'building_1/drawings/levelId_1/Drawing_2_1554720257001.jpeg','IMG_20190407_135426_965.jpg'),(53,1,2,'2019-04-08 18:45:06.000',1,'building_1/drawings/levelId_1/Drawing_2_1554720279848.jpeg','IMG_20190211_230439_161.jpg'),(54,1,2,'2019-04-08 18:45:06.000',1,'building_1/drawings/levelId_1/Drawing_2_1554720285768.jpeg','IMG_20190220_205148_020.jpg'),(55,1,2,'2019-04-08 18:45:06.000',1,'building_1/drawings/levelId_1/Drawing_2_1554720288754.pdf','Escalation Process and Preparedness.pdf'),(56,1,2,'2019-04-08 18:45:06.000',1,'building_1/drawings/levelId_1/Drawing_2_1554720292235.pdf','fire_drill_reporting_sample.pdf'),(57,1,2,'2019-04-08 18:45:38.000',1,'building_1/drawings/levelId_1/Drawing_2_1554720335810.pdf','fire_drill_reporting_sample.pdf'),(58,1,2,'2019-04-08 18:47:56.000',1,'building_1/drawings/levelId_1/Drawing_2_1554720474861.jpeg','IMG_20190407_135426_965.jpg'),(59,1,2,'2019-04-08 18:48:11.000',1,'building_1/drawings/levelId_1/Drawing_2_1554720485261.jpeg','bg_popup_quizmax.png'),(60,1,2,'2019-04-08 18:48:11.000',1,'building_1/drawings/levelId_1/Drawing_2_1554720488030.pdf','Escalation Process and Preparedness.pdf'),(61,1,2,'2019-04-08 18:48:45.000',1,'building_1/drawings/levelId_1/Drawing_2_1554720506015.jpeg','IMG_20190220_205148_020.jpg'),(62,1,2,'2019-04-08 18:48:45.000',1,'building_1/drawings/levelId_1/Drawing_2_1554720517641.jpeg','IMG_20190206_001651_247.jpg'),(63,1,2,'2019-04-08 18:48:45.000',1,'building_1/drawings/levelId_1/Drawing_2_1554720521970.pdf','Escalation Process and Preparedness.pdf'),(64,1,2,'2019-04-08 18:49:26.000',1,'building_1/drawings/levelId_1/Drawing_2_1554720538459.jpeg','Drawing_2_1554720538459.jpeg'),(65,1,2,'2019-04-08 18:49:26.000',1,'building_1/drawings/levelId_1/Drawing_2_1554720545304.pdf','FPTC-AB-FP-204-6-8(2s-3s-4s)_FP-204(2ND)-Model.pdf'),(66,1,2,'2019-04-08 18:49:26.000',1,'building_1/drawings/levelId_1/Drawing_2_1554720562820.jpeg','IMG20190331123901.jpg'),(67,1,1,'2019-04-12 11:56:24.000',0,'building_1/drawings/levelId_1/Drawing_1_1555041367749.pdf','Escalation Process and Preparedness.pdf'),(68,1,1,'2019-04-12 11:56:24.000',0,'building_1/drawings/levelId_1/Drawing_1_1555041381688.jpeg','IMG_20190326_011801_973.jpg');
/*!40000 ALTER TABLE `Drawings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ERP`
--

DROP TABLE IF EXISTS `ERP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ERP` (
  `erpId` int(11) NOT NULL AUTO_INCREMENT,
  `buildingId` int(11) NOT NULL,
  `documentName` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `documentKey` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`erpId`),
  KEY `buildingId` (`buildingId`),
  CONSTRAINT `ERP_ibfk_1` FOREIGN KEY (`buildingId`) REFERENCES `Building` (`buildingId`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ERP`
--

LOCK TABLES `ERP` WRITE;
/*!40000 ALTER TABLE `ERP` DISABLE KEYS */;
INSERT INTO `ERP` VALUES (5,1,'IMG_20190407_135426_965.jpg','building_1/erp/erp_1_1554713823419.jpeg',1),(6,1,'Escalation Process and Preparedness.pdf','building_1/erp/erp_1_1554715701376.pdf',1),(7,1,'IMG_20190218_000848_058.jpg','building_1/erp/erp_1_1554717618788.jpeg',1),(8,1,'IMG_20190124_193842_986.jpg','building_1/erp/erp_1_1554718294675.jpeg',1),(9,1,'Escalation Process and Preparedness.pdf','building_1/erp/erp_1_1554718299846.pdf',1),(10,1,'IMG_20190206_001651_247.jpg','building_1/erp/erp_1_1554718330656.jpeg',1),(11,1,'IMG_20190307_000308_863.jpg','building_1/erp/erp_1_1554718336711.jpeg',1),(12,1,'IMG_20190316_133404_612.jpg','building_1/erp/erp_2_1554719600896.jpeg',1),(13,1,'bg_popup_quizmax.png','building_1/erp/erp_2_1554719605977.jpeg',1),(14,1,'erp_2_1554720598714.jpeg','building_1/erp/erp_2_1554720598714.jpeg',1),(15,1,'FPTC-AB-FP-204-6-8(2s-3s-4s)_FP-208(4TH)-Model.pdf','building_1/erp/erp_2_1554720602260.pdf',1),(16,1,'bg_popup_quizmax.png','building_1/erp/erp_2_1554720614362.jpeg',1),(17,1,'IMG_20190407_135426_965.jpg','building_1/erp/erp_2_1554720819163.jpeg',0),(18,1,'IMG_20190323_203830_735.jpg','building_1/erp/erp_2_1554721011084.jpeg',1),(19,1,'Escalation Process and Preparedness.pdf','building_1/erp/erp_2_1554721014401.pdf',1),(20,1,'IMG_20190211_230439_161.jpg','building_1/erp/erp_2_1554721572847.jpeg',0),(21,1,'IMG_20190220_205148_020.jpg','building_1/erp/erp_2_1554721592947.jpeg',0),(22,3,'IMG_20190220_205148_020.jpg','building_3/erp/erp_29_1555051049468.jpeg',1),(23,3,'Escalation Process and Preparedness.pdf','building_3/erp/erp_29_1555051058600.pdf',0),(24,3,'fire_drill_reporting_sample.pdf','building_3/erp/erp_29_1555051062078.pdf',0),(25,1,'FPTC-AB-FP-204-6-8(2s-3s-4s)_FP-208(4TH)-Model.pdf','building_1/erp/erp_2_1554720602260.pdf',0);
/*!40000 ALTER TABLE `ERP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EmergencyData`
--

DROP TABLE IF EXISTS `EmergencyData`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `EmergencyData` (
  `emergencyDataId` int(11) NOT NULL AUTO_INCREMENT,
  `documentName` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `documentKey` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `levelId` int(11) NOT NULL,
  `editedBy` int(11) NOT NULL,
  `dateTime` datetime(3) NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`emergencyDataId`),
  KEY `editedBy` (`editedBy`),
  KEY `levelId` (`levelId`),
  CONSTRAINT `EmergencyData_ibfk_1` FOREIGN KEY (`editedBy`) REFERENCES `User` (`userId`),
  CONSTRAINT `EmergencyData_ibfk_2` FOREIGN KEY (`levelId`) REFERENCES `BuildingLevel` (`buildingLevelId`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EmergencyData`
--

LOCK TABLES `EmergencyData` WRITE;
/*!40000 ALTER TABLE `EmergencyData` DISABLE KEYS */;
INSERT INTO `EmergencyData` VALUES (1,'IMG_20190211_230439_161.jpg','building_2/ped/levelId_4/PED_2_1554458419700.jpeg',4,2,'2019-04-05 18:00:22.000',1),(2,'Equipment List for Fire Protection System.pdf','building_2/ped/levelId_7/PED_2_1554458454970.pdf',7,2,'2019-04-05 18:00:58.000',1),(3,'IMG_20190112_203353_503.jpg','building_2/ped/levelId_4/PED_2_1554458524802.jpeg',4,2,'2019-04-05 18:02:20.000',1),(4,'IMG_20190218_000848_058.jpg','building_2/ped/levelId_4/PED_2_1554458532940.jpeg',4,2,'2019-04-05 18:02:20.000',1),(5,'Equipment List for Fire Protection System.pdf','building_2/ped/levelId_4/PED_2_1554458536527.pdf',4,2,'2019-04-05 18:02:20.000',0),(6,'IMG_20190208_140352_447.jpg','building_2/ped/levelId_9/PED_2_1554458552472.jpeg',9,2,'2019-04-05 18:02:40.000',0),(7,'bg_popup_quizmax.png','building_2/ped/levelId_9/PED_2_1554458557883.jpeg',9,2,'2019-04-05 18:02:40.000',0),(8,'IMG_20181029_033114_206.jpg','building_2/ped/levelId_4/PED_2_1554458587075.jpeg',4,2,'2019-04-05 18:03:10.000',1),(9,'IMG_20190220_205148_020.jpg','building_2/ped/levelId_4/PED_2_1554458646420.jpeg',4,2,'2019-04-05 18:04:16.000',1),(10,'IMG_20190211_230439_161.jpg','building_2/ped/levelId_4/PED_2_1554458652451.jpeg',4,2,'2019-04-05 18:04:16.000',1),(11,'IMG_20190211_230439_161.jpg','building_2/ped/levelId_4/PED_2_1554458867651.jpeg',4,2,'2019-04-05 18:07:59.000',0),(12,'IMG_20190126_003024_052.jpg','building_2/ped/levelId_4/PED_2_1554458875458.jpeg',4,2,'2019-04-05 18:07:59.000',0),(13,'Escalation Process and Preparedness.pdf','building_2/ped/levelId_5/PED_2_1554458916986.pdf',5,2,'2019-04-05 18:08:39.000',1),(14,'IMG_20190112_203353_503.jpg','building_2/ped/levelId_5/PED_2_1554458925772.jpeg',5,2,'2019-04-05 18:09:21.000',1),(15,'bg_popup_quizmax.png','building_2/ped/levelId_5/PED_2_1554458931306.jpeg',5,2,'2019-04-05 18:09:21.000',1),(16,'PED_2_1554458940535.jpeg','building_2/ped/levelId_5/PED_2_1554458940535.jpeg',5,2,'2019-04-05 18:09:21.000',0),(17,'Escalation Process and Preparedness.pdf','building_2/ped/levelId_5/PED_2_1554458944985.pdf',5,2,'2019-04-05 18:09:21.000',0),(18,'IMG_20190208_140352_447.jpg','building_2/ped/levelId_5/PED_2_1554458970332.jpeg',5,2,'2019-04-05 18:09:42.000',0),(19,'IMG20190102131741.jpg','building_2/ped/levelId_5/PED_2_1554458978824.jpeg',5,2,'2019-04-05 18:09:42.000',0),(20,'IMG_20190211_230439_161.jpg','building_2/ped/levelId_8/PED_2_1554460070508.jpeg',8,2,'2019-04-05 18:27:54.000',1),(21,'IMG_20190211_230439_161.jpg','building_2/ped/levelId_8/PED_2_1554460115641.jpeg',8,2,'2019-04-05 18:28:44.000',1),(22,'IMG_20190211_230439_161.jpg','building_2/ped/levelId_8/PED_2_1554460683021.jpeg',8,2,'2019-04-05 18:38:12.000',1),(23,'IMG_20190211_230439_161.jpg','building_1/ped/levelId_1/PED_2_1554719057300.jpeg',1,2,'2019-04-08 18:24:29.000',1),(24,'IMG_20190105_103616_324.jpg','building_1/ped/levelId_1/PED_2_1554719066196.jpeg',1,2,'2019-04-08 18:24:29.000',1),(25,'IMG_20190407_135426_965.jpg','building_1/ped/levelId_1/PED_2_1554719086694.jpeg',1,2,'2019-04-08 18:24:48.000',0),(26,'IMG_20190220_205148_020.jpg','building_1/ped/levelId_2/PED_2_1554719106817.jpeg',2,2,'2019-04-08 18:25:09.000',0),(27,'IMG_20190126_003024_052.jpg','building_1/ped/levelId_3/PED_2_1554719116830.jpeg',3,2,'2019-04-08 18:25:19.000',0),(28,'PED_2_1554956556489.jpeg','building_1/ped/levelId_2/PED_2_1554956556489.jpeg',2,2,'2019-04-11 12:22:39.000',0),(29,'IMG_20190220_205148_020.jpg','building_1/ped/levelId_1/PED_2_1554956623862.jpeg',1,2,'2019-04-11 12:23:47.000',0);
/*!40000 ALTER TABLE `EmergencyData` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Escalation`
--

DROP TABLE IF EXISTS `Escalation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Escalation` (
  `escalationId` int(11) NOT NULL AUTO_INCREMENT,
  `buildingId` int(11) NOT NULL,
  `dateTime` datetime(3) NOT NULL,
  `reporter` int(11) NOT NULL,
  `lastUpdate` datetime(3) NOT NULL,
  `status` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `completeDateTime` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`escalationId`),
  KEY `reporter` (`reporter`),
  KEY `buildingId` (`buildingId`),
  CONSTRAINT `Escalation_ibfk_1` FOREIGN KEY (`reporter`) REFERENCES `User` (`userId`),
  CONSTRAINT `Escalation_ibfk_2` FOREIGN KEY (`buildingId`) REFERENCES `Building` (`buildingId`)
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Escalation`
--

LOCK TABLES `Escalation` WRITE;
/*!40000 ALTER TABLE `Escalation` DISABLE KEYS */;
INSERT INTO `Escalation` VALUES (11,1,'2019-04-08 16:47:29.000',1,'2019-04-08 16:59:57.000','close','2019-04-08 16:59:57.000'),(12,1,'2019-04-08 17:00:23.000',1,'2019-04-08 17:17:42.000','close','2019-04-08 17:17:42.000'),(13,1,'2019-04-08 17:18:02.000',1,'2019-04-08 17:46:05.000','close','2019-04-08 17:46:04.000'),(14,1,'2019-04-08 18:02:21.000',1,'2019-04-08 19:01:45.000','close','2019-04-08 19:01:43.000'),(15,1,'2019-04-08 18:09:20.000',1,'2019-04-08 18:18:12.000','close','2019-04-08 18:18:11.000'),(16,1,'2019-04-08 18:18:23.000',2,'2019-04-08 18:18:32.000','close','2019-04-08 18:18:31.000'),(17,1,'2019-04-08 18:18:35.000',2,'2019-04-08 18:19:52.000','close','2019-04-08 18:19:51.000'),(18,1,'2019-04-08 19:01:38.000',1,'2019-04-08 19:01:51.000','close','2019-04-08 19:01:50.000'),(19,1,'2019-04-08 19:01:54.000',1,'2019-04-08 19:02:02.000','close','2019-04-08 19:02:01.000'),(20,1,'2019-04-08 19:02:05.000',1,'2019-04-08 19:05:24.000','close','2019-04-08 19:05:22.000'),(21,1,'2019-04-08 19:05:28.000',1,'2019-04-08 19:05:29.000','close','2019-04-08 19:05:29.000'),(22,1,'2019-04-08 19:10:22.000',1,'2019-04-08 19:10:25.000','close','2019-04-08 19:10:24.000'),(23,1,'2019-04-08 19:10:30.000',1,'2019-04-08 19:11:31.000','close','2019-04-08 19:10:38.000'),(24,1,'2019-04-08 19:11:48.000',1,'2019-04-08 19:11:56.000','close','2019-04-08 19:11:54.000'),(25,1,'2019-04-09 09:23:05.000',2,'2019-04-09 09:23:54.000','close','2019-04-09 09:23:54.000'),(26,1,'2019-04-09 09:24:08.000',2,'2019-04-09 09:25:05.000','close','2019-04-09 09:25:05.000'),(27,1,'2019-04-09 09:41:50.000',2,'2019-04-09 09:42:16.000','close','2019-04-09 09:42:15.000'),(28,1,'2019-04-09 09:42:38.000',2,'2019-04-09 09:43:36.000','close','2019-04-09 09:43:36.000'),(29,1,'2019-04-09 09:44:17.000',2,'2019-04-09 09:44:34.000','close','2019-04-09 09:44:34.000'),(30,1,'2019-04-09 09:46:07.000',2,'2019-04-09 09:46:59.000','close','2019-04-09 09:46:59.000'),(31,1,'2019-04-09 09:48:40.000',2,'2019-04-09 09:49:20.000','close','2019-04-09 09:49:20.000'),(32,1,'2019-04-09 09:49:27.000',2,'2019-04-09 09:51:18.000','close','2019-04-09 09:51:18.000'),(33,1,'2019-04-09 09:53:07.000',2,'2019-04-09 10:13:13.000','close','2019-04-09 10:13:13.000'),(34,1,'2019-04-09 10:23:33.000',2,'2019-04-09 10:25:34.000','close','2019-04-09 10:25:34.000'),(35,1,'2019-04-09 10:25:58.000',2,'2019-04-09 10:29:20.000','close','2019-04-09 10:29:19.000'),(36,1,'2019-04-09 10:29:55.000',2,'2019-04-09 10:30:36.000','close','2019-04-09 10:30:35.000'),(37,1,'2019-04-09 10:31:17.000',2,'2019-04-09 10:31:26.000','close','2019-04-09 10:31:26.000'),(38,1,'2019-04-09 10:32:36.000',2,'2019-04-09 10:32:42.000','close','2019-04-09 10:32:41.000'),(39,1,'2019-04-09 10:32:47.000',2,'2019-04-09 10:33:05.000','close','2019-04-09 10:33:04.000'),(40,1,'2019-04-09 10:33:14.000',2,'2019-04-09 10:37:07.000','close','2019-04-09 10:37:06.000'),(41,1,'2019-04-09 10:37:28.000',2,'2019-04-09 10:39:09.000','close','2019-04-09 10:39:08.000'),(42,1,'2019-04-09 10:41:56.000',2,'2019-04-09 10:53:27.000','close','2019-04-09 10:53:27.000'),(43,1,'2019-04-09 10:53:58.000',2,'2019-04-09 10:55:20.000','close','2019-04-09 10:55:20.000'),(44,1,'2019-04-09 10:59:38.000',2,'2019-04-09 10:59:48.000','close','2019-04-09 10:59:48.000'),(45,1,'2019-04-09 11:00:35.000',2,'2019-04-09 11:02:29.000','close','2019-04-09 11:02:28.000'),(46,1,'2019-04-09 11:03:50.000',2,'2019-04-09 11:04:48.000','close','2019-04-09 11:04:47.000'),(47,1,'2019-04-09 11:04:57.000',2,'2019-04-09 11:06:19.000','close','2019-04-09 11:06:18.000'),(48,1,'2019-04-09 11:06:52.000',2,'2019-04-09 11:08:29.000','close','2019-04-09 11:08:28.000'),(49,1,'2019-04-09 11:09:04.000',2,'2019-04-09 11:10:58.000','close','2019-04-09 11:10:57.000'),(50,1,'2019-04-09 11:11:10.000',2,'2019-04-09 11:13:52.000','close','2019-04-09 11:13:51.000'),(51,1,'2019-04-09 11:14:27.000',2,'2019-04-09 11:15:59.000','close','2019-04-09 11:15:59.000'),(52,1,'2019-04-09 11:16:26.000',2,'2019-04-09 11:19:10.000','close','2019-04-09 11:19:08.000'),(53,1,'2019-04-09 11:19:43.000',2,'2019-04-09 11:22:42.000','close','2019-04-09 11:22:42.000'),(54,1,'2019-04-09 11:22:49.000',2,'2019-04-09 11:40:27.000','close','2019-04-09 11:40:26.000'),(55,1,'2019-04-09 11:55:44.000',2,'2019-04-09 11:56:10.000','close','2019-04-09 11:56:10.000'),(56,3,'2019-04-09 12:00:39.000',3,'2019-04-09 12:00:53.000','close','2019-04-09 12:00:53.000'),(57,1,'2019-04-09 12:00:45.000',2,'2019-04-09 12:01:15.000','close','2019-04-09 12:01:14.000'),(58,2,'2019-04-09 12:02:15.000',4,'2019-04-09 12:02:32.000','close','2019-04-09 12:02:32.000'),(59,1,'2019-04-09 12:02:23.000',2,'2019-04-09 12:04:05.000','close','2019-04-09 12:04:05.000'),(60,1,'2019-04-09 12:04:12.000',1,'2019-04-09 12:04:20.000','close','2019-04-09 12:04:19.000'),(61,2,'2019-04-09 12:04:57.000',4,'2019-04-09 12:08:47.000','close','2019-04-09 12:08:47.000'),(62,1,'2019-04-09 12:05:02.000',2,'2019-04-09 12:05:11.000','close','2019-04-09 12:05:10.000'),(63,2,'2019-04-09 16:59:06.000',2,'2019-04-09 17:00:20.000','close','2019-04-09 17:00:20.000'),(64,1,'2019-04-09 18:32:49.000',1,'2019-04-09 18:33:01.000','close','2019-04-09 18:33:01.000'),(65,1,'2019-04-10 18:07:07.000',4,'2019-04-10 18:07:17.000','close','2019-04-10 18:07:16.000'),(66,1,'2019-04-10 18:10:24.000',2,'2019-04-10 18:15:34.000','close','2019-04-10 18:15:34.000');
/*!40000 ALTER TABLE `Escalation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EscalationAttendance`
--

DROP TABLE IF EXISTS `EscalationAttendance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `EscalationAttendance` (
  `escalationAttendanceId` int(11) NOT NULL AUTO_INCREMENT,
  `escalationId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `status` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`escalationAttendanceId`)
) ENGINE=InnoDB AUTO_INCREMENT=129 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EscalationAttendance`
--

LOCK TABLES `EscalationAttendance` WRITE;
/*!40000 ALTER TABLE `EscalationAttendance` DISABLE KEYS */;
INSERT INTO `EscalationAttendance` VALUES (1,9,1,'present'),(2,10,1,'absent'),(3,11,1,'absent'),(4,12,1,'absent'),(8,22,1,'absent'),(9,23,1,'absent'),(10,24,1,'absent'),(11,25,2,'absent'),(12,26,2,'absent'),(13,27,1,'absent'),(14,27,4,'absent'),(15,27,2,'absent'),(16,28,1,'absent'),(17,28,4,'absent'),(18,28,2,'absent'),(19,29,1,'absent'),(20,29,4,'absent'),(21,29,2,'absent'),(22,30,1,'absent'),(23,30,4,'absent'),(24,30,2,'absent'),(25,31,1,'absent'),(26,31,4,'absent'),(27,31,2,'absent'),(28,32,1,'absent'),(29,32,4,'absent'),(30,32,2,'absent'),(31,33,1,'present'),(32,33,4,'not participating'),(33,33,2,'absent'),(34,34,1,'present'),(35,34,4,'absent'),(36,34,2,'absent'),(37,35,1,'absent'),(38,35,4,'absent'),(39,35,2,'absent'),(40,36,1,'absent'),(41,36,4,'absent'),(42,36,2,'absent'),(43,37,1,'absent'),(44,37,4,'absent'),(45,37,2,'absent'),(46,38,1,'absent'),(47,38,4,'absent'),(48,38,2,'absent'),(49,39,1,'absent'),(50,39,4,'absent'),(51,39,2,'absent'),(52,40,1,'absent'),(53,40,4,'absent'),(54,40,2,'absent'),(55,41,1,'absent'),(56,41,4,'absent'),(57,41,2,'absent'),(58,42,1,'absent'),(59,42,4,'absent'),(60,42,2,'absent'),(61,43,1,'absent'),(62,43,4,'absent'),(63,43,2,'absent'),(64,44,1,'absent'),(65,44,4,'absent'),(66,44,2,'absent'),(67,45,1,'absent'),(68,45,4,'absent'),(69,45,2,'absent'),(70,46,1,'absent'),(71,46,4,'absent'),(72,46,2,'absent'),(73,47,1,'absent'),(74,47,4,'absent'),(75,47,2,'absent'),(76,48,1,'absent'),(77,48,4,'absent'),(78,48,2,'absent'),(79,49,1,'absent'),(80,49,4,'absent'),(81,49,2,'absent'),(82,50,1,'absent'),(83,50,4,'absent'),(84,50,2,'absent'),(85,51,1,'absent'),(86,51,4,'absent'),(87,51,2,'absent'),(88,52,1,'absent'),(89,52,4,'absent'),(90,52,2,'absent'),(91,53,1,'absent'),(92,53,4,'absent'),(93,53,2,'absent'),(94,54,1,'absent'),(95,54,4,'absent'),(96,54,2,'absent'),(97,55,1,'absent'),(98,55,4,'absent'),(99,55,2,'absent'),(100,56,1,'absent'),(101,56,3,'absent'),(102,57,1,'absent'),(103,57,4,'absent'),(104,57,2,'absent'),(105,58,4,'absent'),(106,58,2,'absent'),(107,59,1,'absent'),(108,59,4,'absent'),(109,59,2,'absent'),(110,60,1,'absent'),(111,60,4,'absent'),(112,60,2,'absent'),(113,61,4,'absent'),(114,61,2,'absent'),(115,62,1,'absent'),(116,62,4,'absent'),(117,62,2,'absent'),(118,63,4,'absent'),(119,63,2,'absent'),(120,64,1,'present'),(121,64,4,'present'),(122,64,2,'present'),(123,65,1,'absent'),(124,65,4,'absent'),(125,65,2,'absent'),(126,66,1,'absent'),(127,66,4,'present'),(128,66,2,'absent');
/*!40000 ALTER TABLE `EscalationAttendance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FSC`
--

DROP TABLE IF EXISTS `FSC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `FSC` (
  `fscId` int(11) NOT NULL AUTO_INCREMENT,
  `buildingId` int(11) NOT NULL,
  `documentName` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `documentKey` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`fscId`),
  KEY `buildingId` (`buildingId`),
  CONSTRAINT `FSC_ibfk_1` FOREIGN KEY (`buildingId`) REFERENCES `Building` (`buildingId`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FSC`
--

LOCK TABLES `FSC` WRITE;
/*!40000 ALTER TABLE `FSC` DISABLE KEYS */;
INSERT INTO `FSC` VALUES (4,1,'FSCTest_0001_1554348344760.jpeg','test/fsc/FSCTest_0001_1554348344760.jpeg'),(5,1,'FSCTest_0001_1554352311818.jpeg','test/fsc/FSCTest_0001_1554352311818.jpeg'),(6,3,'FSCTest_0001_1554352541430.jpeg','test/fsc/FSCTest_0001_1554352541430.jpeg'),(7,4,'FSCTest_0001_1554352597207.jpeg','test/fsc/FSCTest_0001_1554352597207.jpeg'),(8,1,'FPTC-AB-FP-204-6-8(2s-3s-4s)_FP-204(2ND)-Model.pdf','test/fsc/FSCTest_0001_1554352645033.pdf'),(9,1,'FSCTest_0001_1554358071481.jpeg','test/fsc/FSCTest_0001_1554358071481.jpeg'),(10,1,'FSCTest_0001_1554363731075.jpeg','test/fsc/FSCTest_0001_1554363731075.jpeg'),(11,1,'IMG_2376.JPG.jpeg','test/fsc/FSCtest_userid_636899671363690240.jpeg'),(12,1,'IMG_2333.JPG.jpeg','test/fsc/FSCtest_userid_636899679276425856.jpeg'),(13,1,'IMG_2333.JPG.jpeg','test/fsc/FSCtest_userid_636899679276425856.jpeg'),(14,1,'IMG_20190105_103616_324.jpg','test/fsc/FSCTest_0001_1554372748070.jpeg'),(15,1,'IMG_2114.PNG.jpeg','test/fsc/FSCtest_userid_636899702086461184.jpeg'),(16,2,'IMG_20190112_152008_116.jpg','test/fsc/FSCTest_0001_1554374022893.jpeg'),(17,3,'FSCTest_0001_1554374283665.jpeg','test/fsc/FSCTest_0001_1554374283665.jpeg'),(18,2,'Escalation Process and Preparedness.pdf','test/fsc/FSCTest_0001_1554453999376.pdf'),(19,2,'IMG_20190220_205148_020.jpg','building_2/fsc/FSC_21554454462258.jpeg'),(20,2,'DrawingTest_0001_1554438333902.jpeg','building_2/fsc/FSC_2_1554454580285.jpeg');
/*!40000 ALTER TABLE `FSC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FireDrillAttendance`
--

DROP TABLE IF EXISTS `FireDrillAttendance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `FireDrillAttendance` (
  `fireDrillAttendanceId` int(11) NOT NULL AUTO_INCREMENT,
  `tenantEmployeeId` int(11) DEFAULT NULL,
  `fireDrillId` int(11) DEFAULT NULL,
  `status` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`fireDrillAttendanceId`),
  KEY `tenantEmployeeId` (`tenantEmployeeId`),
  KEY `fireDrillId` (`fireDrillId`),
  CONSTRAINT `FireDrillAttandence_ibfk_2` FOREIGN KEY (`fireDrillId`) REFERENCES `FireDrillSchedule` (`fireDrillId`),
  CONSTRAINT `FireDrillAttendance_ibfk_1` FOREIGN KEY (`tenantEmployeeId`) REFERENCES `TenantEmployee` (`tenantEmployeeId`)
) ENGINE=InnoDB AUTO_INCREMENT=626 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FireDrillAttendance`
--

LOCK TABLES `FireDrillAttendance` WRITE;
/*!40000 ALTER TABLE `FireDrillAttendance` DISABLE KEYS */;
INSERT INTO `FireDrillAttendance` VALUES (1,1,11,'absent'),(2,1,18,'absent'),(3,1,19,'present'),(4,1,20,'absent'),(5,1,21,'absent'),(6,1,22,'absent'),(7,1,23,'present'),(8,5,23,'present'),(9,6,23,'absent'),(10,7,23,'present'),(11,8,23,'absent'),(12,1,24,'absent'),(13,5,24,'absent'),(14,6,24,'present'),(15,7,24,'present'),(16,8,24,'present'),(17,1,25,'absent'),(18,5,25,'absent'),(19,6,25,'absent'),(20,7,25,'absent'),(21,8,25,'absent'),(22,1,26,'absent'),(23,5,26,'absent'),(24,6,26,'absent'),(25,7,26,'absent'),(26,8,26,'absent'),(27,1,27,'absent'),(28,5,27,'absent'),(29,6,27,'absent'),(30,7,27,'absent'),(31,8,27,'absent'),(32,1,28,'absent'),(33,5,28,'absent'),(34,6,28,'absent'),(35,7,28,'absent'),(36,8,28,'absent'),(37,1,29,'absent'),(38,5,29,'absent'),(39,6,29,'absent'),(40,7,29,'absent'),(41,8,29,'absent'),(42,1,30,'absent'),(43,5,30,'absent'),(44,6,30,'absent'),(45,7,30,'absent'),(46,8,30,'absent'),(47,1,31,'absent'),(48,5,31,'absent'),(49,6,31,'absent'),(50,7,31,'absent'),(51,8,31,'absent'),(52,1,32,'absent'),(53,5,32,'absent'),(54,6,32,'absent'),(55,7,32,'absent'),(56,8,32,'absent'),(57,1,33,'absent'),(58,5,33,'absent'),(59,6,33,'absent'),(60,7,33,'absent'),(61,8,33,'absent'),(62,1,34,'absent'),(63,2,34,'absent'),(64,3,34,'absent'),(65,4,34,'absent'),(66,8,34,'absent'),(67,1,35,'absent'),(68,5,35,'absent'),(69,6,35,'absent'),(70,7,35,'absent'),(71,8,35,'absent'),(72,1,36,'absent'),(73,2,36,'absent'),(74,3,36,'absent'),(75,4,36,'absent'),(76,8,36,'absent'),(77,1,37,'absent'),(78,2,37,'absent'),(79,3,37,'absent'),(80,4,37,'absent'),(81,8,37,'absent'),(82,1,38,'absent'),(83,2,38,'absent'),(84,3,38,'absent'),(85,4,38,'absent'),(86,8,38,'absent'),(87,1,39,'absent'),(88,5,39,'absent'),(89,6,39,'absent'),(90,7,39,'absent'),(91,8,39,'absent'),(92,1,40,'absent'),(93,4,40,'absent'),(94,6,40,'absent'),(95,7,40,'absent'),(96,8,40,'absent'),(97,1,41,'absent'),(98,4,41,'absent'),(99,6,41,'absent'),(100,7,41,'absent'),(101,8,41,'absent'),(102,1,42,'absent'),(103,4,42,'absent'),(104,6,42,'absent'),(105,7,42,'absent'),(106,8,42,'absent'),(107,1,43,'absent'),(108,4,43,'absent'),(109,6,43,'absent'),(110,7,43,'absent'),(111,8,43,'absent'),(112,1,44,'absent'),(113,4,44,'absent'),(114,6,44,'absent'),(115,7,44,'absent'),(116,8,44,'absent'),(117,1,45,'absent'),(118,4,45,'absent'),(119,6,45,'absent'),(120,7,45,'absent'),(121,8,45,'absent'),(122,1,46,'absent'),(123,4,46,'absent'),(124,6,46,'absent'),(125,7,46,'absent'),(126,8,46,'absent'),(127,1,47,'absent'),(128,4,47,'absent'),(129,6,47,'absent'),(130,7,47,'absent'),(131,8,47,'absent'),(132,1,48,'absent'),(133,4,48,'absent'),(134,6,48,'absent'),(135,7,48,'absent'),(136,8,48,'absent'),(137,1,49,'absent'),(138,4,49,'absent'),(139,6,49,'absent'),(140,7,49,'absent'),(141,8,49,'absent'),(142,1,50,'absent'),(143,4,50,'absent'),(144,6,50,'absent'),(145,7,50,'absent'),(146,8,50,'absent'),(147,1,51,'absent'),(148,4,51,'absent'),(149,6,51,'absent'),(150,7,51,'absent'),(151,8,51,'absent'),(152,1,52,'absent'),(153,4,52,'absent'),(154,6,52,'absent'),(155,7,52,'absent'),(156,8,52,'absent'),(157,1,53,'absent'),(158,4,53,'absent'),(159,6,53,'absent'),(160,7,53,'absent'),(161,8,53,'absent'),(162,1,54,'absent'),(163,4,54,'absent'),(164,6,54,'absent'),(165,7,54,'absent'),(166,8,54,'absent'),(167,1,55,'absent'),(168,4,55,'absent'),(169,6,55,'absent'),(170,7,55,'absent'),(171,8,55,'absent'),(172,1,56,'absent'),(173,4,56,'absent'),(174,6,56,'absent'),(175,7,56,'absent'),(176,8,56,'absent'),(177,1,57,'absent'),(178,4,57,'absent'),(179,6,57,'absent'),(180,7,57,'absent'),(181,8,57,'absent'),(182,1,58,'absent'),(183,4,58,'absent'),(184,6,58,'absent'),(185,7,58,'absent'),(186,8,58,'absent'),(187,1,59,'absent'),(188,4,59,'absent'),(189,6,59,'absent'),(190,7,59,'absent'),(191,8,59,'absent'),(192,1,60,'absent'),(193,4,60,'absent'),(194,6,60,'absent'),(195,7,60,'absent'),(196,8,60,'absent'),(197,1,61,'absent'),(198,4,61,'absent'),(199,6,61,'absent'),(200,7,61,'absent'),(201,8,61,'absent'),(202,1,62,'absent'),(203,4,62,'absent'),(204,6,62,'absent'),(205,7,62,'absent'),(206,8,62,'absent'),(207,1,63,'absent'),(208,4,63,'absent'),(209,6,63,'absent'),(210,7,63,'absent'),(211,8,63,'absent'),(212,1,64,'absent'),(213,4,64,'absent'),(214,6,64,'absent'),(215,7,64,'absent'),(216,8,64,'absent'),(217,1,65,'absent'),(218,4,65,'absent'),(219,6,65,'absent'),(220,7,65,'absent'),(221,8,65,'absent'),(222,1,66,'absent'),(223,4,66,'absent'),(224,6,66,'absent'),(225,7,66,'absent'),(226,8,66,'absent'),(227,1,67,'absent'),(228,4,67,'absent'),(229,6,67,'absent'),(230,7,67,'absent'),(231,8,67,'absent'),(232,1,68,'absent'),(233,4,68,'absent'),(234,6,68,'absent'),(235,7,68,'absent'),(236,8,68,'absent'),(237,1,69,'absent'),(238,4,69,'absent'),(239,6,69,'absent'),(240,7,69,'absent'),(241,8,69,'absent'),(242,1,70,'absent'),(243,4,70,'absent'),(244,6,70,'absent'),(245,7,70,'absent'),(246,8,70,'absent'),(247,1,71,'absent'),(248,4,71,'absent'),(249,6,71,'absent'),(250,7,71,'absent'),(251,8,71,'absent'),(252,1,72,'absent'),(253,4,72,'absent'),(254,6,72,'absent'),(255,7,72,'absent'),(256,8,72,'absent'),(257,1,73,'absent'),(258,4,73,'absent'),(259,6,73,'absent'),(260,7,73,'absent'),(261,8,73,'absent'),(262,1,74,'absent'),(263,4,74,'absent'),(264,6,74,'absent'),(265,7,74,'absent'),(266,8,74,'absent'),(267,1,75,'absent'),(268,4,75,'absent'),(269,6,75,'absent'),(270,7,75,'absent'),(271,8,75,'absent'),(272,1,76,'absent'),(273,4,76,'absent'),(274,6,76,'absent'),(275,7,76,'absent'),(276,8,76,'absent'),(277,1,77,'absent'),(278,4,77,'absent'),(279,6,77,'absent'),(280,7,77,'absent'),(281,8,77,'absent'),(282,1,78,'absent'),(283,4,78,'absent'),(284,6,78,'absent'),(285,7,78,'absent'),(286,8,78,'absent'),(287,1,79,'absent'),(288,4,79,'absent'),(289,6,79,'absent'),(290,7,79,'absent'),(291,8,79,'absent'),(292,1,80,'present'),(293,4,80,'absent'),(294,6,80,'absent'),(295,7,80,'absent'),(296,8,80,'present'),(297,1,81,'absent'),(298,5,81,'absent'),(299,6,81,'absent'),(300,7,81,'absent'),(301,8,81,'absent'),(302,1,82,'absent'),(303,3,82,'absent'),(304,4,82,'absent'),(305,5,82,'absent'),(306,6,82,'absent'),(307,7,82,'absent'),(308,8,82,'absent'),(309,9,82,'absent'),(310,196,82,'absent'),(311,20,82,'absent'),(312,22,82,'absent'),(313,23,82,'absent'),(314,24,82,'absent'),(315,25,82,'absent'),(316,26,82,'absent'),(317,27,82,'absent'),(318,28,82,'absent'),(319,29,82,'absent'),(320,30,82,'absent'),(321,32,82,'absent'),(322,33,82,'absent'),(323,34,82,'absent'),(324,35,82,'absent'),(325,36,82,'absent'),(326,37,82,'absent'),(327,38,82,'absent'),(328,39,82,'absent'),(329,40,82,'absent'),(330,41,82,'absent'),(331,43,82,'absent'),(332,44,82,'absent'),(333,45,82,'absent'),(334,46,82,'absent'),(335,47,82,'absent'),(336,48,82,'absent'),(337,49,82,'absent'),(338,1,83,'absent'),(339,3,83,'absent'),(340,4,83,'absent'),(341,5,83,'absent'),(342,6,83,'absent'),(343,7,83,'absent'),(344,8,83,'absent'),(345,9,83,'absent'),(346,196,83,'absent'),(347,20,83,'absent'),(348,22,83,'absent'),(349,23,83,'absent'),(350,24,83,'absent'),(351,25,83,'absent'),(352,26,83,'absent'),(353,27,83,'absent'),(354,28,83,'absent'),(355,29,83,'absent'),(356,30,83,'absent'),(357,32,83,'absent'),(358,33,83,'absent'),(359,34,83,'absent'),(360,35,83,'absent'),(361,36,83,'absent'),(362,37,83,'absent'),(363,38,83,'absent'),(364,39,83,'absent'),(365,40,83,'absent'),(366,41,83,'absent'),(367,43,83,'absent'),(368,44,83,'absent'),(369,45,83,'absent'),(370,46,83,'absent'),(371,47,83,'absent'),(372,48,83,'absent'),(373,49,83,'absent'),(374,1,84,'absent'),(375,3,84,'absent'),(376,4,84,'absent'),(377,5,84,'absent'),(378,6,84,'absent'),(379,7,84,'absent'),(380,8,84,'absent'),(381,9,84,'absent'),(382,196,84,'absent'),(383,20,84,'absent'),(384,22,84,'absent'),(385,23,84,'absent'),(386,24,84,'absent'),(387,25,84,'absent'),(388,26,84,'absent'),(389,27,84,'absent'),(390,28,84,'absent'),(391,29,84,'absent'),(392,30,84,'absent'),(393,32,84,'absent'),(394,33,84,'absent'),(395,34,84,'absent'),(396,35,84,'absent'),(397,36,84,'absent'),(398,37,84,'absent'),(399,38,84,'absent'),(400,39,84,'absent'),(401,40,84,'absent'),(402,41,84,'absent'),(403,43,84,'absent'),(404,44,84,'absent'),(405,45,84,'absent'),(406,46,84,'absent'),(407,47,84,'absent'),(408,48,84,'absent'),(409,49,84,'absent'),(410,1,85,'absent'),(411,3,85,'absent'),(412,4,85,'absent'),(413,5,85,'absent'),(414,6,85,'absent'),(415,7,85,'absent'),(416,8,85,'absent'),(417,9,85,'absent'),(418,196,85,'absent'),(419,20,85,'absent'),(420,22,85,'absent'),(421,23,85,'absent'),(422,24,85,'absent'),(423,25,85,'absent'),(424,26,85,'absent'),(425,27,85,'absent'),(426,28,85,'absent'),(427,29,85,'absent'),(428,30,85,'absent'),(429,32,85,'absent'),(430,33,85,'absent'),(431,34,85,'absent'),(432,35,85,'absent'),(433,36,85,'absent'),(434,37,85,'absent'),(435,38,85,'absent'),(436,39,85,'absent'),(437,40,85,'absent'),(438,41,85,'absent'),(439,43,85,'absent'),(440,44,85,'absent'),(441,45,85,'absent'),(442,46,85,'absent'),(443,47,85,'absent'),(444,48,85,'absent'),(445,49,85,'absent'),(446,1,86,'absent'),(447,3,86,'absent'),(448,4,86,'absent'),(449,5,86,'absent'),(450,6,86,'absent'),(451,7,86,'absent'),(452,8,86,'absent'),(453,9,86,'absent'),(454,196,86,'absent'),(455,20,86,'absent'),(456,22,86,'absent'),(457,23,86,'absent'),(458,24,86,'absent'),(459,25,86,'absent'),(460,26,86,'absent'),(461,27,86,'absent'),(462,28,86,'absent'),(463,29,86,'absent'),(464,30,86,'absent'),(465,32,86,'absent'),(466,33,86,'absent'),(467,34,86,'absent'),(468,35,86,'absent'),(469,36,86,'absent'),(470,37,86,'absent'),(471,38,86,'absent'),(472,39,86,'absent'),(473,40,86,'absent'),(474,41,86,'absent'),(475,43,86,'absent'),(476,44,86,'absent'),(477,45,86,'absent'),(478,46,86,'absent'),(479,47,86,'absent'),(480,48,86,'absent'),(481,49,86,'absent'),(482,1,87,'absent'),(483,3,87,'absent'),(484,4,87,'absent'),(485,5,87,'absent'),(486,6,87,'absent'),(487,7,87,'absent'),(488,8,87,'absent'),(489,9,87,'absent'),(490,196,87,'absent'),(491,20,87,'absent'),(492,22,87,'absent'),(493,23,87,'absent'),(494,24,87,'absent'),(495,25,87,'absent'),(496,26,87,'absent'),(497,27,87,'absent'),(498,28,87,'absent'),(499,29,87,'absent'),(500,30,87,'absent'),(501,32,87,'absent'),(502,33,87,'absent'),(503,34,87,'absent'),(504,35,87,'absent'),(505,36,87,'absent'),(506,37,87,'absent'),(507,38,87,'absent'),(508,39,87,'absent'),(509,40,87,'absent'),(510,41,87,'absent'),(511,43,87,'absent'),(512,44,87,'absent'),(513,45,87,'absent'),(514,46,87,'absent'),(515,47,87,'absent'),(516,48,87,'absent'),(517,49,87,'absent'),(518,1,88,'absent'),(519,3,88,'absent'),(520,4,88,'absent'),(521,5,88,'absent'),(522,6,88,'absent'),(523,7,88,'absent'),(524,8,88,'absent'),(525,9,88,'absent'),(526,196,88,'absent'),(527,20,88,'absent'),(528,22,88,'absent'),(529,23,88,'absent'),(530,24,88,'absent'),(531,25,88,'absent'),(532,26,88,'absent'),(533,27,88,'absent'),(534,28,88,'absent'),(535,29,88,'absent'),(536,30,88,'absent'),(537,32,88,'absent'),(538,33,88,'absent'),(539,34,88,'absent'),(540,35,88,'absent'),(541,36,88,'absent'),(542,37,88,'absent'),(543,38,88,'absent'),(544,39,88,'absent'),(545,40,88,'absent'),(546,41,88,'absent'),(547,43,88,'absent'),(548,44,88,'absent'),(549,45,88,'absent'),(550,46,88,'absent'),(551,47,88,'absent'),(552,48,88,'absent'),(553,49,88,'absent'),(554,1,89,'absent'),(555,3,89,'absent'),(556,4,89,'absent'),(557,5,89,'absent'),(558,6,89,'absent'),(559,7,89,'absent'),(560,8,89,'absent'),(561,9,89,'absent'),(562,196,89,'absent'),(563,20,89,'absent'),(564,22,89,'absent'),(565,23,89,'absent'),(566,24,89,'absent'),(567,25,89,'absent'),(568,26,89,'absent'),(569,27,89,'absent'),(570,28,89,'absent'),(571,29,89,'absent'),(572,30,89,'absent'),(573,32,89,'absent'),(574,33,89,'absent'),(575,34,89,'absent'),(576,35,89,'absent'),(577,36,89,'absent'),(578,37,89,'absent'),(579,38,89,'absent'),(580,39,89,'absent'),(581,40,89,'absent'),(582,41,89,'absent'),(583,43,89,'absent'),(584,44,89,'absent'),(585,45,89,'absent'),(586,46,89,'absent'),(587,47,89,'absent'),(588,48,89,'absent'),(589,49,89,'absent'),(590,1,90,'absent'),(591,3,90,'absent'),(592,4,90,'absent'),(593,5,90,'absent'),(594,6,90,'absent'),(595,7,90,'absent'),(596,8,90,'absent'),(597,9,90,'absent'),(598,196,90,'absent'),(599,20,90,'absent'),(600,22,90,'absent'),(601,23,90,'absent'),(602,24,90,'absent'),(603,25,90,'absent'),(604,26,90,'absent'),(605,27,90,'absent'),(606,28,90,'absent'),(607,29,90,'absent'),(608,30,90,'absent'),(609,32,90,'absent'),(610,33,90,'absent'),(611,34,90,'absent'),(612,35,90,'absent'),(613,36,90,'absent'),(614,37,90,'absent'),(615,38,90,'absent'),(616,39,90,'absent'),(617,40,90,'absent'),(618,41,90,'absent'),(619,43,90,'absent'),(620,44,90,'absent'),(621,45,90,'absent'),(622,46,90,'absent'),(623,47,90,'absent'),(624,48,90,'absent'),(625,49,90,'absent');
/*!40000 ALTER TABLE `FireDrillAttendance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FireDrillSchedule`
--

DROP TABLE IF EXISTS `FireDrillSchedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `FireDrillSchedule` (
  `fireDrillId` int(11) NOT NULL AUTO_INCREMENT,
  `buildingId` int(11) NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fireDrillTypeId` int(11) DEFAULT NULL,
  `status` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `scheduledBy` int(11) NOT NULL,
  `dateTime` datetime(3) NOT NULL,
  `lastUpdate` datetime(3) NOT NULL,
  `completeDateTime` datetime(3) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `editedBy` int(11) DEFAULT NULL,
  PRIMARY KEY (`fireDrillId`),
  KEY `buildingId` (`buildingId`),
  KEY `fireDrillTypeId` (`fireDrillTypeId`),
  KEY `scheduledBy` (`scheduledBy`),
  CONSTRAINT `FireDrillSchedule_ibfk_1` FOREIGN KEY (`buildingId`) REFERENCES `Building` (`buildingId`),
  CONSTRAINT `FireDrillSchedule_ibfk_2` FOREIGN KEY (`fireDrillTypeId`) REFERENCES `FireDrillType` (`fireDrillTypeId`),
  CONSTRAINT `FireDrillSchedule_ibfk_3` FOREIGN KEY (`scheduledBy`) REFERENCES `User` (`userId`)
) ENGINE=InnoDB AUTO_INCREMENT=91 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FireDrillSchedule`
--

LOCK TABLES `FireDrillSchedule` WRITE;
/*!40000 ALTER TABLE `FireDrillSchedule` DISABLE KEYS */;
INSERT INTO `FireDrillSchedule` VALUES (1,1,NULL,NULL,'close',1,'2009-01-01 15:00:01.000','2009-01-01 15:00:10.004','2009-01-01 15:00:10.000',0,1),(2,2,NULL,NULL,'close',2,'2009-01-02 16:00:02.123','2009-01-02 16:20:00.013','2009-01-02 16:20:10.013',0,2),(3,3,NULL,NULL,'close',1,'2009-01-03 15:00:01.004','2009-01-03 17:00:10.100','2009-01-03 17:30:15.000',0,3),(4,4,NULL,NULL,'close',2,'2009-01-04 15:00:01.002','2009-01-04 18:00:10.020','2009-01-04 18:30:08.080',0,4),(5,1,'the start ',NULL,'close',3,'2009-01-05 15:00:01.034','2009-01-05 19:01:10.001','2019-04-09 10:03:50.000',0,2),(6,2,NULL,NULL,'close',4,'2019-04-10 11:04:16.000','2019-04-10 11:04:16.000','2019-04-12 11:24:37.000',0,46),(7,3,NULL,NULL,'open',1,'2020-01-11 17:00:01.050','2020-01-11 17:00:01.050',NULL,0,3),(8,4,NULL,NULL,'open',2,'2009-01-08 15:00:01.100','2009-01-08 22:04:10.020',NULL,0,4),(9,1,'4day later',NULL,'close',3,'2009-01-09 15:00:01.030','2009-01-09 23:05:10.003','2019-04-09 10:04:13.000',0,2),(10,2,NULL,NULL,'open',4,'2019-04-10 11:09:16.000','2019-04-10 11:09:16.000',NULL,0,2),(11,3,NULL,NULL,'open',1,'2020-01-11 17:00:01.050','2009-01-11 02:07:10.100',NULL,0,3),(12,4,NULL,NULL,'open',2,'2020-01-12 18:00:01.000','2009-01-12 03:08:10.020',NULL,0,4),(13,1,'coming year',NULL,'open',3,'2020-01-13 19:00:01.067','2019-04-05 10:14:08.000',NULL,1,1),(14,2,NULL,NULL,'open',4,'2020-01-14 20:00:01.089','2009-01-14 05:10:10.020',NULL,0,2),(15,3,NULL,NULL,'open',2,'2020-01-15 21:00:01.012','2009-01-15 06:11:10.100',NULL,0,3),(16,4,NULL,NULL,'open',1,'2020-01-16 22:00:01.100','2009-01-16 07:12:10.020',NULL,0,4),(17,1,'',1,'close',1,'2019-04-05 11:38:16.000','2019-04-05 11:38:16.000','2019-04-09 10:04:16.000',0,2),(18,1,'',2,'close',1,'2019-04-05 11:39:36.000','2019-04-10 11:09:16.000','2019-04-09 10:04:19.000',0,2),(19,1,'',2,'close',1,'2019-04-06 11:46:24.000','2019-04-05 11:46:52.000','2019-04-09 10:04:21.000',0,2),(20,1,'',3,'close',1,'2019-04-06 00:47:59.000','2019-04-05 11:47:23.000','2019-04-09 10:04:24.000',0,2),(21,1,'',3,'close',1,'2019-04-05 11:51:26.000','2019-04-05 11:51:31.000','2019-04-09 10:04:27.000',0,2),(22,1,'',3,'close',1,'2019-04-05 11:52:46.000','2019-04-05 11:52:51.000','2019-04-10 11:14:56.000',0,2),(23,1,'',1,'close',2,'2019-04-08 10:25:58.000','2019-04-08 10:16:33.000','2019-04-08 13:07:43.000',0,2),(24,1,'This is the fire drill dry run testing 1',1,'close',2,'2019-04-09 09:50:27.000','2019-04-09 09:45:22.000','2019-04-09 10:02:32.000',0,2),(25,1,'Fire Drill Now',3,'close',2,'2019-04-09 10:04:52.000','2019-04-09 10:04:38.000','2019-04-09 10:05:09.000',0,2),(26,1,'',1,'close',2,'2019-04-09 12:05:27.000','2019-04-09 11:59:43.000','2019-04-10 11:15:02.000',0,2),(27,1,'',1,'close',2,'2019-04-10 11:21:52.000','2019-04-10 11:20:10.000','2019-04-10 11:24:35.000',0,2),(28,1,'',1,'open',1,'2019-04-10 11:29:48.000','2019-04-10 11:29:13.000',NULL,1,1),(29,1,'',1,'close',1,'2019-04-10 11:32:14.000','2019-04-10 11:30:30.000','2019-04-10 11:37:28.000',0,2),(30,1,'',1,'close',1,'2019-04-10 11:35:33.000','2019-04-10 11:30:46.000','2019-04-10 13:17:14.000',0,2),(31,1,'',2,'close',2,'2019-04-10 14:40:14.000','2019-04-10 13:27:26.000','2019-04-10 14:45:29.000',0,2),(32,1,'',1,'close',2,'2019-04-10 14:50:41.000','2019-04-10 14:46:00.000','2019-04-10 15:11:38.000',0,2),(33,1,'',1,'close',2,'2019-04-10 15:15:40.000','2019-04-10 15:11:53.000','2019-04-10 15:31:41.000',0,4),(34,1,'e\n',1,'close',2,'2019-04-10 15:30:55.000','2019-04-10 15:12:17.000','2019-04-10 15:31:39.000',0,4),(35,1,'',1,'close',4,'2019-04-10 15:40:43.000','2019-04-10 15:37:28.000','2019-04-10 15:42:39.000',0,4),(36,1,'',1,'close',4,'2019-04-10 15:44:07.000','2019-04-10 15:43:29.000','2019-04-10 15:44:45.000',0,4),(37,1,'',1,'close',4,'2019-04-10 15:47:27.000','2019-04-10 15:44:43.000','2019-04-10 15:48:24.000',0,4),(38,1,'',1,'close',4,'2019-04-10 15:49:33.000','2019-04-10 15:48:48.000','2019-04-10 15:50:24.000',0,4),(39,1,'',1,'open',4,'2019-04-10 15:55:30.000','2019-04-10 15:51:35.000',NULL,1,4),(40,1,'',1,'close',4,'2019-04-10 15:52:36.000','2019-04-10 15:51:51.000','2019-04-10 16:24:15.000',0,2),(41,1,'',1,'close',2,'2019-04-10 16:26:32.000','2019-04-10 16:24:46.000','2019-04-10 16:41:34.000',0,2),(42,1,'',1,'close',2,'2019-04-10 16:28:48.000','2019-04-10 16:25:14.000','2019-04-10 16:41:36.000',0,2),(43,1,'',1,'close',2,'2019-04-10 16:44:42.000','2019-04-10 16:42:54.000','2019-04-10 16:46:00.000',0,2),(44,1,'j\n',1,'close',2,'2019-04-10 16:47:56.000','2019-04-10 16:43:17.000','2019-04-10 16:53:59.000',0,2),(45,1,'',1,'close',2,'2019-04-10 16:57:04.000','2019-04-10 16:54:15.000','2019-04-10 16:57:52.000',0,2),(46,1,'',1,'close',2,'2019-04-10 17:00:57.000','2019-04-10 16:58:12.000','2019-04-10 17:02:28.000',0,2),(47,1,'',1,'close',2,'2019-04-10 17:04:31.000','2019-04-10 17:02:54.000','2019-04-10 17:05:37.000',0,4),(48,1,'',1,'close',4,'2019-04-10 17:06:40.000','2019-04-10 17:05:53.000','2019-04-10 17:08:09.000',0,4),(49,1,'',1,'close',4,'2019-04-10 17:09:11.000','2019-04-10 17:08:24.000','2019-04-10 17:55:49.000',0,2),(50,1,'',1,'close',2,'2019-04-11 09:30:51.000','2019-04-10 18:03:05.000','2019-04-11 14:13:00.000',0,2),(51,1,'',1,'close',2,'2019-04-11 09:59:21.000','2019-04-10 17:56:45.000','2019-04-11 14:13:03.000',0,2),(52,1,'',1,'close',2,'2019-04-11 09:45:49.000','2019-04-10 17:57:03.000','2019-04-11 14:13:05.000',0,2),(53,1,'',1,'close',2,'2019-04-11 10:15:14.000','2019-04-10 17:57:27.000','2019-04-11 14:13:06.000',0,2),(54,1,'',1,'close',2,'2019-04-11 10:30:31.000','2019-04-10 17:57:49.000','2019-04-11 14:13:08.000',0,2),(55,1,'',1,'close',2,'2019-04-11 10:45:58.000','2019-04-10 17:58:10.000','2019-04-11 14:13:10.000',0,2),(56,1,'',1,'close',2,'2019-04-11 11:00:11.000','2019-04-10 17:58:23.000','2019-04-11 14:13:12.000',0,2),(57,1,'',1,'close',2,'2019-04-11 11:15:28.000','2019-04-10 17:58:44.000','2019-04-11 14:13:15.000',0,2),(58,1,'',1,'close',2,'2019-04-11 11:30:13.000','2019-04-10 17:59:24.000','2019-04-11 14:13:18.000',0,2),(59,1,'',1,'close',2,'2019-04-11 11:45:26.000','2019-04-10 17:59:41.000','2019-04-11 14:13:20.000',0,2),(60,1,'',1,'close',2,'2019-04-11 12:00:48.000','2019-04-10 18:00:13.000','2019-04-11 14:13:22.000',0,2),(61,1,'',2,'close',2,'2019-04-11 12:15:19.000','2019-04-10 18:00:40.000','2019-04-11 14:13:26.000',0,2),(62,1,'',2,'open',2,'2019-04-11 12:15:19.000','2019-04-10 18:03:04.000',NULL,1,2),(63,1,'',1,'open',2,'2019-04-12 12:30:18.000','2019-04-11 14:18:17.000',NULL,1,2),(64,1,'',1,'open',2,'2019-04-12 12:45:25.000','2019-04-11 14:18:20.000',NULL,1,2),(65,1,'',1,'close',2,'2019-04-11 13:00:50.000','2019-04-10 18:07:04.000','2019-04-11 14:13:47.000',0,2),(66,1,'',1,'close',2,'2019-04-11 13:15:39.000','2019-04-10 18:07:49.000','2019-04-11 14:13:50.000',0,2),(67,1,'',1,'close',2,'2019-04-11 13:45:57.000','2019-04-10 18:08:06.000','2019-04-11 14:13:53.000',0,2),(68,1,'',1,'close',2,'2019-04-11 14:21:55.000','2019-04-11 14:19:14.000','2019-04-11 14:23:10.000',0,2),(69,1,'',1,'open',2,'2019-04-11 14:35:42.000','2019-04-11 14:36:41.000',NULL,1,2),(70,1,'',1,'close',1,'1970-01-03 11:34:38.000','2019-04-11 14:52:04.000','2019-04-11 14:53:34.000',0,2),(71,1,'',1,'close',2,'1970-01-03 11:45:56.000','2019-04-11 15:03:34.000','2019-04-11 15:04:15.000',0,2),(72,1,'',1,'close',2,'1970-01-01 07:55:54.000','2019-04-11 15:11:11.000','2019-04-11 15:11:19.000',0,2),(73,1,'',1,'close',2,'1970-01-01 07:55:54.000','2019-04-11 15:11:12.000','2019-04-11 15:12:03.000',0,2),(74,1,'',1,'close',2,'1970-01-01 07:55:54.000','2019-04-11 15:11:30.000','2019-04-11 15:14:58.000',0,2),(75,1,'',1,'open',2,'2019-04-11 15:17:12.000','2019-04-11 15:17:39.000',NULL,1,2),(76,1,'',1,'open',2,'2019-04-11 15:20:03.000','2019-04-11 15:21:50.000',NULL,1,2),(77,1,'',1,'open',2,'2019-04-11 15:22:50.000','2019-04-11 15:23:03.000',NULL,1,2),(78,1,'',1,'close',2,'2019-04-11 15:24:03.000','2019-04-11 15:23:16.000','2019-04-11 16:10:04.000',0,2),(79,1,'',1,'close',2,'2019-04-11 16:17:21.000','2019-04-11 16:14:41.000','2019-04-11 16:28:29.000',0,2),(80,1,'',1,'close',2,'2019-04-11 16:35:00.000','2019-04-11 16:32:33.000','2019-04-11 16:35:42.000',0,2),(81,1,'',1,'close',2,'2019-04-11 17:01:00.000','2019-04-11 16:59:46.000','2019-04-11 17:02:52.000',0,2),(82,1,'first testing after database reform',1,'close',46,'2019-04-12 12:15:00.000','2019-04-12 12:04:23.000','2019-04-12 12:16:35.000',0,46),(83,1,'',1,'close',46,'2019-04-12 12:30:00.000','2019-04-12 12:29:47.000','2019-04-12 12:32:02.000',0,46),(84,1,'',1,'open',46,'2019-04-12 12:33:00.000','2019-04-12 12:33:35.000',NULL,1,46),(85,1,'',1,'open',46,'2019-04-12 12:34:00.000','2019-04-12 12:35:52.000',NULL,1,46),(86,1,'',1,'open',46,'2019-04-12 12:37:00.000','2019-04-12 12:37:38.000',NULL,1,46),(87,1,'',1,'open',46,'2019-04-12 12:39:00.000','2019-04-12 12:39:42.000',NULL,1,46),(88,1,'',1,'open',46,'2019-04-12 12:42:00.000','2019-04-12 12:42:22.000',NULL,1,46),(89,1,'',1,'open',46,'2019-04-12 12:44:00.000','2019-04-12 12:44:34.000',NULL,1,46),(90,1,'',1,'close',46,'2019-04-12 12:45:00.000','2019-04-12 12:44:46.000','2019-04-12 14:48:52.000',0,46);
/*!40000 ALTER TABLE `FireDrillSchedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FireDrillType`
--

DROP TABLE IF EXISTS `FireDrillType`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `FireDrillType` (
  `fireDrillTypeId` int(11) NOT NULL AUTO_INCREMENT,
  `fireDrillTypeName` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`fireDrillTypeId`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FireDrillType`
--

LOCK TABLES `FireDrillType` WRITE;
/*!40000 ALTER TABLE `FireDrillType` DISABLE KEYS */;
INSERT INTO `FireDrillType` VALUES (1,'fire drill',0),(2,'dry run',0),(3,'real fire',0);
/*!40000 ALTER TABLE `FireDrillType` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `HazardReport`
--

DROP TABLE IF EXISTS `HazardReport`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `HazardReport` (
  `hazardReportId` int(11) NOT NULL AUTO_INCREMENT,
  `hazardReportName` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `buildingId` int(11) NOT NULL,
  `reporterId` int(11) NOT NULL,
  `status` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dateTime` datetime(3) NOT NULL,
  `lastUpdate` datetime(3) NOT NULL,
  `closeReporterId` int(11) DEFAULT NULL,
  `closeComment` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`hazardReportId`),
  KEY `reporterId` (`reporterId`),
  KEY `buildingId` (`buildingId`),
  KEY `closeReporterId` (`closeReporterId`),
  CONSTRAINT `HazardReport_ibfk_1` FOREIGN KEY (`reporterId`) REFERENCES `User` (`userId`),
  CONSTRAINT `HazardReport_ibfk_2` FOREIGN KEY (`closeReporterId`) REFERENCES `User` (`userId`),
  CONSTRAINT `HazardReport_ibfk_3` FOREIGN KEY (`buildingId`) REFERENCES `Building` (`buildingId`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `HazardReport`
--

LOCK TABLES `HazardReport` WRITE;
/*!40000 ALTER TABLE `HazardReport` DISABLE KEYS */;
INSERT INTO `HazardReport` VALUES (1,'Hazard',1,4,'close','2019-04-10 17:20:32.000','2019-04-10 17:20:32.000',4,'hazy',0),(2,'Obstruction',1,4,'open','2019-04-10 17:31:41.000','2019-04-10 17:31:41.000',NULL,NULL,0),(3,'Report1',1,4,'open','2019-04-10 17:44:34.000','2019-04-10 17:44:34.000',NULL,NULL,0),(4,'Report2',1,4,'open','2019-04-10 17:48:12.000','2019-04-10 17:48:12.000',NULL,NULL,0),(5,'Report3',1,4,'open','2019-04-10 17:57:18.000','2019-04-10 17:57:18.000',NULL,NULL,0),(6,'Report4',1,2,'close','2019-04-11 14:57:27.000','2019-04-11 14:57:27.000',2,'no comment',0),(7,'Report5',1,2,'open','2019-04-11 16:01:31.000','2019-04-11 16:01:31.000',NULL,NULL,0),(8,'Report6',4,2,'open','2019-04-11 17:21:56.000','2019-04-11 17:21:56.000',NULL,NULL,0),(9,'Report7',4,2,'open','2019-04-11 17:33:10.000','2019-04-11 17:33:10.000',NULL,NULL,0),(10,'Report8',4,2,'open','2019-04-11 17:44:27.000','2019-04-11 17:44:27.000',NULL,NULL,0),(11,'hazard',1,1,'open','2019-04-12 12:05:31.000','2019-04-12 12:05:31.000',NULL,NULL,0);
/*!40000 ALTER TABLE `HazardReport` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `HazardReportAnswer`
--

DROP TABLE IF EXISTS `HazardReportAnswer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `HazardReportAnswer` (
  `hazardReportAnswerId` int(11) NOT NULL AUTO_INCREMENT,
  `answerText` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`hazardReportAnswerId`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `HazardReportAnswer`
--

LOCK TABLES `HazardReportAnswer` WRITE;
/*!40000 ALTER TABLE `HazardReportAnswer` DISABLE KEYS */;
INSERT INTO `HazardReportAnswer` VALUES (1,'Yes',0),(2,'No',0),(3,'NA',0);
/*!40000 ALTER TABLE `HazardReportAnswer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `HazardReportClose`
--

DROP TABLE IF EXISTS `HazardReportClose`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `HazardReportClose` (
  `hazardReportCloseId` int(11) NOT NULL,
  `hazardReportId` int(11) NOT NULL,
  `documentName` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `documentKey` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`hazardReportCloseId`),
  KEY `hazardReportId` (`hazardReportId`),
  CONSTRAINT `HazardReportClose_ibfk_1` FOREIGN KEY (`hazardReportId`) REFERENCES `HazardReport` (`hazardReportId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `HazardReportClose`
--

LOCK TABLES `HazardReportClose` WRITE;
/*!40000 ALTER TABLE `HazardReportClose` DISABLE KEYS */;
/*!40000 ALTER TABLE `HazardReportClose` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `HazardReportQuestion`
--

DROP TABLE IF EXISTS `HazardReportQuestion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `HazardReportQuestion` (
  `hazardReportQuestionId` int(11) NOT NULL AUTO_INCREMENT,
  `questionText` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sectionId` int(11) NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`hazardReportQuestionId`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `HazardReportQuestion`
--

LOCK TABLES `HazardReportQuestion` WRITE;
/*!40000 ALTER TABLE `HazardReportQuestion` DISABLE KEYS */;
INSERT INTO `HazardReportQuestion` VALUES (1,'Are all EXIT signs illuminated?',1,0),(2,'Are all the doors self-closing and kept closed at all times?',1,0),(3,'Are all escape routes free from obstructions?',1,0),(4,'Are glass panels in doors obvious and intact?',1,0),(5,'Are escape routes suitable for the people who have to used them (i.e. disabled people)?',1,0),(6,'Is the fire alarm system in operations?',2,0),(7,'Are the manual fire alarm call points unobstructed and clearly visible?',2,0),(8,'Are there portable fire extinguishers (PFE)/hose reels available?',3,0),(9,'Are all extinguisher/hose reels regularly maintained with unexpired test date?',3,0),(10,'Are all extinguisher /hose reels visible and easily accessible?',3,0),(11,'Are extinguisher /hose reels wall mounted?',3,0),(12,'Are the sprinkler head covers intact?',3,0),(13,'Are there 500mm void spaces directly below any sprinkler heads?',3,0),(14,'Fire load in any rooms kept to the minimum by housekeeping efforts?',3,0),(15,'Alcohol based hand-rub kept at minimum quantities and prevented from pilfering? If potential drip onto floor, is there a drip-tray?',3,0),(16,'Are all extension leads of the correct length and fully unwound when in use?',4,0),(17,'Is the area in front of or next to or directly below the electrical panel(s) free from combustible materials?',4,0);
/*!40000 ALTER TABLE `HazardReportQuestion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `HazardReportQuestionData`
--

DROP TABLE IF EXISTS `HazardReportQuestionData`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `HazardReportQuestionData` (
  `hazardQuestionDataId` int(11) NOT NULL AUTO_INCREMENT,
  `questionId` int(11) NOT NULL,
  `answerId` int(11) NOT NULL,
  `observationText` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hazardSectionId` int(11) NOT NULL,
  PRIMARY KEY (`hazardQuestionDataId`),
  KEY `questionId` (`questionId`),
  KEY `answerId` (`answerId`),
  KEY `hazardSectionId` (`hazardSectionId`),
  CONSTRAINT `HazardReportQuestionData_ibfk_1` FOREIGN KEY (`questionId`) REFERENCES `HazardReportQuestion` (`hazardReportQuestionId`),
  CONSTRAINT `HazardReportQuestionData_ibfk_2` FOREIGN KEY (`answerId`) REFERENCES `HazardReportAnswer` (`hazardReportAnswerId`),
  CONSTRAINT `HazardReportQuestionData_ibfk_3` FOREIGN KEY (`hazardSectionId`) REFERENCES `HazardReportSectionData` (`hazardSectionDataId`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `HazardReportQuestionData`
--

LOCK TABLES `HazardReportQuestionData` WRITE;
/*!40000 ALTER TABLE `HazardReportQuestionData` DISABLE KEYS */;
INSERT INTO `HazardReportQuestionData` VALUES (1,1,1,NULL,32),(2,2,2,NULL,32),(3,3,1,NULL,32),(4,4,1,NULL,32),(5,5,3,NULL,32),(6,6,3,NULL,33),(7,7,1,NULL,33),(8,8,2,NULL,34),(9,9,2,NULL,34),(10,10,1,NULL,34),(11,11,3,NULL,34),(12,12,3,NULL,34),(13,13,3,NULL,34),(14,14,3,NULL,34),(15,15,3,NULL,34),(16,16,1,NULL,35),(17,17,2,'Test',35);
/*!40000 ALTER TABLE `HazardReportQuestionData` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `HazardReportSection`
--

DROP TABLE IF EXISTS `HazardReportSection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `HazardReportSection` (
  `sectionId` int(11) NOT NULL AUTO_INCREMENT,
  `sectionName` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`sectionId`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `HazardReportSection`
--

LOCK TABLES `HazardReportSection` WRITE;
/*!40000 ALTER TABLE `HazardReportSection` DISABLE KEYS */;
INSERT INTO `HazardReportSection` VALUES (1,'Fire Escape Routes',0),(2,'Fire Alarm Systems',0),(3,'Firefighting Equipment and prevention',0),(4,'Electrical Equipment',0);
/*!40000 ALTER TABLE `HazardReportSection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `HazardReportSectionData`
--

DROP TABLE IF EXISTS `HazardReportSectionData`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `HazardReportSectionData` (
  `hazardSectionDataId` int(11) NOT NULL AUTO_INCREMENT,
  `sectionId` int(11) NOT NULL,
  `hazardReportId` int(11) NOT NULL,
  PRIMARY KEY (`hazardSectionDataId`),
  KEY `sectionId` (`sectionId`),
  KEY `hazardReportId` (`hazardReportId`),
  CONSTRAINT `HazardReportSectionData_ibfk_1` FOREIGN KEY (`sectionId`) REFERENCES `HazardReportSection` (`sectionId`),
  CONSTRAINT `HazardReportSectionData_ibfk_2` FOREIGN KEY (`hazardReportId`) REFERENCES `HazardReport` (`hazardReportId`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `HazardReportSectionData`
--

LOCK TABLES `HazardReportSectionData` WRITE;
/*!40000 ALTER TABLE `HazardReportSectionData` DISABLE KEYS */;
INSERT INTO `HazardReportSectionData` VALUES (1,1,1),(2,1,2),(3,2,2),(4,3,2),(5,4,2),(6,1,3),(7,2,3),(8,3,3),(9,4,3),(10,1,4),(11,2,4),(12,3,4),(13,4,4),(14,1,5),(15,2,5),(16,3,5),(17,4,5),(18,1,6),(19,2,6),(20,3,6),(21,4,6),(22,1,7),(23,2,7),(24,3,7),(25,4,7),(26,1,8),(27,2,8),(28,3,8),(29,4,8),(30,1,9),(31,1,10),(32,1,11),(33,2,11),(34,3,11),(35,4,11);
/*!40000 ALTER TABLE `HazardReportSectionData` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `HazardReportSectionImage`
--

DROP TABLE IF EXISTS `HazardReportSectionImage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `HazardReportSectionImage` (
  `hazardSectionImageId` int(11) NOT NULL AUTO_INCREMENT,
  `hazardSectionDataId` int(11) NOT NULL,
  `documentName` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `documentKey` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`hazardSectionImageId`),
  KEY `hazardSectionDataId` (`hazardSectionDataId`),
  CONSTRAINT `HazardReportSectionImage_ibfk_1` FOREIGN KEY (`hazardSectionDataId`) REFERENCES `HazardReportSectionData` (`hazardSectionDataId`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `HazardReportSectionImage`
--

LOCK TABLES `HazardReportSectionImage` WRITE;
/*!40000 ALTER TABLE `HazardReportSectionImage` DISABLE KEYS */;
INSERT INTO `HazardReportSectionImage` VALUES (1,20,'NewHazardReport_2_1554965835385.jpeg','building_1/HazardReport/NewHazardReport_2_1554965835385.jpeg'),(2,24,'NewHazardReport_2_1554969667343.jpeg','building_1/HazardReport/NewHazardReport_2_1554969667343.jpeg'),(3,35,'IMG_20190220_205148_020.jpg','building_1/HazardReport/NewHazardReport_1_1555041708496.jpeg');
/*!40000 ALTER TABLE `HazardReportSectionImage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Message`
--

DROP TABLE IF EXISTS `Message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Message` (
  `messageId` int(11) NOT NULL AUTO_INCREMENT,
  `messageTypeId` int(11) NOT NULL,
  `dateTime` datetime(3) NOT NULL,
  `messageTitle` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `messageDetails` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `buildingId` int(11) NOT NULL,
  PRIMARY KEY (`messageId`),
  KEY `messageTypeId` (`messageTypeId`),
  KEY `buildingId` (`buildingId`),
  CONSTRAINT `Message_ibfk_1` FOREIGN KEY (`messageTypeId`) REFERENCES `MessageType` (`messageTypeId`),
  CONSTRAINT `Message_ibfk_2` FOREIGN KEY (`buildingId`) REFERENCES `Building` (`buildingId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Message`
--

LOCK TABLES `Message` WRITE;
/*!40000 ALTER TABLE `Message` DISABLE KEYS */;
/*!40000 ALTER TABLE `Message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MessageType`
--

DROP TABLE IF EXISTS `MessageType`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MessageType` (
  `messageTypeId` int(11) NOT NULL AUTO_INCREMENT,
  `messageType` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`messageTypeId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MessageType`
--

LOCK TABLES `MessageType` WRITE;
/*!40000 ALTER TABLE `MessageType` DISABLE KEYS */;
/*!40000 ALTER TABLE `MessageType` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Notification`
--

DROP TABLE IF EXISTS `Notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Notification` (
  `notificationId` int(11) NOT NULL AUTO_INCREMENT,
  `messageId` int(11) DEFAULT NULL,
  `reciever` int(11) DEFAULT NULL,
  `status` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`notificationId`),
  KEY `messageId` (`messageId`),
  KEY `reciever` (`reciever`),
  CONSTRAINT `Notification_ibfk_1` FOREIGN KEY (`messageId`) REFERENCES `Message` (`messageId`),
  CONSTRAINT `Notification_ibfk_2` FOREIGN KEY (`reciever`) REFERENCES `User` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Notification`
--

LOCK TABLES `Notification` WRITE;
/*!40000 ALTER TABLE `Notification` DISABLE KEYS */;
/*!40000 ALTER TABLE `Notification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Role`
--

DROP TABLE IF EXISTS `Role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Role` (
  `roleId` int(11) NOT NULL AUTO_INCREMENT,
  `roleName` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `editHazardReportGroup` tinyint(4) NOT NULL DEFAULT '0',
  `hazardReportGroup` tinyint(4) NOT NULL DEFAULT '0',
  `authorityToEscalateGroup` tinyint(4) NOT NULL DEFAULT '0',
  `escalationGroup` tinyint(4) NOT NULL DEFAULT '0',
  `fireDrillGroup` tinyint(4) NOT NULL DEFAULT '0',
  `documentManagementGroup` tinyint(4) NOT NULL DEFAULT '0',
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`roleId`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Role`
--

LOCK TABLES `Role` WRITE;
/*!40000 ALTER TABLE `Role` DISABLE KEYS */;
INSERT INTO `Role` VALUES (1,'Leader',1,1,1,1,1,1,0),(2,'Safety & Recovery Services Section I/C',1,1,1,1,1,0,0),(3,'M&E System I/C',0,0,0,1,0,0,0),(4,'Building Section I/C',0,0,0,1,0,0,0),(5,'Cleaning Section I/C',0,0,0,0,0,0,0),(6,'Security Section I/C',0,0,0,1,0,0,0),(7,'Tenant/ Staff Liaison Section I/C',0,0,0,1,0,0,0),(8,'Office Support Section I/C',0,0,0,1,0,0,0),(9,'Other Support Staff',0,0,0,1,0,0,0),(10,'FireWarden',1,1,1,1,0,1,0),(11,'Fire Safety Manager',1,1,1,1,1,1,0);
/*!40000 ALTER TABLE `Role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Tenant`
--

DROP TABLE IF EXISTS `Tenant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Tenant` (
  `tenantId` int(11) NOT NULL AUTO_INCREMENT,
  `tenantName` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `buildingId` int(11) DEFAULT NULL,
  `editedBy` int(11) DEFAULT NULL,
  `dateTime` datetime(3) DEFAULT NULL,
  `deleted` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`tenantId`),
  KEY `buildingId` (`buildingId`),
  KEY `editedBy` (`editedBy`),
  CONSTRAINT `Tenant_ibfk_1` FOREIGN KEY (`buildingId`) REFERENCES `Building` (`buildingId`),
  CONSTRAINT `Tenant_ibfk_2` FOREIGN KEY (`editedBy`) REFERENCES `User` (`userId`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Tenant`
--

LOCK TABLES `Tenant` WRITE;
/*!40000 ALTER TABLE `Tenant` DISABLE KEYS */;
INSERT INTO `Tenant` VALUES (1,'Low Tide Industries',1,2,'2019-03-27 14:34:15.000',0),(2,'Beedle Entertainment',1,2,'2019-03-27 15:34:15.000',1),(3,'Twilight Corp',1,1,'2019-04-08 11:13:15.000',0),(4,'Spideradio',1,1,'2019-04-08 12:34:15.000',0),(5,'Aurarts',1,3,'2019-04-08 12:34:15.000',0),(6,'Moondustries',2,3,'2019-04-08 12:34:15.000',0),(7,'Starlightning',2,2,'2019-04-08 12:34:15.000',0),(8,'Heroaid',2,2,'2019-04-08 12:34:15.000',0),(9,'Ridgeshack',2,2,'2019-04-08 12:34:15.000',0),(10,'Freakbeat',2,2,'2019-04-08 12:34:15.000',0),(11,'Deluge Softwares',3,2,'2019-04-08 12:34:15.000',0),(12,'Willow Electronics',3,2,'2019-04-08 12:34:15.000',1),(13,'Griffin Solutions',3,3,'2019-04-08 12:34:15.000',0),(14,'Alphacom',3,3,'2019-04-08 12:34:15.000',0),(15,'Bluetronics',3,2,'2019-04-08 12:34:15.000',0),(16,'Delugation',4,3,'2019-04-08 12:34:15.000',0),(17,'Titaniumotors',4,1,'2019-04-08 12:34:15.000',0),(18,'Driftstar',4,1,'2019-04-08 12:34:15.000',0),(19,'Joycoms',4,3,'2019-04-08 12:34:15.000',0),(20,'Roottechs',4,1,'2019-04-08 12:34:15.000',0);
/*!40000 ALTER TABLE `Tenant` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TenantEmployee`
--

DROP TABLE IF EXISTS `TenantEmployee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TenantEmployee` (
  `tenantEmployeeId` int(11) NOT NULL AUTO_INCREMENT,
  `tenantEmployeeName` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tenantId` int(11) DEFAULT NULL,
  `title` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `editedBy` int(11) DEFAULT NULL,
  `dateTime` datetime(3) DEFAULT NULL,
  `deleted` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`tenantEmployeeId`),
  KEY `editedBy` (`editedBy`),
  KEY `tenantId` (`tenantId`),
  CONSTRAINT `TenantEmployee_ibfk_1` FOREIGN KEY (`tenantId`) REFERENCES `Tenant` (`tenantId`),
  CONSTRAINT `TenantEmployee_ibfk_2` FOREIGN KEY (`editedBy`) REFERENCES `User` (`userId`)
) ENGINE=InnoDB AUTO_INCREMENT=201 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TenantEmployee`
--

LOCK TABLES `TenantEmployee` WRITE;
/*!40000 ALTER TABLE `TenantEmployee` DISABLE KEYS */;
INSERT INTO `TenantEmployee` VALUES (1,'Nicky Schneider',1,'TenantHead',1,'2019-03-27 15:37:12.000',0),(2,'Jessie Stevens',1,'TenantAssistant',1,'2019-03-27 15:37:12.000',1),(3,'Rome Milner',1,'TenantAssistant3',1,'2019-03-27 15:37:12.000',0),(4,'Nicola Cordova',1,'TenantAssistant4',1,'2019-03-27 15:37:12.000',0),(5,'Kylan Doyle',1,'TenantEmployeeStaff',1,'2019-03-27 15:37:12.000',0),(6,'Zuzanna Larson',1,'TenantEmployeeStaff',1,'2019-03-27 15:37:12.000',0),(7,'Kyan Mccoy',1,'TenantEmployeeStaff',1,'2019-03-27 15:37:12.000',0),(8,'Anil Walker',1,'TenantHead',1,'2019-03-27 15:37:12.000',0),(9,'Zidan Mathis',1,'TenantEmployeeStaff',1,'2019-03-27 15:37:12.000',0),(10,'Lilly-Grace Garza',2,'TenantEmployeeStaff',1,'2019-03-27 15:37:12.000',0),(11,'Axl Shelton',2,'TenantEmployeeStaff',1,'2019-03-27 15:37:12.000',1),(12,'Alisha Chung',2,'TenantEmployeeStaff',1,'2019-03-27 15:37:12.000',0),(13,'Ariyan Meadows',2,'TenantEmployeeStaff',1,'2019-03-27 15:37:12.000',0),(14,'Aalia Rodgers',2,'TenantEmployeeStaff',1,'2019-03-27 15:37:12.000',0),(15,'Brian Small',2,'TenantHead',1,'2019-03-27 15:37:12.000',0),(16,'Emilee Swift',2,'TenantEmployeeStaff',1,'2019-03-27 15:37:12.000',0),(17,'Jarrad Brooks',2,'TenantEmployeeStaff',1,'2019-03-27 15:37:12.000',0),(18,'Rumaysa Heaton',2,'TenantEmployeeStaff',1,'2019-03-27 15:37:12.000',0),(19,'Andreea Conner',2,'TenantEmployeeStaff',1,'2019-03-27 15:37:12.000',0),(20,'Aniela Simmons',3,'TenantEmployeeStaff',1,'2019-03-27 15:37:12.000',0),(21,'Miriam Huynh',3,'TenantEmployeeStaff',1,'2019-03-27 15:37:12.000',1),(22,'Devin Swan',3,'TenantEmployeeStaff',1,'2019-03-27 15:37:12.000',0),(23,'Holli Robbins',3,'TenantEmployeeStaff',1,'2019-03-27 15:37:12.000',0),(24,'Lillia Hancock',3,'TenantAssistant',1,'2019-03-27 15:37:12.000',0),(25,'Montague Lyon',3,'TenantEmployeeStaff',1,'2019-03-27 15:37:12.000',0),(26,'Ashlee Bonner',3,'TenantEmployeeStaff',1,'2019-03-27 15:37:12.000',0),(27,'Haydon Buchanan',3,'TenantHead',1,'2019-03-27 15:37:12.000',0),(28,'Stacey Lott',3,'TenantEmployeeStaff',1,'2019-03-27 15:37:12.000',0),(29,'Jason Philip',3,'TenantEmployeeStaff',1,'2019-03-27 15:37:12.000',0),(30,'Amba Gonzalez',4,'TenantEmployeeStaff',1,'2019-03-27 15:37:12.000',0),(31,'Hilda Hatfield',4,'TenantAssistant',1,'2019-03-27 15:37:12.000',1),(32,'Vikki Baird',4,'TenantEmployeeStaff',1,'2019-03-27 15:37:12.000',0),(33,'Wesley Patton',4,'TenantEmployeeStaff',1,'2019-03-27 15:37:12.000',0),(34,'Connagh Callahan',4,'TenantEmployeeStaff',1,'2019-03-27 15:37:12.000',0),(35,'Hussain Hassan',4,'TenantHead',1,'2019-03-27 15:37:12.000',0),(36,'Jeanne Valenzuela',4,'TenantEmployeeStaff',1,'2019-03-27 15:37:12.000',0),(37,'Keziah Christie',4,'TenantEmployeeStaff',1,'2019-03-27 15:37:12.000',0),(38,'Jemimah Waters',4,'TenantEmployeeStaff',1,'2019-03-27 15:37:12.000',0),(39,'Kush Tierney',4,'TenantEmployeeStaff',1,'2019-03-27 15:37:12.000',0),(40,'Veronika Calderon',5,'TenantEmployeeStaff',1,'2019-03-27 15:37:12.000',0),(41,'Kean Goff',5,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(42,'Johan Quinn',5,'TenantHead',2,'2019-03-27 15:37:12.000',1),(43,'Billy-Joe Harwood',5,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(44,'Stanislaw Brock',5,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(45,'Jared Joyner',5,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(46,'Zachariah Whitley',5,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(47,'Affan Mair',5,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(48,'Shahid Padilla',5,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(49,'Dawud Bowes',5,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(50,'Haroon Conway',6,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(51,'Adeeb Stanton',6,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',1),(52,'Zaine Clay',6,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(53,'Duncan Boone',6,'TenantHead',2,'2019-03-27 15:37:12.000',0),(54,'Evangeline Cameron',6,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(55,'Helen Legge',6,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(56,'Caolan Lloyd',6,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(57,'Jaye Doherty',6,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(58,'Arnie Emery',6,'TenantAssistant',2,'2019-03-27 15:37:12.000',0),(59,'Jaidan Villalobos',6,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(60,'Zephaniah Markham',7,'TenantHead',2,'2019-03-27 15:37:12.000',0),(61,'Eliza Hoover',7,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',1),(62,'Dwayne Hamer',7,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(63,'Jacque Lawrence',7,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(64,'Rochelle George',7,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(65,'Hanan Lozano',7,'TenantAssistant',2,'2019-03-27 15:37:12.000',0),(66,'Ellise Benitez',7,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(67,'Shanna Singh',7,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(68,'Bonita Mendoza',7,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(69,'Lexi-Mae Busby',7,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(70,'Fathima Felix',8,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(71,'Leandro Gillespie',8,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',1),(72,'Rivka Bauer',8,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(73,'Ammara Thomas',8,'TenantHead',2,'2019-03-27 15:37:12.000',0),(74,'Rosalind Robins',8,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(75,'Marley Amin',8,'TenantAssistant',2,'2019-03-27 15:37:12.000',0),(76,'Emmett Mcgregor',8,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(77,'Lola-Rose Redman',9,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',1),(78,'Isabelle Guzman',9,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(79,'Nyla Hale',9,'TenantHead',2,'2019-03-27 15:37:12.000',0),(80,'Jannah Kane',9,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(81,'Ava-Mai Mcdowell',9,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(82,'Savannah Price',9,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(83,'Pablo Holman',9,'TenantAssistant',2,'2019-03-27 15:37:12.000',0),(84,'Ashlyn Whitworth',9,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(85,'Faith Salt',9,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(86,'Lee Charlton',10,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(87,'Kia Navarro',10,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',1),(88,'Olli Frank',10,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(89,'Finnlay Dougherty',10,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(90,'Shanon Smith',10,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(91,'Giorgia Lawson',10,'TenantHead',2,'2019-03-27 15:37:12.000',0),(92,'Enzo Bean',10,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(93,'Inez Sloan',10,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(94,'Neil Chang',10,'TenantAssistant',2,'2019-03-27 15:37:12.000',0),(95,'Oscar Burn',10,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(96,'Reef Ramsey',11,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(97,'Amaya Bernal',11,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',1),(98,'Keanu Floyd',11,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(99,'Salman Brooks',11,'TenantEmployeeStaff',2,'2019-03-27 15:37:12.000',0),(100,'Bertie Frey',11,'TenantHead',2,'2019-03-27 15:37:12.000',0),(101,'Tre Gamble',11,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(102,'Raiden Wallace',11,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(103,'Priscilla Tillman',11,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(104,'Bibi Preston',11,'TenantAssistant',3,'2019-03-27 15:37:12.000',0),(105,'Wilbur Guzman',11,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(106,'Melanie Peters',12,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(107,'Chelsey Hutchinson',12,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',1),(108,'Adam Cairns',12,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(109,'Akbar Craft',12,'TenantAssistant',3,'2019-03-27 15:37:12.000',0),(110,'Lucy Bush',12,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(111,'Arabella Dodd',12,'TenantHead',3,'2019-03-27 15:37:12.000',0),(112,'Leona Horn',12,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(113,'Alfie Pennington',12,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(114,'Imaad Fowler',12,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(115,'Jo Aguirre',12,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(116,'Gabriela Brett',13,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(117,'Susan Herberta',13,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',1),(118,'Shazia Chan',13,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(119,'May Garner',13,'TenantAssistant',3,'2019-03-27 15:37:12.000',0),(120,'Alanah Gates',13,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(121,'Suhail Magana',13,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(122,'Estelle Howell',13,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(123,'Fay Rivera',13,'TenantHead',3,'2019-03-27 15:37:12.000',0),(124,'Daniela Mcneil',13,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(125,'Kalum Kent',13,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(126,'Luc Justice',14,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(127,'Beck Mercer',14,'TenantAssistant',3,'2019-03-27 15:37:12.000',1),(128,'Susanna Adkins',14,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(129,'Borys Ayala',14,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(130,'Mylee Sutherland',14,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(131,'Samiha Chen',14,'TenantHead',3,'2019-03-27 15:37:12.000',0),(132,'Kenan Calvert',14,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(133,'Blanka Hart',14,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(134,'Ann-Marie Stuart',14,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(135,'Rhiann Zhang',14,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(136,'Marianne Naylor',15,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(137,'Leoni Curran',15,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',1),(138,'Eliott Wilkinson',15,'TenantAssistant',3,'2019-03-27 15:37:12.000',0),(139,'Fred Wooten',15,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(140,'Abi Andrews',15,'TenantHead',3,'2019-03-27 15:37:12.000',0),(141,'Lowri Davey',15,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(142,'Rocco Woolley',15,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(143,'Sebastien Connelly',15,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(144,'Richie Ho',15,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(145,'Woodrow Baxter',15,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(146,'Katlyn Timms',16,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(147,'Sophie Hughes',16,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',1),(148,'Lubna Mckenzie',16,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(149,'Ava-May Bridges',16,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(150,'Vernon Fountain',16,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(151,'Samera Le',16,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(152,'Bobbi Powers',16,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(153,'Brayden Arnold',16,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(154,'Nancie Melia',16,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(155,'Ryan Hulme',16,'TenantHead',3,'2019-03-27 15:37:12.000',0),(156,'Mahi Fletcher',17,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(157,'Stuart Marsh',17,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',1),(158,'Marlie Simon',17,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(159,'Yvonne Guerrero',17,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(160,'Tehya Anthony',17,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(161,'Mikail Mohammed',17,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(162,'Nuha Melendez',17,'TenantHead',3,'2019-03-27 15:37:12.000',0),(163,'Yaseen Espinosa',17,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(164,'Shelbie Begum',17,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(165,'Silas Mosley',17,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(166,'Lyla John',18,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(167,'Jacob Wainwright',18,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',1),(168,'Vincenzo Nixon',18,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(169,'Blaine Wise',18,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(170,'Maisy Hoffman',18,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(171,'Aya Carson',18,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(172,'Jemima O\'Neill',18,'TenantHead',3,'2019-03-27 15:37:12.000',0),(173,'Hassan Prince',18,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(174,'Omer Alvarez',18,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(175,'Caitlan Hinton',18,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(176,'Natalie Hampton',19,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(177,'Arnold Osborn',19,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',1),(178,'Adela Barton',19,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(179,'Makenzie Ellis',19,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(180,'Selin Macfarlane',19,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(181,'Michael Ventura',19,'TenantHead',3,'2019-03-27 15:37:12.000',0),(182,'Neil Lim',19,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(183,'Om Clements',19,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(184,'Ayra Ellwood',19,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(185,'Niam Pearson',19,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(186,'Gertrude Dillon',20,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(187,'Hettie Chung',20,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',1),(188,'Lynn Greer',20,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(189,'Carter Pearce',20,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(190,'Shoaib Brookes',20,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(191,'Mathew Wilder',20,'TenantHead',3,'2019-03-27 15:37:12.000',0),(192,'Ingrid Fenton',20,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(193,'Kelvin Villanueva',20,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(194,'Jokubas Nielsen',20,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(195,'Cadence Walters',20,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(196,'Mahira Ellison',1,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(197,'Oluwatobiloba Hines',8,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(198,'Tiarna Rose',8,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(199,'Mitchell John',8,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0),(200,'Caroline Pitts',9,'TenantEmployeeStaff',3,'2019-03-27 15:37:12.000',0);
/*!40000 ALTER TABLE `TenantEmployee` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `User`
--

DROP TABLE IF EXISTS `User`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `User` (
  `userId` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `displayName` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pushNotificationToken` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `profileImage` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tenantEmployeeId` int(11) DEFAULT NULL,
  `phoneNumber` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notification` tinyint(1) DEFAULT '1',
  `deleted` tinyint(1) DEFAULT '0',
  `isAdmin` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`userId`),
  UNIQUE KEY `username_UNIQUE` (`username`),
  KEY `tenantEmployeeId` (`tenantEmployeeId`),
  CONSTRAINT `User_ibfk_1` FOREIGN KEY (`tenantEmployeeId`) REFERENCES `TenantEmployee` (`tenantEmployeeId`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `User`
--

LOCK TABLES `User` WRITE;
/*!40000 ALTER TABLE `User` DISABLE KEYS */;
INSERT INTO `User` VALUES (1,'user001','Cheng Su Chen','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','title1','user01@gmail.com','12j3lkjkarjlafaraes','test/userprofileimage/0001_1554447768518.jpeg',1,'98554069',1,0,0),(2,'user002','Heng Tze Kiang','$2a$10$JTKqCBDs.fRCWSY/RU2kguoF1xxn0huTkhfr1QUes9rA6sa4kwRqa','title2','user02@gmail.com','feKBTVMVYV8:APA91bHb28EAm0GpGTGRgzU69RDdEmo6wTkfHuYvjqzY3x0pk1hWknhf7Wad5Vh0Da6BdkUY_heE8dO_zJ3cAoCOFKiLHhhg003imCZxADX2A_gRdTXD6o146qCPyGWRBt_YXD_tURio','test/userprofileimage/0001_1554453985262.jpeg',2,'97995746',1,0,0),(3,'user003','Christopher Loh','$2a$10$N3Mj1Q6kiKf84Z3nb2fdRubj4Eeg/Qw68JfYWe9c7PSN0GamPuDi6','title3','user03@gmail.com','feKBTVMVYV8:APA91bHb28EAm0GpGTGRgzU69RDdEmo6wTkfHuYvjqzY3x0pk1hWknhf7Wad5Vh0Da6BdkUY_heE8dO_zJ3cAoCOFKiLHhhg003imCZxADX2A_gRdTXD6o146qCPyGWRBt_YXD_tURio','test/userprofileimage/0001_1554374300010.jpeg',11,'82002261',1,0,0),(4,'user004','Sunny Tan','$2a$10$X9a1lKWgUpsC78SiGPa8beZU8sitIsEcUAA76lpHkLwm4ElMShn3.','title4','user04@gmail.com','feKBTVMVYV8:APA91bHb28EAm0GpGTGRgzU69RDdEmo6wTkfHuYvjqzY3x0pk1hWknhf7Wad5Vh0Da6BdkUY_heE8dO_zJ3cAoCOFKiLHhhg003imCZxADX2A_gRdTXD6o146qCPyGWRBt_YXD_tURio','default_image.jpeg',12,'97333632',1,0,0),(5,'user005','Maria Chyril','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','title5','',NULL,'default_image.jpeg',21,'82019041',1,0,0),(6,'user006','Asen Chow','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','title6','',NULL,'default_image.jpeg',31,'97913488',1,1,0),(7,'user007','Wilson Voon','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','title7','',NULL,'default_image.jpeg',32,'98508971',1,0,0),(8,'user008','Fong Siew Cheong','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','title8','',NULL,'default_image.jpeg',41,'96801398',1,1,0),(9,'user009','Lawrence Wu','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','title9','',NULL,'default_image.jpeg',42,'91111253',1,0,0),(10,'user010','Sam Tan','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','title10','',NULL,'default_image.jpeg',51,'93671215',1,1,0),(11,'user011','Hemalatha','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','title11','',NULL,'default_image.jpeg',52,'96566972',1,0,0),(12,'user012','Patrik Poh','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','title12','',NULL,'default_image.jpeg',61,'97422568',1,1,0),(13,'user013','David Tay','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','title13','',NULL,'default_image.jpeg',62,'90051757',1,0,0),(14,'user014','Jenny Tan','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','title14','',NULL,'default_image.jpeg',71,'97610551',1,1,0),(15,'user015','Satwant Singh','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','title15','',NULL,'default_image.jpeg',72,'64485606',1,0,0),(16,'user016','Christopher Loh','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','title16','','eflZvBRGn2s:APA91bEzD4vWc1iLc-QqT76C48YfH-095oHIDbbkroEYP-cScyOwlDOHnhpMrC2b8tEU6vrcdNwebwvlP2kM3LTlWihFbx8TmGWYvz_46mGmOA_cMAP_vjqm0TKKpCQybxPGdDjg5VKo','default_image.jpeg',81,'82002261',1,1,0),(17,'user017','Simon Lim','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','title17','',NULL,'default_image.jpeg',82,'98776159',1,0,0),(18,'user018','Barry Chong','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','title18','',NULL,'default_image.jpeg',91,'90068268',1,1,0),(19,'user019','Png Chiew Hoon','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','title19','',NULL,'default_image.jpeg',92,'64489262',1,0,0),(20,'user020','Amy Foo','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','title20','',NULL,'default_image.jpeg',101,'93362609',1,1,0),(21,'user021','Dylan Wong','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','title21','',NULL,'default_image.jpeg',102,'91776058',1,0,0),(22,'user022','Christina Goh','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','title22','',NULL,'default_image.jpeg',111,'96835044',1,1,0),(23,'user023','Chelsia Chan','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','title23','',NULL,'default_image.jpeg',112,'97583921',1,0,0),(24,'user024','Catherine Ng','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','title24','',NULL,'default_image.jpeg',121,'91502754',1,1,0),(25,'user025','Alicia Tay','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','title25','',NULL,'default_image.jpeg',122,'91013182',1,0,0),(26,'user026','R Sakinah','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','title26','',NULL,'default_image.jpeg',131,'82004746',1,1,0),(27,'user027','Michelle lau','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','title27','','feKBTVMVYV8:APA91bHb28EAm0GpGTGRgzU69RDdEmo6wTkfHuYvjqzY3x0pk1hWknhf7Wad5Vh0Da6BdkUY_heE8dO_zJ3cAoCOFKiLHhhg003imCZxADX2A_gRdTXD6o146qCPyGWRBt_YXD_tURio','default_image.jpeg',132,'97614573',1,0,0),(28,'user028','Wong Wei Ting','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','title28','',NULL,'default_image.jpeg',141,'97382007',1,1,0),(29,'user029','Alvin Loke','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','title29','','feKBTVMVYV8:APA91bHb28EAm0GpGTGRgzU69RDdEmo6wTkfHuYvjqzY3x0pk1hWknhf7Wad5Vh0Da6BdkUY_heE8dO_zJ3cAoCOFKiLHhhg003imCZxADX2A_gRdTXD6o146qCPyGWRBt_YXD_tURio','default_image.jpeg',142,'90210956',1,0,0),(30,'user030','Jaslyn Lau','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','title30','',NULL,'default_image.jpeg',151,'97428177',1,1,0),(31,'tester001','Katlyn Timms','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','title31','',NULL,'default_image.jpeg',152,NULL,1,0,0),(32,'tester002','Sophie Hughes','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','title32','',NULL,'default_image.jpeg',161,NULL,1,1,0),(33,'tester003','Mahi Fletcher','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','title33','',NULL,'default_image.jpeg',162,NULL,1,0,0),(34,'tester004','Stuart Marsh','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','title34','',NULL,'default_image.jpeg',171,NULL,1,1,0),(35,'tester005','Lyla John','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','title35','',NULL,'default_image.jpeg',172,NULL,1,0,0),(36,'tester006','Jacob Wainwright','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','title36','',NULL,'default_image.jpeg',181,NULL,1,1,0),(37,'tester007','Natalie Hampton','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','title37','',NULL,'default_image.jpeg',182,NULL,1,0,0),(38,'tester008','Arnold Osborn','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','title38','',NULL,'default_image.jpeg',191,NULL,1,1,0),(39,'tester009','Gertrude Dillon','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','title39','','eflZvBRGn2s:APA91bEzD4vWc1iLc-QqT76C48YfH-095oHIDbbkroEYP-cScyOwlDOHnhpMrC2b8tEU6vrcdNwebwvlP2kM3LTlWihFbx8TmGWYvz_46mGmOA_cMAP_vjqm0TKKpCQybxPGdDjg5VKo','default_image.jpeg',192,NULL,1,0,0),(40,'tester010','Hettie Chung','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','title40','',NULL,'default_image.jpeg',NULL,NULL,1,1,0),(41,'tester011','Raisa Green','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','title41','',NULL,'default_image.jpeg',NULL,NULL,1,0,0),(42,'tester012','Cathy Molloy','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','title42','',NULL,'default_image.jpeg',NULL,NULL,1,0,0),(43,'tester013','Sameer Hodge','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','title43','',NULL,'default_image.jpeg',NULL,NULL,1,0,0),(44,'tester014','Maha Felix','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','title44','',NULL,'default_image.jpeg',NULL,NULL,1,0,0),(45,'tester015','Nishat Carter','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','title45','',NULL,'default_image.jpeg',NULL,NULL,1,0,0),(46,'tester016','Charly Olson','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','title46','','','default_image.jpeg',NULL,NULL,1,0,0),(47,'tester017','Chandni Wardle','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','title47','','cRu9tXFZVyM:APA91bF61bVTkJ5A6qhw1HwT5xTHkqt8LR7t7movDKwT0dr9T6I7O8tWijSnzWh_JaljsKks72mOXasSI_0R3N0XNdeFeuDMaAtof6vIu_jM27qCdHtVOohP-8RM7q4bRBuyrkXSzTNh','default_image.jpeg',NULL,NULL,1,0,0),(48,'tester018','Mali Middleton','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','title48','',NULL,'default_image.jpeg',NULL,NULL,1,0,0),(49,'tester019','Filip Whelan','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','title49','',NULL,'default_image.jpeg',NULL,NULL,1,0,0),(50,'tester020','Alessia Grainger','$2a$10$1LzBmMhSkCpnfUFteTTNlep4PTuG0S/G0XS7vmJiQS1xnDumM6GzC','title50','',NULL,'default_image.jpeg',NULL,NULL,1,0,0);
/*!40000 ALTER TABLE `User` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'FSA'
--

--
-- Dumping routines for database 'FSA'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-04-12 19:30:04
