<?php
include("init.php");

$sql = "ALTER TABLE `FSA`.`ResetPassword` CHANGE COLUMN `expiryDate` `expiryDate` TIMESTAMP(3) NULL DEFAULT NULL; ";
$sql.= "ALTER TABLE `FSA`.`FireDrillSchedule` ADD COLUMN `lastAttendanceUpdate` TIMESTAMP(3) NULL DEFAULT NULL AFTER `editedBy`;";

if ($conn->multi_query($sql) === TRUE) {
   echo " 2 table update successfully \n";
} else {
   echo "Error: " . $conn->errno . "<br>" . $conn->error;
}

?>
