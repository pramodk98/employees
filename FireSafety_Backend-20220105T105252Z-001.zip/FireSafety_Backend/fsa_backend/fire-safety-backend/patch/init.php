<?php
header('Content-Type: text/plain; charset=utf-8');
$servername = "127.0.0.1:8085";
$username = "root";
$password = "";
$dbname = "FSA";
date_default_timezone_set("Asia/Singapore");

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

?>
